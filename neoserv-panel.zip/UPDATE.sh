#!/bin/bash
# X NeoServ Panel - Update Script
# Use this to update an existing installation

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}"
echo "=============================================="
echo "     X NeoServ Panel - Update v3.0"
echo "=============================================="
echo -e "${NC}"

# Check if running as root
if [ "$EUID" -ne 0 ]; then
  echo -e "${RED}Please run as root (sudo bash UPDATE.sh)${NC}"
  exit 1
fi

# Check current directory
if [ ! -f "/opt/neoserv/package.json" ]; then
  echo -e "${RED}X NeoServ not found in /opt/neoserv${NC}"
  echo "Please run install.sh first for new installations."
  exit 1
fi

# Backup current .env
echo -e "${BLUE}[1/6] Backing up configuration...${NC}"
cp /opt/neoserv/.env /opt/neoserv/.env.backup 2>/dev/null || true
echo -e "${GREEN}Configuration backed up${NC}"

# Stop service
echo -e "${BLUE}[2/6] Stopping service...${NC}"
systemctl stop neoserv 2>/dev/null || true

# Copy new files (preserve .env)
echo -e "${BLUE}[3/6] Updating files...${NC}"
cd /opt/neoserv

# Extract update package if exists
if [ -f "neoserv-panel-v3.0.zip" ]; then
  unzip -o -qq neoserv-panel-v3.0.zip -x ".env"
  echo -e "${GREEN}Files updated from ZIP${NC}"
else
  echo -e "${YELLOW}No update ZIP found. Continuing with current files.${NC}"
fi

# Restore .env
cp /opt/neoserv/.env.backup /opt/neoserv/.env 2>/dev/null || true

# Install dependencies
echo -e "${BLUE}[4/6] Updating dependencies...${NC}"
npm install --silent 2>/dev/null

# Run database migrations
echo -e "${BLUE}[5/6] Updating database schema...${NC}"
npm run db:push 2>/dev/null

# Rebuild
echo -e "${BLUE}[6/6] Rebuilding application...${NC}"
npm run build 2>/dev/null

# Restart service
systemctl start neoserv

echo ""
echo -e "${GREEN}=============================================="
echo "     Update Complete!"
echo "==============================================${NC}"
echo ""

# Verify
sleep 2
if systemctl is-active --quiet neoserv; then
  echo -e "${GREEN}[✓] Service is running successfully!${NC}"
else
  echo -e "${RED}[!] Service may have failed to start.${NC}"
  echo "Check logs: journalctl -u neoserv -f"
fi
