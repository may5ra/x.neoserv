import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Globe } from "lucide-react";
import { ComposableMap, Geographies, Geography, ZoomableGroup } from "react-simple-maps";
import { memo, useMemo } from "react";

interface CountryData {
  country: string;
  countryCode: string;
  count: number;
  percent: number;
}

const countryNames: Record<string, string> = {
  DEU: "Germany", DE: "Germany",
  USA: "United States of America", US: "United States of America",
  FRA: "France", FR: "France",
  ROU: "Romania", RO: "Romania",
  NLD: "Netherlands", NL: "Netherlands",
  GBR: "United Kingdom", GB: "United Kingdom",
  ITA: "Italy", IT: "Italy",
  ESP: "Spain", ES: "Spain",
  POL: "Poland", PL: "Poland",
  TUR: "Turkey", TR: "Turkey",
  SRB: "Serbia", RS: "Serbia",
  HRV: "Croatia", HR: "Croatia",
  BIH: "Bosnia", BA: "Bosnia",
  MKD: "North Macedonia", MK: "North Macedonia",
  SVN: "Slovenia", SI: "Slovenia",
  AUT: "Austria", AT: "Austria",
  CHE: "Switzerland", CH: "Switzerland",
  BEL: "Belgium", BE: "Belgium",
  SWE: "Sweden", SE: "Sweden",
  NOR: "Norway", NO: "Norway",
  DNK: "Denmark", DK: "Denmark",
  FIN: "Finland", FI: "Finland",
  PRT: "Portugal", PT: "Portugal",
  GRC: "Greece", GR: "Greece",
  CZE: "Czech Republic", CZ: "Czech Republic",
  SVK: "Slovakia", SK: "Slovakia",
  HUN: "Hungary", HU: "Hungary",
  BGR: "Bulgaria", BG: "Bulgaria",
  UKR: "Ukraine", UA: "Ukraine",
  RUS: "Russia", RU: "Russia",
  CAN: "Canada", CA: "Canada",
  AUS: "Australia", AU: "Australia",
  BRA: "Brazil", BR: "Brazil",
  MEX: "Mexico", MX: "Mexico",
  ARG: "Argentina", AR: "Argentina",
  IND: "India", IN: "India",
  CHN: "China", CN: "China",
  JPN: "Japan", JP: "Japan",
  KOR: "South Korea", KR: "South Korea",
  ARE: "UAE", AE: "UAE",
  SAU: "Saudi Arabia", SA: "Saudi Arabia",
  EGY: "Egypt", EG: "Egypt",
  ZAF: "South Africa", ZA: "South Africa",
};

const iso2ToIso3: Record<string, string> = {
  DE: "DEU", US: "USA", FR: "FRA", RO: "ROU", NL: "NLD", GB: "GBR",
  IT: "ITA", ES: "ESP", PL: "POL", TR: "TUR", RS: "SRB", HR: "HRV",
  BA: "BIH", MK: "MKD", SI: "SVN", AT: "AUT", CH: "CHE", BE: "BEL",
  SE: "SWE", NO: "NOR", DK: "DNK", FI: "FIN", PT: "PRT", GR: "GRC",
  CZ: "CZE", SK: "SVK", HU: "HUN", BG: "BGR", UA: "UKR", RU: "RUS",
  CA: "CAN", AU: "AUS", BR: "BRA", MX: "MEX", AR: "ARG", IN: "IND",
  CN: "CHN", JP: "JPN", KR: "KOR", AE: "ARE", SA: "SAU", EG: "EGY",
  ZA: "ZAF",
};

const countryColors = [
  "#f97316",
  "#38bdf8",
  "#a78bfa",
  "#22c55e",
  "#f472b6",
  "#fbbf24",
  "#06b6d4",
  "#ef4444",
];

function getCountryColor(index: number): string {
  return countryColors[index % countryColors.length];
}

const geoUrl = "https://cdn.jsdelivr.net/npm/world-atlas@2/countries-110m.json";

export function ConnectionsByLocation() {
  const { data, isLoading } = useQuery<CountryData[]>({
    queryKey: ["/api/dashboard/connections-by-country"],
    refetchInterval: 10000,
  });

  const topCountries = data?.slice(0, 5) || [];
  const totalConnections = data?.reduce((sum, c) => sum + c.count, 0) || 0;

  const activeCountryMap = useMemo(() => {
    const map = new Map<string, { color: string; data: CountryData }>();
    topCountries.forEach((country, index) => {
      const iso3 = iso2ToIso3[country.countryCode] || country.countryCode;
      map.set(iso3, { color: getCountryColor(index), data: country });
      map.set(country.countryCode, { color: getCountryColor(index), data: country });
    });
    return map;
  }, [topCountries]);

  return (
    <Card data-testid="card-connections-by-location">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg font-semibold">Connections by Location</CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        {isLoading ? (
          <Skeleton className="h-[300px] w-full" />
        ) : data && data.length > 0 ? (
          <div className="flex flex-col lg:flex-row bg-slate-100 dark:bg-card">
            <div className="flex-1 relative">
              <div className="absolute top-4 left-4 z-10 flex flex-col gap-1.5">
                {topCountries.slice(0, 3).map((country, index) => (
                  <div 
                    key={country.countryCode}
                    className="w-2.5 h-2.5 rounded-full"
                    style={{ backgroundColor: getCountryColor(index) }}
                  />
                ))}
              </div>
              <WorldMap activeCountryMap={activeCountryMap} />
            </div>
            <div className="w-full lg:w-80 p-6 space-y-5 bg-slate-100 dark:bg-card">
              {topCountries.map((country, index) => (
                <div key={country.countryCode} className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-baseline gap-3">
                      <span className="text-xl font-bold text-foreground">
                        {country.count.toLocaleString()}
                      </span>
                      <span className="text-sm text-muted-foreground">
                        {countryNames[country.countryCode] || country.country || country.countryCode}
                      </span>
                    </div>
                    <span className="text-sm text-muted-foreground">{country.percent}%</span>
                  </div>
                  <div className="h-1.5 rounded-full overflow-hidden bg-slate-300 dark:bg-slate-700">
                    <div 
                      className="h-full rounded-full transition-all duration-500"
                      style={{ 
                        width: `${country.percent}%`,
                        backgroundColor: getCountryColor(index)
                      }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center h-[300px] text-muted-foreground">
            <Globe className="h-12 w-12 mb-4 opacity-50" />
            <p>No connection data available</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

interface WorldMapProps {
  activeCountryMap: Map<string, { color: string; data: CountryData }>;
}

const WorldMap = memo(function WorldMap({ activeCountryMap }: WorldMapProps) {
  return (
    <div className="h-[280px] bg-slate-100 dark:bg-card">
      <ComposableMap
        projection="geoMercator"
        projectionConfig={{
          scale: 120,
          center: [10, 35],
        }}
        style={{ width: "100%", height: "100%" }}
      >
        <ZoomableGroup center={[10, 35]} zoom={1}>
          <Geographies geography={geoUrl}>
            {({ geographies }: { geographies: any[] }) =>
              geographies.map((geo: any) => {
                const countryCode = geo.properties?.["ISO_A3"] || geo.id;
                const countryData = activeCountryMap.get(countryCode);
                const isActive = !!countryData;
                
                return (
                  <Geography
                    key={geo.rsmKey}
                    geography={geo}
                    className={isActive ? "" : "fill-slate-300 dark:fill-slate-600"}
                    fill={isActive ? countryData.color : undefined}
                    stroke="currentColor"
                    strokeWidth={0.4}
                    style={{
                      default: {
                        outline: "none",
                        transition: "fill 0.3s",
                        stroke: "#94a3b8",
                      },
                      hover: {
                        fill: isActive ? countryData.color : undefined,
                        outline: "none",
                        cursor: "pointer",
                      },
                      pressed: {
                        outline: "none",
                      },
                    }}
                  />
                );
              })
            }
          </Geographies>
        </ZoomableGroup>
      </ComposableMap>
    </div>
  );
});
