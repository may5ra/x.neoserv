import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts";

interface TrafficDataPoint {
  time: string;
  input: number;
  output: number;
}

export function NetworkTrafficChart() {
  const { data, isLoading } = useQuery<TrafficDataPoint[]>({
    queryKey: ["/api/dashboard/network-traffic"],
    refetchInterval: 30000,
  });

  const formatBytes = (value: number) => {
    if (value >= 1024 * 1024) {
      return `${(value / (1024 * 1024)).toFixed(1)} GB`;
    }
    if (value >= 1024) {
      return `${(value / 1024).toFixed(1)} MB`;
    }
    return `${value} KB`;
  };

  return (
    <Card data-testid="card-network-traffic">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg font-semibold">Network Traffic</CardTitle>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <Skeleton className="h-[280px] w-full" />
        ) : data && data.length > 0 ? (
          <ResponsiveContainer width="100%" height={280}>
            <AreaChart data={data} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
              <defs>
                <linearGradient id="colorInput" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#f97316" stopOpacity={0.4} />
                  <stop offset="95%" stopColor="#f97316" stopOpacity={0.05} />
                </linearGradient>
                <linearGradient id="colorOutput" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#38bdf8" stopOpacity={0.4} />
                  <stop offset="95%" stopColor="#38bdf8" stopOpacity={0.05} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
              <XAxis 
                dataKey="time" 
                tick={{ fontSize: 11, fill: "#9ca3af" }}
                tickLine={false}
                axisLine={false}
              />
              <YAxis 
                tickFormatter={formatBytes}
                tick={{ fontSize: 11, fill: "#9ca3af" }}
                tickLine={false}
                axisLine={false}
                width={60}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: "rgba(17, 24, 39, 0.95)",
                  border: "1px solid rgba(255,255,255,0.1)",
                  borderRadius: "8px",
                  fontSize: "12px",
                  color: "#e5e7eb",
                }}
                labelStyle={{ color: "#e5e7eb" }}
                formatter={(value: number, name: string) => [
                  formatBytes(value),
                  name === "input" ? "Input" : "Output",
                ]}
              />
              <Legend 
                iconType="circle"
                wrapperStyle={{ fontSize: "12px", color: "#9ca3af" }}
                formatter={(value: string) => (
                  <span style={{ color: "#9ca3af" }}>
                    {value === "input" ? "Input" : "Output"}
                  </span>
                )}
              />
              <Area
                type="monotone"
                dataKey="output"
                stroke="#38bdf8"
                fill="url(#colorOutput)"
                strokeWidth={2}
                name="output"
              />
              <Area
                type="monotone"
                dataKey="input"
                stroke="#f97316"
                fill="url(#colorInput)"
                strokeWidth={2}
                name="input"
              />
            </AreaChart>
          </ResponsiveContainer>
        ) : (
          <div className="flex items-center justify-center h-[280px] text-muted-foreground">
            No traffic data available
          </div>
        )}
      </CardContent>
    </Card>
  );
}
