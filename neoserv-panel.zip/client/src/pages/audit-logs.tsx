import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  Shield, 
  Search, 
  RefreshCw, 
  User, 
  Play, 
  Settings, 
  Trash2,
  Plus,
  Edit,
  Power,
  Ban,
  Download,
  Key,
  Server,
  Tv,
  Package,
  Users,
  Activity
} from "lucide-react";
import { format } from "date-fns";

interface AuditLog {
  id: number;
  adminId: number;
  adminUsername: string;
  adminRole: string;
  action: string;
  targetType: string;
  targetId: number | null;
  targetName: string | null;
  details: string | null;
  ipAddress: string | null;
  userAgent: string | null;
  createdAt: number;
}

interface AuditStats {
  todayCount: number;
  weekCount: number;
  topActions: [string, number][];
  topAdmins: [string, number][];
}

const ACTION_ICONS: Record<string, any> = {
  login: Key,
  logout: Key,
  login_failed: Ban,
  user_create: Plus,
  user_update: Edit,
  user_delete: Trash2,
  user_ban: Ban,
  user_enable: Power,
  user_disable: Power,
  stream_create: Plus,
  stream_update: Edit,
  stream_delete: Trash2,
  stream_start: Play,
  stream_stop: Power,
  stream_restart: RefreshCw,
  category_create: Plus,
  category_update: Edit,
  category_delete: Trash2,
  bouquet_create: Plus,
  bouquet_update: Edit,
  bouquet_delete: Trash2,
  server_create: Plus,
  server_update: Edit,
  server_delete: Trash2,
  settings_update: Settings,
  connection_kill: Power,
  migration_import: Download,
  playlist_download: Download,
};

const ACTION_COLORS: Record<string, string> = {
  login: "bg-green-500/10 text-green-500",
  logout: "bg-gray-500/10 text-gray-500",
  login_failed: "bg-red-500/10 text-red-500",
  user_create: "bg-blue-500/10 text-blue-500",
  user_update: "bg-yellow-500/10 text-yellow-500",
  user_delete: "bg-red-500/10 text-red-500",
  user_ban: "bg-red-500/10 text-red-500",
  user_enable: "bg-green-500/10 text-green-500",
  user_disable: "bg-orange-500/10 text-orange-500",
  stream_create: "bg-blue-500/10 text-blue-500",
  stream_update: "bg-yellow-500/10 text-yellow-500",
  stream_delete: "bg-red-500/10 text-red-500",
  stream_start: "bg-green-500/10 text-green-500",
  stream_stop: "bg-orange-500/10 text-orange-500",
  stream_restart: "bg-purple-500/10 text-purple-500",
  settings_update: "bg-purple-500/10 text-purple-500",
  connection_kill: "bg-red-500/10 text-red-500",
  migration_import: "bg-blue-500/10 text-blue-500",
};

const TARGET_ICONS: Record<string, any> = {
  user: User,
  stream: Tv,
  category: Package,
  bouquet: Package,
  server: Server,
  series: Tv,
  epg: Activity,
  mag_device: Tv,
  reseller: Users,
  package: Package,
  settings: Settings,
  connection: Activity,
  system: Shield,
};

export default function AuditLogs() {
  const [search, setSearch] = useState("");
  const [actionFilter, setActionFilter] = useState<string>("all");
  const [targetTypeFilter, setTargetTypeFilter] = useState<string>("all");

  const buildQueryUrl = () => {
    const params = new URLSearchParams();
    if (search) params.append("search", search);
    if (actionFilter !== "all") params.append("action", actionFilter);
    if (targetTypeFilter !== "all") params.append("targetType", targetTypeFilter);
    params.append("limit", "200");
    const queryStr = params.toString();
    return queryStr ? `/api/audit-logs?${queryStr}` : "/api/audit-logs";
  };

  const { data: logs, isLoading, refetch } = useQuery<AuditLog[]>({
    queryKey: ["/api/audit-logs", search, actionFilter, targetTypeFilter],
    queryFn: async () => {
      const res = await fetch(buildQueryUrl(), { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch audit logs");
      return res.json();
    },
  });

  const { data: stats } = useQuery<AuditStats>({
    queryKey: ["/api/audit-logs/stats"],
  });

  const filteredLogs = logs?.filter(log => {
    if (search) {
      const searchLower = search.toLowerCase();
      if (!log.adminUsername.toLowerCase().includes(searchLower) &&
          !log.action.toLowerCase().includes(searchLower) &&
          !(log.targetName?.toLowerCase().includes(searchLower)) &&
          !(log.details?.toLowerCase().includes(searchLower))) {
        return false;
      }
    }
    if (actionFilter !== "all" && !log.action.startsWith(actionFilter)) {
      return false;
    }
    if (targetTypeFilter !== "all" && log.targetType !== targetTypeFilter) {
      return false;
    }
    return true;
  });

  const formatAction = (action: string) => {
    return action.split("_").map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(" ");
  };

  const ActionIcon = ({ action }: { action: string }) => {
    const Icon = ACTION_ICONS[action] || Activity;
    return <Icon className="h-4 w-4" />;
  };

  const TargetIcon = ({ targetType }: { targetType: string }) => {
    const Icon = TARGET_ICONS[targetType] || Activity;
    return <Icon className="h-4 w-4" />;
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <Shield className="h-6 w-6" />
            Audit Logs
          </h1>
          <p className="text-muted-foreground">Track all admin and reseller activities</p>
        </div>
        <Button onClick={() => refetch()} variant="outline" data-testid="button-refresh">
          <RefreshCw className="h-4 w-4 mr-2" />
          Refresh
        </Button>
      </div>

      {stats && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card>
            <CardHeader className="pb-2">
              <CardDescription>Today</CardDescription>
              <CardTitle className="text-2xl">{stats.todayCount}</CardTitle>
            </CardHeader>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardDescription>This Week</CardDescription>
              <CardTitle className="text-2xl">{stats.weekCount}</CardTitle>
            </CardHeader>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardDescription>Top Action</CardDescription>
              <CardTitle className="text-lg">
                {stats.topActions[0]?.[0] ? formatAction(stats.topActions[0][0]) : "N/A"}
              </CardTitle>
            </CardHeader>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardDescription>Most Active</CardDescription>
              <CardTitle className="text-lg">{stats.topAdmins[0]?.[0] || "N/A"}</CardTitle>
            </CardHeader>
          </Card>
        </div>
      )}

      <Card>
        <CardHeader>
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search logs..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-10"
                data-testid="input-search"
              />
            </div>
            <Select value={actionFilter} onValueChange={setActionFilter}>
              <SelectTrigger className="w-[180px]" data-testid="select-action">
                <SelectValue placeholder="Action type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Actions</SelectItem>
                <SelectItem value="login">Login/Logout</SelectItem>
                <SelectItem value="user">User Actions</SelectItem>
                <SelectItem value="stream">Stream Actions</SelectItem>
                <SelectItem value="category">Category Actions</SelectItem>
                <SelectItem value="bouquet">Bouquet Actions</SelectItem>
                <SelectItem value="server">Server Actions</SelectItem>
                <SelectItem value="settings">Settings</SelectItem>
              </SelectContent>
            </Select>
            <Select value={targetTypeFilter} onValueChange={setTargetTypeFilter}>
              <SelectTrigger className="w-[180px]" data-testid="select-target">
                <SelectValue placeholder="Target type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Targets</SelectItem>
                <SelectItem value="user">Users</SelectItem>
                <SelectItem value="stream">Streams</SelectItem>
                <SelectItem value="category">Categories</SelectItem>
                <SelectItem value="bouquet">Bouquets</SelectItem>
                <SelectItem value="server">Servers</SelectItem>
                <SelectItem value="series">Series</SelectItem>
                <SelectItem value="reseller">Resellers</SelectItem>
                <SelectItem value="settings">Settings</SelectItem>
                <SelectItem value="system">System</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-3">
              {[1, 2, 3, 4, 5].map((i) => (
                <Skeleton key={i} className="h-16 w-full" />
              ))}
            </div>
          ) : filteredLogs && filteredLogs.length > 0 ? (
            <div className="space-y-2">
              {filteredLogs.map((log) => (
                <div
                  key={log.id}
                  className="flex items-start gap-4 p-4 rounded-lg border bg-card hover-elevate"
                  data-testid={`log-entry-${log.id}`}
                >
                  <div className={`p-2 rounded-lg ${ACTION_COLORS[log.action] || "bg-gray-500/10 text-gray-500"}`}>
                    <ActionIcon action={log.action} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-medium">{log.adminUsername}</span>
                      <Badge variant="outline" className="text-xs">
                        {log.adminRole}
                      </Badge>
                      <span className="text-muted-foreground">performed</span>
                      <Badge className={ACTION_COLORS[log.action] || "bg-gray-500/10 text-gray-500"}>
                        {formatAction(log.action)}
                      </Badge>
                    </div>
                    {log.targetName && (
                      <div className="flex items-center gap-2 mt-1 text-sm text-muted-foreground">
                        <TargetIcon targetType={log.targetType} />
                        <span>on {log.targetType}:</span>
                        <span className="font-medium text-foreground">{log.targetName}</span>
                        {log.targetId && <span className="text-xs">(ID: {log.targetId})</span>}
                      </div>
                    )}
                    {log.details && (
                      <p className="text-sm text-muted-foreground mt-1 truncate">
                        {log.details}
                      </p>
                    )}
                    <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground">
                      <span>{format(new Date(log.createdAt * 1000), "PPpp")}</span>
                      {log.ipAddress && <span>IP: {log.ipAddress}</span>}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12 text-muted-foreground">
              <Shield className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>No audit logs found</p>
              <p className="text-sm">Activities will appear here as they occur</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
