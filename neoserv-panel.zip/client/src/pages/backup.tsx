import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Database,
  Download,
  Upload,
  FileJson,
  FileText,
  FileCode,
  Loader2,
  HardDrive,
  Clock,
  CheckCircle,
  Trash2,
  Calendar,
  AlertTriangle,
} from "lucide-react";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface BackupInfo {
  lastBackup: string | null;
  lastRestore: string | null;
  scheduledBackups: number;
  estimatedDatabaseSize: number;
  formattedSize: string;
  stats: {
    users: number;
    streams: number;
    series: number;
    categories: number;
  };
}

interface BackupSchedule {
  id: string;
  frequency: string;
  time: string;
  retention: number;
  enabled: boolean;
  createdAt: string;
  lastRun: string | null;
  nextRun: string;
}

export default function BackupPage() {
  const { toast } = useToast();
  const [exportFormat, setExportFormat] = useState("neoserv");
  const [fileFormat, setFileFormat] = useState("json");
  const [importFormat, setImportFormat] = useState("neoserv");
  const [importFile, setImportFile] = useState<File | null>(null);
  const [scheduleDialogOpen, setScheduleDialogOpen] = useState(false);
  const [restoreDialogOpen, setRestoreDialogOpen] = useState(false);
  const [scheduleFrequency, setScheduleFrequency] = useState("daily");
  const [scheduleTime, setScheduleTime] = useState("03:00");
  const [scheduleRetention, setScheduleRetention] = useState(7);

  const { data: backupInfo, refetch: refetchInfo } = useQuery<BackupInfo>({
    queryKey: ["/api/backup/info"],
  });

  const { data: schedules = [], refetch: refetchSchedules } = useQuery<BackupSchedule[]>({
    queryKey: ["/api/backup/schedules"],
  });

  const exportMutation = useMutation({
    mutationFn: async ({ format, fileFormat }: { format: string; fileFormat: string }) => {
      const response = await fetch(`/api/backup/export?format=${format}&fileFormat=${fileFormat}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
      });
      
      if (!response.ok) throw new Error("Export failed");
      
      const contentType = response.headers.get("content-type");
      
      if (contentType?.includes("application/sql") || contentType?.includes("application/xml")) {
        const text = await response.text();
        return { text, contentType };
      }
      
      const json = await response.json();
      return { json, contentType: "application/json" };
    },
    onSuccess: (data) => {
      let blob: Blob;
      let ext: string;
      
      if (data.text) {
        blob = new Blob([data.text], { type: data.contentType || "text/plain" });
        ext = data.contentType?.includes("sql") ? "sql" : "xml";
      } else {
        blob = new Blob([JSON.stringify(data.json, null, 2)], { type: "application/json" });
        ext = "json";
      }
      
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `backup-${exportFormat}-${new Date().toISOString().split("T")[0]}.${ext}`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      toast({ title: "Export successful", description: `Database exported as ${ext.toUpperCase()}` });
    },
    onError: () => {
      toast({ title: "Export failed", variant: "destructive" });
    },
  });

  const fullBackupMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/backup/full");
      return response.json();
    },
    onSuccess: (data) => {
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `full-backup-${new Date().toISOString().split("T")[0]}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      refetchInfo();
      toast({ 
        title: "Full Backup Complete", 
        description: `Backed up ${data.stats.users} users, ${data.stats.streams} streams` 
      });
    },
    onError: () => {
      toast({ title: "Full backup failed", variant: "destructive" });
    },
  });

  const restoreMutation = useMutation({
    mutationFn: async (backupData: any) => {
      const response = await apiRequest("POST", "/api/backup/restore", { 
        data: backupData,
        options: {
          skipExisting: true,
          importUsers: true,
          importStreams: true,
          importCategories: true,
          importBouquets: true,
          importSeries: true,
        }
      });
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries();
      refetchInfo();
      setRestoreDialogOpen(false);
      setImportFile(null);
      toast({ 
        title: "Restore Complete", 
        description: data.message 
      });
    },
    onError: () => {
      toast({ title: "Restore failed", variant: "destructive" });
    },
  });

  const createScheduleMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/backup/schedules", {
        frequency: scheduleFrequency,
        time: scheduleTime,
        retention: scheduleRetention,
        enabled: true,
      });
      return response.json();
    },
    onSuccess: () => {
      refetchSchedules();
      setScheduleDialogOpen(false);
      toast({ title: "Schedule Created", description: `Backup scheduled ${scheduleFrequency} at ${scheduleTime}` });
    },
    onError: () => {
      toast({ title: "Failed to create schedule", variant: "destructive" });
    },
  });

  const deleteScheduleMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/backup/schedules/${id}`);
    },
    onSuccess: () => {
      refetchSchedules();
      toast({ title: "Schedule deleted" });
    },
  });

  const handleImport = async () => {
    if (!importFile) {
      toast({ title: "Please select a file", variant: "destructive" });
      return;
    }
    
    try {
      const text = await importFile.text();
      let backupData: any;
      
      if (importFile.name.endsWith(".json")) {
        backupData = JSON.parse(text);
      } else if (importFile.name.endsWith(".xml")) {
        toast({ title: "XML import", description: "XML import requires conversion - using JSON format recommended" });
        return;
      } else if (importFile.name.endsWith(".sql")) {
        toast({ title: "SQL import", description: "SQL import is not yet supported - use JSON format" });
        return;
      } else {
        backupData = JSON.parse(text);
      }
      
      restoreMutation.mutate(backupData);
    } catch (e) {
      toast({ title: "Invalid file format", variant: "destructive" });
    }
  };

  const handleRestoreFromFile = async () => {
    if (!importFile) return;
    
    try {
      const text = await importFile.text();
      const backupData = JSON.parse(text);
      restoreMutation.mutate(backupData);
    } catch (e) {
      toast({ title: "Invalid backup file", variant: "destructive" });
    }
  };

  const formats = [
    { value: "neoserv", label: "X NeoServ", description: "Full native backup" },
    { value: "xui-one", label: "XUI.ONE", description: "XUI.ONE compatible" },
    { value: "xtream-codec", label: "Xtream Codec", description: "Xtream Codes format" },
    { value: "1-stream", label: "1-Stream", description: "1-Stream compatible" },
    { value: "nxt", label: "NXT Panel", description: "NXT compatible" },
  ];

  const fileFormats = [
    { value: "json", label: "JSON", icon: FileJson, description: "Standard format" },
    { value: "sql", label: "SQL", icon: FileCode, description: "SQL dump" },
    { value: "xml", label: "XML", icon: FileText, description: "XML format" },
  ];

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold">Backup & Export</h1>
          <p className="text-muted-foreground">Export, import, and manage database backups</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Download className="h-5 w-5 text-orange-500" />
              Export Database
            </CardTitle>
            <CardDescription>Export your database in various formats</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Panel Format</label>
              <Select value={exportFormat} onValueChange={setExportFormat}>
                <SelectTrigger data-testid="select-export-format">
                  <SelectValue placeholder="Select format" />
                </SelectTrigger>
                <SelectContent>
                  {formats.map((f) => (
                    <SelectItem key={f.value} value={f.value}>
                      {f.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">File Format</label>
              <div className="grid grid-cols-3 gap-2">
                {fileFormats.map((f) => (
                  <Button
                    key={f.value}
                    variant={fileFormat === f.value ? "default" : "outline"}
                    size="sm"
                    onClick={() => setFileFormat(f.value)}
                    className="gap-2"
                    data-testid={`button-file-format-${f.value}`}
                  >
                    <f.icon className="h-4 w-4" />
                    {f.label}
                  </Button>
                ))}
              </div>
            </div>

            <Separator />

            <div className="space-y-2 text-sm text-muted-foreground">
              <p className="font-medium text-foreground">Export includes:</p>
              <ul className="list-disc list-inside space-y-1">
                <li>Users & Lines ({backupInfo?.stats.users || 0})</li>
                <li>Live Streams ({backupInfo?.stats.streams || 0})</li>
                <li>Series ({backupInfo?.stats.series || 0})</li>
                <li>Categories ({backupInfo?.stats.categories || 0})</li>
                <li>Bouquets, Servers, EPG</li>
              </ul>
            </div>

            <Button 
              onClick={() => exportMutation.mutate({ format: exportFormat, fileFormat })}
              disabled={exportMutation.isPending}
              className="w-full bg-orange-600 hover:bg-orange-700"
              data-testid="button-export"
            >
              {exportMutation.isPending ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Exporting...
                </>
              ) : (
                <>
                  <Download className="h-4 w-4 mr-2" />
                  Export as {fileFormat.toUpperCase()}
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Upload className="h-5 w-5 text-orange-500" />
              Import Database
            </CardTitle>
            <CardDescription>Import data from another panel</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Import Format</label>
              <Select value={importFormat} onValueChange={setImportFormat}>
                <SelectTrigger data-testid="select-import-format">
                  <SelectValue placeholder="Select format" />
                </SelectTrigger>
                <SelectContent>
                  {formats.map((f) => (
                    <SelectItem key={f.value} value={f.value}>
                      {f.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <Separator />

            <div className="space-y-2">
              <label className="text-sm font-medium">Select Backup File</label>
              <Input
                type="file"
                accept=".json,.sql,.xml"
                onChange={(e) => setImportFile(e.target.files?.[0] || null)}
                data-testid="input-import-file"
              />
              {importFile && (
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <FileJson className="h-4 w-4" />
                  {importFile.name}
                  <CheckCircle className="h-4 w-4 text-green-500" />
                </div>
              )}
            </div>

            <div className="p-3 bg-muted/50 rounded-md text-sm">
              <div className="flex items-center gap-2 text-amber-600 dark:text-amber-400">
                <AlertTriangle className="h-4 w-4" />
                <span className="font-medium">Import will add new records</span>
              </div>
              <p className="text-muted-foreground mt-1">
                Existing data will not be overwritten. Duplicate entries will be skipped.
              </p>
            </div>

            <Button 
              onClick={handleImport}
              disabled={restoreMutation.isPending || !importFile}
              className="w-full"
              variant="outline"
              data-testid="button-import"
            >
              {restoreMutation.isPending ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Importing...
                </>
              ) : (
                <>
                  <Upload className="h-4 w-4 mr-2" />
                  Import Database
                </>
              )}
            </Button>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Database className="h-5 w-5 text-orange-500" />
            Database Management
          </CardTitle>
          <CardDescription>Full database backup, restore, and scheduled backups</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <Button 
              variant="outline" 
              className="justify-start"
              onClick={() => fullBackupMutation.mutate()}
              disabled={fullBackupMutation.isPending}
              data-testid="button-backup-db"
            >
              {fullBackupMutation.isPending ? (
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              ) : (
                <HardDrive className="h-4 w-4 mr-2" />
              )}
              Full Backup
            </Button>
            <Button 
              variant="outline" 
              className="justify-start"
              onClick={() => setRestoreDialogOpen(true)}
              data-testid="button-restore-db"
            >
              <Upload className="h-4 w-4 mr-2" />
              Restore Backup
            </Button>
            <Button 
              variant="outline" 
              className="justify-start"
              onClick={() => setScheduleDialogOpen(true)}
              data-testid="button-schedule-backup"
            >
              <Clock className="h-4 w-4 mr-2" />
              Schedule Backup
            </Button>
          </div>
          
          <Separator />
          
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Last backup:</span>
              <span>{backupInfo?.lastBackup ? new Date(backupInfo.lastBackup).toLocaleString() : "Never"}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Last restore:</span>
              <span>{backupInfo?.lastRestore ? new Date(backupInfo.lastRestore).toLocaleString() : "Never"}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Database size:</span>
              <span>{backupInfo?.formattedSize || "Calculating..."}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Scheduled backups:</span>
              <Badge variant="secondary">{schedules.length}</Badge>
            </div>
          </div>
        </CardContent>
      </Card>

      {schedules.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="h-5 w-5 text-orange-500" />
              Scheduled Backups
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Frequency</TableHead>
                  <TableHead>Time</TableHead>
                  <TableHead>Retention</TableHead>
                  <TableHead>Next Run</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {schedules.map((schedule) => (
                  <TableRow key={schedule.id}>
                    <TableCell className="capitalize">{schedule.frequency}</TableCell>
                    <TableCell>{schedule.time}</TableCell>
                    <TableCell>{schedule.retention} days</TableCell>
                    <TableCell>{new Date(schedule.nextRun).toLocaleString()}</TableCell>
                    <TableCell>
                      <Badge variant={schedule.enabled ? "default" : "secondary"}>
                        {schedule.enabled ? "Active" : "Disabled"}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Button
                        size="icon"
                        variant="ghost"
                        onClick={() => deleteScheduleMutation.mutate(schedule.id)}
                        data-testid={`button-delete-schedule-${schedule.id}`}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      <Dialog open={scheduleDialogOpen} onOpenChange={setScheduleDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Schedule Automatic Backup</DialogTitle>
            <DialogDescription>
              Configure automatic database backups
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Frequency</label>
              <Select value={scheduleFrequency} onValueChange={setScheduleFrequency}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="daily">Daily</SelectItem>
                  <SelectItem value="weekly">Weekly</SelectItem>
                  <SelectItem value="monthly">Monthly</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Time (24h format)</label>
              <Input
                type="time"
                value={scheduleTime}
                onChange={(e) => setScheduleTime(e.target.value)}
                data-testid="input-schedule-time"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Retention (days)</label>
              <Input
                type="number"
                min={1}
                max={365}
                value={scheduleRetention}
                onChange={(e) => setScheduleRetention(parseInt(e.target.value) || 7)}
                data-testid="input-schedule-retention"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setScheduleDialogOpen(false)}>
              Cancel
            </Button>
            <Button 
              onClick={() => createScheduleMutation.mutate()}
              disabled={createScheduleMutation.isPending}
              className="bg-orange-600 hover:bg-orange-700"
            >
              {createScheduleMutation.isPending ? (
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              ) : null}
              Create Schedule
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={restoreDialogOpen} onOpenChange={setRestoreDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Restore Database</DialogTitle>
            <DialogDescription>
              Restore from a full backup file
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="p-4 bg-destructive/10 border border-destructive/20 rounded-md">
              <div className="flex items-center gap-2 text-destructive">
                <AlertTriangle className="h-5 w-5" />
                <span className="font-medium">Warning</span>
              </div>
              <p className="text-sm text-muted-foreground mt-2">
                Restoring will add new data from the backup. Existing data will be preserved.
                Make sure to create a backup before restoring.
              </p>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Select Backup File</label>
              <Input
                type="file"
                accept=".json"
                onChange={(e) => setImportFile(e.target.files?.[0] || null)}
                data-testid="input-restore-file"
              />
              {importFile && (
                <div className="flex items-center gap-2 text-sm">
                  <FileJson className="h-4 w-4" />
                  {importFile.name}
                  <CheckCircle className="h-4 w-4 text-green-500" />
                </div>
              )}
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setRestoreDialogOpen(false)}>
              Cancel
            </Button>
            <Button 
              onClick={handleRestoreFromFile}
              disabled={restoreMutation.isPending || !importFile}
              variant="destructive"
            >
              {restoreMutation.isPending ? (
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              ) : null}
              Restore Database
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
