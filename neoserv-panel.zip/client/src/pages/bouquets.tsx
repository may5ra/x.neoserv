import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Plus,
  Search,
  MoreHorizontal,
  Edit,
  Trash2,
  Package,
  Tv,
  Film,
  Clapperboard,
  Copy,
  ArrowUpDown,
  ArrowUp,
  ArrowDown,
  ChevronUp,
  ChevronDown,
  X,
  GripVertical,
  CheckSquare,
  Square,
} from "lucide-react";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { DeleteConfirmation } from "@/components/delete-confirmation";
import type { Bouquet, Stream, Series, StreamCategory } from "@shared/schema";

type SortField = "order" | "name" | "channels" | "movies" | "series";
type SortDirection = "asc" | "desc";

interface Movie {
  id: number;
  name?: string;
  streamDisplayName?: string;
}

const bouquetFormSchema = z.object({
  bouquetName: z.string().min(1, "Name is required"),
  bouquetOrder: z.coerce.number().default(0),
});

type BouquetFormData = z.infer<typeof bouquetFormSchema>;

function BouquetFormDialog({ 
  bouquet, 
  open, 
  onOpenChange 
}: { 
  bouquet?: Bouquet; 
  open: boolean; 
  onOpenChange: (open: boolean) => void;
}) {
  const { toast } = useToast();
  const isEditing = !!bouquet;
  const [activeTab, setActiveTab] = useState("general");
  const [channelSearch, setChannelSearch] = useState("");
  const [movieSearch, setMovieSearch] = useState("");
  const [seriesSearch, setSeriesSearch] = useState("");
  
  // Category filter state
  const [channelCategory, setChannelCategory] = useState<string>("all");
  const [movieCategory, setMovieCategory] = useState<string>("all");
  const [seriesCategory, setSeriesCategory] = useState<string>("all");

  // Selected items state
  const [selectedChannels, setSelectedChannels] = useState<number[]>([]);
  const [selectedMovies, setSelectedMovies] = useState<number[]>([]);
  const [selectedSeries, setSelectedSeries] = useState<number[]>([]);

  // Fetch all available content
  const { data: allStreams = [] } = useQuery<Stream[]>({
    queryKey: ["/api/streams"],
  });

  const { data: allMovies = [] } = useQuery<Movie[]>({
    queryKey: ["/api/movies"],
  });

  const { data: allSeries = [] } = useQuery<Series[]>({
    queryKey: ["/api/series"],
  });
  
  const { data: allCategories = [] } = useQuery<StreamCategory[]>({
    queryKey: ["/api/categories"],
  });
  
  // Categories by type - API returns 'type' not 'categoryType'
  const liveCategories = allCategories.filter(c => (c as any).type === "live");
  const movieCategories = allCategories.filter(c => (c as any).type === "movie");
  const seriesCategories = allCategories.filter(c => (c as any).type === "series");

  // Initialize selected items when bouquet changes
  useEffect(() => {
    if (bouquet) {
      try {
        const channels = bouquet.bouquetChannels ? JSON.parse(bouquet.bouquetChannels) : [];
        const movies = bouquet.bouquetMovies ? JSON.parse(bouquet.bouquetMovies) : [];
        const series = bouquet.bouquetSeries ? JSON.parse(bouquet.bouquetSeries) : [];
        setSelectedChannels(channels.map((id: number | string) => Number(id)));
        setSelectedMovies(movies.map((id: number | string) => Number(id)));
        setSelectedSeries(series.map((id: number | string) => Number(id)));
      } catch {
        setSelectedChannels([]);
        setSelectedMovies([]);
        setSelectedSeries([]);
      }
    } else {
      setSelectedChannels([]);
      setSelectedMovies([]);
      setSelectedSeries([]);
    }
  }, [bouquet, open]);

  const form = useForm<BouquetFormData>({
    resolver: zodResolver(bouquetFormSchema),
    defaultValues: {
      bouquetName: bouquet?.bouquetName || "",
      bouquetOrder: bouquet?.bouquetOrder || 0,
    },
  });

  // Reset form when bouquet changes
  useEffect(() => {
    if (open) {
      form.reset({
        bouquetName: bouquet?.bouquetName || "",
        bouquetOrder: bouquet?.bouquetOrder || 0,
      });
    }
  }, [bouquet, open, form]);

  const mutation = useMutation({
    mutationFn: async (data: BouquetFormData) => {
      const payload = {
        ...data,
        bouquetChannels: JSON.stringify(selectedChannels),
        bouquetMovies: JSON.stringify(selectedMovies),
        bouquetSeries: JSON.stringify(selectedSeries),
      };
      if (isEditing) {
        return apiRequest("PATCH", `/api/bouquets/${bouquet.id}`, payload);
      }
      return apiRequest("POST", "/api/bouquets", payload);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bouquets"] });
      toast({
        title: isEditing ? "Bouquet updated" : "Bouquet created",
      });
      onOpenChange(false);
      form.reset();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to save bouquet",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: BouquetFormData) => {
    mutation.mutate(data);
  };

  // Helper functions for item management
  const toggleChannel = (id: number) => {
    setSelectedChannels(prev => 
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    );
  };

  const toggleMovie = (id: number) => {
    setSelectedMovies(prev => 
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    );
  };

  const toggleSeries = (id: number) => {
    setSelectedSeries(prev => 
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    );
  };

  const moveItem = (list: number[], setList: (items: number[]) => void, index: number, direction: "up" | "down") => {
    const newIndex = direction === "up" ? index - 1 : index + 1;
    if (newIndex < 0 || newIndex >= list.length) return;
    const newList = [...list];
    [newList[index], newList[newIndex]] = [newList[newIndex], newList[index]];
    setList(newList);
  };

  const removeItem = (list: number[], setList: (items: number[]) => void, id: number) => {
    setList(list.filter(i => i !== id));
  };

  // Filter available items with category support
  const filteredStreams = allStreams.filter(s => {
    const name = (s as any).name || s.streamDisplayName || "";
    const matchesSearch = name.toLowerCase().includes(channelSearch.toLowerCase());
    const matchesCategory = channelCategory === "all" || String(s.categoryId) === channelCategory;
    return matchesSearch && matchesCategory;
  });

  const filteredMovies = allMovies.filter(m => {
    const name = (m as any).name || m.streamDisplayName || "";
    const matchesSearch = name.toLowerCase().includes(movieSearch.toLowerCase());
    const matchesCategory = movieCategory === "all" || String((m as any).categoryId) === movieCategory;
    return matchesSearch && matchesCategory;
  });

  const filteredSeries = allSeries.filter(s => {
    const matchesSearch = (s.title || "").toLowerCase().includes(seriesSearch.toLowerCase());
    const matchesCategory = seriesCategory === "all" || String(s.categoryId) === seriesCategory;
    return matchesSearch && matchesCategory;
  });
  
  // Select All helpers
  const selectAllChannels = () => {
    const filtered = filteredStreams.map(s => s.id);
    setSelectedChannels(prev => Array.from(new Set([...prev, ...filtered])));
  };
  
  const deselectAllChannels = () => {
    const filteredIds = filteredStreams.map(s => s.id);
    setSelectedChannels(prev => prev.filter(id => !filteredIds.includes(id)));
  };
  
  const selectAllMovies = () => {
    const filtered = filteredMovies.map(m => m.id);
    setSelectedMovies(prev => Array.from(new Set([...prev, ...filtered])));
  };
  
  const deselectAllMovies = () => {
    const filteredIds = filteredMovies.map(m => m.id);
    setSelectedMovies(prev => prev.filter(id => !filteredIds.includes(id)));
  };
  
  const selectAllSeries = () => {
    const filtered = filteredSeries.map(s => s.id);
    setSelectedSeries(prev => Array.from(new Set([...prev, ...filtered])));
  };
  
  const deselectAllSeries = () => {
    const filteredIds = filteredSeries.map(s => s.id);
    setSelectedSeries(prev => prev.filter(id => !filteredIds.includes(id)));
  };
  
  // Check if all filtered items are selected
  const allChannelsSelected = filteredStreams.length > 0 && filteredStreams.every(s => selectedChannels.includes(s.id));
  const allMoviesSelected = filteredMovies.length > 0 && filteredMovies.every(m => selectedMovies.includes(m.id));
  const allSeriesSelected = filteredSeries.length > 0 && filteredSeries.every(s => selectedSeries.includes(s.id));

  // Get item details by ID
  const getStreamName = (id: number) => {
    const stream = allStreams.find(s => s.id === id);
    return (stream as any)?.name || stream?.streamDisplayName || `Channel #${id}`;
  };

  const getMovieName = (id: number) => {
    const movie = allMovies.find(m => m.id === id);
    return (movie as any)?.name || movie?.streamDisplayName || `Movie #${id}`;
  };

  const getSeriesName = (id: number) => {
    const series = allSeries.find(s => s.id === id);
    return series?.title || `Series #${id}`;
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[85vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Package className="h-5 w-5" />
            {isEditing ? "Edit Bouquet" : "Add New Bouquet"}
          </DialogTitle>
        </DialogHeader>
        
        <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 overflow-hidden flex flex-col">
          <TabsList className="grid grid-cols-4 w-full">
            <TabsTrigger value="general" data-testid="tab-general">General</TabsTrigger>
            <TabsTrigger value="channels" data-testid="tab-channels">
              Channels ({selectedChannels.length})
            </TabsTrigger>
            <TabsTrigger value="movies" data-testid="tab-movies">
              Movies ({selectedMovies.length})
            </TabsTrigger>
            <TabsTrigger value="series" data-testid="tab-series">
              Series ({selectedSeries.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="general" className="mt-4 space-y-4">
            <Form {...form}>
              <div className="space-y-4">
                <FormField
                  control={form.control}
                  name="bouquetName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Bouquet Name</FormLabel>
                      <FormControl>
                        <Input placeholder="Premium Package" {...field} data-testid="input-bouquet-name" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="bouquetOrder"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Sort Order</FormLabel>
                      <FormControl>
                        <Input type="number" placeholder="0" {...field} data-testid="input-bouquet-order" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </Form>
          </TabsContent>

          <TabsContent value="channels" className="mt-4 flex-1 overflow-hidden">
            <div className="grid grid-cols-2 gap-4 h-full">
              {/* Available Channels */}
              <div className="border rounded-lg flex flex-col">
                <div className="p-3 border-b bg-muted/50 space-y-2">
                  <h4 className="font-medium text-sm">Available Channels</h4>
                  <div className="flex gap-2">
                    <div className="relative flex-1">
                      <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                      <Input 
                        placeholder="Search channels..." 
                        className="pl-8"
                        value={channelSearch}
                        onChange={(e) => setChannelSearch(e.target.value)}
                        data-testid="input-search-channels"
                      />
                    </div>
                    <Select value={channelCategory} onValueChange={setChannelCategory}>
                      <SelectTrigger className="w-[140px]" data-testid="select-channel-category">
                        <SelectValue placeholder="Category" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Categories</SelectItem>
                        {liveCategories.map(cat => (
                          <SelectItem key={cat.id} value={String(cat.id)}>
                            {(cat as any).name || cat.categoryName}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex items-center gap-2 pt-1">
                    <Checkbox
                      checked={allChannelsSelected}
                      onCheckedChange={(checked) => checked ? selectAllChannels() : deselectAllChannels()}
                      data-testid="checkbox-select-all-channels"
                    />
                    <span className="text-xs text-muted-foreground">
                      Select All ({filteredStreams.length})
                    </span>
                  </div>
                </div>
                <div className="flex-1 overflow-y-scroll p-2" style={{ maxHeight: "300px" }}>
                  <div className="space-y-1">
                    {filteredStreams.map(stream => (
                      <div 
                        key={stream.id}
                        className="flex items-center gap-2 p-2 rounded hover-elevate cursor-pointer"
                        onClick={() => toggleChannel(stream.id)}
                        data-testid={`channel-item-${stream.id}`}
                      >
                        <Checkbox 
                          checked={selectedChannels.includes(stream.id)}
                          onCheckedChange={() => toggleChannel(stream.id)}
                        />
                        <Tv className="h-4 w-4 text-muted-foreground" />
                        <span className="text-sm truncate flex-1">
                          {(stream as any).name || stream.streamDisplayName || `Channel #${stream.id}`}
                        </span>
                      </div>
                    ))}
                    {filteredStreams.length === 0 && (
                      <p className="text-sm text-muted-foreground text-center py-4">No channels found</p>
                    )}
                  </div>
                </div>
              </div>

              {/* Selected Channels (Ordered) */}
              <div className="border rounded-lg flex flex-col">
                <div className="p-3 border-b bg-muted/50">
                  <h4 className="font-medium text-sm">Selected Channels ({selectedChannels.length})</h4>
                </div>
                <div className="flex-1 overflow-y-scroll p-2" style={{ maxHeight: "300px" }}>
                  <div className="space-y-1">
                    {selectedChannels.map((id, index) => (
                      <div 
                        key={id}
                        className="flex items-center gap-1 p-2 rounded bg-accent/50"
                        data-testid={`selected-channel-${id}`}
                      >
                        <GripVertical className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                        <span className="text-sm truncate flex-1 min-w-0">{getStreamName(id)}</span>
                        <button 
                          type="button"
                          className="p-1 rounded hover:bg-muted disabled:opacity-30"
                          onClick={() => moveItem(selectedChannels, setSelectedChannels, index, "up")}
                          disabled={index === 0}
                          data-testid={`btn-move-up-${id}`}
                        >
                          <ChevronUp className="h-4 w-4" />
                        </button>
                        <button 
                          type="button"
                          className="p-1 rounded hover:bg-muted disabled:opacity-30"
                          onClick={() => moveItem(selectedChannels, setSelectedChannels, index, "down")}
                          disabled={index === selectedChannels.length - 1}
                          data-testid={`btn-move-down-${id}`}
                        >
                          <ChevronDown className="h-4 w-4" />
                        </button>
                        <button 
                          type="button"
                          className="p-1 rounded text-destructive hover:bg-destructive hover:text-white"
                          onClick={() => removeItem(selectedChannels, setSelectedChannels, id)}
                          data-testid={`btn-remove-${id}`}
                        >
                          <X className="h-4 w-4" />
                        </button>
                      </div>
                    ))}
                    {selectedChannels.length === 0 && (
                      <p className="text-sm text-muted-foreground text-center py-4">
                        No channels selected. Click channels on the left to add them.
                      </p>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="movies" className="mt-4 flex-1 overflow-hidden">
            <div className="grid grid-cols-2 gap-4 h-full">
              {/* Available Movies */}
              <div className="border rounded-lg flex flex-col">
                <div className="p-3 border-b bg-muted/50 space-y-2">
                  <h4 className="font-medium text-sm">Available Movies</h4>
                  <div className="flex gap-2">
                    <div className="relative flex-1">
                      <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                      <Input 
                        placeholder="Search movies..." 
                        className="pl-8"
                        value={movieSearch}
                        onChange={(e) => setMovieSearch(e.target.value)}
                        data-testid="input-search-movies"
                      />
                    </div>
                    <Select value={movieCategory} onValueChange={setMovieCategory}>
                      <SelectTrigger className="w-[140px]" data-testid="select-movie-category">
                        <SelectValue placeholder="Category" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Categories</SelectItem>
                        {movieCategories.map(cat => (
                          <SelectItem key={cat.id} value={String(cat.id)}>
                            {(cat as any).name || cat.categoryName}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex items-center gap-2 pt-1">
                    <Checkbox
                      checked={allMoviesSelected}
                      onCheckedChange={(checked) => checked ? selectAllMovies() : deselectAllMovies()}
                      data-testid="checkbox-select-all-movies"
                    />
                    <span className="text-xs text-muted-foreground">
                      Select All ({filteredMovies.length})
                    </span>
                  </div>
                </div>
                <div className="flex-1 overflow-y-scroll p-2" style={{ maxHeight: "300px" }}>
                  <div className="space-y-1">
                    {filteredMovies.map(movie => (
                      <div 
                        key={movie.id}
                        className="flex items-center gap-2 p-2 rounded hover-elevate cursor-pointer"
                        onClick={() => toggleMovie(movie.id)}
                        data-testid={`movie-item-${movie.id}`}
                      >
                        <Checkbox 
                          checked={selectedMovies.includes(movie.id)}
                          onCheckedChange={() => toggleMovie(movie.id)}
                        />
                        <Film className="h-4 w-4 text-muted-foreground" />
                        <span className="text-sm truncate flex-1">
                          {movie.name || movie.streamDisplayName || `Movie #${movie.id}`}
                        </span>
                      </div>
                    ))}
                    {filteredMovies.length === 0 && (
                      <p className="text-sm text-muted-foreground text-center py-4">No movies found</p>
                    )}
                  </div>
                </div>
              </div>

              {/* Selected Movies */}
              <div className="border rounded-lg flex flex-col">
                <div className="p-3 border-b bg-muted/50">
                  <h4 className="font-medium text-sm">Selected Movies ({selectedMovies.length})</h4>
                </div>
                <div className="flex-1 overflow-y-scroll p-2" style={{ maxHeight: "300px" }}>
                  <div className="space-y-1">
                    {selectedMovies.map((id, index) => (
                      <div 
                        key={id}
                        className="flex items-center gap-1 p-2 rounded bg-accent/50"
                        data-testid={`selected-movie-${id}`}
                      >
                        <GripVertical className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                        <span className="text-sm truncate flex-1 min-w-0">{getMovieName(id)}</span>
                        <button 
                          type="button"
                          className="p-1 rounded hover:bg-muted disabled:opacity-30"
                          onClick={() => moveItem(selectedMovies, setSelectedMovies, index, "up")}
                          disabled={index === 0}
                        >
                          <ChevronUp className="h-4 w-4" />
                        </button>
                        <button 
                          type="button"
                          className="p-1 rounded hover:bg-muted disabled:opacity-30"
                          onClick={() => moveItem(selectedMovies, setSelectedMovies, index, "down")}
                          disabled={index === selectedMovies.length - 1}
                        >
                          <ChevronDown className="h-4 w-4" />
                        </button>
                        <button 
                          type="button"
                          className="p-1 rounded text-destructive hover:bg-destructive hover:text-white"
                          onClick={() => removeItem(selectedMovies, setSelectedMovies, id)}
                        >
                          <X className="h-4 w-4" />
                        </button>
                      </div>
                    ))}
                    {selectedMovies.length === 0 && (
                      <p className="text-sm text-muted-foreground text-center py-4">
                        No movies selected.
                      </p>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="series" className="mt-4 flex-1 overflow-hidden">
            <div className="grid grid-cols-2 gap-4 h-full">
              {/* Available Series */}
              <div className="border rounded-lg flex flex-col">
                <div className="p-3 border-b bg-muted/50 space-y-2">
                  <h4 className="font-medium text-sm">Available Series</h4>
                  <div className="flex gap-2">
                    <div className="relative flex-1">
                      <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                      <Input 
                        placeholder="Search series..." 
                        className="pl-8"
                        value={seriesSearch}
                        onChange={(e) => setSeriesSearch(e.target.value)}
                        data-testid="input-search-series"
                      />
                    </div>
                    <Select value={seriesCategory} onValueChange={setSeriesCategory}>
                      <SelectTrigger className="w-[140px]" data-testid="select-series-category">
                        <SelectValue placeholder="Category" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Categories</SelectItem>
                        {seriesCategories.map(cat => (
                          <SelectItem key={cat.id} value={String(cat.id)}>
                            {(cat as any).name || cat.categoryName}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex items-center gap-2 pt-1">
                    <Checkbox
                      checked={allSeriesSelected}
                      onCheckedChange={(checked) => checked ? selectAllSeries() : deselectAllSeries()}
                      data-testid="checkbox-select-all-series"
                    />
                    <span className="text-xs text-muted-foreground">
                      Select All ({filteredSeries.length})
                    </span>
                  </div>
                </div>
                <div className="flex-1 overflow-y-scroll p-2" style={{ maxHeight: "300px" }}>
                  <div className="space-y-1">
                    {filteredSeries.map(series => (
                      <div 
                        key={series.id}
                        className="flex items-center gap-2 p-2 rounded hover-elevate cursor-pointer"
                        onClick={() => toggleSeries(series.id)}
                        data-testid={`series-item-${series.id}`}
                      >
                        <Checkbox 
                          checked={selectedSeries.includes(series.id)}
                          onCheckedChange={() => toggleSeries(series.id)}
                        />
                        <Clapperboard className="h-4 w-4 text-muted-foreground" />
                        <span className="text-sm truncate flex-1">
                          {series.title}
                        </span>
                      </div>
                    ))}
                    {filteredSeries.length === 0 && (
                      <p className="text-sm text-muted-foreground text-center py-4">No series found</p>
                    )}
                  </div>
                </div>
              </div>

              {/* Selected Series */}
              <div className="border rounded-lg flex flex-col">
                <div className="p-3 border-b bg-muted/50">
                  <h4 className="font-medium text-sm">Selected Series ({selectedSeries.length})</h4>
                </div>
                <div className="flex-1 overflow-y-scroll p-2" style={{ maxHeight: "300px" }}>
                  <div className="space-y-1">
                    {selectedSeries.map((id, index) => (
                      <div 
                        key={id}
                        className="flex items-center gap-1 p-2 rounded bg-accent/50"
                        data-testid={`selected-series-${id}`}
                      >
                        <GripVertical className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                        <span className="text-sm truncate flex-1 min-w-0">{getSeriesName(id)}</span>
                        <button 
                          type="button"
                          className="p-1 rounded hover:bg-muted disabled:opacity-30"
                          onClick={() => moveItem(selectedSeries, setSelectedSeries, index, "up")}
                          disabled={index === 0}
                        >
                          <ChevronUp className="h-4 w-4" />
                        </button>
                        <button 
                          type="button"
                          className="p-1 rounded hover:bg-muted disabled:opacity-30"
                          onClick={() => moveItem(selectedSeries, setSelectedSeries, index, "down")}
                          disabled={index === selectedSeries.length - 1}
                        >
                          <ChevronDown className="h-4 w-4" />
                        </button>
                        <button 
                          type="button"
                          className="p-1 rounded text-destructive hover:bg-destructive hover:text-white"
                          onClick={() => removeItem(selectedSeries, setSelectedSeries, id)}
                        >
                          <X className="h-4 w-4" />
                        </button>
                      </div>
                    ))}
                    {selectedSeries.length === 0 && (
                      <p className="text-sm text-muted-foreground text-center py-4">
                        No series selected.
                      </p>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>

        <div className="flex justify-end gap-2 pt-4 border-t mt-4">
          <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button 
            onClick={form.handleSubmit(onSubmit)} 
            disabled={mutation.isPending} 
            data-testid="button-save-bouquet"
          >
            {mutation.isPending ? "Saving..." : isEditing ? "Update" : "Create"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export default function BouquetsPage() {
  const [search, setSearch] = useState("");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingBouquet, setEditingBouquet] = useState<Bouquet | undefined>();
  const [sortField, setSortField] = useState<SortField>("order");
  const [sortDirection, setSortDirection] = useState<SortDirection>("asc");
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [bouquetToDelete, setBouquetToDelete] = useState<Bouquet | null>(null);
  const [selectedBouquets, setSelectedBouquets] = useState<Set<number>>(new Set());
  const [massDeleteOpen, setMassDeleteOpen] = useState(false);
  const { toast } = useToast();

  const { data: bouquets, isLoading } = useQuery<Bouquet[]>({
    queryKey: ["/api/bouquets"],
  });

  const { data: streams = [] } = useQuery<Stream[]>({
    queryKey: ["/api/streams"],
  });

  const { data: movies = [] } = useQuery<{ id: number }[]>({
    queryKey: ["/api/movies"],
  });

  const { data: series = [] } = useQuery<Series[]>({
    queryKey: ["/api/series"],
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest("DELETE", `/api/bouquets/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bouquets"] });
      toast({ title: "Bouquet deleted" });
      setDeleteDialogOpen(false);
      setBouquetToDelete(null);
    },
  });

  const massDeleteMutation = useMutation({
    mutationFn: async (ids: number[]) => {
      await Promise.all(ids.map(id => apiRequest("DELETE", `/api/bouquets/${id}`)));
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bouquets"] });
      toast({ title: `${selectedBouquets.size} bouquets deleted` });
      setMassDeleteOpen(false);
      setSelectedBouquets(new Set());
    },
  });

  const moveMutation = useMutation({
    mutationFn: async ({ id, newOrder }: { id: number; newOrder: number }) => {
      return apiRequest("PATCH", `/api/bouquets/${id}`, { bouquetOrder: newOrder });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bouquets"] });
    },
  });

  const moveBouquet = (bouquet: Bouquet, direction: "up" | "down") => {
    const sortedBouquets = [...(bouquets || [])].sort((a, b) => (a.bouquetOrder || 0) - (b.bouquetOrder || 0));
    const currentIndex = sortedBouquets.findIndex(b => b.id === bouquet.id);
    if (currentIndex === -1) return;
    
    const swapIndex = direction === "up" ? currentIndex - 1 : currentIndex + 1;
    if (swapIndex < 0 || swapIndex >= sortedBouquets.length) return;
    
    const otherBouquet = sortedBouquets[swapIndex];
    
    // Swap orders
    moveMutation.mutate({ id: bouquet.id, newOrder: otherBouquet.bouquetOrder || 0 });
    moveMutation.mutate({ id: otherBouquet.id, newOrder: bouquet.bouquetOrder || 0 });
  };

  const toggleSelectAll = () => {
    if (!filteredBouquets) return;
    if (selectedBouquets.size === filteredBouquets.length) {
      setSelectedBouquets(new Set());
    } else {
      setSelectedBouquets(new Set(filteredBouquets.map(b => b.id)));
    }
  };

  const toggleSelect = (id: number) => {
    const newSet = new Set(selectedBouquets);
    if (newSet.has(id)) {
      newSet.delete(id);
    } else {
      newSet.add(id);
    }
    setSelectedBouquets(newSet);
  };

  const getChannelCount = (channels: string) => {
    try {
      return JSON.parse(channels || "[]").length;
    } catch {
      return 0;
    }
  };

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortDirection("asc");
    }
  };

  const getSortIcon = (field: SortField) => {
    if (sortField !== field) return <ArrowUpDown className="h-4 w-4 ml-1" />;
    return sortDirection === "asc" 
      ? <ArrowUp className="h-4 w-4 ml-1" /> 
      : <ArrowDown className="h-4 w-4 ml-1" />;
  };

  const filteredBouquets = bouquets?.filter(bouquet => 
    (bouquet.bouquetName || '').toLowerCase().includes(search.toLowerCase())
  )?.sort((a, b) => {
    let comparison = 0;
    switch (sortField) {
      case "order":
        comparison = (a.bouquetOrder || 0) - (b.bouquetOrder || 0);
        break;
      case "name":
        comparison = (a.bouquetName || "").localeCompare(b.bouquetName || "");
        break;
      case "channels":
        comparison = getChannelCount(a.bouquetChannels) - getChannelCount(b.bouquetChannels);
        break;
      case "movies":
        comparison = getChannelCount(a.bouquetMovies) - getChannelCount(b.bouquetMovies);
        break;
      case "series":
        comparison = getChannelCount(a.bouquetSeries) - getChannelCount(b.bouquetSeries);
        break;
    }
    return sortDirection === "asc" ? comparison : -comparison;
  });

  const handleDeleteClick = (bouquet: Bouquet) => {
    setBouquetToDelete(bouquet);
    setDeleteDialogOpen(true);
  };

  const confirmDelete = () => {
    if (bouquetToDelete) {
      deleteMutation.mutate(bouquetToDelete.id);
    }
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-3xl font-bold tracking-tight" data-testid="page-title">Bouquets</h1>
          <p className="text-muted-foreground">Create and manage content packages</p>
        </div>
        <Button onClick={() => { setEditingBouquet(undefined); setDialogOpen(true); }} data-testid="button-add-bouquet">
          <Plus className="h-4 w-4 mr-2" />
          Add Bouquet
        </Button>
      </div>

      <div className="grid gap-4 grid-cols-1 sm:grid-cols-4">
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 rounded-lg bg-primary/10">
              <Package className="h-5 w-5 text-primary" />
            </div>
            <div>
              <p className="text-2xl font-bold">{bouquets?.length || 0}</p>
              <p className="text-sm text-muted-foreground">Total Bouquets</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 rounded-lg bg-blue-500/10">
              <Tv className="h-5 w-5 text-blue-500" />
            </div>
            <div>
              <p className="text-2xl font-bold">{streams.length}</p>
              <p className="text-sm text-muted-foreground">Live Channels</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 rounded-lg bg-purple-500/10">
              <Film className="h-5 w-5 text-purple-500" />
            </div>
            <div>
              <p className="text-2xl font-bold">{movies.length}</p>
              <p className="text-sm text-muted-foreground">Movies</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 rounded-lg bg-emerald-500/10">
              <Clapperboard className="h-5 w-5 text-emerald-500" />
            </div>
            <div>
              <p className="text-2xl font-bold">{series.length}</p>
              <p className="text-sm text-muted-foreground">TV Series</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between gap-4 pb-4 flex-wrap">
          <div className="flex items-center gap-4 flex-wrap">
            <CardTitle>All Bouquets</CardTitle>
            {selectedBouquets.size > 0 && (
              <div className="flex items-center gap-2">
                <Badge variant="secondary">{selectedBouquets.size} selected</Badge>
                <Button 
                  variant="destructive" 
                  size="sm"
                  onClick={() => setMassDeleteOpen(true)}
                  data-testid="button-mass-delete"
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  Delete Selected
                </Button>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => setSelectedBouquets(new Set())}
                  data-testid="button-clear-selection"
                >
                  Clear
                </Button>
              </div>
            )}
          </div>
          <div className="relative w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search bouquets..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-9"
              data-testid="input-search-bouquets"
            />
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-2">
              {Array(5).fill(0).map((_, i) => (
                <Skeleton key={i} className="h-12 w-full" />
              ))}
            </div>
          ) : filteredBouquets && filteredBouquets.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-12">
                    <Checkbox
                      checked={filteredBouquets && filteredBouquets.length > 0 && selectedBouquets.size === filteredBouquets.length}
                      onCheckedChange={toggleSelectAll}
                      data-testid="checkbox-select-all"
                    />
                  </TableHead>
                  <TableHead>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={() => handleSort("order")}
                      className="flex items-center -ml-3"
                      data-testid="sort-order"
                    >
                      Order {getSortIcon("order")}
                    </Button>
                  </TableHead>
                  <TableHead>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={() => handleSort("name")}
                      className="flex items-center -ml-3"
                      data-testid="sort-name"
                    >
                      Name {getSortIcon("name")}
                    </Button>
                  </TableHead>
                  <TableHead>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={() => handleSort("channels")}
                      className="flex items-center -ml-3"
                      data-testid="sort-channels"
                    >
                      Channels {getSortIcon("channels")}
                    </Button>
                  </TableHead>
                  <TableHead>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={() => handleSort("movies")}
                      className="flex items-center -ml-3"
                      data-testid="sort-movies"
                    >
                      Movies {getSortIcon("movies")}
                    </Button>
                  </TableHead>
                  <TableHead>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={() => handleSort("series")}
                      className="flex items-center -ml-3"
                      data-testid="sort-series"
                    >
                      Series {getSortIcon("series")}
                    </Button>
                  </TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredBouquets.map((bouquet) => (
                  <TableRow key={bouquet.id} data-testid={`bouquet-row-${bouquet.id}`}>
                    <TableCell className="w-12">
                      <Checkbox
                        checked={selectedBouquets.has(bouquet.id)}
                        onCheckedChange={() => toggleSelect(bouquet.id)}
                        data-testid={`checkbox-bouquet-${bouquet.id}`}
                      />
                    </TableCell>
                    <TableCell className="w-24">
                      <div className="flex items-center gap-1">
                        <span className="text-muted-foreground w-8">{bouquet.bouquetOrder}</span>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-6 w-6"
                          onClick={() => moveBouquet(bouquet, "up")}
                          disabled={moveMutation.isPending}
                          data-testid={`button-move-up-${bouquet.id}`}
                        >
                          <ChevronUp className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-6 w-6"
                          onClick={() => moveBouquet(bouquet, "down")}
                          disabled={moveMutation.isPending}
                          data-testid={`button-move-down-${bouquet.id}`}
                        >
                          <ChevronDown className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                    <TableCell className="font-medium">
                      <div className="flex items-center gap-2">
                        <Package className="h-4 w-4 text-muted-foreground" />
                        {bouquet.bouquetName}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline">
                        <Tv className="h-3 w-3 mr-1" />
                        {getChannelCount(bouquet.bouquetChannels)}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline">
                        <Film className="h-3 w-3 mr-1" />
                        {getChannelCount(bouquet.bouquetMovies)}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline">
                        <Clapperboard className="h-3 w-3 mr-1" />
                        {getChannelCount(bouquet.bouquetSeries)}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" data-testid={`button-bouquet-menu-${bouquet.id}`}>
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => { setEditingBouquet(bouquet); setDialogOpen(true); }}>
                            <Edit className="h-4 w-4 mr-2" />
                            Edit
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => {
                            navigator.clipboard.writeText(bouquet.id.toString());
                            toast({ title: "Bouquet ID copied" });
                          }}>
                            <Copy className="h-4 w-4 mr-2" />
                            Copy ID
                          </DropdownMenuItem>
                          <DropdownMenuItem 
                            onClick={() => handleDeleteClick(bouquet)}
                            className="text-destructive"
                          >
                            <Trash2 className="h-4 w-4 mr-2" />
                            Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <Package className="h-12 w-12 text-muted-foreground/50 mb-4" />
              <p className="text-muted-foreground">No bouquets found</p>
              <Button 
                variant="outline" 
                size="sm" 
                className="mt-4"
                onClick={() => { setEditingBouquet(undefined); setDialogOpen(true); }}
              >
                Create your first bouquet
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      <BouquetFormDialog 
        bouquet={editingBouquet} 
        open={dialogOpen} 
        onOpenChange={setDialogOpen} 
      />

      <DeleteConfirmation
        open={deleteDialogOpen}
        onOpenChange={setDeleteDialogOpen}
        onConfirm={confirmDelete}
        title="Delete Bouquet"
        itemName={bouquetToDelete?.bouquetName}
      />

      <DeleteConfirmation
        open={massDeleteOpen}
        onOpenChange={setMassDeleteOpen}
        onConfirm={() => massDeleteMutation.mutate(Array.from(selectedBouquets))}
        title="Delete Selected Bouquets"
        itemName={`${selectedBouquets.size} bouquets`}
      />
    </div>
  );
}
