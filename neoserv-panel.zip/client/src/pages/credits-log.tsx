import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { CreditCard, ArrowUp, ArrowDown, Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { useState } from "react";

interface CreditTransaction {
  id: number;
  resellerId?: number;
  admin?: string;
  amount: number;
  type: string;
  reason: string;
  balanceAfter: number;
  createdAt: string; // ISO date string from backend
}

export default function CreditsLog() {
  const [search, setSearch] = useState("");

  const { data: transactions, isLoading } = useQuery<CreditTransaction[]>({
    queryKey: ["/api/resellers/me/credits-log"],
  });

  const filteredTransactions = transactions?.filter(t =>
    t.reason.toLowerCase().includes(search.toLowerCase()) ||
    t.type.toLowerCase().includes(search.toLowerCase())
  ) || [];

  if (isLoading) {
    return (
      <div className="p-6 space-y-6">
        <div className="bg-gradient-to-r from-emerald-500 to-teal-600 rounded-lg p-6 text-white">
          <Skeleton className="h-8 w-48 bg-white/20" />
          <Skeleton className="h-4 w-64 mt-2 bg-white/20" />
        </div>
        <Card>
          <CardContent className="p-6">
            <Skeleton className="h-64 w-full" />
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <div className="bg-gradient-to-r from-emerald-500 to-teal-600 rounded-lg p-6 text-white">
        <h1 className="text-2xl font-bold">Credits Log</h1>
        <p className="text-white/80 mt-1">View your credit transaction history</p>
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between gap-4 pb-4">
          <CardTitle className="flex items-center gap-2">
            <CreditCard className="h-5 w-5" />
            Transaction History
          </CardTitle>
          <div className="relative w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search transactions..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-9"
              data-testid="input-search-credits"
            />
          </div>
        </CardHeader>
        <CardContent>
          {filteredTransactions.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <CreditCard className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>No credit transactions found</p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-16">#</TableHead>
                  <TableHead>Admin</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Reason</TableHead>
                  <TableHead>Balance After</TableHead>
                  <TableHead>Date</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredTransactions.map((transaction) => (
                  <TableRow key={transaction.id} data-testid={`row-credit-${transaction.id}`}>
                    <TableCell className="font-mono text-muted-foreground">
                      {transaction.id}
                    </TableCell>
                    <TableCell>{transaction.admin || "System"}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        {transaction.amount > 0 ? (
                          <ArrowUp className="h-4 w-4 text-emerald-500" />
                        ) : (
                          <ArrowDown className="h-4 w-4 text-red-500" />
                        )}
                        <span className={transaction.amount > 0 ? "text-emerald-500" : "text-red-500"}>
                          {transaction.amount > 0 ? "+" : ""}{transaction.amount}
                        </span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant={transaction.type === "credit" ? "default" : "secondary"}>
                        {transaction.type}
                      </Badge>
                    </TableCell>
                    <TableCell className="max-w-xs truncate">{transaction.reason}</TableCell>
                    <TableCell className="font-mono">{transaction.balanceAfter}</TableCell>
                    <TableCell className="text-muted-foreground">
                      {new Date(transaction.createdAt).toLocaleDateString()}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
