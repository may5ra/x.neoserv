import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { useAuth } from "@/App";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { NetworkTrafficChart } from "@/components/network-traffic-chart";
import { ConnectionsByLocation } from "@/components/connections-by-location";
import {
  Users,
  Tv,
  Film,
  Server,
  Activity,
  Zap,
  Play,
  AlertTriangle,
  RefreshCw,
  Globe,
  Cpu,
  HardDrive,
  Wifi,
  CreditCard,
} from "lucide-react";
import type { DashboardStats, StreamingServer } from "@shared/schema";

function StatCard({
  title,
  value,
  subtitle,
  icon: Icon,
  trend,
  variant = "default",
  href,
  onClick,
}: {
  title: string;
  value: number | string;
  subtitle?: string;
  icon: React.ElementType;
  trend?: { value: number; positive: boolean };
  variant?: "default" | "success" | "warning" | "destructive" | "info";
  href?: string;
  onClick?: () => void;
}) {
  const cardClasses = {
    default: "bg-card border-border",
    success: "bg-orange-50 dark:bg-[#1f170d] border-orange-200 dark:border-orange-900/50",
    warning: "bg-amber-50 dark:bg-[#1f1a0d] border-amber-200 dark:border-amber-900/50",
    destructive: "bg-red-50 dark:bg-[#1f0d0d] border-red-200 dark:border-red-900/50",
    info: "bg-blue-50 dark:bg-[#0d141f] border-blue-200 dark:border-blue-900/50",
  };

  const iconClasses = {
    default: "text-primary bg-primary/10",
    success: "text-orange-600 dark:text-orange-400 bg-orange-500/10",
    warning: "text-amber-600 dark:text-amber-400 bg-amber-500/10",
    destructive: "text-red-600 dark:text-red-400 bg-red-500/10",
    info: "text-blue-600 dark:text-blue-400 bg-blue-500/10",
  };

  const isClickable = href || onClick;

  return (
    <Card 
      className={`${cardClasses[variant]} ${isClickable ? "cursor-pointer hover-elevate" : ""}`}
      onClick={onClick}
      data-testid={`stat-card-${title.toLowerCase().replace(/\s+/g, '-')}`}
    >
      <CardContent className="p-6">
        <div className="flex items-start justify-between gap-4">
          <div className="flex flex-col gap-1">
            <span className="text-sm font-medium text-muted-foreground">{title}</span>
            <span className="text-3xl font-bold tracking-tight" data-testid={`stat-${title.toLowerCase().replace(/\s+/g, '-')}`}>
              {typeof value === "number" ? value.toLocaleString() : value}
            </span>
            {subtitle && (
              <span className="text-xs text-muted-foreground">{subtitle}</span>
            )}
          </div>
          <div className={`p-3 rounded-lg ${iconClasses[variant]}`}>
            <Icon className="h-5 w-5" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function ServerCard({ server, activeClients = 0 }: { server: StreamingServer; activeClients?: number }) {
  // Handle both number (1/0/-1) and string ("online"/"offline") status
  const status = String(server.status);
  const isOnline = status === "1" || status === "online" || (server as any).isActive === true;
  const isUnchecked = status === "-1" || status === "unchecked";
  const statusText = isOnline ? "online" : isUnchecked ? "unchecked" : "offline";
  const clientPercent = server.maxClients ? Math.min((activeClients / server.maxClients) * 100, 100) : 0;

  return (
    <Card className="hover-elevate" data-testid={`server-card-${server.id}`}>
      <CardContent className="p-4">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className={`w-2 h-2 rounded-full ${isOnline ? "bg-orange-500" : isUnchecked ? "bg-amber-500" : "bg-red-500"}`} />
            <div>
              <h4 className="font-medium">{server.serverName}</h4>
              <p className="text-xs text-muted-foreground">{server.domainName}</p>
            </div>
          </div>
          <Badge variant={isOnline ? "default" : "secondary"} className="text-xs">
            {statusText}
          </Badge>
        </div>

        <div className="space-y-3">
          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center gap-2 text-muted-foreground">
              <Users className="h-3.5 w-3.5" />
              <span>Active / Max</span>
            </div>
            <span className="font-medium">{activeClients} / {server.maxClients || 1000}</span>
          </div>
          <Progress value={clientPercent} className="h-1.5" />

          <div className="flex items-center justify-between text-sm pt-2 border-t border-border">
            <div className="flex items-center gap-2 text-muted-foreground">
              <Globe className="h-3.5 w-3.5" />
              <span>IP</span>
            </div>
            <span className="font-medium text-xs">{server.serverIp || "N/A"}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function ConnectionRow({ connection }: { connection: any }) {
  const getFlagEmoji = (countryCode: string) => {
    return countryCode ? countryCode.toUpperCase() : "UN";
  };

  return (
    <div className="flex items-center justify-between p-3 rounded-lg bg-muted/30 hover-elevate" data-testid={`connection-${connection.id}`}>
      <div className="flex items-center gap-3">
        <div className="flex h-8 w-8 items-center justify-center rounded-md bg-background text-xs font-mono">
          {getFlagEmoji(connection.countryCode || "")}
        </div>
        <div>
          <p className="text-sm font-medium">{connection.username}</p>
          <p className="text-xs text-muted-foreground">{connection.streamName}</p>
        </div>
      </div>
      <div className="text-right">
        <Badge variant="secondary" className="text-xs">
          {connection.streamType}
        </Badge>
        <p className="text-xs text-muted-foreground mt-1">{connection.ipAddress}</p>
      </div>
    </div>
  );
}

export default function Dashboard() {
  const [, navigate] = useLocation();
  const [isRefreshing, setIsRefreshing] = useState(false);
  const { user } = useAuth();
  const isReseller = user?.role === "reseller";
  
  const { data: stats, isLoading: statsLoading, refetch: refetchStats } = useQuery<DashboardStats>({
    queryKey: ["/api/dashboard/stats"],
    refetchInterval: 5000,
  });

  const { data: servers, isLoading: serversLoading, refetch: refetchServers } = useQuery<StreamingServer[]>({
    queryKey: ["/api/servers"],
    refetchInterval: 10000,
  });

  const { data: connections, isLoading: connectionsLoading, refetch: refetchConnections } = useQuery<any[]>({
    queryKey: ["/api/connections"],
    refetchInterval: 5000,
  });
  
  // Comprehensive refresh that cleans stale connections and reloads all data
  const handleRefresh = async () => {
    setIsRefreshing(true);
    try {
      // First clean stale connections on server
      await fetch("/api/connections/cleanup", { method: "POST", credentials: "include" });
      // Then refetch all data
      await Promise.all([
        refetchStats(),
        refetchServers(),
        refetchConnections(),
      ]);
    } finally {
      setIsRefreshing(false);
    }
  };

  return (
    <div className="p-6 space-y-6">
      {isReseller && (
        <div className="bg-gradient-to-r from-emerald-500 to-teal-600 rounded-lg p-6 text-white">
          <h1 className="text-2xl font-bold">Hello Resellers</h1>
          <p className="text-white/80 mt-1">More options will be added soon.</p>
          <p className="text-white/70 text-sm">Regards</p>
        </div>
      )}
      
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-3xl font-bold tracking-tight" data-testid="page-title">
            {isReseller ? "Overview" : "Dashboard"}
          </h1>
          <p className="text-muted-foreground">
            {isReseller ? "Manage your clients and credits" : "Monitor your streaming infrastructure"}
          </p>
        </div>
        <Button variant="outline" size="sm" onClick={handleRefresh} disabled={isRefreshing} data-testid="button-refresh">
          <RefreshCw className={`h-4 w-4 mr-2 ${isRefreshing ? "animate-spin" : ""}`} />
          {isRefreshing ? "Refreshing..." : "Refresh"}
        </Button>
      </div>

      <div className="grid gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-4">
        {statsLoading ? (
          Array(4).fill(0).map((_, i) => (
            <Card key={i}>
              <CardContent className="p-6">
                <Skeleton className="h-20 w-full" />
              </CardContent>
            </Card>
          ))
        ) : (
          <>
            {isReseller && (
              <StatCard
                title="Credits"
                value={user?.credits || 0}
                subtitle="Available balance"
                icon={CreditCard}
                variant="success"
                onClick={() => navigate("/credits-log")}
              />
            )}
            {isReseller && (
              <StatCard
                title="Online Users"
                value={`${stats?.activeUsers || 0} / ${stats?.totalUsers || 0}`}
                subtitle="Active / Total"
                icon={Users}
                variant={stats?.activeUsers ? "info" : "default"}
                onClick={() => navigate("/users")}
              />
            )}
            {!isReseller && (
              <StatCard
                title="Active Connections"
                value={stats?.totalConnections || 0}
                icon={Zap}
                variant="info"
                onClick={() => navigate("/connections")}
              />
            )}
            {!isReseller && (
              <StatCard
                title="Watching Now"
                value={stats?.activeUsers || 0}
                subtitle={`${stats?.totalUsers || 0} total users`}
                icon={Users}
                variant={stats?.activeUsers ? "success" : "default"}
                onClick={() => navigate("/users")}
              />
            )}
            {!isReseller && (
              <StatCard
                title="Streams Playing"
                value={stats?.activeStreams || 0}
                subtitle={`${stats?.totalStreams || 0} total channels`}
                icon={Play}
                variant={stats?.activeStreams ? "success" : "default"}
                onClick={() => navigate("/streams")}
              />
            )}
            {!isReseller && (
              <StatCard
                title="Servers"
                value={`${stats?.onlineServers || 0} / ${stats?.totalServers || 0}`}
                subtitle={stats?.onlineServers === stats?.totalServers ? "All online" : `${stats?.offlineServers || 0} offline`}
                icon={Server}
                variant={stats?.onlineServers === stats?.totalServers && stats?.totalServers ? "success" : stats?.offlineServers ? "warning" : "default"}
                onClick={() => navigate("/servers")}
              />
            )}
            {!isReseller && (
              <StatCard
                title="Expired Users"
                value={stats?.expiredUsers || 0}
                icon={AlertTriangle}
                variant="warning"
                onClick={() => navigate("/users")}
              />
            )}
            {!isReseller && (
              <StatCard
                title="Banned Users"
                value={stats?.bannedUsers || 0}
                icon={Users}
                variant="destructive"
                onClick={() => navigate("/users")}
              />
            )}
          </>
        )}
      </div>

      {!isReseller && (
        <div className="grid gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-4">
          {statsLoading ? (
            Array(4).fill(0).map((_, i) => (
              <Card key={i}>
                <CardContent className="p-6">
                  <Skeleton className="h-16 w-full" />
                </CardContent>
              </Card>
            ))
          ) : (
            <>
              <StatCard
                title="Live Channels"
                value={stats?.totalStreams || 0}
                icon={Tv}
                onClick={() => navigate("/streams")}
              />
              <StatCard
                title="Movies"
                value={stats?.totalMovies || 0}
                icon={Film}
                onClick={() => navigate("/movies")}
              />
              <StatCard
                title="TV Series"
                value={stats?.totalSeries || 0}
                icon={Activity}
                onClick={() => navigate("/series")}
              />
              <StatCard
                title="Resellers"
                value={stats?.totalResellers || 0}
                icon={Users}
                onClick={() => navigate("/resellers")}
              />
            </>
          )}
        </div>
      )}

      {!isReseller && (
        <div className="space-y-6">
          <NetworkTrafficChart />
          <ConnectionsByLocation />
        </div>
      )}

      <div className="grid gap-6 grid-cols-1 lg:grid-cols-3">
        {!isReseller && (
          <Card className="lg:col-span-2">
            <CardHeader className="flex flex-row items-center justify-between gap-2 pb-4">
              <CardTitle className="text-lg font-semibold">Server Status</CardTitle>
              <Badge variant="outline" className="text-xs">
                {servers?.filter(s => String(s.status) === "1" || String(s.status) === "online" || (s as any).isActive === true).length || 0} online
              </Badge>
            </CardHeader>
            <CardContent>
              {serversLoading ? (
                <div className="grid gap-4 grid-cols-1 md:grid-cols-2">
                  {Array(4).fill(0).map((_, i) => (
                    <Skeleton key={i} className="h-40" />
                  ))}
                </div>
              ) : servers && servers.length > 0 ? (
                <div className="grid gap-4 grid-cols-1 md:grid-cols-2">
                  {servers.slice(0, 4).map((server) => {
                    const serverClients = connections?.filter(c => c.serverId === server.id).length || 0;
                    return <ServerCard key={server.id} server={server} activeClients={serverClients} />;
                  })}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center py-12 text-center">
                  <Server className="h-12 w-12 text-muted-foreground/50 mb-4" />
                  <p className="text-muted-foreground">No servers configured</p>
                  <Button variant="outline" size="sm" className="mt-4" data-testid="button-add-server">
                    Add Server
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        )}

        <Card className={isReseller ? "lg:col-span-3" : ""}>
          <CardHeader className="flex flex-row items-center justify-between gap-2 pb-4">
            <CardTitle className="text-lg font-semibold">Live Connections</CardTitle>
            <Badge variant="outline" className="text-xs">
              {connections?.length || 0} active
            </Badge>
          </CardHeader>
          <CardContent>
            {connectionsLoading ? (
              <div className="space-y-3">
                {Array(5).fill(0).map((_, i) => (
                  <Skeleton key={i} className="h-14" />
                ))}
              </div>
            ) : connections && connections.length > 0 ? (
              <div className="space-y-2 max-h-[400px] overflow-y-auto">
                {connections.slice(0, 10).map((connection) => (
                  <ConnectionRow key={connection.id} connection={connection} />
                ))}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <Wifi className="h-12 w-12 text-muted-foreground/50 mb-4" />
                <p className="text-muted-foreground">No active connections</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
