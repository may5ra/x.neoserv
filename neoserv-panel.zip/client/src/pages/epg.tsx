import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Plus,
  Search,
  MoreHorizontal,
  Edit,
  Trash2,
  Calendar,
  RefreshCw,
  Download,
  ExternalLink,
  Clock,
} from "lucide-react";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { DeleteConfirmation } from "@/components/delete-confirmation";

interface EpgSource {
  id: string;
  name: string;
  url: string;
  isActive: boolean;
  lastUpdated?: string;
  lastUpdate?: string;
  channelCount?: number;
}

const epgFormSchema = z.object({
  name: z.string().min(1, "Name is required"),
  url: z.string().url("Must be a valid URL"),
  isActive: z.boolean(),
});

type EpgFormData = z.infer<typeof epgFormSchema>;

function EpgFormDialog({ 
  epgSource, 
  open, 
  onOpenChange 
}: { 
  epgSource?: EpgSource; 
  open: boolean; 
  onOpenChange: (open: boolean) => void;
}) {
  const { toast } = useToast();
  const isEditing = !!epgSource;

  const form = useForm<EpgFormData>({
    resolver: zodResolver(epgFormSchema),
    defaultValues: {
      name: epgSource?.name || "",
      url: epgSource?.url || "",
      isActive: epgSource?.isActive ?? true,
    },
  });

  const mutation = useMutation({
    mutationFn: async (data: EpgFormData) => {
      if (isEditing) {
        return apiRequest("PATCH", `/api/epg/${epgSource.id}`, data);
      }
      return apiRequest("POST", "/api/epg", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/epg"] });
      toast({
        title: isEditing ? "EPG source updated" : "EPG source created",
      });
      onOpenChange(false);
      form.reset();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to save EPG source",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: EpgFormData) => {
    mutation.mutate(data);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>{isEditing ? "Edit EPG Source" : "Add EPG Source"}</DialogTitle>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Source Name</FormLabel>
                  <FormControl>
                    <Input placeholder="TV Guide UK" {...field} data-testid="input-epg-name" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="url"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>EPG URL (XMLTV format)</FormLabel>
                  <FormControl>
                    <Input placeholder="http://example.com/epg.xml" {...field} data-testid="input-epg-url" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="isActive"
              render={({ field }) => (
                <FormItem className="flex items-center justify-between rounded-lg border p-3">
                  <div>
                    <FormLabel>Active</FormLabel>
                    <p className="text-sm text-muted-foreground">Enable this EPG source</p>
                  </div>
                  <FormControl>
                    <Switch checked={field.value} onCheckedChange={field.onChange} data-testid="switch-epg-active" />
                  </FormControl>
                </FormItem>
              )}
            />
            <div className="flex justify-end gap-2 pt-4">
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
                Cancel
              </Button>
              <Button type="submit" disabled={mutation.isPending} data-testid="button-save-epg">
                {mutation.isPending ? "Saving..." : isEditing ? "Update" : "Create"}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}

export default function EpgPage() {
  const [search, setSearch] = useState("");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingEpg, setEditingEpg] = useState<EpgSource | undefined>();
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [epgToDelete, setEpgToDelete] = useState<EpgSource | null>(null);
  const { toast } = useToast();

  const { data: epgSources, isLoading, refetch } = useQuery<EpgSource[]>({
    queryKey: ["/api/epg"],
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      return apiRequest("DELETE", `/api/epg/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/epg"] });
      toast({ title: "EPG source deleted" });
      setDeleteDialogOpen(false);
      setEpgToDelete(null);
    },
  });

  const handleDeleteClick = (epg: EpgSource) => {
    setEpgToDelete(epg);
    setDeleteDialogOpen(true);
  };

  const confirmDelete = () => {
    if (epgToDelete) {
      deleteMutation.mutate(epgToDelete.id);
    }
  };

  const refreshMutation = useMutation({
    mutationFn: async (id: string) => {
      console.log("Refreshing EPG:", id);
      return apiRequest("POST", `/api/epg/${id}/refresh`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/epg"] });
      toast({ title: "EPG refresh started" });
    },
    onError: (error: Error) => {
      console.error("EPG refresh error:", error);
      toast({ title: "EPG refresh failed", description: error.message, variant: "destructive" });
    },
  });

  const filteredEpgSources = epgSources?.filter(epg => 
    epg.name.toLowerCase().includes(search.toLowerCase()) ||
    epg.url.toLowerCase().includes(search.toLowerCase())
  );

  const activeCount = epgSources?.filter(e => e.isActive).length || 0;

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-3xl font-bold tracking-tight" data-testid="page-title">EPG Sources</h1>
          <p className="text-muted-foreground">Manage Electronic Program Guide data</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={() => refetch()} data-testid="button-refresh-all-epg">
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh All
          </Button>
          <Button onClick={() => { setEditingEpg(undefined); setDialogOpen(true); }} data-testid="button-add-epg">
            <Plus className="h-4 w-4 mr-2" />
            Add Source
          </Button>
        </div>
      </div>

      <div className="grid gap-4 grid-cols-1 sm:grid-cols-3">
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 rounded-lg bg-primary/10">
              <Calendar className="h-5 w-5 text-primary" />
            </div>
            <div>
              <p className="text-2xl font-bold">{epgSources?.length || 0}</p>
              <p className="text-sm text-muted-foreground">Total Sources</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 rounded-lg bg-emerald-500/10">
              <Download className="h-5 w-5 text-emerald-500" />
            </div>
            <div>
              <p className="text-2xl font-bold">{activeCount}</p>
              <p className="text-sm text-muted-foreground">Active</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 rounded-lg bg-blue-500/10">
              <Clock className="h-5 w-5 text-blue-500" />
            </div>
            <div>
              <p className="text-2xl font-bold">24h</p>
              <p className="text-sm text-muted-foreground">Update Interval</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between gap-4 pb-4">
          <CardTitle>EPG Sources</CardTitle>
          <div className="relative w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search sources..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-9"
              data-testid="input-search-epg"
            />
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-2">
              {Array(3).fill(0).map((_, i) => (
                <Skeleton key={i} className="h-12 w-full" />
              ))}
            </div>
          ) : filteredEpgSources && filteredEpgSources.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>URL</TableHead>
                  <TableHead>Last Update</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredEpgSources.map((epg) => (
                  <TableRow key={epg.id} data-testid={`epg-row-${epg.id}`}>
                    <TableCell className="font-medium">
                      <div className="flex items-center gap-2">
                        <Calendar className="h-4 w-4 text-muted-foreground" />
                        {epg.name}
                      </div>
                    </TableCell>
                    <TableCell className="max-w-[200px]">
                      <span className="text-sm text-muted-foreground truncate block font-mono">
                        {epg.url}
                      </span>
                    </TableCell>
                    <TableCell className="text-muted-foreground">
                      {epg.lastUpdate || "Never"}
                    </TableCell>
                    <TableCell>
                      <Badge variant={epg.isActive ? "default" : "secondary"}>
                        {epg.isActive ? "Active" : "Inactive"}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" data-testid={`button-epg-menu-${epg.id}`}>
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem 
                            onClick={(e) => {
                              e.preventDefault();
                              e.stopPropagation();
                              console.log("EPG Refresh clicked, ID:", epg.id);
                              refreshMutation.mutate(String(epg.id));
                            }}
                          >
                            <RefreshCw className="h-4 w-4 mr-2" />
                            Refresh Now
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => window.open(epg.url, "_blank")}>
                            <ExternalLink className="h-4 w-4 mr-2" />
                            View Source
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => { setEditingEpg(epg); setDialogOpen(true); }}>
                            <Edit className="h-4 w-4 mr-2" />
                            Edit
                          </DropdownMenuItem>
                          <DropdownMenuItem 
                            onClick={() => handleDeleteClick(epg)}
                            className="text-destructive"
                          >
                            <Trash2 className="h-4 w-4 mr-2" />
                            Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <Calendar className="h-12 w-12 text-muted-foreground/50 mb-4" />
              <p className="text-muted-foreground">No EPG sources configured</p>
              <Button 
                variant="outline" 
                size="sm" 
                className="mt-4"
                onClick={() => { setEditingEpg(undefined); setDialogOpen(true); }}
              >
                Add your first EPG source
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      <EpgFormDialog 
        epgSource={editingEpg} 
        open={dialogOpen} 
        onOpenChange={setDialogOpen} 
      />

      <DeleteConfirmation
        open={deleteDialogOpen}
        onOpenChange={setDeleteDialogOpen}
        onConfirm={confirmDelete}
        title="Delete EPG Source"
        itemName={epgToDelete?.name}
      />
    </div>
  );
}
