import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { Key, CheckCircle2, Copy, Trash2, Loader2, AlertCircle, Shield, Eye, EyeOff, Monitor, Calendar, Clock, Mail, Server, RotateCcw, CalendarPlus } from "lucide-react";
import type { License } from "@shared/schema";

interface LicenseStatus {
  licensed: boolean;
  licenseType?: string;
  status?: string;
  expiresAt?: number;
  daysRemaining?: number | null;
  email?: string;
  requiresActivation?: boolean;
  licenseKey?: string;
  activatedAt?: number;
}

export default function LicensePage() {
  const { toast } = useToast();
  const [clientEmail, setClientEmail] = useState("");
  const [durationDays, setDurationDays] = useState("30");
  const [activationDialogOpen, setActivationDialogOpen] = useState(false);
  const [activationKey, setActivationKey] = useState("");
  const [showLicenseKey, setShowLicenseKey] = useState(false);
  const [clientPreviewMode, setClientPreviewMode] = useState(false);
  const [developerKeyInput, setDeveloperKeyInput] = useState("");
  const [showDeveloperMode, setShowDeveloperMode] = useState(false);
  const [extendDialogOpen, setExtendDialogOpen] = useState(false);
  const [extendLicenseId, setExtendLicenseId] = useState<number | null>(null);
  const [extendDays, setExtendDays] = useState("30");

  const { data: licenseStatus, isLoading: statusLoading } = useQuery<LicenseStatus>({
    queryKey: ["/api/license/status"],
  });

  const { data: licenses = [], isLoading: licensesLoading } = useQuery<License[]>({
    queryKey: ["/api/licenses"],
    enabled: licenseStatus?.licenseType === "developer",
  });

  const generateMutation = useMutation({
    mutationFn: async (data: { email: string; durationDays: number }) => {
      const res = await apiRequest("POST", "/api/licenses/generate", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/licenses"] });
      setClientEmail("");
      toast({
        title: "License Generated",
        description: "New license key has been created successfully.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to generate license",
        variant: "destructive",
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/licenses/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/licenses"] });
      toast({
        title: "License Deleted",
        description: "License has been removed.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete license",
        variant: "destructive",
      });
    },
  });

  const resetBindingMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await apiRequest("POST", `/api/licenses/${id}/reset-binding`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/licenses"] });
      toast({
        title: "Binding Reset",
        description: "License can now be activated on a new server.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to reset license binding",
        variant: "destructive",
      });
    },
  });

  const extendMutation = useMutation({
    mutationFn: async ({ id, days }: { id: number; days: number }) => {
      const res = await apiRequest("POST", `/api/licenses/${id}/extend`, { days });
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/licenses"] });
      setExtendDialogOpen(false);
      setExtendLicenseId(null);
      toast({
        title: "License Extended",
        description: data.message || "License has been extended successfully.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to extend license",
        variant: "destructive",
      });
    },
  });

  const activateMutation = useMutation({
    mutationFn: async (licenseKey: string) => {
      const res = await apiRequest("POST", "/api/license/activate", { licenseKey });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/license/status"] });
      setActivationDialogOpen(false);
      setActivationKey("");
      toast({
        title: "License Activated",
        description: "Your panel is now licensed.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Activation Failed",
        description: error.message || "Invalid license key",
        variant: "destructive",
      });
    },
  });

  const seedDevMutation = useMutation({
    mutationFn: async (developerKey?: string) => {
      const res = await apiRequest("POST", "/api/license/seed-developer", 
        developerKey ? { developerKey } : undefined
      );
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/license/status"] });
      queryClient.invalidateQueries({ queryKey: ["/api/licenses"] });
      setDeveloperKeyInput("");
      toast({
        title: "Developer License Created",
        description: `Your license key: ${data.license.licenseKey}`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create developer license",
        variant: "destructive",
      });
    },
  });

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied",
      description: "License key copied to clipboard",
    });
  };

  const handleGenerate = () => {
    if (!clientEmail.trim()) {
      toast({
        title: "Error",
        description: "Please enter a client email",
        variant: "destructive",
      });
      return;
    }
    generateMutation.mutate({
      email: clientEmail,
      durationDays: parseInt(durationDays),
    });
  };

  const formatDate = (timestamp: number | null | undefined) => {
    if (!timestamp) return "Never";
    return new Date(timestamp * 1000).toLocaleDateString();
  };

  const getStatusBadge = (license: License) => {
    const now = Math.floor(Date.now() / 1000);
    if (license.status === "revoked") {
      return <Badge variant="destructive">Revoked</Badge>;
    }
    if (license.expiresAt && now > license.expiresAt) {
      return <Badge variant="destructive">Expired</Badge>;
    }
    if (license.status === "active") {
      return <Badge className="bg-orange-500 hover:bg-orange-600 text-white">Available</Badge>;
    }
    return <Badge variant="secondary">{license.status}</Badge>;
  };

  if (statusLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <Loader2 className="h-8 w-8 animate-spin text-orange-500" />
      </div>
    );
  }

  // Check if no license or requires activation
  if (!licenseStatus?.licensed) {
    return (
      <div className="space-y-6 p-6">
        <Card className="max-w-lg mx-auto">
          <CardHeader className="text-center">
            <div className="mx-auto w-16 h-16 bg-orange-100 dark:bg-orange-900/30 rounded-full flex items-center justify-center mb-4">
              <AlertCircle className="h-8 w-8 text-orange-500" />
            </div>
            <CardTitle>License Required</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Tabs defaultValue="client" className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="client" data-testid="tab-client-activation">Client</TabsTrigger>
                <TabsTrigger value="developer" data-testid="tab-developer-activation">Developer</TabsTrigger>
              </TabsList>
              
              {/* Client Activation Tab */}
              <TabsContent value="client" className="space-y-4 mt-4">
                <p className="text-center text-muted-foreground text-sm">
                  Enter the license key provided by your administrator.
                </p>
                <div className="space-y-2">
                  <Label htmlFor="license-key">License Key</Label>
                  <Input
                    id="license-key"
                    placeholder="NEO-XXXX-XXXX-XXXX-XXXX"
                    value={activationKey}
                    onChange={(e) => setActivationKey(e.target.value)}
                    data-testid="input-license-key"
                  />
                </div>
                <Button
                  className="w-full bg-orange-500 hover:bg-orange-600"
                  onClick={() => activateMutation.mutate(activationKey)}
                  disabled={activateMutation.isPending || !activationKey.trim()}
                  data-testid="button-activate-license"
                >
                  {activateMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  Activate License
                </Button>
              </TabsContent>
              
              {/* Developer Activation Tab */}
              <TabsContent value="developer" className="space-y-4 mt-4">
                <p className="text-center text-muted-foreground text-sm">
                  Create a developer license using your secret developer key.
                </p>
                <div className="space-y-2">
                  <Label htmlFor="developer-key">Developer Key</Label>
                  <Input
                    id="developer-key"
                    type="password"
                    placeholder="Enter your developer key"
                    value={developerKeyInput}
                    onChange={(e) => setDeveloperKeyInput(e.target.value)}
                    data-testid="input-developer-key"
                  />
                  <p className="text-xs text-muted-foreground">
                    Set DEVELOPER_KEY in your .env file to enable developer activation.
                  </p>
                </div>
                <Button
                  className="w-full bg-orange-500 hover:bg-orange-600"
                  onClick={() => seedDevMutation.mutate(developerKeyInput || undefined)}
                  disabled={seedDevMutation.isPending || !developerKeyInput.trim()}
                  data-testid="button-create-dev-license"
                >
                  {seedDevMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  Create Developer License
                </Button>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    );
  }

  const isDeveloper = licenseStatus.licenseType === "developer";
  const showAsClient = clientPreviewMode && isDeveloper;

  // Simulate client license for preview
  const previewClientLicense = licenses.find(l => l.licenseType === 'client');
  const previewDaysRemaining = previewClientLicense?.expiresAt 
    ? Math.ceil((previewClientLicense.expiresAt - Math.floor(Date.now() / 1000)) / 86400)
    : 30;

  return (
    <div className="space-y-6 p-6">
      {/* Client Preview Toggle (only for developers) */}
      {isDeveloper && (
        <div className="flex justify-end">
          <Button
            variant={clientPreviewMode ? "default" : "outline"}
            size="sm"
            onClick={() => setClientPreviewMode(!clientPreviewMode)}
            className={clientPreviewMode ? "bg-orange-500 hover:bg-orange-600" : ""}
            data-testid="button-client-preview"
          >
            <Monitor className="h-4 w-4 mr-2" />
            {clientPreviewMode ? "Exit Client Preview" : "Client Preview"}
          </Button>
        </div>
      )}

      {/* License Status Card */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-orange-100 dark:bg-orange-900/30 rounded-lg">
              <Key className="h-5 w-5 text-orange-500" />
            </div>
            <CardTitle>License Status</CardTitle>
          </div>
          <Badge className="bg-orange-500 hover:bg-orange-600 text-white">
            <Shield className="h-3 w-3 mr-1" />
            {showAsClient ? "Client" : (isDeveloper ? "Developer" : "Client")}
          </Badge>
        </CardHeader>
        <CardContent>
          {/* Developer View */}
          {isDeveloper && !showAsClient && (
            <div className="flex flex-col items-center py-8">
              <div className="w-24 h-24 rounded-full bg-orange-100 dark:bg-orange-900/30 flex items-center justify-center mb-6">
                <CheckCircle2 className="h-12 w-12 text-orange-500" />
              </div>
              <h2 className="text-2xl font-bold mb-1">Developer</h2>
              <p className="text-muted-foreground mb-4">Developer License - Unlimited Access</p>
              {/* Show developer license key with hide/show toggle */}
              {licenses.find(l => l.licenseType === 'developer') && (
                <div className="flex items-center gap-2 bg-muted px-4 py-2 rounded-lg">
                  <span className="font-mono text-sm">
                    {showLicenseKey 
                      ? licenses.find(l => l.licenseType === 'developer')?.licenseKey
                      : "NEO-****-****-****-****"}
                  </span>
                  <Button
                    size="icon"
                    variant="ghost"
                    onClick={() => setShowLicenseKey(!showLicenseKey)}
                    data-testid="button-toggle-license-visibility"
                  >
                    {showLicenseKey ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </Button>
                  <Button
                    size="icon"
                    variant="ghost"
                    onClick={() => copyToClipboard(licenses.find(l => l.licenseType === 'developer')?.licenseKey || '')}
                    data-testid="button-copy-dev-license"
                  >
                    <Copy className="h-4 w-4" />
                  </Button>
                </div>
              )}
            </div>
          )}

          {/* Client View (or Developer Preview as Client) */}
          {(showAsClient || (!isDeveloper && licenseStatus.licenseType === 'client')) && (() => {
            const clientLicense = showAsClient ? previewClientLicense : null;
            const clientEmail = showAsClient ? (clientLicense?.email || "client@example.com") : licenseStatus.email;
            // Mask license key for security - show only last 4 characters
            const rawKey = showAsClient ? (clientLicense?.licenseKey || "NEO-XXXX-XXXX-XXXX-XXXX") : licenseStatus.licenseKey;
            const clientKey = rawKey ? 'NEO-****-****-****-' + rawKey.slice(-4) : 'NEO-****-****-****-****';
            const clientActivatedAt = showAsClient ? (clientLicense?.activatedAt || Math.floor(Date.now() / 1000)) : licenseStatus.activatedAt;
            const clientExpiresAt = showAsClient ? (clientLicense?.expiresAt || Math.floor(Date.now() / 1000) + 30 * 86400) : licenseStatus.expiresAt;
            const clientDaysRemaining = showAsClient ? previewDaysRemaining : (licenseStatus.daysRemaining ?? 0);
            
            const formatDate = (timestamp: number | undefined) => {
              if (!timestamp) return "N/A";
              return new Date(timestamp * 1000).toLocaleDateString('en-US', {
                year: 'numeric',
                month: 'long',
                day: 'numeric'
              });
            };

            return (
              <div className="py-6 space-y-6">
                {/* Status Header */}
                <div className="flex flex-col items-center">
                  <div className="w-20 h-20 rounded-full bg-orange-100 dark:bg-orange-900/30 flex items-center justify-center mb-4">
                    <CheckCircle2 className="h-10 w-10 text-orange-500" />
                  </div>
                  <h2 className="text-xl font-bold">Client License</h2>
                  <div className="mt-2 px-4 py-2 bg-orange-100 dark:bg-orange-900/30 rounded-full">
                    <span className="text-2xl font-bold text-orange-600 dark:text-orange-400">
                      {clientDaysRemaining} days remaining
                    </span>
                  </div>
                </div>

                {/* License Details Grid */}
                <div className="grid gap-4 md:grid-cols-2">
                  {/* Email */}
                  <div className="flex items-center gap-3 p-4 bg-muted rounded-lg">
                    <Mail className="h-5 w-5 text-orange-500 shrink-0" />
                    <div>
                      <p className="text-xs text-muted-foreground">Registration Email</p>
                      <p className="font-medium">{clientEmail}</p>
                    </div>
                  </div>

                  {/* License Key (non-copyable) */}
                  <div className="flex items-center gap-3 p-4 bg-muted rounded-lg">
                    <Key className="h-5 w-5 text-orange-500 shrink-0" />
                    <div>
                      <p className="text-xs text-muted-foreground">License Key</p>
                      <p className="font-mono text-sm select-none" style={{ userSelect: 'none' }}>
                        {clientKey}
                      </p>
                    </div>
                  </div>

                  {/* Activation Date */}
                  <div className="flex items-center gap-3 p-4 bg-muted rounded-lg">
                    <Calendar className="h-5 w-5 text-orange-500 shrink-0" />
                    <div>
                      <p className="text-xs text-muted-foreground">Activation Date</p>
                      <p className="font-medium">{formatDate(clientActivatedAt)}</p>
                    </div>
                  </div>

                  {/* Expiration Date */}
                  <div className="flex items-center gap-3 p-4 bg-muted rounded-lg">
                    <Clock className="h-5 w-5 text-orange-500 shrink-0" />
                    <div>
                      <p className="text-xs text-muted-foreground">Expiration Date</p>
                      <p className="font-medium">{formatDate(clientExpiresAt)}</p>
                    </div>
                  </div>
                </div>

                {/* Warning if expiring soon */}
                {clientDaysRemaining <= 7 && clientDaysRemaining > 0 && (
                  <div className="flex items-center gap-2 p-4 bg-orange-100 dark:bg-orange-900/30 rounded-lg text-orange-700 dark:text-orange-300">
                    <AlertCircle className="h-5 w-5" />
                    <p className="text-sm font-medium">Your license expires soon. Please contact your administrator for renewal.</p>
                  </div>
                )}

                {/* License Terms Warning */}
                <div className="mt-6 p-4 border border-destructive/30 bg-destructive/5 rounded-lg">
                  <div className="flex items-start gap-3">
                    <AlertCircle className="h-5 w-5 text-destructive shrink-0 mt-0.5" />
                    <div className="space-y-2">
                      <h4 className="font-semibold text-destructive">Important License Terms</h4>
                      <ul className="text-sm text-muted-foreground space-y-1.5 list-disc list-inside">
                        <li>This license is <span className="font-medium text-foreground">non-transferable</span> and bound to a single server</li>
                        <li>You <span className="font-medium text-foreground">cannot sell, share, or give</span> your license key to anyone</li>
                        <li>Using this license on <span className="font-medium text-foreground">multiple servers is prohibited</span></li>
                        <li>Attempting to activate on a different server will <span className="font-medium text-foreground">fail and may result in license revocation</span></li>
                      </ul>
                      <p className="text-xs text-muted-foreground pt-2 border-t border-destructive/20">
                        Violation of these terms will result in immediate and permanent license termination without refund. 
                        All license activations are logged and monitored.
                      </p>
                      <p className="text-xs text-orange-500 font-medium pt-2 text-right">
                        X NeoServ Software
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            );
          })()}
        </CardContent>
      </Card>

      {/* Developer License Features (hidden in client preview mode) */}
      {isDeveloper && !showAsClient && (
        <>
          {/* Generate License Card */}
          <Card>
            <CardHeader>
              <div className="flex items-center gap-2">
                <Key className="h-5 w-5 text-orange-500" />
                <CardTitle className="text-lg">Generate free license (30 days)</CardTitle>
              </div>
              <p className="text-sm text-muted-foreground mt-1">
                As a developer you can generate free 30-day licenses for clients.
              </p>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-4 items-end">
                <div className="flex-1 min-w-[200px]">
                  <Input
                    placeholder="Client email..."
                    value={clientEmail}
                    onChange={(e) => setClientEmail(e.target.value)}
                    data-testid="input-client-email"
                  />
                </div>
                <Select value={durationDays} onValueChange={setDurationDays}>
                  <SelectTrigger className="w-[140px]" data-testid="select-duration">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="7">7 days</SelectItem>
                    <SelectItem value="14">14 days</SelectItem>
                    <SelectItem value="30">30 days</SelectItem>
                    <SelectItem value="60">60 days</SelectItem>
                    <SelectItem value="90">90 days</SelectItem>
                    <SelectItem value="180">180 days</SelectItem>
                    <SelectItem value="365">365 days</SelectItem>
                  </SelectContent>
                </Select>
                <Button
                  className="bg-orange-500 hover:bg-orange-600"
                  onClick={handleGenerate}
                  disabled={generateMutation.isPending}
                  data-testid="button-generate-license"
                >
                  {generateMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  <Key className="mr-2 h-4 w-4" />
                  Generate
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Generated Licenses Table */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Generated License Keys</CardTitle>
            </CardHeader>
            <CardContent>
              {licensesLoading ? (
                <div className="flex justify-center py-8">
                  <Loader2 className="h-8 w-8 animate-spin text-orange-500" />
                </div>
              ) : licenses.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  No licenses generated yet. Use the form above to create license keys for clients.
                </div>
              ) : (
                <div className="rounded-md border overflow-hidden">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Key</TableHead>
                        <TableHead>Email</TableHead>
                        <TableHead>Duration</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Server Binding</TableHead>
                        <TableHead>Created</TableHead>
                        <TableHead className="w-[120px]">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {licenses.filter(l => l.licenseType !== 'developer').map((license) => (
                        <TableRow key={license.id} data-testid={`row-license-${license.id}`}>
                          <TableCell className="font-mono text-sm">
                            <div className="flex items-center gap-2">
                              {license.licenseKey}
                              <Button
                                size="icon"
                                variant="ghost"
                                onClick={() => copyToClipboard(license.licenseKey)}
                                data-testid={`button-copy-${license.id}`}
                              >
                                <Copy className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                          <TableCell>{license.email}</TableCell>
                          <TableCell>{license.durationDays} days</TableCell>
                          <TableCell>{getStatusBadge(license)}</TableCell>
                          <TableCell>
                            {license.boundServerId ? (
                              <div className="flex items-center gap-1">
                                <Badge variant="outline" className="text-xs">
                                  <Server className="h-3 w-3 mr-1" />
                                  Bound
                                </Badge>
                              </div>
                            ) : (
                              <Badge variant="secondary" className="text-xs">Unbound</Badge>
                            )}
                          </TableCell>
                          <TableCell>{formatDate(license.createdAt)}</TableCell>
                          <TableCell>
                            <div className="flex items-center gap-1">
                              <Button
                                size="icon"
                                variant="ghost"
                                className="text-green-500 hover:text-green-600"
                                onClick={() => {
                                  setExtendLicenseId(license.id);
                                  setExtendDialogOpen(true);
                                }}
                                title="Extend license"
                                data-testid={`button-extend-${license.id}`}
                              >
                                <CalendarPlus className="h-4 w-4" />
                              </Button>
                              {license.boundServerId && (
                                <Button
                                  size="icon"
                                  variant="ghost"
                                  className="text-orange-500 hover:text-orange-600"
                                  onClick={() => resetBindingMutation.mutate(license.id)}
                                  disabled={resetBindingMutation.isPending}
                                  title="Reset server binding"
                                  data-testid={`button-reset-${license.id}`}
                                >
                                  <RotateCcw className="h-4 w-4" />
                                </Button>
                              )}
                              <Button
                                size="icon"
                                variant="ghost"
                                className="text-destructive hover:text-destructive"
                                onClick={() => deleteMutation.mutate(license.id)}
                                disabled={deleteMutation.isPending}
                                data-testid={`button-delete-${license.id}`}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </>
      )}

      {/* Activation Dialog */}
      <Dialog open={activationDialogOpen} onOpenChange={setActivationDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Activate License</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>License Key</Label>
              <Input
                placeholder="NEO-XXXX-XXXX-XXXX-XXXX"
                value={activationKey}
                onChange={(e) => setActivationKey(e.target.value)}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setActivationDialogOpen(false)}>
              Cancel
            </Button>
            <Button
              className="bg-orange-500 hover:bg-orange-600"
              onClick={() => activateMutation.mutate(activationKey)}
              disabled={activateMutation.isPending}
            >
              {activateMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Activate
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Extend License Dialog */}
      <Dialog open={extendDialogOpen} onOpenChange={setExtendDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Extend License</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Add more days to this license. The new expiration will be calculated from the current expiration date (or from today if already expired).
            </p>
            <div className="space-y-2">
              <Label>Duration to Add</Label>
              <Select value={extendDays} onValueChange={setExtendDays}>
                <SelectTrigger data-testid="select-extend-duration">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="7">7 days</SelectItem>
                  <SelectItem value="14">14 days</SelectItem>
                  <SelectItem value="30">30 days</SelectItem>
                  <SelectItem value="60">60 days</SelectItem>
                  <SelectItem value="90">90 days</SelectItem>
                  <SelectItem value="180">180 days</SelectItem>
                  <SelectItem value="365">365 days</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setExtendDialogOpen(false)}>
              Cancel
            </Button>
            <Button
              className="bg-green-500 hover:bg-green-600"
              onClick={() => {
                if (extendLicenseId) {
                  extendMutation.mutate({ id: extendLicenseId, days: parseInt(extendDays) });
                }
              }}
              disabled={extendMutation.isPending}
              data-testid="button-confirm-extend"
            >
              {extendMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              <CalendarPlus className="mr-2 h-4 w-4" />
              Extend
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
