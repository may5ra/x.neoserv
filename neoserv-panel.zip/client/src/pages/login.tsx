import { useState, useEffect } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest, queryClient, setAuthToken, clearAuthToken } from "@/lib/queryClient";

interface Branding {
  panelName: string;
  panelLogoUrl: string;
}
import { useAuth } from "@/App";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { Radio, Loader2, Eye, EyeOff, Shield, ArrowLeft } from "lucide-react";

export default function Login() {
  const { toast } = useToast();
  const { refetch } = useAuth();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [requires2FA, setRequires2FA] = useState(false);
  const [twoFactorCode, setTwoFactorCode] = useState("");
  const [honeypot, setHoneypot] = useState("");
  
  const { data: branding } = useQuery<Branding>({
    queryKey: ["/api/branding"],
    staleTime: 0,
    refetchOnMount: true,
    refetchOnWindowFocus: true,
  });
  const panelName = branding?.panelName || "X NeoServ";
  const panelLogoUrl = branding?.panelLogoUrl || "";

  useEffect(() => {
    document.documentElement.classList.add("dark");
    return () => {
      const savedTheme = localStorage.getItem("theme");
      if (savedTheme === "light") {
        document.documentElement.classList.remove("dark");
      }
    };
  }, []);

  const loginMutation = useMutation({
    mutationFn: async (credentials: { username: string; password: string }) => {
      const response = await apiRequest("POST", "/api/auth/login", credentials);
      return response.json();
    },
    onSuccess: async (data) => {
      if (data.requires2FA) {
        setRequires2FA(true);
        toast({
          title: "2FA Required",
          description: "Please enter your authenticator code",
        });
        return;
      }
      
      if (data.token) {
        clearAuthToken();
        setAuthToken(data.token);
      }
      toast({
        title: "Welcome back!",
        description: `Logged in as ${data.username}`,
      });
      await queryClient.resetQueries({ queryKey: ["/api/auth/me"] });
      refetch();
    },
    onError: (error: any) => {
      toast({
        title: "Login failed",
        description: error.message || "Invalid username or password",
        variant: "destructive",
      });
    },
  });

  const verify2FAMutation = useMutation({
    mutationFn: async (data: { username: string; password: string; token: string }) => {
      const response = await apiRequest("POST", "/api/auth/2fa/verify", data);
      return response.json();
    },
    onSuccess: async (data) => {
      if (data.token) {
        clearAuthToken();
        setAuthToken(data.token);
      }
      toast({
        title: "Welcome back!",
        description: `Logged in as ${data.username}`,
      });
      await queryClient.resetQueries({ queryKey: ["/api/auth/me"] });
      refetch();
    },
    onError: (error: any) => {
      toast({
        title: "Verification failed",
        description: error.message || "Invalid 2FA code",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (honeypot) {
      console.log("[Security] Honeypot triggered");
      return;
    }
    
    if (!username || !password) {
      toast({
        title: "Missing credentials",
        description: "Please enter both username and password",
        variant: "destructive",
      });
      return;
    }
    loginMutation.mutate({ username, password });
  };

  const handle2FASubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!twoFactorCode || twoFactorCode.length !== 6) {
      toast({
        title: "Invalid code",
        description: "Please enter a 6-digit code",
        variant: "destructive",
      });
      return;
    }
    
    verify2FAMutation.mutate({ username, password, token: twoFactorCode });
  };

  const handleBack = () => {
    setRequires2FA(false);
    setTwoFactorCode("");
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#0c0f14] p-4 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-orange-500/3 via-transparent to-rose-500/3" />
      <div className="absolute top-1/3 left-1/3 w-80 h-80 bg-orange-500/5 rounded-full blur-3xl" />
      <div className="absolute bottom-1/3 right-1/3 w-80 h-80 bg-rose-500/5 rounded-full blur-3xl" />
      
      <Card className="w-full max-w-md relative z-10 bg-[#13161c] border-[#1e2330] shadow-2xl">
        <CardHeader className="text-center pb-2">
          <div className="flex flex-col items-center mb-4">
            {panelLogoUrl ? (
              <img src={panelLogoUrl} alt={panelName} className="h-24 w-auto object-contain mb-4" />
            ) : (
              <div className="flex h-20 w-20 items-center justify-center rounded-2xl bg-gradient-to-br from-orange-500 to-rose-500 shadow-lg shadow-orange-500/25 mb-4">
                {requires2FA ? (
                  <Shield className="h-10 w-10 text-white" />
                ) : (
                  <Radio className="h-10 w-10 text-white" />
                )}
              </div>
            )}
            <CardTitle className="text-3xl font-bold tracking-tight bg-gradient-to-r from-orange-400 to-rose-400 bg-clip-text text-transparent">
              {requires2FA ? "Two-Factor Auth" : panelName}
            </CardTitle>
          </div>
          <CardDescription className="text-[#8b949e]">
            {requires2FA 
              ? "Enter the 6-digit code from your authenticator app"
              : "Sign in to access your streaming dashboard"
            }
          </CardDescription>
        </CardHeader>
        <CardContent className="pt-6">
          {requires2FA ? (
            <form onSubmit={handle2FASubmit} className="space-y-5">
              <div className="space-y-2">
                <Label htmlFor="2fa-code" className="text-[#c9d1d9]">Authentication Code</Label>
                <Input
                  id="2fa-code"
                  data-testid="input-2fa-code"
                  type="text"
                  inputMode="numeric"
                  pattern="[0-9]*"
                  maxLength={6}
                  placeholder="000000"
                  value={twoFactorCode}
                  onChange={(e) => setTwoFactorCode(e.target.value.replace(/\D/g, "").slice(0, 6))}
                  autoComplete="one-time-code"
                  autoFocus
                  className="bg-[#0c0f14] border-[#1e2330] text-[#e2e8f0] placeholder:text-[#4a5568] focus:border-orange-500 focus:ring-orange-500/20 h-11 text-center text-2xl tracking-[0.5em] font-mono"
                />
              </div>
              <div className="flex gap-2">
                <Button
                  type="button"
                  variant="outline"
                  onClick={handleBack}
                  className="h-11 border-[#1e2330] text-[#c9d1d9]"
                  data-testid="button-back"
                >
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Back
                </Button>
                <Button
                  type="submit"
                  className="flex-1 h-11 bg-gradient-to-r from-orange-500 to-rose-500 hover:from-orange-600 hover:to-rose-600 text-white font-medium shadow-lg shadow-orange-500/25 border-0"
                  disabled={verify2FAMutation.isPending || twoFactorCode.length !== 6}
                  data-testid="button-verify-2fa"
                >
                  {verify2FAMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Verifying...
                    </>
                  ) : (
                    "Verify"
                  )}
                </Button>
              </div>
            </form>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-5">
              {/* Honeypot field - hidden from users, catches bots */}
              <input
                type="text"
                name="website"
                value={honeypot}
                onChange={(e) => setHoneypot(e.target.value)}
                tabIndex={-1}
                autoComplete="off"
                style={{ position: "absolute", left: "-9999px", opacity: 0 }}
              />
              
              <div className="space-y-2">
                <Label htmlFor="username" className="text-[#c9d1d9]">Username</Label>
                <Input
                  id="username"
                  data-testid="input-username"
                  type="text"
                  placeholder="Enter your username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  autoComplete="username"
                  className="bg-[#0c0f14] border-[#1e2330] text-[#e2e8f0] placeholder:text-[#4a5568] focus:border-orange-500 focus:ring-orange-500/20 h-11"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password" className="text-[#c9d1d9]">Password</Label>
                <div className="relative">
                  <Input
                    id="password"
                    data-testid="input-password"
                    type={showPassword ? "text" : "password"}
                    placeholder="Enter your password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    autoComplete="current-password"
                    className="bg-[#0c0f14] border-[#1e2330] text-[#e2e8f0] placeholder:text-[#4a5568] focus:border-orange-500 focus:ring-orange-500/20 h-11 pr-10"
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    className="absolute right-0 top-0 h-11 w-11 text-[#8b949e] hover:text-[#c9d1d9] hover:bg-transparent"
                    onClick={() => setShowPassword(!showPassword)}
                    data-testid="button-toggle-password"
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </Button>
                </div>
              </div>
              <Button
                type="submit"
                className="w-full h-11 bg-gradient-to-r from-orange-500 to-rose-500 hover:from-orange-600 hover:to-rose-600 text-white font-medium shadow-lg shadow-orange-500/25 border-0"
                disabled={loginMutation.isPending}
                data-testid="button-login"
              >
                {loginMutation.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Signing in...
                  </>
                ) : (
                  "Sign in"
                )}
              </Button>
            </form>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
