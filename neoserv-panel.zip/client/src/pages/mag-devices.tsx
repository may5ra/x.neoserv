import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { useAuth } from "@/App";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
  FormDescription,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Plus,
  MoreHorizontal,
  Edit,
  Trash2,
  Monitor,
  Search,
  Copy,
  Link,
} from "lucide-react";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { DeleteConfirmation } from "@/components/delete-confirmation";
import type { MagDevice as MagDeviceBase, User, Bouquet } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";

type MagDevice = Omit<MagDeviceBase, 'bouquetIds'> & {
  bouquetIds: number[];
};

const magDeviceFormSchema = z.object({
  mac: z.string().min(12, "MAC address is required").max(50),
  userId: z.coerce.number().default(0),
  expiry: z.string().default(""),
  duration: z.coerce.number().default(30),
  isTrial: z.boolean().default(false),
  testDuration: z.string().default("24"),
  lockDevice: z.boolean().default(false),
  lockToIsp: z.boolean().default(false),
  playbackLimit: z.coerce.number().min(1).max(10).default(1),
  adminNotes: z.string().default(""),
  resellerNotes: z.string().default(""),
  bouquetIds: z.array(z.number()).default([]),
});

// Fallback duration options (used when API not available)
const FALLBACK_DURATION_OPTIONS = [
  { label: "1 Month", days: 30, multiplier: 1 },
  { label: "3 Months", days: 90, multiplier: 3 },
  { label: "6 Months", days: 180, multiplier: 6 },
  { label: "1 Year", days: 365, multiplier: 12 },
];

interface DurationOption {
  label: string;
  days: number;
  multiplier: number;
}

const TEST_DURATION_OPTIONS = [
  { value: "24", label: "24 Hours", hours: 24 },
  { value: "48", label: "48 Hours", hours: 48 },
  { value: "72", label: "72 Hours", hours: 72 },
];

function formatMacAddress(value: string): string {
  const cleaned = value.replace(/[^a-fA-F0-9]/g, "").toUpperCase();
  const chunks = cleaned.match(/.{1,2}/g) || [];
  return chunks.slice(0, 6).join(":");
}

function parseChannelCount(channelsJson: string | null | undefined): number {
  if (!channelsJson) return 0;
  try {
    const channels = JSON.parse(channelsJson);
    return Array.isArray(channels) ? channels.length : 0;
  } catch {
    return 0;
  }
}

type MagDeviceFormData = z.infer<typeof magDeviceFormSchema>;

interface Setting {
  id: number;
  type: string;
  value: string;
}

function MagDeviceForm({
  device,
  onSuccess,
  users,
  bouquets,
  isReseller,
}: {
  device?: MagDevice;
  onSuccess: () => void;
  users: User[];
  bouquets: Bouquet[];
  isReseller?: boolean;
}) {
  const { toast } = useToast();
  const isEditing = !!device;
  
  // Always fetch fresh settings data - admin may have changed prices
  const { data: settings } = useQuery<Setting[]>({
    queryKey: ["/api/settings"],
    enabled: isReseller && !isEditing,
    staleTime: 0,
    refetchOnMount: "always",
  });
  
  // Fetch duration options from admin settings - always get fresh data
  const { data: durationOptions } = useQuery<DurationOption[]>({
    queryKey: ["/api/settings/duration-options"],
    enabled: isReseller && !isEditing,
    staleTime: 0,
    refetchOnMount: "always",
  });
  
  // Use API duration options or fallback
  const activeDurationOptions = durationOptions?.length ? durationOptions : FALLBACK_DURATION_OPTIONS;
  
  const parsedCost = parseFloat(settings?.find(s => s.type === "credit_price_per_line")?.value || "1");
  const creditCost = Number.isFinite(parsedCost) ? parsedCost : 1;
  const parsedPerConn = parseFloat(settings?.find(s => s.type === "credit_price_per_connection")?.value || "0");
  const pricePerConnection = Number.isFinite(parsedPerConn) ? parsedPerConn : 0;

  const defaultExpiry = new Date();
  defaultExpiry.setMonth(defaultExpiry.getMonth() + 1);

  const form = useForm<MagDeviceFormData>({
    resolver: zodResolver(magDeviceFormSchema),
    defaultValues: {
      mac: device?.mac ?? "",
      userId: device?.userId ?? 0,
      expiry: device?.expiry ?? defaultExpiry.toISOString().split("T")[0],
      duration: 30,
      isTrial: device?.isTrial === 1,
      testDuration: "24",
      lockDevice: device?.lockDevice === 1,
      lockToIsp: device?.lockToIsp === 1,
      playbackLimit: device?.playbackLimit ?? 1,
      adminNotes: device?.adminNotes ?? "",
      resellerNotes: device?.resellerNotes ?? "",
      bouquetIds: device?.bouquetIds ?? [],
    },
  });

  // Watch form values for dynamic calculations
  const watchedDuration = form.watch("duration");
  const watchedIsTrial = form.watch("isTrial");
  const watchedTestDuration = form.watch("testDuration");
  const watchedPlaybackLimit = form.watch("playbackLimit") || 1;
  
  // Calculate credit cost with multiplier from API settings
  const selectedDurationOption = activeDurationOptions.find(d => d.days === watchedDuration);
  const durationMultiplier = selectedDurationOption?.multiplier || 1;
  const extraConnections = Math.max(0, watchedPlaybackLimit - 1);
  const extraConnectionCost = extraConnections * pricePerConnection * durationMultiplier;
  const totalCreditCost = (creditCost * durationMultiplier) + extraConnectionCost;

  const mutation = useMutation({
    mutationFn: async (data: MagDeviceFormData) => {
      // Calculate expiry date based on duration selection
      let calculatedExpiry = data.expiry;
      if (!isEditing && isReseller) {
        const now = new Date();
        if (data.isTrial) {
          const testHours = TEST_DURATION_OPTIONS.find(t => t.value === data.testDuration)?.hours || 24;
          now.setHours(now.getHours() + testHours);
        } else {
          // Use days from duration option
          const days = data.duration || 30;
          now.setDate(now.getDate() + days);
        }
        calculatedExpiry = now.toISOString().split("T")[0];
      }
      
      const payload = {
        mac: data.mac,
        userId: data.userId,
        expiry: calculatedExpiry,
        isTrial: data.isTrial ? 1 : 0,
        lockDevice: data.lockDevice ? 1 : 0,
        lockToIsp: data.lockToIsp ? 1 : 0,
        playbackLimit: data.playbackLimit,
        adminNotes: data.adminNotes,
        resellerNotes: data.resellerNotes,
        bouquetIds: data.bouquetIds,
      };
      if (isEditing) {
        return apiRequest("PATCH", `/api/mag-devices/${device.magId}`, payload);
      }
      return apiRequest("POST", "/api/mag-devices", payload);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/mag-devices"] });
      toast({ title: isEditing ? "Device updated" : "Device added" });
      onSuccess();
    },
    onError: () => {
      toast({ title: "Failed to save device", variant: "destructive" });
    },
  });

  const selectedBouquets = form.watch("bouquetIds") ?? [];

  const toggleBouquet = (bouquetId: number) => {
    const current = selectedBouquets;
    if (current.includes(bouquetId)) {
      form.setValue("bouquetIds", current.filter(id => id !== bouquetId));
    } else {
      form.setValue("bouquetIds", [...current, bouquetId]);
    }
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit((data) => mutation.mutate(data))} className="space-y-4">
        <FormField
          control={form.control}
          name="mac"
          render={({ field }) => (
            <FormItem>
              <FormLabel>MAC Address</FormLabel>
              <FormControl>
                <Input
                  placeholder="00:1A:79:XX:XX:XX"
                  value={field.value ?? ""}
                  onChange={(e) => field.onChange(formatMacAddress(e.target.value))}
                  data-testid="input-mac"
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="userId"
            render={({ field }) => (
              <FormItem>
                <FormLabel>User</FormLabel>
                <Select
                  onValueChange={(val) => field.onChange(val ? parseInt(val) : 0)}
                  value={field.value ? field.value.toString() : "0"}
                >
                  <FormControl>
                    <SelectTrigger data-testid="select-user">
                      <SelectValue placeholder="Select user..." />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="0">No User</SelectItem>
                    {users.map((user) => (
                      <SelectItem key={user.id} value={user.id.toString()}>
                        {user.username}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />

          {isReseller && !isEditing ? (
            <FormField
              control={form.control}
              name="duration"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Duration</FormLabel>
                  <Select 
                    onValueChange={(value) => field.onChange(parseInt(value))} 
                    value={field.value?.toString()}
                  >
                    <FormControl>
                      <SelectTrigger data-testid="select-duration">
                        <SelectValue placeholder="Select duration" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {activeDurationOptions.map((opt) => (
                        <SelectItem key={opt.days} value={opt.days.toString()}>
                          {opt.label} ({opt.days} days)
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
          ) : (
            <FormField
              control={form.control}
              name="expiry"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Expiry Date</FormLabel>
                  <FormControl>
                    <Input
                      type="date"
                      value={field.value ?? ""}
                      onChange={field.onChange}
                      data-testid="input-expiry"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          )}
        </div>

        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="isTrial"
            render={({ field }) => (
              <FormItem className="flex items-center justify-between rounded-lg border p-3">
                <div className="space-y-0.5">
                  <FormLabel>Trial</FormLabel>
                  <FormDescription>Mark as trial device</FormDescription>
                </div>
                <FormControl>
                  <Switch
                    checked={field.value}
                    onCheckedChange={field.onChange}
                    data-testid="switch-trial"
                  />
                </FormControl>
              </FormItem>
            )}
          />

          {isReseller && !isEditing && watchedIsTrial && (
            <FormField
              control={form.control}
              name="testDuration"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Test Duration</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl>
                      <SelectTrigger data-testid="select-test-duration">
                        <SelectValue placeholder="Select test duration" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {TEST_DURATION_OPTIONS.map((opt) => (
                        <SelectItem key={opt.value} value={opt.value}>
                          {opt.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
          )}

          <FormField
            control={form.control}
            name="lockDevice"
            render={({ field }) => (
              <FormItem className="flex items-center justify-between rounded-lg border p-3">
                <div className="space-y-0.5">
                  <FormLabel>Lock Device</FormLabel>
                  <FormDescription>Disable this device</FormDescription>
                </div>
                <FormControl>
                  <Switch
                    checked={field.value}
                    onCheckedChange={field.onChange}
                    data-testid="switch-lock"
                  />
                </FormControl>
              </FormItem>
            )}
          />
        </div>

        <FormField
          control={form.control}
          name="lockToIsp"
          render={({ field }) => (
            <FormItem className="flex items-center justify-between rounded-lg border p-3">
              <div className="space-y-0.5">
                <FormLabel>Lock to ISP/IP</FormLabel>
                <FormDescription>Restrict device to current IP</FormDescription>
              </div>
              <FormControl>
                <Switch
                  checked={field.value}
                  onCheckedChange={field.onChange}
                  data-testid="switch-lock-isp"
                />
              </FormControl>
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="playbackLimit"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Playback Limit</FormLabel>
              <FormDescription>Maximum simultaneous streams</FormDescription>
              <FormControl>
                <Input
                  type="number"
                  min={1}
                  max={10}
                  {...field}
                  data-testid="input-playback-limit"
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="adminNotes"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Admin Notes</FormLabel>
              <FormControl>
                <Textarea
                  placeholder="Notes visible only to admins..."
                  value={field.value ?? ""}
                  onChange={field.onChange}
                  rows={2}
                  data-testid="textarea-admin-notes"
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="resellerNotes"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Reseller Notes</FormLabel>
              <FormControl>
                <Textarea
                  placeholder="Notes visible to resellers..."
                  value={field.value ?? ""}
                  onChange={field.onChange}
                  rows={2}
                  data-testid="textarea-reseller-notes"
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <div>
          <FormLabel>Bouquets</FormLabel>
          <FormDescription className="mb-2">
            Select content packages for this device
          </FormDescription>
          <div className="border rounded-md p-4 space-y-2 max-h-48 overflow-y-auto">
            {bouquets.length === 0 ? (
              <p className="text-muted-foreground text-sm">No bouquets available</p>
            ) : (
              bouquets.map((bouquet) => (
                <div key={bouquet.id} className="flex items-center space-x-2">
                  <Checkbox
                    id={`bouquet-${bouquet.id}`}
                    checked={selectedBouquets.includes(bouquet.id)}
                    onCheckedChange={() => toggleBouquet(bouquet.id)}
                    data-testid={`checkbox-bouquet-${bouquet.id}`}
                  />
                  <label
                    htmlFor={`bouquet-${bouquet.id}`}
                    className="text-sm font-medium cursor-pointer flex-1"
                  >
                    {bouquet.bouquetName}
                  </label>
                  <Badge variant="secondary" className="text-xs">
                    {parseChannelCount(bouquet.bouquetChannels)} ch
                  </Badge>
                </div>
              ))
            )}
          </div>
        </div>

        {isReseller && !isEditing && (
          <div className="p-3 rounded-lg bg-orange-500/10 border border-orange-500/30">
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">
                {watchedIsTrial ? "Test (Free)" : `Cost (${selectedDurationOption?.label || "1 Month"}):`}
              </span>
              <span className="font-semibold text-lg text-orange-500">
                {watchedIsTrial ? "€0.00" : `€${totalCreditCost.toFixed(2)}`}
              </span>
            </div>
            {!watchedIsTrial && (
              <div className="text-xs text-muted-foreground mt-1 space-y-0.5">
                <p>Base: €{creditCost.toFixed(2)} x {selectedDurationOption?.label || "1 Month"} = €{(creditCost * durationMultiplier).toFixed(2)}</p>
                {extraConnections > 0 && (
                  <p>Extra connections: {extraConnections} x €{pricePerConnection.toFixed(2)} x {durationMultiplier} = €{extraConnectionCost.toFixed(2)}</p>
                )}
              </div>
            )}
            {watchedIsTrial && (
              <p className="text-xs text-muted-foreground mt-1">
                Test accounts are free ({TEST_DURATION_OPTIONS.find(t => t.value === watchedTestDuration)?.label || "24 Hours"})
              </p>
            )}
          </div>
        )}

        <div className="flex justify-end pt-4">
          <Button 
            type="submit" 
            disabled={mutation.isPending} 
            className="bg-orange-500 hover:bg-orange-600"
            data-testid="button-submit"
          >
            {mutation.isPending ? "Saving..." : isEditing ? "Update Device" : "Add Device"}
          </Button>
        </div>
      </form>
    </Form>
  );
}

interface ResellerProfile {
  resellerDns: string;
}

export default function MagDevicesPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [editingDevice, setEditingDevice] = useState<MagDevice | null>(null);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [deviceToDelete, setDeviceToDelete] = useState<MagDevice | null>(null);
  const { toast } = useToast();
  const { user } = useAuth();
  const isReseller = user?.role === "reseller";

  const { data: devices, isLoading } = useQuery<MagDevice[]>({
    queryKey: ["/api/mag-devices"],
  });

  const { data: users } = useQuery<User[]>({
    queryKey: ["/api/users"],
  });

  const { data: bouquets } = useQuery<Bouquet[]>({
    queryKey: ["/api/bouquets"],
  });
  
  const { data: resellerProfile } = useQuery<ResellerProfile>({
    queryKey: ["/api/resellers/me/profile"],
    enabled: isReseller,
  });
  
  const getMagPortalUrl = () => {
    if (isReseller && resellerProfile?.resellerDns) {
      const dns = resellerProfile.resellerDns;
      if (dns.startsWith("http://") || dns.startsWith("https://")) {
        return `${dns.replace(/\/$/, "")}/xmag/c/`;
      }
      return `http://${dns}/xmag/c/`;
    }
    return `${window.location.origin}/xmag/c/`;
  };

  const deleteMutation = useMutation({
    mutationFn: (id: number) => apiRequest("DELETE", `/api/mag-devices/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/mag-devices"] });
      toast({ title: "Device deleted" });
      setDeleteDialogOpen(false);
    },
    onError: () => {
      toast({ title: "Failed to delete device", variant: "destructive" });
    },
  });

  const filteredDevices = devices?.filter(
    (device) =>
      device.mac?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      device.ip?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getUsernameById = (userId: number) => {
    if (!userId) return "-";
    const user = users?.find((u) => u.id === userId);
    return user?.username ?? "-";
  };

  const handleDeleteClick = (device: MagDevice) => {
    setDeviceToDelete(device);
    setDeleteDialogOpen(true);
  };

  const confirmDelete = () => {
    if (deviceToDelete) {
      deleteMutation.mutate(deviceToDelete.magId);
    }
  };

  return (
    <div className="space-y-6 p-6">
      <DeleteConfirmation
        open={deleteDialogOpen}
        onOpenChange={setDeleteDialogOpen}
        onConfirm={confirmDelete}
        title="Delete MAG Device"
        description={`Are you sure you want to delete the device with MAC ${deviceToDelete?.mac}?`}
      />

      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">MAG Devices</h1>
          <p className="text-muted-foreground">Manage MAG set-top boxes</p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-orange-500 hover:bg-orange-600" data-testid="button-add-device">
              <Plus className="h-4 w-4 mr-2" />
              Add Device
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Add MAG Device</DialogTitle>
            </DialogHeader>
            <MagDeviceForm
              users={users ?? []}
              bouquets={bouquets ?? []}
              onSuccess={() => setIsAddDialogOpen(false)}
              isReseller={isReseller}
            />
          </DialogContent>
        </Dialog>
      </div>

      <Card className="bg-orange-500/10 border-orange-500/30">
        <CardHeader className="flex flex-row items-center justify-between gap-4 space-y-0 pb-2">
          <CardTitle className="flex items-center gap-2 text-base">
            <Link className="h-4 w-4 text-orange-500" />
            MAG Portal URL
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-3 flex-wrap">
            <code className="bg-muted px-3 py-2 rounded-md text-sm font-mono flex-1 min-w-0" data-testid="text-mag-portal-url">
              {getMagPortalUrl()}
            </code>
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                navigator.clipboard.writeText(getMagPortalUrl());
                toast({ title: "Portal URL copied to clipboard" });
              }}
              data-testid="button-copy-portal-url"
            >
              <Copy className="h-4 w-4 mr-2" />
              Copy
            </Button>
          </div>
          <p className="text-sm text-muted-foreground mt-2">
            Configure MAG devices with this portal URL. Use the MAC address as device identifier.
            {isReseller && resellerProfile?.resellerDns && (
              <span className="block text-orange-500 mt-1">Using your custom DNS: {resellerProfile.resellerDns}</span>
            )}
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between gap-4 space-y-0 pb-4">
          <CardTitle className="flex items-center gap-2">
            <Monitor className="h-5 w-5" />
            All Devices
            <Badge variant="secondary" className="ml-2">{devices?.length ?? 0}</Badge>
          </CardTitle>
          <div className="relative w-72">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search by MAC or IP..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9"
              data-testid="input-search"
            />
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-3">
              {[...Array(5)].map((_, i) => (
                <Skeleton key={i} className="h-12 w-full" />
              ))}
            </div>
          ) : (filteredDevices?.length ?? 0) === 0 ? (
            <div className="text-center py-12">
              <Monitor className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium mb-1">No devices found</h3>
              <p className="text-muted-foreground">Add a MAG device to get started</p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>MAC Address</TableHead>
                  <TableHead>User</TableHead>
                  <TableHead>Online</TableHead>
                  <TableHead>Expiry</TableHead>
                  <TableHead>Limit</TableHead>
                  <TableHead>Trial</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Last Active</TableHead>
                  <TableHead className="w-[50px]"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredDevices?.map((device) => (
                  <TableRow key={device.magId} data-testid={`row-device-${device.magId}`}>
                    <TableCell className="font-mono">{device.mac}</TableCell>
                    <TableCell>{getUsernameById(device.userId)}</TableCell>
                    <TableCell>
                      {(device as any).isOnline ? (
                        <Badge variant="default" className="bg-emerald-500 text-white">
                          <div className="w-2 h-2 rounded-full bg-white mr-1.5 animate-pulse" />
                          Online
                        </Badge>
                      ) : (
                        <span className="text-muted-foreground text-sm">Offline</span>
                      )}
                    </TableCell>
                    <TableCell>{device.expiry ?? "-"}</TableCell>
                    <TableCell>
                      <Badge variant="outline">{device.playbackLimit ?? 1}</Badge>
                    </TableCell>
                    <TableCell>
                      {device.isTrial === 1 ? (
                        <Badge variant="secondary">Trial</Badge>
                      ) : "-"}
                    </TableCell>
                    <TableCell>
                      <Badge variant={device.lockDevice === 1 ? "destructive" : "default"}>
                        {device.lockDevice === 1 ? "Locked" : "Active"}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {device.lastActive
                        ? new Date(device.lastActive * 1000).toLocaleString()
                        : "Never"}
                    </TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" data-testid={`button-menu-${device.magId}`}>
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem
                            onClick={() => setEditingDevice(device)}
                            data-testid={`button-edit-${device.magId}`}
                          >
                            <Edit className="h-4 w-4 mr-2" />
                            Edit
                          </DropdownMenuItem>
                          <DropdownMenuItem
                            onClick={() => handleDeleteClick(device)}
                            className="text-destructive"
                            data-testid={`button-delete-${device.magId}`}
                          >
                            <Trash2 className="h-4 w-4 mr-2" />
                            Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <Dialog open={!!editingDevice} onOpenChange={() => setEditingDevice(null)}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edit MAG Device</DialogTitle>
          </DialogHeader>
          {editingDevice && (
            <MagDeviceForm
              device={editingDevice}
              users={users ?? []}
              bouquets={bouquets ?? []}
              onSuccess={() => setEditingDevice(null)}
              isReseller={isReseller}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
