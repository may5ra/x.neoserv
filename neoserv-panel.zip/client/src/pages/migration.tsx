import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";
import { 
  Upload, 
  FileText, 
  CheckCircle2, 
  XCircle, 
  AlertTriangle,
  Database,
  Users,
  Tv,
  Package,
  Server,
  ArrowRight,
  Loader2
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

interface PreviewResult {
  tables: { name: string; rowCount: number }[];
  warnings?: string[];
  hasBlockingWarnings?: boolean;
}

interface MigrationResult {
  success: boolean;
  tables: {
    name: string;
    imported: number;
    skipped: number;
    errors: string[];
  }[];
  totalImported: number;
  totalErrors: number;
}

const tableIcons: Record<string, any> = {
  users: Users,
  streams: Tv,
  bouquets: Package,
  streaming_servers: Server,
  mag_devices: Tv,
  users_packages: Package,
  reg_users: Users,
  stream_categories: Database,
  series: Tv,
  epg: FileText,
};

export default function Migration() {
  const [sqlDump, setSqlDump] = useState("");
  const [preview, setPreview] = useState<PreviewResult | null>(null);
  const [result, setResult] = useState<MigrationResult | null>(null);
  const { toast } = useToast();

  const previewMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/migration/xui/preview", { sqlDump });
      return res.json();
    },
    onSuccess: (data) => {
      setPreview(data);
      setResult(null);
      toast({
        title: "Preview Complete",
        description: `Found ${data.tables?.length || 0} tables to import`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Preview Failed",
        description: error.message || "Could not parse SQL dump",
        variant: "destructive",
      });
    },
  });

  const migrateMutation = useMutation({
    mutationFn: async (force: boolean = false) => {
      const res = await apiRequest("POST", "/api/migration/xui", { sqlDump, preview: false, force });
      return res.json();
    },
    onSuccess: (data) => {
      setResult(data);
      if (data.error) {
        toast({
          title: "Migration Blocked",
          description: data.error,
          variant: "destructive",
        });
      } else {
        toast({
          title: data.success ? "Migration Complete" : "Migration Completed with Errors",
          description: `Imported ${data.totalImported} records`,
          variant: data.success ? "default" : "destructive",
        });
      }
    },
    onError: (error: any) => {
      toast({
        title: "Migration Failed",
        description: error.message || "An error occurred during migration",
        variant: "destructive",
      });
    },
  });

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setSqlDump(event.target?.result as string);
        setPreview(null);
        setResult(null);
      };
      reader.readAsText(file);
    }
  };

  const totalPreviewRows = preview?.tables.reduce((sum, t) => sum + t.rowCount, 0) || 0;

  return (
    <div className="container mx-auto p-6 max-w-4xl">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">XUI.one Migration</h1>
        <p className="text-muted-foreground">
          Import your existing XUI.one database to NeoServ Panel
        </p>
      </div>

      <div className="grid gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Upload className="h-5 w-5" />
              Upload XUI Database Dump
            </CardTitle>
            <CardDescription>
              Export your XUI database with: mysqldump -u root -p xtream_iptvpro &gt; xui_dump.sql
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex gap-4">
              <input
                type="file"
                accept=".sql,.txt"
                onChange={handleFileUpload}
                className="hidden"
                id="sql-upload"
                data-testid="input-sql-upload"
              />
              <label htmlFor="sql-upload">
                <Button variant="outline" asChild>
                  <span className="cursor-pointer">
                    <FileText className="h-4 w-4 mr-2" />
                    Choose SQL File
                  </span>
                </Button>
              </label>
              {sqlDump && (
                <Badge variant="secondary" className="self-center">
                  {(sqlDump.length / 1024).toFixed(1)} KB loaded
                </Badge>
              )}
            </div>

            <div className="relative">
              <Textarea
                placeholder="Or paste your SQL dump here..."
                value={sqlDump}
                onChange={(e) => {
                  setSqlDump(e.target.value);
                  setPreview(null);
                  setResult(null);
                }}
                className="min-h-[200px] font-mono text-sm"
                data-testid="textarea-sql-dump"
              />
            </div>

            <div className="flex gap-3">
              <Button
                onClick={() => previewMutation.mutate()}
                disabled={!sqlDump || previewMutation.isPending}
                variant="outline"
                data-testid="button-preview"
              >
                {previewMutation.isPending ? (
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                ) : (
                  <Database className="h-4 w-4 mr-2" />
                )}
                Preview Data
              </Button>

              <Button
                onClick={() => migrateMutation.mutate(false)}
                disabled={!preview || migrateMutation.isPending}
                data-testid="button-migrate"
              >
                {migrateMutation.isPending ? (
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                ) : (
                  <ArrowRight className="h-4 w-4 mr-2" />
                )}
                Start Migration
              </Button>

              {preview?.hasBlockingWarnings && (
                <Button
                  onClick={() => migrateMutation.mutate(true)}
                  disabled={migrateMutation.isPending}
                  variant="destructive"
                  data-testid="button-force-migrate"
                >
                  {migrateMutation.isPending ? (
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  ) : (
                    <AlertTriangle className="h-4 w-4 mr-2" />
                  )}
                  Force Import (Ignore Warnings)
                </Button>
              )}
            </div>
          </CardContent>
        </Card>

        {preview && !result && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Database className="h-5 w-5" />
                Preview: {totalPreviewRows.toLocaleString()} records found
              </CardTitle>
              <CardDescription>
                The following data will be imported
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {preview.tables.map((table) => {
                  const Icon = tableIcons[table.name] || Database;
                  return (
                    <div
                      key={table.name}
                      className="flex items-center gap-3 p-3 rounded-lg border bg-card"
                    >
                      <Icon className="h-5 w-5 text-muted-foreground" />
                      <div>
                        <div className="font-medium capitalize">
                          {table.name.replace(/_/g, " ")}
                        </div>
                        <div className="text-sm text-muted-foreground">
                          {table.rowCount.toLocaleString()} rows
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              {preview.warnings && preview.warnings.length > 0 && (
                <Alert className="mt-4" variant="destructive">
                  <AlertTriangle className="h-4 w-4" />
                  <AlertTitle>Parsing Warnings</AlertTitle>
                  <AlertDescription>
                    <ul className="list-disc list-inside text-sm mt-2">
                      {preview.warnings.map((warning, idx) => (
                        <li key={idx}>{warning}</li>
                      ))}
                    </ul>
                  </AlertDescription>
                </Alert>
              )}

              <Alert className="mt-4">
                <AlertTriangle className="h-4 w-4" />
                <AlertTitle>Important</AlertTitle>
                <AlertDescription>
                  Existing records with the same ID will be skipped. This is a safe, non-destructive import.
                </AlertDescription>
              </Alert>
            </CardContent>
          </Card>
        )}

        {result && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                {result.success ? (
                  <CheckCircle2 className="h-5 w-5 text-green-500" />
                ) : (
                  <XCircle className="h-5 w-5 text-red-500" />
                )}
                Migration {result.success ? "Complete" : "Completed with Errors"}
              </CardTitle>
              <CardDescription>
                Imported {result.totalImported.toLocaleString()} records
                {result.totalErrors > 0 && `, ${result.totalErrors} errors`}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Progress
                value={(result.totalImported / (result.totalImported + result.totalErrors)) * 100}
                className="h-2"
              />

              <div className="space-y-3">
                {result.tables.map((table) => {
                  const Icon = tableIcons[table.name] || Database;
                  const hasErrors = table.errors.length > 0;
                  
                  return (
                    <div
                      key={table.name}
                      className={`p-4 rounded-lg border ${
                        hasErrors ? "border-yellow-500/50 bg-yellow-500/5" : "bg-card"
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <Icon className="h-5 w-5 text-muted-foreground" />
                          <span className="font-medium capitalize">
                            {table.name.replace(/_/g, " ")}
                          </span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge variant="secondary">
                            {table.imported} imported
                          </Badge>
                          {table.skipped > 0 && (
                            <Badge variant="outline">
                              {table.skipped} skipped
                            </Badge>
                          )}
                          {hasErrors && (
                            <Badge variant="destructive">
                              {table.errors.length} errors
                            </Badge>
                          )}
                        </div>
                      </div>

                      {hasErrors && (
                        <div className="mt-3 text-sm text-muted-foreground">
                          {table.errors.slice(0, 3).map((err, i) => (
                            <div key={i} className="truncate">
                              {err}
                            </div>
                          ))}
                          {table.errors.length > 3 && (
                            <div className="text-xs mt-1">
                              +{table.errors.length - 3} more errors
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>

              {result.success && (
                <Alert className="border-green-500/50 bg-green-500/5">
                  <CheckCircle2 className="h-4 w-4 text-green-500" />
                  <AlertTitle>Success!</AlertTitle>
                  <AlertDescription>
                    Your XUI data has been successfully imported to NeoServ. 
                    You can now manage users, streams, and content from the dashboard.
                  </AlertDescription>
                </Alert>
              )}
            </CardContent>
          </Card>
        )}

        <Card>
          <CardHeader>
            <CardTitle>Supported XUI Tables</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-sm">
              {[
                "users", "streams", "bouquets", "stream_categories",
                "series", "streaming_servers", "mag_devices", "users_packages",
                "reg_users", "epg", "transcoding_profiles", "access_output"
              ].map((table) => (
                <div key={table} className="flex items-center gap-2 text-muted-foreground">
                  <CheckCircle2 className="h-3 w-3 text-green-500" />
                  {table}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
