import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Plus,
  Search,
  MoreHorizontal,
  Edit,
  Trash2,
  Film,
  Play,
  Star,
  Calendar,
  Grid,
  List,
} from "lucide-react";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { DeleteConfirmation } from "@/components/delete-confirmation";

interface Category {
  id: number;
  name: string;
  type: string;
}

interface Movie {
  id: number;
  name: string;
  streamUrl: string;
  categoryId: number | string | null;
  posterUrl: string | null;
  backdropUrl?: string | null;
  description: string | null;
  duration?: string | null;
  rating?: string | null;
  releaseYear?: string | null;
  genres?: string | null;
  isActive: boolean;
  vodId: number;
}

const movieFormSchema = z.object({
  name: z.string().min(1, "Name is required"),
  streamUrl: z.string().url("Must be a valid URL"),
  categoryId: z.string().optional(),
  posterUrl: z.string().url("Must be a valid URL").optional().or(z.literal("")),
  backdropUrl: z.string().url("Must be a valid URL").optional().or(z.literal("")),
  description: z.string().optional(),
  duration: z.string().optional(),
  rating: z.string().optional(),
  releaseYear: z.string().optional(),
  genres: z.string().optional(),
  isActive: z.boolean(),
});

type MovieFormData = z.infer<typeof movieFormSchema>;

function MovieFormDialog({ 
  movie, 
  categories,
  open, 
  onOpenChange 
}: { 
  movie?: Movie; 
  categories: Category[];
  open: boolean; 
  onOpenChange: (open: boolean) => void;
}) {
  const { toast } = useToast();
  const isEditing = !!movie;

  const form = useForm<MovieFormData>({
    resolver: zodResolver(movieFormSchema),
    defaultValues: {
      name: movie?.name || "",
      streamUrl: movie?.streamUrl || "",
      categoryId: movie?.categoryId || "",
      posterUrl: movie?.posterUrl || "",
      backdropUrl: movie?.backdropUrl || "",
      description: movie?.description || "",
      duration: movie?.duration || "",
      rating: movie?.rating || "",
      releaseYear: movie?.releaseYear || "",
      genres: movie?.genres || "",
      isActive: movie?.isActive ?? true,
    },
  });

  const mutation = useMutation({
    mutationFn: async (data: MovieFormData) => {
      if (isEditing) {
        return apiRequest("PATCH", `/api/movies/${movie.id}`, data);
      }
      return apiRequest("POST", "/api/movies", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/movies"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({
        title: isEditing ? "Movie updated" : "Movie created",
      });
      onOpenChange(false);
      form.reset();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to save movie",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: MovieFormData) => {
    mutation.mutate(data);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{isEditing ? "Edit Movie" : "Add New Movie"}</DialogTitle>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Movie Title</FormLabel>
                  <FormControl>
                    <Input placeholder="The Dark Knight" {...field} data-testid="input-movie-name" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="streamUrl"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Stream URL</FormLabel>
                  <FormControl>
                    <Input placeholder="http://example.com/movie.mp4" {...field} data-testid="input-movie-url" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="categoryId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Category</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value || "none"}>
                      <FormControl>
                        <SelectTrigger data-testid="select-movie-category">
                          <SelectValue placeholder="Select category" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="none">None</SelectItem>
                        {categories.filter(c => c.type === "movie").map((cat) => (
                          <SelectItem key={cat.id} value={String(cat.id)}>{cat.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="releaseYear"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Release Year</FormLabel>
                    <FormControl>
                      <Input placeholder="2024" {...field} data-testid="input-movie-year" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="posterUrl"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Poster URL</FormLabel>
                    <FormControl>
                      <Input placeholder="http://example.com/poster.jpg" {...field} data-testid="input-poster-url" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="backdropUrl"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Backdrop URL</FormLabel>
                    <FormControl>
                      <Input placeholder="http://example.com/backdrop.jpg" {...field} data-testid="input-backdrop-url" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            <div className="grid grid-cols-3 gap-4">
              <FormField
                control={form.control}
                name="duration"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Duration</FormLabel>
                    <FormControl>
                      <Input placeholder="2h 30m" {...field} data-testid="input-duration" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="rating"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Rating</FormLabel>
                    <FormControl>
                      <Input placeholder="8.5" {...field} data-testid="input-rating" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="genres"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Genres</FormLabel>
                    <FormControl>
                      <Input placeholder="Action, Drama" {...field} data-testid="input-genres" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description</FormLabel>
                  <FormControl>
                    <Textarea placeholder="Movie description..." {...field} data-testid="input-description" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="isActive"
              render={({ field }) => (
                <FormItem className="flex items-center justify-between rounded-lg border p-3">
                  <div>
                    <FormLabel>Active</FormLabel>
                    <p className="text-sm text-muted-foreground">Enable this movie for users</p>
                  </div>
                  <FormControl>
                    <Switch checked={field.value} onCheckedChange={field.onChange} data-testid="switch-movie-active" />
                  </FormControl>
                </FormItem>
              )}
            />
            <div className="flex justify-end gap-2 pt-4">
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
                Cancel
              </Button>
              <Button type="submit" disabled={mutation.isPending} data-testid="button-save-movie">
                {mutation.isPending ? "Saving..." : isEditing ? "Update" : "Create"}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}

function MovieCard({ movie, onEdit, onDelete }: { movie: Movie; onEdit: () => void; onDelete: () => void }) {
  return (
    <Card className="overflow-hidden hover-elevate group" data-testid={`movie-card-${movie.id}`}>
      <div className="aspect-[2/3] relative bg-muted">
        {movie.posterUrl ? (
          <img 
            src={movie.posterUrl} 
            alt={movie.name}
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <Film className="h-12 w-12 text-muted-foreground/50" />
          </div>
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity">
          <div className="absolute bottom-0 left-0 right-0 p-4">
            <div className="flex gap-2">
              <Button size="sm" variant="secondary" className="flex-1" onClick={onEdit}>
                <Edit className="h-4 w-4 mr-1" />
                Edit
              </Button>
              <Button size="sm" variant="destructive" onClick={onDelete}>
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
        {movie.rating && (
          <Badge className="absolute top-2 right-2 bg-black/70">
            <Star className="h-3 w-3 mr-1 fill-yellow-400 text-yellow-400" />
            {movie.rating}
          </Badge>
        )}
        {!movie.isActive && (
          <Badge variant="secondary" className="absolute top-2 left-2">
            Inactive
          </Badge>
        )}
      </div>
      <CardContent className="p-3">
        <h4 className="font-medium truncate">{movie.name}</h4>
        <div className="flex items-center gap-2 mt-1 text-xs text-muted-foreground">
          {movie.releaseYear && <span>{movie.releaseYear}</span>}
          {movie.duration && (
            <>
              <span className="w-1 h-1 rounded-full bg-muted-foreground" />
              <span>{movie.duration}</span>
            </>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

export default function MoviesPage() {
  const [search, setSearch] = useState("");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingMovie, setEditingMovie] = useState<Movie | undefined>();
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [movieToDelete, setMovieToDelete] = useState<Movie | null>(null);
  const { toast } = useToast();

  const { data: movies, isLoading } = useQuery<Movie[]>({
    queryKey: ["/api/movies"],
  });

  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      return apiRequest("DELETE", `/api/movies/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/movies"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({ title: "Movie deleted" });
      setDeleteDialogOpen(false);
      setMovieToDelete(null);
    },
  });

  const handleDeleteClick = (movie: Movie) => {
    setMovieToDelete(movie);
    setDeleteDialogOpen(true);
  };

  const confirmDelete = () => {
    if (movieToDelete) {
      deleteMutation.mutate(movieToDelete.id);
    }
  };

  const filteredMovies = movies?.filter(movie => 
    movie.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-3xl font-bold tracking-tight" data-testid="page-title">Movies</h1>
          <p className="text-muted-foreground">Manage video on demand content</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex rounded-lg border p-1">
            <Button 
              variant={viewMode === "grid" ? "secondary" : "ghost"} 
              size="icon"
              onClick={() => setViewMode("grid")}
              data-testid="button-view-grid"
            >
              <Grid className="h-4 w-4" />
            </Button>
            <Button 
              variant={viewMode === "list" ? "secondary" : "ghost"} 
              size="icon"
              onClick={() => setViewMode("list")}
              data-testid="button-view-list"
            >
              <List className="h-4 w-4" />
            </Button>
          </div>
          <Button onClick={() => { setEditingMovie(undefined); setDialogOpen(true); }} data-testid="button-add-movie">
            <Plus className="h-4 w-4 mr-2" />
            Add Movie
          </Button>
        </div>
      </div>

      <div className="flex items-center gap-4">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search movies..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
            data-testid="input-search-movies"
          />
        </div>
        <Badge variant="outline">{movies?.length || 0} movies</Badge>
      </div>

      {isLoading ? (
        <div className="grid gap-4 grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6">
          {Array(12).fill(0).map((_, i) => (
            <Card key={i} className="overflow-hidden">
              <Skeleton className="aspect-[2/3]" />
              <CardContent className="p-3">
                <Skeleton className="h-4 w-3/4 mb-2" />
                <Skeleton className="h-3 w-1/2" />
              </CardContent>
            </Card>
          ))}
        </div>
      ) : filteredMovies && filteredMovies.length > 0 ? (
        <div className="grid gap-4 grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6">
          {filteredMovies.map((movie) => (
            <MovieCard 
              key={movie.id} 
              movie={movie} 
              onEdit={() => { setEditingMovie(movie); setDialogOpen(true); }}
              onDelete={() => handleDeleteClick(movie)}
            />
          ))}
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center py-24 text-center">
          <Film className="h-16 w-16 text-muted-foreground/50 mb-4" />
          <h3 className="text-lg font-medium mb-1">No movies found</h3>
          <p className="text-muted-foreground mb-4">Get started by adding your first movie</p>
          <Button onClick={() => { setEditingMovie(undefined); setDialogOpen(true); }}>
            <Plus className="h-4 w-4 mr-2" />
            Add Movie
          </Button>
        </div>
      )}

      <MovieFormDialog 
        movie={editingMovie} 
        categories={categories}
        open={dialogOpen} 
        onOpenChange={setDialogOpen} 
      />

      <DeleteConfirmation
        open={deleteDialogOpen}
        onOpenChange={setDeleteDialogOpen}
        onConfirm={confirmDelete}
        title="Delete Movie"
        itemName={movieToDelete?.name}
      />
    </div>
  );
}
