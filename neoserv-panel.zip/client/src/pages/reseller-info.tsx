import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Info, CreditCard, CheckCircle, XCircle, AlertTriangle } from "lucide-react";

interface DurationOption {
  label: string;
  days: number;
  multiplier: number;
}

interface ResellerInfo {
  username: string;
  email: string;
  credits: number;
  creditPricePerLine: number;
  creditPricePerConnection: number;
  resellerDns: string;
  durationOptions: DurationOption[];
  rights: {
    canCreateUsers: boolean;
    canViewOwnUsers: boolean;
    canEditOwnUsers: boolean;
    canDeleteOwnUsers: boolean;
    canViewMagDevices: boolean;
    canAccessStreams: boolean;
    canAccessMovies: boolean;
    canAccessSeries: boolean;
    canAccessServers: boolean;
    canAccessEPG: boolean;
    canAccessSettings: boolean;
    canAccessBackup: boolean;
    creditRefundOnDelete: boolean;
  };
  notes: string;
}

export default function ResellerInfoPage() {
  const { data: info, isLoading } = useQuery<ResellerInfo>({
    queryKey: ["/api/resellers/me/info"],
  });

  if (isLoading) {
    return (
      <div className="p-6 space-y-6">
        <Skeleton className="h-8 w-48" />
        <div className="grid gap-6 md:grid-cols-2">
          <Skeleton className="h-48" />
          <Skeleton className="h-48" />
        </div>
      </div>
    );
  }

  if (!info) {
    return (
      <div className="p-6">
        <Card>
          <CardContent className="p-6 text-center text-muted-foreground">
            Unable to load reseller information.
          </CardContent>
        </Card>
      </div>
    );
  }

  const rightsList = [
    { key: "canCreateUsers", label: "Create Lines/Users", value: info.rights.canCreateUsers },
    { key: "canViewOwnUsers", label: "View Own Users", value: info.rights.canViewOwnUsers },
    { key: "canEditOwnUsers", label: "Edit Own Users", value: info.rights.canEditOwnUsers },
    { key: "canDeleteOwnUsers", label: "Delete Own Users", value: info.rights.canDeleteOwnUsers },
    { key: "canViewMagDevices", label: "View MAG Devices", value: info.rights.canViewMagDevices },
    { key: "canAccessStreams", label: "Access Live Streams", value: info.rights.canAccessStreams },
    { key: "canAccessMovies", label: "Access Movies", value: info.rights.canAccessMovies },
    { key: "canAccessSeries", label: "Access Series", value: info.rights.canAccessSeries },
    { key: "canAccessServers", label: "Access Servers", value: info.rights.canAccessServers },
    { key: "canAccessEPG", label: "Access EPG", value: info.rights.canAccessEPG },
    { key: "canAccessSettings", label: "Access Settings", value: info.rights.canAccessSettings },
    { key: "canAccessBackup", label: "Access Backup", value: info.rights.canAccessBackup },
    { key: "creditRefundOnDelete", label: "Credit Refund on Delete", value: info.rights.creditRefundOnDelete },
  ];

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center gap-2">
        <Info className="h-6 w-6 text-orange-500" />
        <h1 className="text-2xl font-bold" data-testid="text-page-title">Reseller Information</h1>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CreditCard className="h-5 w-5 text-orange-500" />
              Credit Information
            </CardTitle>
            <CardDescription>Your current credits and pricing</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="p-4 bg-orange-50 dark:bg-orange-950/30 rounded-lg space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Available Credits</span>
                <span className="text-3xl font-bold text-orange-600 dark:text-orange-400" data-testid="text-credits-balance">
                  {info.credits}
                </span>
              </div>
              <div className="text-center pt-2 border-t border-orange-200 dark:border-orange-800">
                <span className="text-sm font-medium text-orange-700 dark:text-orange-300">
                  Credits will be deducted upon creation (1 credit = 1 €)
                </span>
              </div>
            </div>
            
            <div className="flex items-center justify-between p-3 border rounded-lg">
              <span className="text-muted-foreground">Base Price (1 connection)</span>
              <Badge variant="outline" className="text-lg" data-testid="text-credit-price">
                {info.creditPricePerLine} credit(s)
              </Badge>
            </div>

            <div className="flex items-center justify-between p-3 border rounded-lg">
              <span className="text-muted-foreground">Per Extra Connection</span>
              <Badge variant="outline" className="text-lg" data-testid="text-credit-price-connection">
                +{info.creditPricePerConnection} credit(s)
              </Badge>
            </div>

            <div className="flex items-center justify-between p-3 border rounded-lg">
              <span className="text-muted-foreground">Lines You Can Create (1 conn, 30 days)</span>
              <Badge className="bg-green-600 text-lg" data-testid="text-lines-available">
                {Math.floor(info.credits / info.creditPricePerLine)}
              </Badge>
            </div>
            
            {info.durationOptions && info.durationOptions.length > 0 && (
              <div className="space-y-2">
                <span className="text-sm font-medium">Duration Pricing (x multiplier):</span>
                <div className="grid grid-cols-2 gap-2">
                  {info.durationOptions.map((opt) => (
                    <div key={opt.days} className="p-2 border rounded-md text-sm flex justify-between items-center">
                      <span>{opt.label}</span>
                      <Badge variant="secondary">x{opt.multiplier}</Badge>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="p-3 bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 rounded-lg flex items-start gap-2">
              <AlertTriangle className="h-5 w-5 text-amber-600 dark:text-amber-400 flex-shrink-0 mt-0.5" />
              <p className="text-sm text-amber-800 dark:text-amber-200">
                {info.notes}
              </p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Your Access Rights</CardTitle>
            <CardDescription>What you can and cannot do as a reseller</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {rightsList.map((right) => (
                <div 
                  key={right.key} 
                  className="flex items-center justify-between p-2 border-b last:border-0"
                  data-testid={`right-${right.key}`}
                >
                  <span className="text-sm">{right.label}</span>
                  {right.value ? (
                    <CheckCircle className="h-5 w-5 text-green-500" />
                  ) : (
                    <XCircle className="h-5 w-5 text-red-500" />
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Account Details</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-3">
            <div className="p-3 border rounded-lg">
              <span className="text-sm text-muted-foreground block">Username</span>
              <span className="font-medium" data-testid="text-username">{info.username}</span>
            </div>
            <div className="p-3 border rounded-lg">
              <span className="text-sm text-muted-foreground block">Email</span>
              <span className="font-medium" data-testid="text-email">{info.email || "Not set"}</span>
            </div>
            <div className="p-3 border rounded-lg">
              <span className="text-sm text-muted-foreground block">Reseller DNS</span>
              <span className="font-medium" data-testid="text-dns">{info.resellerDns || "Not configured"}</span>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="border-red-200 dark:border-red-900">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-red-600 dark:text-red-400">
            <AlertTriangle className="h-5 w-5" />
            Credit Policy and Terms
          </CardTitle>
          <CardDescription>Important information about credits and line management</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-3">
            <div className="p-3 bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-800 rounded-lg">
              <h4 className="font-semibold text-red-700 dark:text-red-400 mb-2">Credits Are Non-Refundable</h4>
              <ul className="text-sm text-red-800 dark:text-red-300 space-y-1 list-disc list-inside">
                <li>Once credits are used to create a line or MAG device, they cannot be refunded</li>
                <li>Deleting a user/line does NOT return credits to your balance</li>
                <li>Credits purchased from admin are final - no refunds or chargebacks</li>
                <li>Plan carefully before creating lines - you cannot undo credit usage</li>
              </ul>
            </div>

            <div className="p-3 bg-muted rounded-lg">
              <h4 className="font-semibold mb-2">How Credits Work</h4>
              <ul className="text-sm text-muted-foreground space-y-1 list-disc list-inside">
                <li>Credits are deducted immediately when you create a line or MAG device</li>
                <li>The cost depends on: number of connections and subscription duration</li>
                <li>Formula: (Base Price + Extra Connections x Connection Price) x Duration Multiplier</li>
                <li>You can only create lines/devices if you have sufficient credits</li>
              </ul>
            </div>

            <div className="p-3 bg-muted rounded-lg">
              <h4 className="font-semibold mb-2">Line Management Rules</h4>
              <ul className="text-sm text-muted-foreground space-y-1 list-disc list-inside">
                <li>You can only manage lines/users that YOU created</li>
                <li>You cannot see or modify lines created by admin or other resellers</li>
                <li>You can edit, disable, ban, or delete your own lines</li>
                <li>Extending expired lines may require additional credits (contact admin)</li>
              </ul>
            </div>

            <div className="p-3 bg-muted rounded-lg">
              <h4 className="font-semibold mb-2">Your Responsibilities</h4>
              <ul className="text-sm text-muted-foreground space-y-1 list-disc list-inside">
                <li>You are responsible for your end-users and their activities</li>
                <li>Do not share your reseller account credentials</li>
                <li>Keep track of your credits and plan purchases accordingly</li>
                <li>Contact admin for credit top-ups and support</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
