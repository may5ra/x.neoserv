import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
  FormDescription,
} from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Plus,
  Search,
  MoreHorizontal,
  Edit,
  Trash2,
  Users,
  CreditCard,
  Ban,
  CheckCircle,
  DollarSign,
} from "lucide-react";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { DeleteConfirmation } from "@/components/delete-confirmation";
import type { RegUser } from "@shared/schema";

const resellerFormSchema = z.object({
  username: z.string().min(1, "Username is required"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  email: z.string().email("Invalid email").optional().or(z.literal("")),
  credits: z.coerce.number().default(0),
  status: z.coerce.number().default(1),
  notes: z.string().optional().or(z.literal("")),
  resellerDns: z.string().optional().or(z.literal("")),
});

type ResellerFormData = z.infer<typeof resellerFormSchema>;

const addCreditsSchema = z.object({
  credits: z.coerce.number().min(1, "Credits must be at least 1"),
});

type AddCreditsData = z.infer<typeof addCreditsSchema>;

function ResellerFormDialog({ 
  reseller, 
  open, 
  onOpenChange 
}: { 
  reseller?: RegUser; 
  open: boolean; 
  onOpenChange: (open: boolean) => void;
}) {
  const { toast } = useToast();
  const isEditing = !!reseller;

  const form = useForm<ResellerFormData>({
    resolver: zodResolver(isEditing 
      ? resellerFormSchema.extend({ password: z.string().min(6).optional().or(z.literal("")) })
      : resellerFormSchema
    ),
    defaultValues: {
      username: reseller?.username || "",
      password: "",
      email: reseller?.email || "",
      credits: reseller?.credits ?? 0,
      status: reseller?.status ?? 1,
      notes: reseller?.notes || "",
      resellerDns: reseller?.resellerDns || "",
    },
  });

  const mutation = useMutation({
    mutationFn: async (data: ResellerFormData) => {
      const payload = { ...data, memberGroupId: 2 };
      if (isEditing && !payload.password) {
        delete (payload as any).password;
      }
      if (isEditing) {
        return apiRequest("PATCH", `/api/resellers/${reseller.id}`, payload);
      }
      return apiRequest("POST", "/api/resellers", payload);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/resellers"] });
      toast({
        title: isEditing ? "Reseller updated" : "Reseller created",
      });
      onOpenChange(false);
      form.reset();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to save reseller",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: ResellerFormData) => {
    mutation.mutate(data);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>{isEditing ? "Edit Reseller" : "Add Reseller"}</DialogTitle>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="username"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Username</FormLabel>
                    <FormControl>
                      <Input placeholder="reseller1" {...field} data-testid="input-reseller-username" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="password"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>{isEditing ? "New Password" : "Password"}</FormLabel>
                    <FormControl>
                      <Input 
                        type="password" 
                        placeholder={isEditing ? "Leave empty to keep" : "******"} 
                        {...field} 
                        data-testid="input-reseller-password" 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            <FormField
              control={form.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Email</FormLabel>
                  <FormControl>
                    <Input type="email" placeholder="reseller@example.com" {...field} data-testid="input-reseller-email" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="credits"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Credits</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        step="0.01"
                        {...field} 
                        onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                        data-testid="input-reseller-credits" 
                      />
                    </FormControl>
                    <FormDescription>Credits for creating users (1 credit = 1 €)</FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="status"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Status</FormLabel>
                    <FormControl>
                      <select
                        className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm"
                        value={field.value}
                        onChange={(e) => field.onChange(parseInt(e.target.value))}
                        data-testid="select-reseller-status"
                      >
                        <option value={1}>Active</option>
                        <option value={0}>Disabled</option>
                      </select>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            <FormField
              control={form.control}
              name="resellerDns"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Reseller DNS</FormLabel>
                  <FormControl>
                    <Input placeholder="reseller.example.com" {...field} data-testid="input-reseller-dns" />
                  </FormControl>
                  <FormDescription>Custom DNS for this reseller's users</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="notes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Notes</FormLabel>
                  <FormControl>
                    <Input placeholder="Internal notes..." {...field} data-testid="input-reseller-notes" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <div className="flex justify-end gap-2">
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
                Cancel
              </Button>
              <Button type="submit" disabled={mutation.isPending} data-testid="button-save-reseller">
                {mutation.isPending ? "Saving..." : isEditing ? "Update" : "Create"}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}

function AddCreditsDialog({
  reseller,
  open,
  onOpenChange,
}: {
  reseller: RegUser;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const { toast } = useToast();

  const form = useForm<AddCreditsData>({
    resolver: zodResolver(addCreditsSchema),
    defaultValues: {
      credits: 10,
    },
  });

  const mutation = useMutation({
    mutationFn: async (data: AddCreditsData) => {
      return apiRequest("POST", `/api/resellers/${reseller.id}/credits`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/resellers"] });
      toast({
        title: "Credits added",
        description: `Added ${form.getValues("credits")} credits to ${reseller.username}`,
      });
      onOpenChange(false);
      form.reset();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to add credits",
        variant: "destructive",
      });
    },
  });

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[400px]">
        <DialogHeader>
          <DialogTitle>Add Credits to {reseller.username}</DialogTitle>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit((data) => mutation.mutate(data))} className="space-y-4">
            <div className="text-sm text-muted-foreground">
              Current credits: <span className="font-semibold text-foreground">{reseller.credits}</span>
            </div>
            <FormField
              control={form.control}
              name="credits"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Credits to Add</FormLabel>
                  <FormControl>
                    <Input 
                      type="number" 
                      step="0.01"
                      min="1"
                      {...field} 
                      onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                      data-testid="input-add-credits" 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <div className="flex justify-end gap-2">
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
                Cancel
              </Button>
              <Button type="submit" disabled={mutation.isPending} data-testid="button-confirm-add-credits">
                {mutation.isPending ? "Adding..." : "Add Credits"}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}

export default function ResellersPage() {
  const [search, setSearch] = useState("");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [selectedReseller, setSelectedReseller] = useState<RegUser | undefined>();
  const [deleteReseller, setDeleteReseller] = useState<RegUser | null>(null);
  const [creditsReseller, setCreditsReseller] = useState<RegUser | null>(null);
  const { toast } = useToast();

  const { data: resellers, isLoading } = useQuery<RegUser[]>({
    queryKey: ["/api/resellers"],
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest("DELETE", `/api/resellers/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/resellers"] });
      toast({ title: "Reseller deleted" });
      setDeleteReseller(null);
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete reseller",
        variant: "destructive",
      });
    },
  });

  const toggleStatusMutation = useMutation({
    mutationFn: async ({ id, status }: { id: number; status: number }) => {
      return apiRequest("PATCH", `/api/resellers/${id}`, { status });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/resellers"] });
      toast({ title: "Status updated" });
    },
  });

  const filteredResellers = resellers?.filter(r =>
    r.username.toLowerCase().includes(search.toLowerCase()) ||
    r.email?.toLowerCase().includes(search.toLowerCase())
  ) || [];

  const handleEdit = (reseller: RegUser) => {
    setSelectedReseller(reseller);
    setDialogOpen(true);
  };

  const handleAdd = () => {
    setSelectedReseller(undefined);
    setDialogOpen(true);
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex flex-col sm:flex-row justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold" data-testid="text-page-title">Resellers</h1>
          <p className="text-muted-foreground">Manage reseller accounts and credits <span className="text-orange-500 font-medium">(1 credit = 1 €)</span></p>
        </div>
        <Button onClick={handleAdd} data-testid="button-add-reseller">
          <Plus className="mr-2 h-4 w-4" />
          Add Reseller
        </Button>
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between gap-4 space-y-0 pb-4">
          <CardTitle className="text-lg">All Resellers</CardTitle>
          <div className="relative w-64">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search resellers..."
              className="pl-8"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              data-testid="input-search-resellers"
            />
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-2">
              {[...Array(5)].map((_, i) => (
                <Skeleton key={i} className="h-12 w-full" />
              ))}
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Username</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Credits (€)</TableHead>
                  <TableHead>Users</TableHead>
                  <TableHead>DNS</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="w-[80px]">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredResellers.map((reseller) => (
                  <TableRow key={reseller.id} data-testid={`row-reseller-${reseller.id}`}>
                    <TableCell className="font-medium">
                      <div className="flex items-center gap-2">
                        <Users className="h-4 w-4 text-muted-foreground" />
                        {reseller.username}
                      </div>
                    </TableCell>
                    <TableCell>{reseller.email || "-"}</TableCell>
                    <TableCell>
                      <Badge variant="secondary" className="gap-1">
                        <CreditCard className="h-3 w-3" />
                        €{reseller.credits?.toFixed(2) || "0.00"}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline">
                        {(reseller as any).userCount || 0}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {reseller.resellerDns || "-"}
                    </TableCell>
                    <TableCell>
                      {reseller.status === 1 ? (
                        <Badge variant="default" className="bg-green-600">Active</Badge>
                      ) : (
                        <Badge variant="destructive">Disabled</Badge>
                      )}
                    </TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" data-testid={`button-reseller-actions-${reseller.id}`}>
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => handleEdit(reseller)}>
                            <Edit className="mr-2 h-4 w-4" />
                            Edit
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => setCreditsReseller(reseller)}>
                            <DollarSign className="mr-2 h-4 w-4" />
                            Add Credits
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          {reseller.status === 1 ? (
                            <DropdownMenuItem 
                              onClick={() => toggleStatusMutation.mutate({ id: reseller.id, status: 0 })}
                            >
                              <Ban className="mr-2 h-4 w-4" />
                              Disable
                            </DropdownMenuItem>
                          ) : (
                            <DropdownMenuItem 
                              onClick={() => toggleStatusMutation.mutate({ id: reseller.id, status: 1 })}
                            >
                              <CheckCircle className="mr-2 h-4 w-4" />
                              Enable
                            </DropdownMenuItem>
                          )}
                          <DropdownMenuSeparator />
                          <DropdownMenuItem 
                            onClick={() => setDeleteReseller(reseller)}
                            className="text-destructive"
                          >
                            <Trash2 className="mr-2 h-4 w-4" />
                            Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
                {filteredResellers.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                      No resellers found
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <ResellerFormDialog
        reseller={selectedReseller}
        open={dialogOpen}
        onOpenChange={setDialogOpen}
      />

      {deleteReseller && (
        <DeleteConfirmation
          open={!!deleteReseller}
          onOpenChange={(open) => !open && setDeleteReseller(null)}
          title="Delete Reseller"
          description={`Are you sure you want to delete "${deleteReseller.username}"? This will also affect all users created by this reseller.`}
          onConfirm={() => deleteMutation.mutate(deleteReseller.id)}
        />
      )}

      {creditsReseller && (
        <AddCreditsDialog
          reseller={creditsReseller}
          open={!!creditsReseller}
          onOpenChange={(open) => !open && setCreditsReseller(null)}
        />
      )}
    </div>
  );
}
