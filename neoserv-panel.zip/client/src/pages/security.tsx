import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Plus, Trash2, Ban, Globe, MonitorSmartphone, CheckCircle, Shield } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { DeleteConfirmation } from "@/components/delete-confirmation";

interface BlockedIp {
  id: number;
  ip: string;
  notes: string;
  date: number;
  attemptsBlocked: number;
}

interface BlockedUserAgent {
  id: number;
  userAgent: string;
  exactMatch: number;
  attemptsBlocked: number;
}

interface AllowedIp {
  id: number;
  ip: string;
  notes: string;
  date: number;
}

export default function SecurityPage() {
  const { toast } = useToast();
  const [ipDialogOpen, setIpDialogOpen] = useState(false);
  const [uaDialogOpen, setUaDialogOpen] = useState(false);
  const [allowedIpDialogOpen, setAllowedIpDialogOpen] = useState(false);
  const [newIp, setNewIp] = useState("");
  const [newIpNotes, setNewIpNotes] = useState("");
  const [newUa, setNewUa] = useState("");
  const [newUaExactMatch, setNewUaExactMatch] = useState(false);
  const [newAllowedIp, setNewAllowedIp] = useState("");
  const [newAllowedIpNotes, setNewAllowedIpNotes] = useState("");
  const [deleteIpDialogOpen, setDeleteIpDialogOpen] = useState(false);
  const [blockedIpToDelete, setBlockedIpToDelete] = useState<BlockedIp | null>(null);
  const [deleteUaDialogOpen, setDeleteUaDialogOpen] = useState(false);
  const [blockedUaToDelete, setBlockedUaToDelete] = useState<BlockedUserAgent | null>(null);
  const [deleteAllowedIpDialogOpen, setDeleteAllowedIpDialogOpen] = useState(false);
  const [allowedIpToDelete, setAllowedIpToDelete] = useState<AllowedIp | null>(null);

  const { data: blockedIps = [], isLoading: loadingIps } = useQuery<BlockedIp[]>({
    queryKey: ["/api/security/blocked-ips"],
  });

  const { data: blockedUserAgents = [], isLoading: loadingUas } = useQuery<BlockedUserAgent[]>({
    queryKey: ["/api/security/blocked-user-agents"],
  });

  const { data: allowedIps = [], isLoading: loadingAllowedIps } = useQuery<AllowedIp[]>({
    queryKey: ["/api/security/allowed-ips"],
  });

  const addIpMutation = useMutation({
    mutationFn: async (data: { ip: string; notes: string }) => {
      return apiRequest("POST", "/api/security/blocked-ips", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/security/blocked-ips"] });
      toast({ title: "IP blocked successfully" });
      setIpDialogOpen(false);
      setNewIp("");
      setNewIpNotes("");
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to block IP", variant: "destructive" });
    },
  });

  const deleteIpMutation = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest("DELETE", `/api/security/blocked-ips/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/security/blocked-ips"] });
      toast({ title: "IP unblocked successfully" });
      setDeleteIpDialogOpen(false);
      setBlockedIpToDelete(null);
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to unblock IP", variant: "destructive" });
    },
  });

  const handleDeleteBlockedIpClick = (ip: BlockedIp) => {
    setBlockedIpToDelete(ip);
    setDeleteIpDialogOpen(true);
  };

  const confirmDeleteBlockedIp = () => {
    if (blockedIpToDelete) {
      deleteIpMutation.mutate(blockedIpToDelete.id);
    }
  };

  const addUaMutation = useMutation({
    mutationFn: async (data: { userAgent: string; exactMatch: boolean }) => {
      return apiRequest("POST", "/api/security/blocked-user-agents", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/security/blocked-user-agents"] });
      toast({ title: "User agent blocked successfully" });
      setUaDialogOpen(false);
      setNewUa("");
      setNewUaExactMatch(false);
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to block user agent", variant: "destructive" });
    },
  });

  const deleteUaMutation = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest("DELETE", `/api/security/blocked-user-agents/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/security/blocked-user-agents"] });
      toast({ title: "User agent unblocked successfully" });
      setDeleteUaDialogOpen(false);
      setBlockedUaToDelete(null);
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to unblock user agent", variant: "destructive" });
    },
  });

  const handleDeleteBlockedUaClick = (ua: BlockedUserAgent) => {
    setBlockedUaToDelete(ua);
    setDeleteUaDialogOpen(true);
  };

  const confirmDeleteBlockedUa = () => {
    if (blockedUaToDelete) {
      deleteUaMutation.mutate(blockedUaToDelete.id);
    }
  };

  const addAllowedIpMutation = useMutation({
    mutationFn: async (data: { ip: string; notes: string }) => {
      return apiRequest("POST", "/api/security/allowed-ips", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/security/allowed-ips"] });
      toast({ title: "IP added to whitelist successfully" });
      setAllowedIpDialogOpen(false);
      setNewAllowedIp("");
      setNewAllowedIpNotes("");
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to add IP to whitelist", variant: "destructive" });
    },
  });

  const deleteAllowedIpMutation = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest("DELETE", `/api/security/allowed-ips/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/security/allowed-ips"] });
      toast({ title: "IP removed from whitelist successfully" });
      setDeleteAllowedIpDialogOpen(false);
      setAllowedIpToDelete(null);
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to remove IP from whitelist", variant: "destructive" });
    },
  });

  const handleDeleteAllowedIpClick = (ip: AllowedIp) => {
    setAllowedIpToDelete(ip);
    setDeleteAllowedIpDialogOpen(true);
  };

  const confirmDeleteAllowedIp = () => {
    if (allowedIpToDelete) {
      deleteAllowedIpMutation.mutate(allowedIpToDelete.id);
    }
  };

  const formatDate = (timestamp: number) => {
    return new Date(timestamp * 1000).toLocaleString();
  };

  return (
    <div className="flex-1 p-6 space-y-6 overflow-y-auto">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-3xl font-bold" data-testid="text-security-title">Security</h1>
          <p className="text-muted-foreground">Manage IP blocking and access restrictions</p>
        </div>
      </div>

      <Tabs defaultValue="blocked-ips" className="space-y-4">
        <TabsList>
          <TabsTrigger value="allowed-ips" data-testid="tab-allowed-ips">
            <CheckCircle className="h-4 w-4 mr-2" />
            Allowed IPs
          </TabsTrigger>
          <TabsTrigger value="blocked-ips" data-testid="tab-blocked-ips">
            <Ban className="h-4 w-4 mr-2" />
            Blocked IPs
          </TabsTrigger>
          <TabsTrigger value="blocked-user-agents" data-testid="tab-blocked-user-agents">
            <MonitorSmartphone className="h-4 w-4 mr-2" />
            Blocked User Agents
          </TabsTrigger>
        </TabsList>

        <TabsContent value="allowed-ips" className="space-y-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between gap-4">
              <div>
                <CardTitle className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5" />
                  Allowed IP Addresses (Whitelist)
                </CardTitle>
                <CardDescription>
                  When IPs are added here, only these IPs can access the panel. Leave empty to allow all.
                </CardDescription>
              </div>
              <Button onClick={() => setAllowedIpDialogOpen(true)} data-testid="button-allow-ip">
                <Plus className="h-4 w-4 mr-2" />
                Add IP
              </Button>
            </CardHeader>
            <CardContent>
              {loadingAllowedIps ? (
                <div className="text-center py-8 text-muted-foreground">Loading...</div>
              ) : allowedIps.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <CheckCircle className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>No whitelist configured</p>
                  <p className="text-sm">All IP addresses are allowed to access the panel</p>
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>IP Address</TableHead>
                      <TableHead>Notes</TableHead>
                      <TableHead>Date Added</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {allowedIps.map((ip) => (
                      <TableRow key={ip.id} data-testid={`row-allowed-ip-${ip.id}`}>
                        <TableCell className="font-mono">{ip.ip}</TableCell>
                        <TableCell>{ip.notes || "-"}</TableCell>
                        <TableCell>{formatDate(ip.date)}</TableCell>
                        <TableCell className="text-right">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleDeleteAllowedIpClick(ip)}
                            disabled={deleteAllowedIpMutation.isPending}
                            data-testid={`button-remove-allowed-ip-${ip.id}`}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="blocked-ips" className="space-y-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between gap-4">
              <div>
                <CardTitle className="flex items-center gap-2">
                  <Globe className="h-5 w-5" />
                  Blocked IP Addresses
                </CardTitle>
                <CardDescription>
                  Block specific IP addresses from accessing the panel and streams
                </CardDescription>
              </div>
              <Button onClick={() => setIpDialogOpen(true)} data-testid="button-block-ip">
                <Plus className="h-4 w-4 mr-2" />
                Block IP
              </Button>
            </CardHeader>
            <CardContent>
              {loadingIps ? (
                <div className="text-center py-8 text-muted-foreground">Loading...</div>
              ) : blockedIps.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <Shield className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>No blocked IP addresses</p>
                  <p className="text-sm">Block IPs that should be denied access</p>
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>IP Address</TableHead>
                      <TableHead>Notes</TableHead>
                      <TableHead>Date Blocked</TableHead>
                      <TableHead>Attempts Blocked</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {blockedIps.map((ip) => (
                      <TableRow key={ip.id} data-testid={`row-blocked-ip-${ip.id}`}>
                        <TableCell className="font-mono">{ip.ip}</TableCell>
                        <TableCell>{ip.notes || "-"}</TableCell>
                        <TableCell>{formatDate(ip.date)}</TableCell>
                        <TableCell>
                          <Badge variant="secondary">{ip.attemptsBlocked}</Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleDeleteBlockedIpClick(ip)}
                            disabled={deleteIpMutation.isPending}
                            data-testid={`button-unblock-ip-${ip.id}`}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="blocked-user-agents" className="space-y-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between gap-4">
              <div>
                <CardTitle className="flex items-center gap-2">
                  <MonitorSmartphone className="h-5 w-5" />
                  Blocked User Agents
                </CardTitle>
                <CardDescription>
                  Block specific user agents from accessing streams
                </CardDescription>
              </div>
              <Button onClick={() => setUaDialogOpen(true)} data-testid="button-block-ua">
                <Plus className="h-4 w-4 mr-2" />
                Block User Agent
              </Button>
            </CardHeader>
            <CardContent>
              {loadingUas ? (
                <div className="text-center py-8 text-muted-foreground">Loading...</div>
              ) : blockedUserAgents.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <MonitorSmartphone className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>No blocked user agents</p>
                  <p className="text-sm">Block specific apps or devices from accessing streams</p>
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>User Agent</TableHead>
                      <TableHead>Match Type</TableHead>
                      <TableHead>Attempts Blocked</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {blockedUserAgents.map((ua) => (
                      <TableRow key={ua.id} data-testid={`row-blocked-ua-${ua.id}`}>
                        <TableCell className="font-mono max-w-md truncate">{ua.userAgent}</TableCell>
                        <TableCell>
                          <Badge variant={ua.exactMatch === 1 ? "default" : "secondary"}>
                            {ua.exactMatch === 1 ? "Exact" : "Contains"}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Badge variant="secondary">{ua.attemptsBlocked}</Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleDeleteBlockedUaClick(ua)}
                            disabled={deleteUaMutation.isPending}
                            data-testid={`button-unblock-ua-${ua.id}`}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <Dialog open={ipDialogOpen} onOpenChange={setIpDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Block IP Address</DialogTitle>
            <DialogDescription>
              Add an IP address to the blocklist. This will prevent access from this IP.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="ip">IP Address</Label>
              <Input
                id="ip"
                placeholder="192.168.1.100"
                value={newIp}
                onChange={(e) => setNewIp(e.target.value)}
                data-testid="input-block-ip"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="notes">Notes (optional)</Label>
              <Input
                id="notes"
                placeholder="Reason for blocking..."
                value={newIpNotes}
                onChange={(e) => setNewIpNotes(e.target.value)}
                data-testid="input-block-ip-notes"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIpDialogOpen(false)}>
              Cancel
            </Button>
            <Button
              onClick={() => addIpMutation.mutate({ ip: newIp, notes: newIpNotes })}
              disabled={!newIp || addIpMutation.isPending}
              data-testid="button-confirm-block-ip"
            >
              Block IP
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={uaDialogOpen} onOpenChange={setUaDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Block User Agent</DialogTitle>
            <DialogDescription>
              Block a specific user agent from accessing streams.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="userAgent">User Agent String</Label>
              <Input
                id="userAgent"
                placeholder="VLC/3.0.16 LibVLC/3.0.16"
                value={newUa}
                onChange={(e) => setNewUa(e.target.value)}
                data-testid="input-block-ua"
              />
            </div>
            <div className="flex items-center justify-between rounded-lg border p-3">
              <div>
                <Label>Exact Match</Label>
                <p className="text-sm text-muted-foreground">
                  If enabled, blocks only exact matches. Otherwise, blocks if contains.
                </p>
              </div>
              <Switch
                checked={newUaExactMatch}
                onCheckedChange={setNewUaExactMatch}
                data-testid="switch-exact-match"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setUaDialogOpen(false)}>
              Cancel
            </Button>
            <Button
              onClick={() => addUaMutation.mutate({ userAgent: newUa, exactMatch: newUaExactMatch })}
              disabled={!newUa || addUaMutation.isPending}
              data-testid="button-confirm-block-ua"
            >
              Block User Agent
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={allowedIpDialogOpen} onOpenChange={setAllowedIpDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add IP to Whitelist</DialogTitle>
            <DialogDescription>
              Add an IP address that is allowed to access the panel. When the whitelist has entries, only whitelisted IPs can access.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="allowedIp">IP Address</Label>
              <Input
                id="allowedIp"
                placeholder="192.168.1.100 or 192.168.1.*"
                value={newAllowedIp}
                onChange={(e) => setNewAllowedIp(e.target.value)}
                data-testid="input-allow-ip"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="allowedNotes">Notes (optional)</Label>
              <Input
                id="allowedNotes"
                placeholder="Admin office, My home IP..."
                value={newAllowedIpNotes}
                onChange={(e) => setNewAllowedIpNotes(e.target.value)}
                data-testid="input-allow-ip-notes"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setAllowedIpDialogOpen(false)}>
              Cancel
            </Button>
            <Button
              onClick={() => addAllowedIpMutation.mutate({ ip: newAllowedIp, notes: newAllowedIpNotes })}
              disabled={!newAllowedIp || addAllowedIpMutation.isPending}
              data-testid="button-confirm-allow-ip"
            >
              Add IP
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <DeleteConfirmation
        open={deleteIpDialogOpen}
        onOpenChange={setDeleteIpDialogOpen}
        onConfirm={confirmDeleteBlockedIp}
        title="Unblock IP Address"
        itemName={blockedIpToDelete?.ip}
      />

      <DeleteConfirmation
        open={deleteUaDialogOpen}
        onOpenChange={setDeleteUaDialogOpen}
        onConfirm={confirmDeleteBlockedUa}
        title="Unblock User Agent"
        itemName={blockedUaToDelete?.userAgent}
      />

      <DeleteConfirmation
        open={deleteAllowedIpDialogOpen}
        onOpenChange={setDeleteAllowedIpDialogOpen}
        onConfirm={confirmDeleteAllowedIp}
        title="Remove from Whitelist"
        itemName={allowedIpToDelete?.ip}
      />
    </div>
  );
}
