import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Plus,
  Search,
  Edit,
  Trash2,
  Clapperboard,
  Star,
  ChevronRight,
  Layers,
} from "lucide-react";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { DeleteConfirmation } from "@/components/delete-confirmation";

interface Category {
  id: number;
  name: string;
  type: string;
}

interface Series {
  id: number;
  name: string;
  categoryId: number | string | null;
  posterUrl: string | null;
  backdropUrl?: string | null;
  description: string | null;
  rating: string | null;
  releaseYear: string | null;
  genres: string | null;
  actors: string | null;
  isActive: boolean;
  tmdbId: number | null;
  totalSeasons: number;
  seriesId: number;
}

const seriesFormSchema = z.object({
  name: z.string().min(1, "Name is required"),
  categoryId: z.string().optional(),
  posterUrl: z.string().url("Must be a valid URL").optional().or(z.literal("")),
  backdropUrl: z.string().url("Must be a valid URL").optional().or(z.literal("")),
  description: z.string().optional(),
  rating: z.string().optional(),
  releaseYear: z.string().optional(),
  genres: z.string().optional(),
  isActive: z.boolean(),
});

type SeriesFormData = z.infer<typeof seriesFormSchema>;

function SeriesFormDialog({ 
  series, 
  categories,
  open, 
  onOpenChange 
}: { 
  series?: Series; 
  categories: Category[];
  open: boolean; 
  onOpenChange: (open: boolean) => void;
}) {
  const { toast } = useToast();
  const isEditing = !!series;

  const form = useForm<SeriesFormData>({
    resolver: zodResolver(seriesFormSchema),
    defaultValues: {
      name: series?.name || "",
      categoryId: series?.categoryId || "",
      posterUrl: series?.posterUrl || "",
      backdropUrl: series?.backdropUrl || "",
      description: series?.description || "",
      rating: series?.rating || "",
      releaseYear: series?.releaseYear || "",
      genres: series?.genres || "",
      isActive: series?.isActive ?? true,
    },
  });

  const mutation = useMutation({
    mutationFn: async (data: SeriesFormData) => {
      if (isEditing) {
        return apiRequest("PATCH", `/api/series/${series.id}`, data);
      }
      return apiRequest("POST", "/api/series", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/series"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({
        title: isEditing ? "Series updated" : "Series created",
      });
      onOpenChange(false);
      form.reset();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to save series",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: SeriesFormData) => {
    mutation.mutate(data);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{isEditing ? "Edit Series" : "Add New Series"}</DialogTitle>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Series Title</FormLabel>
                  <FormControl>
                    <Input placeholder="Breaking Bad" {...field} data-testid="input-series-name" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="categoryId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Category</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value || "none"}>
                      <FormControl>
                        <SelectTrigger data-testid="select-series-category">
                          <SelectValue placeholder="Select category" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="none">None</SelectItem>
                        {categories.filter(c => c.type === "series").map((cat) => (
                          <SelectItem key={cat.id} value={String(cat.id)}>{cat.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="releaseYear"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Release Year</FormLabel>
                    <FormControl>
                      <Input placeholder="2024" {...field} data-testid="input-series-year" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="posterUrl"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Poster URL</FormLabel>
                    <FormControl>
                      <Input placeholder="http://example.com/poster.jpg" {...field} data-testid="input-series-poster" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="backdropUrl"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Backdrop URL</FormLabel>
                    <FormControl>
                      <Input placeholder="http://example.com/backdrop.jpg" {...field} data-testid="input-series-backdrop" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="rating"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Rating</FormLabel>
                    <FormControl>
                      <Input placeholder="9.5" {...field} data-testid="input-series-rating" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="genres"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Genres</FormLabel>
                    <FormControl>
                      <Input placeholder="Drama, Crime" {...field} data-testid="input-series-genres" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description</FormLabel>
                  <FormControl>
                    <Textarea placeholder="Series description..." {...field} data-testid="input-series-description" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="isActive"
              render={({ field }) => (
                <FormItem className="flex items-center justify-between rounded-lg border p-3">
                  <div>
                    <FormLabel>Active</FormLabel>
                    <p className="text-sm text-muted-foreground">Enable this series for users</p>
                  </div>
                  <FormControl>
                    <Switch checked={field.value} onCheckedChange={field.onChange} data-testid="switch-series-active" />
                  </FormControl>
                </FormItem>
              )}
            />
            <div className="flex justify-end gap-2 pt-4">
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
                Cancel
              </Button>
              <Button type="submit" disabled={mutation.isPending} data-testid="button-save-series">
                {mutation.isPending ? "Saving..." : isEditing ? "Update" : "Create"}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}

function SeriesCard({ series, onEdit, onDelete }: { series: Series; onEdit: () => void; onDelete: () => void }) {
  return (
    <Card className="overflow-hidden hover-elevate group" data-testid={`series-card-${series.id}`}>
      <div className="aspect-[2/3] relative bg-muted">
        {series.posterUrl ? (
          <img 
            src={series.posterUrl} 
            alt={series.name}
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <Clapperboard className="h-12 w-12 text-muted-foreground/50" />
          </div>
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity">
          <div className="absolute bottom-0 left-0 right-0 p-4">
            <div className="flex gap-2">
              <Button size="sm" variant="secondary" className="flex-1" onClick={onEdit}>
                <Edit className="h-4 w-4 mr-1" />
                Edit
              </Button>
              <Button size="sm" variant="destructive" onClick={onDelete}>
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
        {series.rating && (
          <Badge className="absolute top-2 right-2 bg-black/70">
            <Star className="h-3 w-3 mr-1 fill-yellow-400 text-yellow-400" />
            {series.rating}
          </Badge>
        )}
        {!series.isActive && (
          <Badge variant="secondary" className="absolute top-2 left-2">
            Inactive
          </Badge>
        )}
      </div>
      <CardContent className="p-3">
        <h4 className="font-medium truncate">{series.name}</h4>
        <div className="flex items-center gap-2 mt-1 text-xs text-muted-foreground">
          {series.releaseYear && <span>{series.releaseYear}</span>}
          {series.genres && (
            <>
              <span className="w-1 h-1 rounded-full bg-muted-foreground" />
              <span className="truncate">{series.genres}</span>
            </>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

export default function SeriesPage() {
  const [search, setSearch] = useState("");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingSeries, setEditingSeries] = useState<Series | undefined>();
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [seriesToDelete, setSeriesToDelete] = useState<Series | null>(null);
  const { toast } = useToast();

  const { data: seriesList, isLoading } = useQuery<Series[]>({
    queryKey: ["/api/series"],
  });

  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      return apiRequest("DELETE", `/api/series/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/series"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({ title: "Series deleted" });
      setDeleteDialogOpen(false);
      setSeriesToDelete(null);
    },
  });

  const handleDeleteClick = (series: Series) => {
    setSeriesToDelete(series);
    setDeleteDialogOpen(true);
  };

  const confirmDelete = () => {
    if (seriesToDelete) {
      deleteMutation.mutate(seriesToDelete.id);
    }
  };

  const filteredSeries = seriesList?.filter(series => 
    series.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-3xl font-bold tracking-tight" data-testid="page-title">TV Series</h1>
          <p className="text-muted-foreground">Manage TV shows and episodes</p>
        </div>
        <Button onClick={() => { setEditingSeries(undefined); setDialogOpen(true); }} data-testid="button-add-series">
          <Plus className="h-4 w-4 mr-2" />
          Add Series
        </Button>
      </div>

      <div className="flex items-center gap-4">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search series..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
            data-testid="input-search-series"
          />
        </div>
        <Badge variant="outline">{seriesList?.length || 0} series</Badge>
      </div>

      {isLoading ? (
        <div className="grid gap-4 grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6">
          {Array(12).fill(0).map((_, i) => (
            <Card key={i} className="overflow-hidden">
              <Skeleton className="aspect-[2/3]" />
              <CardContent className="p-3">
                <Skeleton className="h-4 w-3/4 mb-2" />
                <Skeleton className="h-3 w-1/2" />
              </CardContent>
            </Card>
          ))}
        </div>
      ) : filteredSeries && filteredSeries.length > 0 ? (
        <div className="grid gap-4 grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6">
          {filteredSeries.map((series) => (
            <SeriesCard 
              key={series.id} 
              series={series} 
              onEdit={() => { setEditingSeries(series); setDialogOpen(true); }}
              onDelete={() => handleDeleteClick(series)}
            />
          ))}
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center py-24 text-center">
          <Clapperboard className="h-16 w-16 text-muted-foreground/50 mb-4" />
          <h3 className="text-lg font-medium mb-1">No series found</h3>
          <p className="text-muted-foreground mb-4">Get started by adding your first TV series</p>
          <Button onClick={() => { setEditingSeries(undefined); setDialogOpen(true); }}>
            <Plus className="h-4 w-4 mr-2" />
            Add Series
          </Button>
        </div>
      )}

      <SeriesFormDialog 
        series={editingSeries} 
        categories={categories}
        open={dialogOpen} 
        onOpenChange={setDialogOpen} 
      />

      <DeleteConfirmation
        open={deleteDialogOpen}
        onOpenChange={setDeleteDialogOpen}
        onConfirm={confirmDelete}
        title="Delete Series"
        itemName={seriesToDelete?.name}
      />
    </div>
  );
}
