import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import { Progress } from "@/components/ui/progress";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
  FormDescription,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Alert,
  AlertDescription,
} from "@/components/ui/alert";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Plus,
  Search,
  MoreHorizontal,
  Edit,
  Trash2,
  Server,
  Cpu,
  HardDrive,
  Wifi,
  Users,
  Globe,
  Power,
  RefreshCw,
  Settings,
  Shield,
  Zap,
  Lock,
  Download,
  Eye,
  Network,
  Activity,
  Info,
  Check,
  X,
  Loader2,
  Terminal,
} from "lucide-react";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { DeleteConfirmation } from "@/components/delete-confirmation";

interface ServerType {
  id: number;
  name: string;
  domainName: string;
  serverIp?: string;
  privateIp?: string;
  httpPort: number;
  httpsPort: number;
  rtmpPort: number;
  sshPort?: number;
  status: string;
  totalClients: number;
  maxClients: number;
  isMain: boolean;
  isActive: boolean;
  timeshiftOnly?: boolean;
  proxied?: boolean;
  networkInterface?: string;
  networkSpeed?: number;
  geoipPriority?: string;
  geoipCountries?: string;
  geoipLoadBalancing?: boolean;
  ispPriority?: string;
  ispNames?: string;
  ispLoadBalancing?: boolean;
  cpuUsage?: number;
  ramUsage?: number;
  diskUsage?: number;
}

interface ServerMonitoringStats {
  id: number;
  name: string;
  domainName: string;
  serverIp: string;
  status: string;
  isMain: boolean;
  isLoadBalancer: boolean;
  activeClients: number;
  maxClients: number;
  activeStreams: number;
  totalStreams: number;
  uploadMbps: number;
  downloadMbps: number;
  totalBandwidthMbps: number;
  cpuUsage: number;
  memoryUsage: number;
  diskUsage: number;
  networkIn: number;
  networkOut: number;
  metricsStatus: "live" | "stale";
  lastMetricsUpdate: string | null;
  metricsAgeSeconds: number | null;
  uptime: string;
  lastSeen: string | null;
}

interface MonitoringResponse {
  servers: ServerMonitoringStats[];
  totals: {
    totalServers: number;
    onlineServers: number;
    offlineServers: number;
    totalClients: number;
    totalStreams: number;
    totalUploadMbps: number;
    totalDownloadMbps: number;
    avgCpuUsage: number;
    avgMemoryUsage: number;
  };
  timestamp: string;
}

const detailsFormSchema = z.object({
  name: z.string().min(1, "Server name is required"),
  serverIp: z.string().min(1, "Server IP is required"),
  privateIp: z.string().optional(),
  maxClients: z.coerce.number().min(1).default(2000),
  timeshiftOnly: z.boolean().default(false),
  isActive: z.boolean().default(true),
  proxied: z.boolean().default(false),
});

const advancedFormSchema = z.object({
  httpPorts: z.string().default("80,8080"),
  httpsPorts: z.string().default("443"),
  rtmpPort: z.coerce.number().min(1).max(65535).default(8880),
  disableRamdisk: z.boolean().default(false),
  networkInterface: z.string().default("eth0"),
  networkSpeed: z.coerce.number().min(0).default(1000),
  geoipPriority: z.enum(["high_priority", "low_priority"]).default("high_priority"),
  geoipCountries: z.string().default(""),
  geoipLoadBalancing: z.boolean().default(true),
  ispPriority: z.enum(["high_priority", "low_priority"]).default("high_priority"),
  ispNames: z.string().default(""),
  ispLoadBalancing: z.boolean().default(true),
});

const performanceFormSchema = z.object({
  phpVersion: z.string().default("8.1"),
  phpServices: z.coerce.number().min(1).max(100).default(20),
  rateLimitPerSecond: z.coerce.number().min(0).default(0),
  rateLimitBurstQueue: z.coerce.number().min(0).default(0),
  cpuGovernor: z.string().default("performance"),
  customSysctl: z.string().default(""),
});

const installFormSchema = z.object({
  name: z.string().min(1, "Server name is required"),
  serverIp: z.string().min(1, "Server IP is required"),
  sshPort: z.coerce.number().min(1).max(65535).default(22),
  sshUsername: z.string().default("root"),
  sshPassword: z.string().min(1, "SSH password is required"),
  mainServerIp: z.string().min(1, "Main server IP is required"),
  updateSysctl: z.boolean().default(true),
});

type DetailsFormData = z.infer<typeof detailsFormSchema>;
type AdvancedFormData = z.infer<typeof advancedFormSchema>;
type PerformanceFormData = z.infer<typeof performanceFormSchema>;
type InstallFormData = z.infer<typeof installFormSchema>;

function ServerInstallWizard({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const { toast } = useToast();
  const [installing, setInstalling] = useState(false);
  const [installProgress, setInstallProgress] = useState(0);
  const [installLog, setInstallLog] = useState<string[]>([]);

  const form = useForm<InstallFormData>({
    resolver: zodResolver(installFormSchema),
    defaultValues: {
      name: "",
      serverIp: "",
      sshPort: 22,
      sshUsername: "root",
      sshPassword: "",
      mainServerIp: "",
      updateSysctl: true,
    },
  });

  const mutation = useMutation({
    mutationFn: async (data: InstallFormData) => {
      return apiRequest("POST", "/api/servers/install", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/servers"] });
      toast({ title: "Server installation started" });
      setInstalling(true);
      simulateInstall();
    },
    onError: () => {
      toast({
        title: "Installation failed",
        description: "Could not connect to server",
        variant: "destructive",
      });
    },
  });

  const simulateInstall = () => {
    const steps = [
      "Connecting to server via SSH...",
      "Checking system requirements...",
      "Updating package repositories...",
      "Installing nginx...",
      "Installing PHP and dependencies...",
      "Configuring nginx for streaming...",
      "Setting up firewall rules...",
      "Optimizing system settings...",
      "Installing streaming components...",
      "Finalizing installation...",
    ];

    let currentStep = 0;
    const interval = setInterval(() => {
      if (currentStep < steps.length) {
        setInstallLog((prev) => [...prev, steps[currentStep]]);
        setInstallProgress(((currentStep + 1) / steps.length) * 100);
        currentStep++;
      } else {
        clearInterval(interval);
        setInstallLog((prev) => [...prev, "Installation completed successfully!"]);
        queryClient.invalidateQueries({ queryKey: ["/api/servers"] });
        toast({ title: "Server installed successfully" });
        setTimeout(() => {
          setInstalling(false);
          setInstallProgress(0);
          setInstallLog([]);
          onOpenChange(false);
          form.reset();
        }, 2000);
      }
    }, 1500);
  };

  const onSubmit = (data: InstallFormData) => {
    mutation.mutate(data);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Download className="h-5 w-5" />
            Server Installation
          </DialogTitle>
          <DialogDescription>
            Install streaming software on a new server. The panel will connect via SSH and configure nginx automatically.
          </DialogDescription>
        </DialogHeader>

        {!installing ? (
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <div className="bg-primary/5 rounded-lg p-4 border">
                <h3 className="font-medium flex items-center gap-2 mb-4">
                  <Settings className="h-4 w-4" />
                  Details
                </h3>
                <div className="space-y-4">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Server Name</FormLabel>
                        <FormControl>
                          <Input placeholder="EU-Server-1" {...field} data-testid="input-install-server-name" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="serverIp"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Server IP</FormLabel>
                          <FormControl>
                            <Input placeholder="192.168.1.100" {...field} data-testid="input-install-server-ip" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="sshPort"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>SSH Port</FormLabel>
                          <FormControl>
                            <Input type="number" {...field} data-testid="input-install-ssh-port" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="sshUsername"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>SSH Username</FormLabel>
                          <FormControl>
                            <Input placeholder="root" {...field} data-testid="input-install-ssh-username" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="sshPassword"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>SSH Password</FormLabel>
                          <FormControl>
                            <Input type="password" placeholder="Enter password" {...field} data-testid="input-install-ssh-password" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  <FormField
                    control={form.control}
                    name="mainServerIp"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Main Server IP</FormLabel>
                        <FormControl>
                          <Input placeholder="IP address of your main panel server" {...field} data-testid="input-install-main-server-ip" />
                        </FormControl>
                        <FormDescription className="text-xs">LB will proxy all traffic to this IP on port 5000</FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="updateSysctl"
                    render={({ field }) => (
                      <FormItem className="flex items-center justify-between rounded-lg border p-3">
                        <div>
                          <FormLabel>Update sysctl.conf</FormLabel>
                          <FormDescription className="text-xs">Optimize kernel parameters for streaming</FormDescription>
                        </div>
                        <FormControl>
                          <Switch checked={field.value} onCheckedChange={field.onChange} data-testid="switch-update-sysctl" />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                </div>
              </div>

              <Alert>
                <Info className="h-4 w-4" />
                <AlertDescription>
                  Installation will begin immediately. You will be alerted of progress on the Server View page. After installation is complete you can amend the ports and other server settings.
                </AlertDescription>
              </Alert>

              <div className="flex justify-end gap-2">
                <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
                  Cancel
                </Button>
                <Button type="submit" disabled={mutation.isPending} data-testid="button-install-server">
                  {mutation.isPending ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Connecting...
                    </>
                  ) : (
                    "Install Server"
                  )}
                </Button>
              </div>
            </form>
          </Form>
        ) : (
          <div className="space-y-4">
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Installation Progress</span>
                <span>{Math.round(installProgress)}%</span>
              </div>
              <Progress value={installProgress} className="h-2" />
            </div>
            <div className="bg-muted rounded-lg p-4 font-mono text-xs max-h-60 overflow-y-auto">
              {installLog.map((log, i) => (
                <div key={i} className="flex items-center gap-2 py-1">
                  {i === installLog.length - 1 && installProgress < 100 ? (
                    <Loader2 className="h-3 w-3 animate-spin text-primary" />
                  ) : (
                    <Check className="h-3 w-3 text-emerald-500" />
                  )}
                  <span>{log}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

const defaultSysctl = `# X NeoServ
net.core.somaxconn = 655350
net.ipv4.route.flush=1
net.ipv4.tcp_no_metrics_save=1
net.ipv4.tcp_moderate_rcvbuf = 1
fs.file-max = 6815744
fs.aio-max-nr = 6815744
fs.nr_open = 6815744
net.ipv4.ip_local_port_range = 1024 65000
net.ipv4.tcp_sack = 1
net.ipv4.tcp_rmem = 10000000 10000000 10000000
net.ipv4.tcp_wmem = 10000000 10000000 10000000
net.ipv4.tcp_mem = 10000000 10000000 10000000
net.core.rmem_max = 524287
net.core.wmem_max = 524287`;

function ServerEditDialog({
  server,
  open,
  onOpenChange,
}: {
  server?: ServerType;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("details");

  // Fetch performance settings for this server
  const { data: perfData } = useQuery<PerformanceFormData>({
    queryKey: ["/api/servers", server?.id, "performance"],
    enabled: !!server?.id && open,
  });

  const detailsForm = useForm<DetailsFormData>({
    resolver: zodResolver(detailsFormSchema),
    defaultValues: {
      name: "",
      serverIp: "",
      privateIp: "",
      maxClients: 2000,
      timeshiftOnly: false,
      isActive: true,
      proxied: false,
    },
  });

  const advancedForm = useForm<AdvancedFormData>({
    resolver: zodResolver(advancedFormSchema),
    defaultValues: {
      httpPorts: "80,8080",
      httpsPorts: "443",
      rtmpPort: 8880,
      disableRamdisk: false,
      networkInterface: "eth0",
      networkSpeed: 1000,
      geoipPriority: "high_priority",
      geoipCountries: "",
      geoipLoadBalancing: true,
      ispPriority: "high_priority",
      ispNames: "",
      ispLoadBalancing: true,
    },
  });

  const performanceForm = useForm<PerformanceFormData>({
    resolver: zodResolver(performanceFormSchema),
    defaultValues: {
      phpVersion: "8.1",
      phpServices: 20,
      rateLimitPerSecond: 0,
      rateLimitBurstQueue: 0,
      cpuGovernor: "performance",
      customSysctl: defaultSysctl,
    },
  });

  // Reset all forms when server changes or dialog opens
  useEffect(() => {
    if (open) {
      if (server) {
        detailsForm.reset({
          name: server.name,
          serverIp: server.serverIp || server.domainName,
          privateIp: server.privateIp || "",
          maxClients: server.maxClients || 2000,
          timeshiftOnly: server.timeshiftOnly ?? false,
          isActive: server.isActive ?? true,
          proxied: server.proxied ?? false,
        });

        advancedForm.reset({
          httpPorts: server.httpPort ? `${server.httpPort},8080` : "80,8080",
          httpsPorts: server.httpsPort ? `${server.httpsPort}` : "443",
          rtmpPort: server.rtmpPort || 8880,
          disableRamdisk: false,
          networkInterface: server.networkInterface || "eth0",
          networkSpeed: server.networkSpeed || 1000,
          geoipPriority: (server.geoipPriority as "high_priority" | "low_priority") || "high_priority",
          geoipCountries: server.geoipCountries || "",
          geoipLoadBalancing: server.geoipLoadBalancing ?? true,
          ispPriority: (server.ispPriority as "high_priority" | "low_priority") || "high_priority",
          ispNames: server.ispNames || "",
          ispLoadBalancing: server.ispLoadBalancing ?? true,
        });
      } else {
        // Reset to defaults for new server
        detailsForm.reset({
          name: "",
          serverIp: "",
          privateIp: "",
          maxClients: 2000,
          timeshiftOnly: false,
          isActive: true,
          proxied: false,
        });
        advancedForm.reset({
          httpPorts: "80,8080",
          httpsPorts: "443",
          rtmpPort: 8880,
          disableRamdisk: false,
          networkInterface: "eth0",
          networkSpeed: 1000,
          geoipPriority: "high_priority",
          geoipCountries: "",
          geoipLoadBalancing: true,
          ispPriority: "high_priority",
          ispNames: "",
          ispLoadBalancing: true,
        });
      }
    }
  }, [server, open, detailsForm, advancedForm]);

  // Reset performance form when perfData loads
  useEffect(() => {
    if (perfData) {
      performanceForm.reset({
        phpVersion: perfData.phpVersion || "8.1",
        phpServices: perfData.phpServices || 20,
        rateLimitPerSecond: perfData.rateLimitPerSecond || 0,
        rateLimitBurstQueue: perfData.rateLimitBurstQueue || 0,
        cpuGovernor: perfData.cpuGovernor || "performance",
        customSysctl: perfData.customSysctl || defaultSysctl,
      });
    }
  }, [perfData, performanceForm]);

  const mutation = useMutation({
    mutationFn: async (data: DetailsFormData & Partial<AdvancedFormData> & Partial<PerformanceFormData> & { domainName?: string; httpPort?: number; httpsPort?: number }) => {
      if (server) {
        return apiRequest("PATCH", `/api/servers/${server.id}`, data);
      }
      return apiRequest("POST", "/api/servers", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/servers"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      if (server?.id) {
        queryClient.invalidateQueries({ queryKey: ["/api/servers", server.id, "performance"] });
      }
      toast({ title: server ? "Server updated" : "Server created" });
      onOpenChange(false);
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to save server",
        variant: "destructive",
      });
    },
  });

  const handleSave = () => {
    const detailsData = detailsForm.getValues();
    const advancedData = advancedForm.getValues();
    const performanceData = performanceForm.getValues();
    mutation.mutate({
      ...detailsData,
      ...advancedData,
      ...performanceData,
      domainName: detailsData.serverIp,
      httpPort: parseInt(advancedData.httpPorts.split(",")[0]) || 80,
      httpsPort: parseInt(advancedData.httpsPorts.split(",")[0]) || 443,
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle className="flex items-center gap-2">
              <Server className="h-5 w-5" />
              {server ? "Edit Server" : "Add Server"}
            </DialogTitle>
            {server && (
              <Button variant="outline" size="sm" data-testid="button-view-server">
                <Eye className="h-4 w-4 mr-2" />
                View Server
              </Button>
            )}
          </div>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid grid-cols-5 w-full">
            <TabsTrigger value="details" className="flex items-center gap-2" data-testid="tab-details">
              <Settings className="h-4 w-4" />
              Details
            </TabsTrigger>
            <TabsTrigger value="domains" className="flex items-center gap-2" data-testid="tab-domains">
              <Globe className="h-4 w-4" />
              Domains & IPs
            </TabsTrigger>
            <TabsTrigger value="advanced" className="flex items-center gap-2" data-testid="tab-advanced">
              <Network className="h-4 w-4" />
              Advanced
            </TabsTrigger>
            <TabsTrigger value="performance" className="flex items-center gap-2" data-testid="tab-performance">
              <Zap className="h-4 w-4" />
              Performance
            </TabsTrigger>
            <TabsTrigger value="ssl" className="flex items-center gap-2" data-testid="tab-ssl">
              <Shield className="h-4 w-4" />
              SSL Certificate
            </TabsTrigger>
          </TabsList>

          <TabsContent value="details" className="mt-6 space-y-4">
            <Form {...detailsForm}>
              <div className="space-y-4">
                <FormField
                  control={detailsForm.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Server Name</FormLabel>
                      <FormControl>
                        <Input placeholder="AMS-185-4-(3GB)" {...field} data-testid="input-server-name" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={detailsForm.control}
                  name="serverIp"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Server IP</FormLabel>
                      <FormControl>
                        <Input placeholder="192.168.1.1" {...field} data-testid="input-server-ip" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={detailsForm.control}
                  name="privateIp"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Private IP</FormLabel>
                      <FormControl>
                        <Input placeholder="10.0.0.1" {...field} data-testid="input-private-ip" />
                      </FormControl>
                      <FormDescription className="text-xs">Optional internal network IP</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={detailsForm.control}
                    name="maxClients"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Max Clients</FormLabel>
                        <FormControl>
                          <Input type="number" placeholder="2000" {...field} data-testid="input-max-clients" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={detailsForm.control}
                    name="timeshiftOnly"
                    render={({ field }) => (
                      <FormItem className="flex items-center justify-between rounded-lg border p-3 h-[72px]">
                        <FormLabel>Timeshift Only</FormLabel>
                        <FormControl>
                          <Switch checked={field.value} onCheckedChange={field.onChange} data-testid="switch-timeshift-only" />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={detailsForm.control}
                    name="isActive"
                    render={({ field }) => (
                      <FormItem className="flex items-center justify-between rounded-lg border p-3">
                        <FormLabel>Enabled</FormLabel>
                        <FormControl>
                          <Switch checked={field.value} onCheckedChange={field.onChange} data-testid="switch-server-enabled" />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={detailsForm.control}
                    name="proxied"
                    render={({ field }) => (
                      <FormItem className="flex items-center justify-between rounded-lg border p-3">
                        <FormLabel>Proxied</FormLabel>
                        <FormControl>
                          <Switch checked={field.value} onCheckedChange={field.onChange} data-testid="switch-server-proxied" />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                </div>
              </div>
            </Form>
          </TabsContent>

          <TabsContent value="domains" className="mt-6 space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Server Domains & IP Addresses</CardTitle>
                <CardDescription>Manage multiple domains and IPs for this server</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex gap-2">
                    <Input placeholder="Enter domain or IP address" data-testid="input-add-domain" />
                    <Button data-testid="button-add-domain">
                      <Plus className="h-4 w-4 mr-2" />
                      Add
                    </Button>
                  </div>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Type</TableHead>
                        <TableHead>Domain / IP</TableHead>
                        <TableHead>SSL</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="w-20">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      <TableRow>
                        <TableCell>
                          <Badge variant="outline">IP</Badge>
                        </TableCell>
                        <TableCell>{server?.serverIp || server?.domainName || "192.168.1.1"}</TableCell>
                        <TableCell>
                          <Badge variant="secondary">None</Badge>
                        </TableCell>
                        <TableCell>
                          <Badge className="bg-emerald-500/10 text-emerald-500 border-emerald-500/20">Active</Badge>
                        </TableCell>
                        <TableCell>
                          <Button variant="ghost" size="icon">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="advanced" className="mt-6 space-y-4">
            <Form {...advancedForm}>
              <div className="space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={advancedForm.control}
                    name="httpPorts"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>HTTP Ports</FormLabel>
                        <FormControl>
                          <Input placeholder="80,8080" {...field} data-testid="input-http-ports" />
                        </FormControl>
                        <FormDescription className="text-xs">Comma separated</FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={advancedForm.control}
                    name="httpsPorts"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>HTTPS Ports</FormLabel>
                        <FormControl>
                          <Input placeholder="443" {...field} data-testid="input-https-ports" />
                        </FormControl>
                        <FormDescription className="text-xs">Comma separated</FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={advancedForm.control}
                    name="rtmpPort"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>RTMP Port</FormLabel>
                        <FormControl>
                          <Input type="number" {...field} data-testid="input-rtmp-port" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={advancedForm.control}
                    name="disableRamdisk"
                    render={({ field }) => (
                      <FormItem className="flex items-center justify-between rounded-lg border p-3 h-[72px]">
                        <FormLabel>Disable Ramdisk</FormLabel>
                        <FormControl>
                          <Switch checked={field.value} onCheckedChange={field.onChange} data-testid="switch-disable-ramdisk" />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={advancedForm.control}
                    name="networkInterface"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Network Interface</FormLabel>
                        <Select onValueChange={field.onChange} value={field.value}>
                          <FormControl>
                            <SelectTrigger data-testid="select-network-interface">
                              <SelectValue placeholder="Select interface" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="eth0">eth0</SelectItem>
                            <SelectItem value="eth1">eth1</SelectItem>
                            <SelectItem value="enp2s0">enp2s0</SelectItem>
                            <SelectItem value="ens3">ens3</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={advancedForm.control}
                    name="networkSpeed"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Network Speed (Mbps)</FormLabel>
                        <FormControl>
                          <Input type="number" {...field} data-testid="input-network-speed" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="border-t pt-4">
                  <h4 className="font-medium mb-4">GeoIP Settings</h4>
                  <div className="space-y-4">
                    <FormField
                      control={advancedForm.control}
                      name="geoipPriority"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>GeoIP Priority</FormLabel>
                          <Select onValueChange={field.onChange} value={field.value}>
                            <FormControl>
                              <SelectTrigger data-testid="select-geoip-priority">
                                <SelectValue />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="high_priority">High Priority</SelectItem>
                              <SelectItem value="low_priority">Low Priority</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={advancedForm.control}
                      name="geoipCountries"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>GeoIP Countries</FormLabel>
                          <FormControl>
                            <Input placeholder="US,GB,DE,FR" {...field} data-testid="input-geoip-countries" />
                          </FormControl>
                          <FormDescription className="text-xs">Comma separated country codes</FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={advancedForm.control}
                      name="geoipLoadBalancing"
                      render={({ field }) => (
                        <FormItem className="flex items-center justify-between rounded-lg border p-3">
                          <FormLabel>GeoIP Load Balancing</FormLabel>
                          <FormControl>
                            <Switch checked={field.value} onCheckedChange={field.onChange} data-testid="switch-geoip-lb" />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                  </div>
                </div>

                <div className="border-t pt-4">
                  <h4 className="font-medium mb-4">ISP Settings</h4>
                  <div className="space-y-4">
                    <FormField
                      control={advancedForm.control}
                      name="ispPriority"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>GeoISP Priority</FormLabel>
                          <Select onValueChange={field.onChange} value={field.value}>
                            <FormControl>
                              <SelectTrigger data-testid="select-isp-priority">
                                <SelectValue />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="high_priority">High Priority</SelectItem>
                              <SelectItem value="low_priority">Low Priority</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={advancedForm.control}
                      name="ispNames"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>GeoISP Names</FormLabel>
                          <FormControl>
                            <Input placeholder="Comcast,AT&T,Verizon" {...field} data-testid="input-isp-names" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={advancedForm.control}
                      name="ispLoadBalancing"
                      render={({ field }) => (
                        <FormItem className="flex items-center justify-between rounded-lg border p-3">
                          <FormLabel>GeoISP Load Balancing</FormLabel>
                          <FormControl>
                            <Switch checked={field.value} onCheckedChange={field.onChange} data-testid="switch-isp-lb" />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                  </div>
                </div>
              </div>
            </Form>
          </TabsContent>

          <TabsContent value="performance" className="mt-6 space-y-4">
            <Form {...performanceForm}>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={performanceForm.control}
                    name="phpVersion"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>PHP Version</FormLabel>
                        <Select onValueChange={field.onChange} value={field.value}>
                          <FormControl>
                            <SelectTrigger data-testid="select-php-version">
                              <SelectValue />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="7.4">PHP 7.4.10</SelectItem>
                            <SelectItem value="8.0">PHP 8.0</SelectItem>
                            <SelectItem value="8.1">PHP 8.1</SelectItem>
                            <SelectItem value="8.2">PHP 8.2</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={performanceForm.control}
                    name="phpServices"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>PHP Services</FormLabel>
                        <FormControl>
                          <Input type="number" {...field} data-testid="input-php-services" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={performanceForm.control}
                    name="rateLimitPerSecond"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Rate Limit - Per Second</FormLabel>
                        <FormControl>
                          <Input type="number" {...field} data-testid="input-rate-limit-per-second" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={performanceForm.control}
                    name="rateLimitBurstQueue"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Rate Limit - Burst Queue</FormLabel>
                        <FormControl>
                          <Input type="number" {...field} data-testid="input-rate-limit-burst" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                <FormField
                  control={performanceForm.control}
                  name="cpuGovernor"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>CPU Governor</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-cpu-governor">
                            <SelectValue />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="performance">* - Freq: 0GHz - 0GHz</SelectItem>
                          <SelectItem value="powersave">Powersave</SelectItem>
                          <SelectItem value="ondemand">Ondemand</SelectItem>
                          <SelectItem value="conservative">Conservative</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={performanceForm.control}
                  name="customSysctl"
                  render={({ field }) => (
                    <FormItem>
                      <div className="flex items-center justify-between">
                        <FormLabel>Custom Sysctl.conf</FormLabel>
                        <Button 
                          variant="outline" 
                          size="sm" 
                          type="button"
                          onClick={() => performanceForm.setValue("customSysctl", defaultSysctl)}
                          data-testid="button-default-sysctl"
                        >
                          Default
                        </Button>
                      </div>
                      <FormControl>
                        <Textarea
                          className="font-mono text-xs min-h-[200px]"
                          {...field}
                          data-testid="textarea-custom-sysctl"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </Form>
          </TabsContent>

          <TabsContent value="ssl" className="mt-6 space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Lock className="h-4 w-4" />
                  SSL Certificate Management
                </CardTitle>
                <CardDescription>Configure SSL certificates for secure streaming</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div>
                    <p className="font-medium">Auto-generate Let's Encrypt Certificate</p>
                    <p className="text-sm text-muted-foreground">Free SSL certificate with automatic renewal</p>
                  </div>
                  <Switch data-testid="switch-lets-encrypt" />
                </div>
                <div className="grid gap-4">
                  <div>
                    <Label>SSL Certificate (PEM)</Label>
                    <Textarea
                      placeholder="-----BEGIN CERTIFICATE-----&#10;...&#10;-----END CERTIFICATE-----"
                      className="font-mono text-xs min-h-[100px] mt-2"
                      data-testid="textarea-ssl-cert"
                    />
                  </div>
                  <div>
                    <Label>SSL Private Key</Label>
                    <Textarea
                      placeholder="-----BEGIN PRIVATE KEY-----&#10;...&#10;-----END PRIVATE KEY-----"
                      className="font-mono text-xs min-h-[100px] mt-2"
                      data-testid="textarea-ssl-key"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <div className="flex justify-between pt-4 border-t">
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <div className="flex gap-2">
            {activeTab !== "details" && (
              <Button
                variant="outline"
                onClick={() => {
                  const tabs = ["details", "domains", "advanced", "performance", "ssl"];
                  const currentIndex = tabs.indexOf(activeTab);
                  if (currentIndex > 0) setActiveTab(tabs[currentIndex - 1]);
                }}
              >
                Previous
              </Button>
            )}
            {activeTab !== "ssl" ? (
              <Button
                onClick={() => {
                  const tabs = ["details", "domains", "advanced", "performance", "ssl"];
                  const currentIndex = tabs.indexOf(activeTab);
                  if (currentIndex < tabs.length - 1) setActiveTab(tabs[currentIndex + 1]);
                }}
              >
                Next
              </Button>
            ) : (
              <Button onClick={handleSave} disabled={mutation.isPending} data-testid="button-save-server">
                {mutation.isPending ? "Saving..." : "Save Server"}
              </Button>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function ServerCard({ server, onEdit, onDelete, onView, onDeploy }: { server: ServerType; onEdit: () => void; onDelete: () => void; onView: () => void; onDeploy?: () => void }) {
  const statusColors = {
    online: "bg-emerald-500",
    offline: "bg-red-500",
    maintenance: "bg-amber-500",
  };

  const statusBadges = {
    online: "default" as const,
    offline: "destructive" as const,
    maintenance: "secondary" as const,
  };

  return (
    <Card className="hover-elevate" data-testid={`server-card-${server.id}`}>
      <CardHeader className="flex flex-row items-start justify-between gap-4 pb-2">
        <div className="flex items-center gap-3">
          <div className={`w-3 h-3 rounded-full ${statusColors[server.status as keyof typeof statusColors] || "bg-gray-500"}`} />
          <div>
            <CardTitle className="text-lg flex items-center gap-2">
              {server.name}
              {server.isMain && (
                <Badge variant="outline" className="text-xs">Main</Badge>
              )}
            </CardTitle>
            <p className="text-sm text-muted-foreground">{server.domainName}</p>
          </div>
        </div>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon" data-testid={`button-server-menu-${server.id}`}>
              <MoreHorizontal className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onClick={onView}>
              <Eye className="h-4 w-4 mr-2" />
              View Dashboard
            </DropdownMenuItem>
            <DropdownMenuItem onClick={onEdit}>
              <Edit className="h-4 w-4 mr-2" />
              Edit
            </DropdownMenuItem>
            {!server.isMain && onDeploy && (
              <>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={onDeploy}>
                  <Download className="h-4 w-4 mr-2" />
                  Deploy LB Proxy
                </DropdownMenuItem>
              </>
            )}
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={onDelete} className="text-destructive">
              <Trash2 className="h-4 w-4 mr-2" />
              Delete
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between">
          <Badge variant={statusBadges[server.status as keyof typeof statusBadges] || "secondary"}>
            {server.status}
          </Badge>
          <div className="flex items-center gap-1 text-sm text-muted-foreground">
            <Users className="h-4 w-4" />
            <span>{server.totalClients}/{server.maxClients || 2000}</span>
          </div>
        </div>

        <div className="space-y-3">
          <div>
            <div className="flex items-center justify-between text-sm mb-1">
              <div className="flex items-center gap-2 text-muted-foreground">
                <Cpu className="h-3.5 w-3.5" />
                <span>CPU</span>
              </div>
              <span className="font-medium">{server.cpuUsage || 0}%</span>
            </div>
            <Progress value={server.cpuUsage || 0} className="h-1.5" />
          </div>

          <div>
            <div className="flex items-center justify-between text-sm mb-1">
              <div className="flex items-center gap-2 text-muted-foreground">
                <HardDrive className="h-3.5 w-3.5" />
                <span>RAM</span>
              </div>
              <span className="font-medium">{server.ramUsage || 0}%</span>
            </div>
            <Progress value={server.ramUsage || 0} className="h-1.5" />
          </div>

          <div>
            <div className="flex items-center justify-between text-sm mb-1">
              <div className="flex items-center gap-2 text-muted-foreground">
                <HardDrive className="h-3.5 w-3.5" />
                <span>Disk</span>
              </div>
              <span className="font-medium">{server.diskUsage || 0}%</span>
            </div>
            <Progress value={server.diskUsage || 0} className="h-1.5" />
          </div>
        </div>

        <div className="flex items-center justify-between pt-2 border-t text-xs text-muted-foreground">
          <div className="flex items-center gap-4">
            <span>HTTP: {server.httpPort}</span>
            <span>HTTPS: {server.httpsPort}</span>
            <span>RTMP: {server.rtmpPort}</span>
          </div>
        </div>

        {/* LB Metrics Status - only show for non-main servers */}
        {!server.isMain && (
          <div className="flex items-center justify-between pt-2 border-t text-xs">
            <span className="text-muted-foreground">Metrics:</span>
            {(server as any).metricsStatus === "live" ? (
              <Badge variant="default" className="text-xs">Live</Badge>
            ) : (server as any).hasServerToken ? (
              <Badge variant="secondary" className="text-xs">No Data - Check LB Proxy</Badge>
            ) : (
              <Badge variant="destructive" className="text-xs">No Token - Deploy LB</Badge>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function ServerMonitoringDashboard() {
  const { data: monitoring, isLoading, refetch } = useQuery<MonitoringResponse>({
    queryKey: ["/api/servers/monitoring"],
    refetchInterval: 5000, // Auto-refresh every 5 seconds
  });

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="grid gap-4 grid-cols-2 lg:grid-cols-4">
          {[1, 2, 3, 4].map((i) => (
            <Card key={i}>
              <CardContent className="p-4">
                <Skeleton className="h-12 w-full" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  const totals = monitoring?.totals;
  const servers = monitoring?.servers || [];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Activity className="h-4 w-4 animate-pulse text-emerald-500" />
          <span>Live monitoring - Auto-refreshing every 5 seconds</span>
        </div>
        <Button variant="outline" size="sm" onClick={() => refetch()} data-testid="button-refresh-monitoring">
          <RefreshCw className="h-4 w-4 mr-2" />
          Refresh Now
        </Button>
      </div>

      <div className="grid gap-4 grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-blue-500/10">
                <Users className="h-5 w-5 text-blue-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">{totals?.totalClients || 0}</p>
                <p className="text-xs text-muted-foreground">Active Clients</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-purple-500/10">
                <Wifi className="h-5 w-5 text-purple-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">{totals?.totalStreams || 0}</p>
                <p className="text-xs text-muted-foreground">Active Streams</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-emerald-500/10">
                <Download className="h-5 w-5 text-emerald-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">{totals?.totalUploadMbps || 0} Mbps</p>
                <p className="text-xs text-muted-foreground">Upload Bandwidth</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-amber-500/10">
                <Activity className="h-5 w-5 text-amber-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">{totals?.totalDownloadMbps || 0} Mbps</p>
                <p className="text-xs text-muted-foreground">Download Bandwidth</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 grid-cols-1 lg:grid-cols-2">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center gap-2">
              <Cpu className="h-5 w-5" />
              Resource Usage
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <div className="flex items-center justify-between text-sm mb-1">
                <span className="text-muted-foreground">Average CPU</span>
                <span className="font-medium">{totals?.avgCpuUsage || 0}%</span>
              </div>
              <Progress value={totals?.avgCpuUsage || 0} className="h-2" />
            </div>
            <div>
              <div className="flex items-center justify-between text-sm mb-1">
                <span className="text-muted-foreground">Average Memory</span>
                <span className="font-medium">{totals?.avgMemoryUsage || 0}%</span>
              </div>
              <Progress value={totals?.avgMemoryUsage || 0} className="h-2" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center gap-2">
              <Server className="h-5 w-5" />
              Server Status
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-3 gap-4 text-center">
              <div>
                <p className="text-3xl font-bold text-emerald-500">{totals?.onlineServers || 0}</p>
                <p className="text-xs text-muted-foreground">Online</p>
              </div>
              <div>
                <p className="text-3xl font-bold text-red-500">{totals?.offlineServers || 0}</p>
                <p className="text-xs text-muted-foreground">Offline</p>
              </div>
              <div>
                <p className="text-3xl font-bold">{totals?.totalServers || 0}</p>
                <p className="text-xs text-muted-foreground">Total</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-lg">Server Details</CardTitle>
          <CardDescription>Real-time metrics for each streaming server</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Server</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-center">Clients</TableHead>
                <TableHead className="text-center">Streams</TableHead>
                <TableHead className="text-center">CPU</TableHead>
                <TableHead className="text-center">RAM</TableHead>
                <TableHead className="text-center">Disk</TableHead>
                <TableHead className="text-center">Bandwidth</TableHead>
                <TableHead>Metrics</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {servers.map((server) => (
                <TableRow key={server.id} data-testid={`row-server-monitoring-${server.id}`}>
                  <TableCell>
                    <div className="flex flex-col gap-0.5">
                      <span className="font-medium flex items-center gap-2">
                        {server.name}
                        {server.isMain && (
                          <Badge variant="secondary" className="text-xs">Main</Badge>
                        )}
                        {server.isLoadBalancer && (
                          <Badge variant="outline" className="text-xs">LB</Badge>
                        )}
                      </span>
                      <span className="text-xs text-muted-foreground">{server.serverIp}</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge variant={server.status === "online" ? "default" : server.status === "installing" ? "secondary" : "destructive"}>
                      {server.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-center">
                    <span className="font-medium">{server.activeClients}</span>
                    <span className="text-muted-foreground text-xs">/{server.maxClients}</span>
                  </TableCell>
                  <TableCell className="text-center font-medium">{server.activeStreams}</TableCell>
                  <TableCell className="text-center">
                    <div className="flex flex-col items-center gap-1">
                      <span className={`text-xs font-medium ${server.cpuUsage > 80 ? "text-red-500" : server.cpuUsage > 50 ? "text-yellow-500" : ""}`}>
                        {server.cpuUsage}%
                      </span>
                      <Progress value={server.cpuUsage} className="h-1 w-16" />
                    </div>
                  </TableCell>
                  <TableCell className="text-center">
                    <div className="flex flex-col items-center gap-1">
                      <span className={`text-xs font-medium ${server.memoryUsage > 80 ? "text-red-500" : server.memoryUsage > 50 ? "text-yellow-500" : ""}`}>
                        {server.memoryUsage}%
                      </span>
                      <Progress value={server.memoryUsage} className="h-1 w-16" />
                    </div>
                  </TableCell>
                  <TableCell className="text-center">
                    <div className="flex flex-col items-center gap-1">
                      <span className={`text-xs font-medium ${server.diskUsage > 80 ? "text-red-500" : server.diskUsage > 50 ? "text-yellow-500" : ""}`}>
                        {server.diskUsage}%
                      </span>
                      <Progress value={server.diskUsage} className="h-1 w-16" />
                    </div>
                  </TableCell>
                  <TableCell className="text-center">
                    <div className="flex flex-col items-center gap-0.5">
                      <span className="text-emerald-500 text-xs font-medium">{server.uploadMbps} Mbps</span>
                      <span className="text-blue-500 text-xs font-medium">{server.downloadMbps} Mbps</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex flex-col gap-0.5">
                      {server.metricsStatus === "live" ? (
                        <Badge variant="outline" className="text-xs text-emerald-500 border-emerald-500">Live</Badge>
                      ) : (
                        <Badge variant="outline" className="text-xs text-yellow-500 border-yellow-500">
                          {server.metricsAgeSeconds ? `${server.metricsAgeSeconds}s ago` : "No data"}
                        </Badge>
                      )}
                    </div>
                  </TableCell>
                </TableRow>
              ))}
              {servers.length === 0 && (
                <TableRow>
                  <TableCell colSpan={9} className="text-center py-8 text-muted-foreground">
                    No servers to monitor
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <div className="text-xs text-muted-foreground text-right">
        Last updated: {monitoring?.timestamp ? new Date(monitoring.timestamp).toLocaleTimeString() : "N/A"}
      </div>
    </div>
  );
}

// Deploy dialog for existing servers with real-time status polling
function DeployLBDialog({ 
  server, 
  open, 
  onOpenChange 
}: { 
  server: ServerType | null; 
  open: boolean; 
  onOpenChange: (open: boolean) => void;
}) {
  const { toast } = useToast();
  const [deploying, setDeploying] = useState(false);
  const [sshPassword, setSshPassword] = useState("");
  const [sshPort, setSshPort] = useState(22);
  const [mainServerIp, setMainServerIp] = useState("");
  const [deployProgress, setDeployProgress] = useState(0);
  const [deployStep, setDeployStep] = useState("");
  const [deployLogs, setDeployLogs] = useState<string[]>([]);
  const pollRef = useRef<NodeJS.Timeout | null>(null);

  // Cleanup polling on unmount or close
  useEffect(() => {
    if (!open && pollRef.current) {
      clearTimeout(pollRef.current);
      pollRef.current = null;
    }
  }, [open]);

  const mutation = useMutation({
    mutationFn: async () => {
      if (!server) return;
      return apiRequest("POST", `/api/servers/${server.id}/deploy`, {
        sshPassword,
        sshPort,
        sshUsername: "root",
        mainServerIp: mainServerIp || undefined,
        updateSysctl: true,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/servers"] });
      toast({ title: "Deployment started", description: "LB proxy is being installed via SSH" });
      setDeploying(true);
      setDeployProgress(5);
      setDeployStep("Connecting via SSH...");
      setDeployLogs(["Deployment started"]);
      
      // Poll for status every 2 seconds
      const pollStatus = async () => {
        try {
          const res = await fetch(`/api/servers/${server?.id}/install-status`, { 
            credentials: "include",
            headers: { "Content-Type": "application/json" }
          });
          if (res.ok) {
            const status = await res.json();
            
            // Update progress based on completedSteps
            const totalSteps = status.totalSteps || 8;
            const completed = status.completedSteps || 0;
            const progress = Math.min(95, Math.round((completed / totalSteps) * 100));
            setDeployProgress(progress);
            setDeployStep(status.currentStep || "Installing...");
            
            // Parse logs for display
            if (status.logs) {
              const logLines = status.logs.split('\n').filter((l: string) => l.trim());
              setDeployLogs(logLines.slice(-10)); // Last 10 lines
            }
            
            if (status.status === "completed") {
              setDeployProgress(100);
              setDeployStep("Completed");
              setDeploying(false);
              queryClient.invalidateQueries({ queryKey: ["/api/servers"] });
              toast({ title: "Deployment successful", description: "LB proxy is now running" });
              setTimeout(() => {
                onOpenChange(false);
                setSshPassword("");
                setDeployProgress(0);
                setDeployStep("");
                setDeployLogs([]);
              }, 1500);
              return;
            } else if (status.status === "failed") {
              setDeploying(false);
              queryClient.invalidateQueries({ queryKey: ["/api/servers"] });
              toast({ title: "Deployment failed", description: status.error || "Check server logs", variant: "destructive" });
              return;
            }
          }
          // Continue polling every 2 seconds
          pollRef.current = setTimeout(pollStatus, 2000);
        } catch {
          pollRef.current = setTimeout(pollStatus, 2000);
        }
      };
      pollRef.current = setTimeout(pollStatus, 1000);
    },
    onError: (err: any) => {
      toast({ title: "Deployment failed", description: err.message, variant: "destructive" });
    },
  });

  if (!server) return null;

  return (
    <Dialog open={open} onOpenChange={(v) => {
      if (!deploying) {
        onOpenChange(v);
        if (!v) {
          setSshPassword("");
          setDeployProgress(0);
          setDeployStep("");
          setDeployLogs([]);
        }
      }
    }}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Download className="h-5 w-5" />
            Deploy LB Proxy to {server.name}
          </DialogTitle>
          <DialogDescription>
            Install the load balancer proxy on {server.serverIp || server.domainName}. This will connect via SSH and set up the streaming proxy.
          </DialogDescription>
        </DialogHeader>

        {deploying ? (
          <div className="space-y-4 py-4">
            <div className="flex items-center gap-3">
              <Loader2 className="h-5 w-5 animate-spin text-primary flex-shrink-0" />
              <span className="text-sm font-medium">{deployStep}</span>
            </div>
            <div className="space-y-1">
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>Progress</span>
                <span>{deployProgress}%</span>
              </div>
              <Progress value={deployProgress} className="h-2" />
            </div>
            <div className="bg-muted rounded-lg p-3 font-mono text-xs max-h-40 overflow-y-auto">
              {deployLogs.map((log, i) => (
                <div key={i} className="py-0.5 text-muted-foreground">
                  {log}
                </div>
              ))}
            </div>
            <p className="text-xs text-muted-foreground text-center">
              Do not close this dialog. Deployment may take 30-90 seconds.
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>SSH Password</Label>
              <Input
                type="password"
                placeholder="Enter SSH password for root"
                value={sshPassword}
                onChange={(e) => setSshPassword(e.target.value)}
                data-testid="input-deploy-ssh-password"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>SSH Port</Label>
                <Input
                  type="number"
                  value={sshPort}
                  onChange={(e) => setSshPort(parseInt(e.target.value) || 22)}
                  data-testid="input-deploy-ssh-port"
                />
              </div>
              <div className="space-y-2">
                <Label>Main Server IP (optional)</Label>
                <Input
                  placeholder="Auto-detect"
                  value={mainServerIp}
                  onChange={(e) => setMainServerIp(e.target.value)}
                  data-testid="input-deploy-main-server-ip"
                />
              </div>
            </div>
            <div className="flex justify-end gap-2 pt-4">
              <Button variant="outline" onClick={() => onOpenChange(false)}>
                Cancel
              </Button>
              <Button 
                onClick={() => mutation.mutate()} 
                disabled={!sshPassword || mutation.isPending}
                data-testid="button-start-deploy"
              >
                {mutation.isPending ? "Starting..." : "Deploy LB Proxy"}
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

export default function ServersPage() {
  const [search, setSearch] = useState("");
  const [activeTab, setActiveTab] = useState("servers");
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [installDialogOpen, setInstallDialogOpen] = useState(false);
  const [deployDialogOpen, setDeployDialogOpen] = useState(false);
  const [serverToDeploy, setServerToDeploy] = useState<ServerType | null>(null);
  const [editingServer, setEditingServer] = useState<ServerType | undefined>();
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [serverToDelete, setServerToDelete] = useState<ServerType | null>(null);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const { toast } = useToast();

  const { data: servers, isLoading, refetch } = useQuery<ServerType[]>({
    queryKey: ["/api/servers"],
  });
  
  const handleRefresh = async () => {
    setIsRefreshing(true);
    try {
      // Cleanup stale connections and refresh
      await fetch("/api/connections/cleanup", { method: "POST", credentials: "include" });
      await refetch();
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
    } finally {
      setIsRefreshing(false);
    }
  };

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest("DELETE", `/api/servers/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/servers"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({ title: "Server deleted" });
      setDeleteDialogOpen(false);
      setServerToDelete(null);
    },
  });

  const handleDeleteClick = (server: ServerType) => {
    setServerToDelete(server);
    setDeleteDialogOpen(true);
  };

  const confirmDelete = () => {
    if (serverToDelete) {
      deleteMutation.mutate(serverToDelete.id);
    }
  };

  const filteredServers = servers?.filter(server =>
    server.name.toLowerCase().includes(search.toLowerCase()) ||
    server.domainName.toLowerCase().includes(search.toLowerCase())
  );

  const onlineCount = servers?.filter(s => s.status === "online").length || 0;
  const offlineCount = servers?.filter(s => s.status === "offline").length || 0;
  const maintenanceCount = servers?.filter(s => s.status === "maintenance").length || 0;

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-3xl font-bold tracking-tight" data-testid="page-title">Servers</h1>
          <p className="text-muted-foreground">Manage streaming infrastructure and load balancers</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={handleRefresh} disabled={isRefreshing} data-testid="button-refresh-servers">
            <RefreshCw className={`h-4 w-4 mr-2 ${isRefreshing ? "animate-spin" : ""}`} />
            {isRefreshing ? "Refreshing..." : "Refresh"}
          </Button>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button data-testid="button-add-server">
                <Plus className="h-4 w-4 mr-2" />
                Add Server
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => setInstallDialogOpen(true)}>
                <Download className="h-4 w-4 mr-2" />
                Install New Server
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => { setEditingServer(undefined); setEditDialogOpen(true); }}>
                <Plus className="h-4 w-4 mr-2" />
                Add Existing Server
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList>
          <TabsTrigger value="servers" data-testid="tab-servers">
            <Server className="h-4 w-4 mr-2" />
            Servers
          </TabsTrigger>
          <TabsTrigger value="monitoring" data-testid="tab-monitoring">
            <Activity className="h-4 w-4 mr-2" />
            Monitoring
          </TabsTrigger>
        </TabsList>

        <TabsContent value="servers" className="space-y-4">
          <div className="grid gap-4 grid-cols-1 sm:grid-cols-4">
            <Card>
              <CardContent className="p-4 flex items-center gap-4">
                <div className="p-3 rounded-lg bg-primary/10">
                  <Server className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{servers?.length || 0}</p>
                  <p className="text-sm text-muted-foreground">Total Servers</p>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4 flex items-center gap-4">
                <div className="p-3 rounded-lg bg-emerald-500/10">
                  <Power className="h-5 w-5 text-emerald-500" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{onlineCount}</p>
                  <p className="text-sm text-muted-foreground">Online</p>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4 flex items-center gap-4">
                <div className="p-3 rounded-lg bg-red-500/10">
                  <Power className="h-5 w-5 text-red-500" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{offlineCount}</p>
                  <p className="text-sm text-muted-foreground">Offline</p>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4 flex items-center gap-4">
                <div className="p-3 rounded-lg bg-amber-500/10">
                  <Activity className="h-5 w-5 text-amber-500" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{maintenanceCount}</p>
                  <p className="text-sm text-muted-foreground">Maintenance</p>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardContent className="p-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search servers..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="pl-9"
                  data-testid="input-search-servers"
                />
              </div>
            </CardContent>
          </Card>

          {isLoading ? (
            <div className="grid gap-4 grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
              {[1, 2, 3].map((i) => (
                <Card key={i}>
                  <CardHeader>
                    <Skeleton className="h-6 w-32" />
                    <Skeleton className="h-4 w-48" />
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <Skeleton className="h-4 w-full" />
                    <Skeleton className="h-4 w-full" />
                    <Skeleton className="h-4 w-full" />
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : filteredServers && filteredServers.length > 0 ? (
            <div className="grid gap-4 grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
              {filteredServers.map((server) => (
                <ServerCard
                  key={server.id}
                  server={server}
                  onEdit={() => {
                    setEditingServer(server);
                    setEditDialogOpen(true);
                  }}
                  onDelete={() => handleDeleteClick(server)}
                  onView={() => {
                    setActiveTab("monitoring");
                  }}
                  onDeploy={() => {
                    setServerToDeploy(server);
                    setDeployDialogOpen(true);
                  }}
                />
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="p-12 text-center">
                <Server className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <h3 className="text-lg font-medium mb-2">No Servers Found</h3>
                <p className="text-muted-foreground mb-4">
                  {search ? "No servers match your search." : "Get started by adding your first streaming server."}
                </p>
                {!search && (
                  <Button onClick={() => setInstallDialogOpen(true)} data-testid="button-add-first-server">
                    <Plus className="h-4 w-4 mr-2" />
                    Install Server
                  </Button>
                )}
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="monitoring">
          <ServerMonitoringDashboard />
        </TabsContent>
      </Tabs>

      <ServerEditDialog
        server={editingServer}
        open={editDialogOpen}
        onOpenChange={setEditDialogOpen}
      />

      <ServerInstallWizard
        open={installDialogOpen}
        onOpenChange={setInstallDialogOpen}
      />

      <DeployLBDialog
        server={serverToDeploy}
        open={deployDialogOpen}
        onOpenChange={setDeployDialogOpen}
      />

      <DeleteConfirmation
        open={deleteDialogOpen}
        onOpenChange={setDeleteDialogOpen}
        onConfirm={confirmDelete}
        title="Delete Server"
        description={`Are you sure you want to delete server "${serverToDelete?.name}"? This action cannot be undone.`}
      />
    </div>
  );
}
