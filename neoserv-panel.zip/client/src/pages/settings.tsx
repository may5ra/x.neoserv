import { useEffect, useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormDescription,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Settings,
  Server,
  Shield,
  Globe,
  Mail,
  Save,
  Key,
  HardDrive,
  Video,
  Database,
  Download,
  Upload,
  FileJson,
  Loader2,
  Cloud,
  Plus,
  Trash2,
} from "lucide-react";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface AdminSetting {
  id: number;
  type: string;
  value: string;
}

function parseSettings(settings: AdminSetting[]): Record<string, string> {
  const result: Record<string, string> = {};
  for (const s of settings) {
    result[s.type] = s.value;
  }
  return result;
}

const generalSettingsSchema = z.object({
  panelName: z.string().min(1, "Panel name is required"),
  panelLogoUrl: z.string().optional().or(z.literal("")),
  panelUrl: z.string().optional().or(z.literal("")),
  timezone: z.string(),
  defaultLanguage: z.string(),
  creditPricePerLine: z.coerce.number().min(0.1, "Minimum 0.1 credits").max(1000),
  creditPricePerConnection: z.coerce.number().min(0, "Minimum 0 credits").max(1000),
});

const securitySettingsSchema = z.object({
  maxLoginAttempts: z.coerce.number().min(1).max(10),
  sessionTimeout: z.coerce.number().min(5).max(1440),
  enforceHttps: z.boolean(),
  allowRegistration: z.boolean(),
});

const streamingSettingsSchema = z.object({
  defaultBitrate: z.string(),
  maxConnections: z.coerce.number().min(1).max(100),
  bufferSize: z.coerce.number().min(1).max(60),
  enableTimeshift: z.boolean(),
  timeshiftDuration: z.coerce.number().min(1).max(168),
});

const serverSettingsSchema = z.object({
  mainServerIp: z.string(),
  mainServerPort: z.coerce.number().min(1).max(65535),
  mainServerUser: z.string(),
  mainServerPassword: z.string(),
  loadBalancerIp: z.string().optional().or(z.literal("")),
  loadBalancerPort: z.coerce.number().min(1).max(65535).optional(),
  loadBalancerUser: z.string().optional().or(z.literal("")),
  loadBalancerPassword: z.string().optional().or(z.literal("")),
});

const emailSettingsSchema = z.object({
  smtpHost: z.string(),
  smtpPort: z.coerce.number().min(1).max(65535),
  smtpUser: z.string(),
  smtpPassword: z.string(),
  smtpFrom: z.string().optional().or(z.literal("")),
  smtpFromName: z.string().optional().or(z.literal("")),
  smtpSecure: z.boolean(),
});

const apiSettingsSchema = z.object({
  apiEnabled: z.boolean(),
  apiPort: z.coerce.number().min(1).max(65535),
  apiKey: z.string().optional().or(z.literal("")),
  playerApiEnabled: z.boolean(),
  enigma2ApiEnabled: z.boolean(),
  magApiEnabled: z.boolean(),
  tmdbApiKey: z.string().optional().or(z.literal("")),
});

const transcodingSettingsSchema = z.object({
  transcodingEnabled: z.boolean(),
  ffmpegPath: z.string(),
  defaultCodec: z.string(),
  hardwareAcceleration: z.boolean(),
  maxTranscodingTasks: z.coerce.number().min(1).max(32),
});

const streamingProxySchema = z.object({
  externalProxyEnabled: z.boolean(),
  externalProxyUrl: z.string().optional().or(z.literal("")),
  proxySecretKey: z.string().min(16, "Secret key must be at least 16 characters"),
  proxyTokenTtl: z.coerce.number().min(60).max(86400),
});

const cloudflareDomainsSchema = z.object({
  panelDomain: z.string().optional().or(z.literal("")),
  panelPort: z.coerce.number().min(1).max(65535),
  streamingDomain: z.string().optional().or(z.literal("")),
  streamingPort: z.coerce.number().min(1).max(65535),
});

type GeneralSettingsData = z.infer<typeof generalSettingsSchema>;
type SecuritySettingsData = z.infer<typeof securitySettingsSchema>;
type StreamingSettingsData = z.infer<typeof streamingSettingsSchema>;
type ServerSettingsData = z.infer<typeof serverSettingsSchema>;
type EmailSettingsData = z.infer<typeof emailSettingsSchema>;
type ApiSettingsData = z.infer<typeof apiSettingsSchema>;
type TranscodingSettingsData = z.infer<typeof transcodingSettingsSchema>;
type StreamingProxyData = z.infer<typeof streamingProxySchema>;
type CloudflareDomainsData = z.infer<typeof cloudflareDomainsSchema>;

function GeneralSettings({ settings }: { settings: Record<string, string> }) {
  const { toast } = useToast();
  
  const form = useForm<GeneralSettingsData>({
    resolver: zodResolver(generalSettingsSchema),
    defaultValues: {
      panelName: "X NeoServ",
      panelLogoUrl: "",
      panelUrl: "",
      timezone: "UTC",
      defaultLanguage: "en",
      creditPricePerLine: 1,
      creditPricePerConnection: 0,
    },
  });

  useEffect(() => {
    if (settings) {
      form.reset({
        panelName: settings.panel_name || "X NeoServ",
        panelLogoUrl: settings.panel_logo_url || "",
        panelUrl: settings.panel_url || "",
        timezone: settings.timezone || "UTC",
        defaultLanguage: settings.default_language || "en",
        creditPricePerLine: parseFloat(settings.credit_price_per_line) || 1,
        creditPricePerConnection: parseFloat(settings.credit_price_per_connection) || 0,
      });
    }
  }, [settings, form]);

  const mutation = useMutation({
    mutationFn: async (data: GeneralSettingsData) => {
      return apiRequest("POST", "/api/settings/general", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/settings"] });
      queryClient.invalidateQueries({ queryKey: ["/api/branding"] }); // Refresh logo/name everywhere
      toast({ title: "Settings saved" });
    },
    onError: () => {
      toast({ title: "Failed to save settings", variant: "destructive" });
    },
  });

  const onSubmit = (data: GeneralSettingsData) => {
    console.log("Form submitted with data:", data);
    mutation.mutate(data);
  };

  const onError = (errors: any) => {
    console.error("Form validation errors:", errors);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Globe className="h-5 w-5" />
          General Settings
        </CardTitle>
        <CardDescription>Configure basic panel settings</CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit, onError)} className="space-y-4">
            <FormField
              control={form.control}
              name="panelName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Panel Name</FormLabel>
                  <FormControl>
                    <Input placeholder="X NeoServ" {...field} data-testid="input-panel-name" />
                  </FormControl>
                  <FormDescription>This name will appear in the browser title</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="panelLogoUrl"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Panel Logo URL</FormLabel>
                  <FormControl>
                    <Input placeholder="https://example.com/logo.png" {...field} data-testid="input-panel-logo" />
                  </FormControl>
                  <FormDescription>Logo image URL (displayed in sidebar). Leave empty for text-only.</FormDescription>
                  {field.value && (
                    <div className="mt-2 p-2 bg-muted rounded-md">
                      <p className="text-xs text-muted-foreground mb-2">Preview:</p>
                      <img src={field.value} alt="Logo preview" className="h-10 object-contain" onError={(e) => (e.currentTarget.style.display = 'none')} />
                    </div>
                  )}
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="panelUrl"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Panel URL</FormLabel>
                  <FormControl>
                    <Input placeholder="https://panel.example.com" {...field} data-testid="input-panel-url" />
                  </FormControl>
                  <FormDescription>Public URL of your panel</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="timezone"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Timezone</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger data-testid="select-timezone">
                          <SelectValue placeholder="Select timezone" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="UTC">UTC</SelectItem>
                        <SelectItem value="America/New_York">Eastern Time</SelectItem>
                        <SelectItem value="America/Los_Angeles">Pacific Time</SelectItem>
                        <SelectItem value="Europe/London">London</SelectItem>
                        <SelectItem value="Europe/Paris">Paris</SelectItem>
                        <SelectItem value="Europe/Zagreb">Zagreb</SelectItem>
                        <SelectItem value="Asia/Tokyo">Tokyo</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="defaultLanguage"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Default Language</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger data-testid="select-language">
                          <SelectValue placeholder="Select language" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="en">English</SelectItem>
                        <SelectItem value="es">Spanish</SelectItem>
                        <SelectItem value="fr">French</SelectItem>
                        <SelectItem value="de">German</SelectItem>
                        <SelectItem value="pt">Portuguese</SelectItem>
                        <SelectItem value="hr">Croatian</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <div className="pt-6 border-t">
              <h3 className="text-lg font-semibold mb-4">Reseller Settings</h3>
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="creditPricePerLine"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Credit Price Per Line (1 connection)</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          min="0.1" 
                          step="0.1" 
                          value={field.value}
                          onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                          onBlur={field.onBlur}
                          name={field.name}
                          ref={field.ref}
                          data-testid="input-credit-price" 
                        />
                      </FormControl>
                      <FormDescription>
                        Base price for 1 user with 1 connection
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="creditPricePerConnection"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Credit Price Per Extra Connection</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          min="0" 
                          step="0.1" 
                          value={field.value}
                          onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                          onBlur={field.onBlur}
                          name={field.name}
                          ref={field.ref}
                          data-testid="input-credit-price-connection" 
                        />
                      </FormControl>
                      <FormDescription>
                        Additional credits per extra connection (0 = no extra cost)
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <p className="text-sm text-muted-foreground mt-2">
                Formula: Total = (Base Price + Extra Connections x Price Per Connection) x Duration Multiplier
              </p>
            </div>

            <div className="flex justify-end pt-4">
              <Button type="submit" disabled={mutation.isPending} data-testid="button-save-general">
                <Save className="h-4 w-4 mr-2" />
                {mutation.isPending ? "Saving..." : "Save Changes"}
              </Button>
            </div>
          </form>
        </Form>
        
        <DurationOptionsSettings />
      </CardContent>
    </Card>
  );
}

interface DurationOption {
  label: string;
  days: number;
  multiplier: number;
}

function DurationOptionsSettings() {
  const { toast } = useToast();
  const [options, setOptions] = useState<DurationOption[]>([]);
  
  const { data: durationOptions, isLoading } = useQuery<DurationOption[]>({
    queryKey: ["/api/settings/duration-options"],
  });
  
  useEffect(() => {
    if (durationOptions) {
      setOptions(durationOptions);
    }
  }, [durationOptions]);
  
  const mutation = useMutation({
    mutationFn: async (opts: DurationOption[]) => {
      return apiRequest("POST", "/api/settings/duration-options", { options: opts });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/settings/duration-options"] });
      toast({ title: "Duration options saved" });
    },
    onError: () => {
      toast({ title: "Failed to save", variant: "destructive" });
    },
  });
  
  const addOption = () => {
    setOptions([...options, { label: "New Option", days: 30, multiplier: 1 }]);
  };
  
  const removeOption = (index: number) => {
    setOptions(options.filter((_, i) => i !== index));
  };
  
  const updateOption = (index: number, field: keyof DurationOption, value: string | number) => {
    const updated = [...options];
    updated[index] = { ...updated[index], [field]: value };
    setOptions(updated);
  };
  
  if (isLoading) return <Skeleton className="h-32" />;
  
  return (
    <div className="pt-6 border-t mt-6">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="text-lg font-semibold">Duration Options</h3>
          <p className="text-sm text-muted-foreground">Configure subscription duration pricing multipliers</p>
        </div>
        <Button variant="outline" size="sm" onClick={addOption} data-testid="button-add-duration">
          <Plus className="h-4 w-4 mr-1" />
          Add Option
        </Button>
      </div>
      
      <div className="space-y-3">
        {options.map((opt, index) => (
          <div key={index} className="flex items-center gap-3 p-3 bg-muted rounded-md">
            <Input 
              placeholder="Label" 
              value={opt.label} 
              onChange={(e) => updateOption(index, "label", e.target.value)}
              className="flex-1"
              data-testid={`input-duration-label-${index}`}
            />
            <div className="flex items-center gap-1">
              <Input 
                type="number" 
                min={1} 
                value={opt.days} 
                onChange={(e) => updateOption(index, "days", parseInt(e.target.value) || 30)}
                className="w-20"
                data-testid={`input-duration-days-${index}`}
              />
              <span className="text-sm text-muted-foreground">days</span>
            </div>
            <div className="flex items-center gap-1">
              <span className="text-sm text-muted-foreground">x</span>
              <Input 
                type="number" 
                min={0.1} 
                step={0.1}
                value={opt.multiplier} 
                onChange={(e) => updateOption(index, "multiplier", parseFloat(e.target.value) || 1)}
                className="w-20"
                data-testid={`input-duration-multiplier-${index}`}
              />
            </div>
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={() => removeOption(index)}
              data-testid={`button-remove-duration-${index}`}
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        ))}
      </div>
      
      {options.length === 0 && (
        <p className="text-sm text-muted-foreground text-center py-4">No duration options configured</p>
      )}
      
      <div className="flex justify-end pt-4">
        <Button onClick={() => mutation.mutate(options)} disabled={mutation.isPending} data-testid="button-save-durations">
          <Save className="h-4 w-4 mr-2" />
          {mutation.isPending ? "Saving..." : "Save Duration Options"}
        </Button>
      </div>
    </div>
  );
}

function SecuritySettings({ settings }: { settings: Record<string, string> }) {
  const { toast } = useToast();
  
  const form = useForm<SecuritySettingsData>({
    resolver: zodResolver(securitySettingsSchema),
    defaultValues: {
      maxLoginAttempts: 5,
      sessionTimeout: 60,
      enforceHttps: true,
      allowRegistration: false,
    },
  });

  useEffect(() => {
    if (settings) {
      form.reset({
        maxLoginAttempts: parseInt(settings.max_login_attempts) || 5,
        sessionTimeout: parseInt(settings.session_timeout) || 60,
        enforceHttps: settings.enforce_https === "1",
        allowRegistration: settings.allow_registration === "1",
      });
    }
  }, [settings, form]);

  const mutation = useMutation({
    mutationFn: async (data: SecuritySettingsData) => {
      return apiRequest("POST", "/api/settings/security", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/settings"] });
      toast({ title: "Security settings saved" });
    },
    onError: () => {
      toast({ title: "Failed to save settings", variant: "destructive" });
    },
  });

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Shield className="h-5 w-5" />
          Security Settings
        </CardTitle>
        <CardDescription>Configure security and authentication</CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit((data) => mutation.mutate(data))} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="maxLoginAttempts"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Max Login Attempts</FormLabel>
                    <FormControl>
                      <Input type="number" min={1} max={10} {...field} data-testid="input-max-attempts" />
                    </FormControl>
                    <FormDescription>Before account lockout</FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="sessionTimeout"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Session Timeout (minutes)</FormLabel>
                    <FormControl>
                      <Input type="number" min={5} max={1440} {...field} data-testid="input-session-timeout" />
                    </FormControl>
                    <FormDescription>Auto logout after inactivity</FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            <FormField
              control={form.control}
              name="enforceHttps"
              render={({ field }) => (
                <FormItem className="flex items-center justify-between rounded-lg border p-4">
                  <div>
                    <FormLabel>Enforce HTTPS</FormLabel>
                    <FormDescription>Redirect all HTTP traffic to HTTPS</FormDescription>
                  </div>
                  <FormControl>
                    <Switch checked={field.value} onCheckedChange={field.onChange} data-testid="switch-https" />
                  </FormControl>
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="allowRegistration"
              render={({ field }) => (
                <FormItem className="flex items-center justify-between rounded-lg border p-4">
                  <div>
                    <FormLabel>Allow Registration</FormLabel>
                    <FormDescription>Allow new users to register accounts</FormDescription>
                  </div>
                  <FormControl>
                    <Switch checked={field.value} onCheckedChange={field.onChange} data-testid="switch-registration" />
                  </FormControl>
                </FormItem>
              )}
            />
            <div className="flex justify-end pt-4">
              <Button type="submit" disabled={mutation.isPending} data-testid="button-save-security">
                <Save className="h-4 w-4 mr-2" />
                {mutation.isPending ? "Saving..." : "Save Changes"}
              </Button>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}

function TwoFactorSettings() {
  const { toast } = useToast();
  const [is2FAEnabled, setIs2FAEnabled] = useState(false);
  const [showSetup, setShowSetup] = useState(false);
  const [setupData, setSetupData] = useState<{ secret: string; qrCode: string } | null>(null);
  const [verificationCode, setVerificationCode] = useState("");
  const [disablePassword, setDisablePassword] = useState("");
  const [showDisableDialog, setShowDisableDialog] = useState(false);

  const { data: authData, refetch } = useQuery<{ has2FA: boolean }>({
    queryKey: ["/api/auth/me"],
  });

  useEffect(() => {
    if (authData) {
      setIs2FAEnabled(authData.has2FA || false);
    }
  }, [authData]);

  const setupMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/auth/2fa/setup", {});
      return response.json();
    },
    onSuccess: (data) => {
      setSetupData(data);
      setShowSetup(true);
    },
    onError: () => {
      toast({ title: "Failed to generate 2FA setup", variant: "destructive" });
    },
  });

  const enableMutation = useMutation({
    mutationFn: async (data: { secret: string; token: string }) => {
      const response = await apiRequest("POST", "/api/auth/2fa/enable", data);
      return response.json();
    },
    onSuccess: () => {
      toast({ title: "2FA Enabled", description: "Your account is now protected with 2FA" });
      setShowSetup(false);
      setSetupData(null);
      setVerificationCode("");
      refetch();
    },
    onError: (error: any) => {
      toast({ title: "Verification failed", description: error.message || "Invalid code", variant: "destructive" });
    },
  });

  const disableMutation = useMutation({
    mutationFn: async (password: string) => {
      const response = await apiRequest("POST", "/api/auth/2fa/disable", { password });
      return response.json();
    },
    onSuccess: () => {
      toast({ title: "2FA Disabled", description: "Two-factor authentication has been disabled" });
      setShowDisableDialog(false);
      setDisablePassword("");
      refetch();
    },
    onError: (error: any) => {
      toast({ title: "Failed to disable 2FA", description: error.message || "Invalid password", variant: "destructive" });
    },
  });

  const handleEnable2FA = () => {
    if (!setupData || verificationCode.length !== 6) return;
    enableMutation.mutate({ secret: setupData.secret, token: verificationCode });
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Shield className="h-5 w-5" />
          Two-Factor Authentication (2FA)
        </CardTitle>
        <CardDescription>
          Add an extra layer of security with authenticator app verification
        </CardDescription>
      </CardHeader>
      <CardContent>
        {is2FAEnabled ? (
          <div className="space-y-4">
            <div className="flex items-center gap-3 p-4 rounded-lg bg-green-500/10 border border-green-500/20">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-green-500/20">
                <Shield className="h-5 w-5 text-green-500" />
              </div>
              <div>
                <p className="font-medium text-green-600 dark:text-green-400">2FA is Enabled</p>
                <p className="text-sm text-muted-foreground">Your account is protected</p>
              </div>
            </div>
            
            <Dialog open={showDisableDialog} onOpenChange={setShowDisableDialog}>
              <DialogTrigger asChild>
                <Button variant="outline" className="text-destructive border-destructive/30 hover:bg-destructive/10" data-testid="button-disable-2fa">
                  <Shield className="h-4 w-4 mr-2" />
                  Disable 2FA
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Disable Two-Factor Authentication</DialogTitle>
                  <DialogDescription>
                    Enter your password to confirm disabling 2FA. This will make your account less secure.
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label>Password</Label>
                    <Input
                      type="password"
                      value={disablePassword}
                      onChange={(e) => setDisablePassword(e.target.value)}
                      placeholder="Enter your password"
                      data-testid="input-disable-password"
                    />
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setShowDisableDialog(false)}>Cancel</Button>
                  <Button
                    variant="destructive"
                    onClick={() => disableMutation.mutate(disablePassword)}
                    disabled={!disablePassword || disableMutation.isPending}
                    data-testid="button-confirm-disable-2fa"
                  >
                    {disableMutation.isPending ? "Disabling..." : "Disable 2FA"}
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        ) : showSetup && setupData ? (
          <div className="space-y-6">
            <div className="text-center">
              <p className="text-sm text-muted-foreground mb-4">
                Scan this QR code with your authenticator app (Google Authenticator, Authy, etc.)
              </p>
              <div className="inline-block p-4 bg-white rounded-lg">
                <img src={setupData.qrCode} alt="2FA QR Code" className="w-48 h-48" />
              </div>
            </div>
            
            <div className="space-y-2">
              <Label className="text-xs text-muted-foreground">Or enter this code manually:</Label>
              <code className="block p-3 bg-muted rounded-md text-sm font-mono break-all select-all">
                {setupData.secret}
              </code>
            </div>
            
            <div className="space-y-2">
              <Label>Verification Code</Label>
              <Input
                type="text"
                inputMode="numeric"
                pattern="[0-9]*"
                maxLength={6}
                value={verificationCode}
                onChange={(e) => setVerificationCode(e.target.value.replace(/\D/g, "").slice(0, 6))}
                placeholder="Enter 6-digit code"
                className="text-center text-lg tracking-widest font-mono"
                data-testid="input-2fa-verification"
              />
            </div>
            
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => { setShowSetup(false); setSetupData(null); }} className="flex-1">
                Cancel
              </Button>
              <Button
                onClick={handleEnable2FA}
                disabled={verificationCode.length !== 6 || enableMutation.isPending}
                className="flex-1"
                data-testid="button-enable-2fa"
              >
                {enableMutation.isPending ? "Verifying..." : "Enable 2FA"}
              </Button>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="flex items-center gap-3 p-4 rounded-lg bg-yellow-500/10 border border-yellow-500/20">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-yellow-500/20">
                <Shield className="h-5 w-5 text-yellow-500" />
              </div>
              <div>
                <p className="font-medium text-yellow-600 dark:text-yellow-400">2FA Not Enabled</p>
                <p className="text-sm text-muted-foreground">Enhance your account security</p>
              </div>
            </div>
            
            <Button onClick={() => setupMutation.mutate()} disabled={setupMutation.isPending} data-testid="button-setup-2fa">
              <Shield className="h-4 w-4 mr-2" />
              {setupMutation.isPending ? "Setting up..." : "Setup 2FA"}
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function StreamingSettings({ settings }: { settings: Record<string, string> }) {
  const { toast } = useToast();
  
  const form = useForm<StreamingSettingsData>({
    resolver: zodResolver(streamingSettingsSchema),
    defaultValues: {
      defaultBitrate: "auto",
      maxConnections: 2,
      bufferSize: 10,
      enableTimeshift: true,
      timeshiftDuration: 24,
    },
  });

  useEffect(() => {
    if (settings) {
      form.reset({
        defaultBitrate: settings.default_bitrate || "auto",
        maxConnections: parseInt(settings.max_connections) || 2,
        bufferSize: parseInt(settings.buffer_size) || 10,
        enableTimeshift: settings.enable_timeshift === "1",
        timeshiftDuration: parseInt(settings.timeshift_duration) || 24,
      });
    }
  }, [settings, form]);

  const mutation = useMutation({
    mutationFn: async (data: StreamingSettingsData) => {
      return apiRequest("POST", "/api/settings/streaming", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/settings"] });
      toast({ title: "Streaming settings saved" });
    },
    onError: () => {
      toast({ title: "Failed to save settings", variant: "destructive" });
    },
  });

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Server className="h-5 w-5" />
          Streaming Settings
        </CardTitle>
        <CardDescription>Configure streaming behavior</CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit((data) => mutation.mutate(data))} className="space-y-4">
            <div className="grid grid-cols-3 gap-4">
              <FormField
                control={form.control}
                name="defaultBitrate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Default Bitrate</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger data-testid="select-bitrate">
                          <SelectValue placeholder="Select bitrate" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="auto">Auto</SelectItem>
                        <SelectItem value="720p">720p</SelectItem>
                        <SelectItem value="1080p">1080p</SelectItem>
                        <SelectItem value="4k">4K</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="maxConnections"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Max Connections</FormLabel>
                    <FormControl>
                      <Input type="number" min={1} max={100} {...field} data-testid="input-max-connections" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="bufferSize"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Buffer Size (sec)</FormLabel>
                    <FormControl>
                      <Input type="number" min={1} max={60} {...field} data-testid="input-buffer-size" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            <Separator />
            <FormField
              control={form.control}
              name="enableTimeshift"
              render={({ field }) => (
                <FormItem className="flex items-center justify-between rounded-lg border p-4">
                  <div>
                    <FormLabel>Enable Timeshift</FormLabel>
                    <FormDescription>Allow users to pause and rewind live TV</FormDescription>
                  </div>
                  <FormControl>
                    <Switch checked={field.value} onCheckedChange={field.onChange} data-testid="switch-timeshift" />
                  </FormControl>
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="timeshiftDuration"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Timeshift Duration (hours)</FormLabel>
                  <FormControl>
                    <Input type="number" min={1} max={168} {...field} data-testid="input-timeshift-duration" />
                  </FormControl>
                  <FormDescription>How far back users can rewind</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            <div className="flex justify-end pt-4">
              <Button type="submit" disabled={mutation.isPending} data-testid="button-save-streaming">
                <Save className="h-4 w-4 mr-2" />
                {mutation.isPending ? "Saving..." : "Save Changes"}
              </Button>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}

function StreamingProxySettings({ settings }: { settings: Record<string, string> }) {
  const { toast } = useToast();
  const [isDownloading, setIsDownloading] = useState(false);
  
  const form = useForm<StreamingProxyData>({
    resolver: zodResolver(streamingProxySchema),
    defaultValues: {
      externalProxyEnabled: false,
      externalProxyUrl: "",
      proxySecretKey: "",
      proxyTokenTtl: 14400,
    },
  });

  useEffect(() => {
    if (settings) {
      form.reset({
        externalProxyEnabled: settings.external_proxy_enabled === "1",
        externalProxyUrl: settings.external_proxy_url || "",
        proxySecretKey: settings.proxy_secret_key || "",
        proxyTokenTtl: parseInt(settings.proxy_token_ttl) || 14400,
      });
    }
  }, [settings, form]);

  const mutation = useMutation({
    mutationFn: async (data: StreamingProxyData) => {
      return apiRequest("POST", "/api/settings/streaming-proxy", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/settings"] });
      toast({ title: "Streaming proxy settings saved" });
    },
    onError: () => {
      toast({ title: "Failed to save settings", variant: "destructive" });
    },
  });

  const generateSecretKey = () => {
    const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    let result = "";
    for (let i = 0; i < 32; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    form.setValue("proxySecretKey", result);
  };

  const downloadNginxConfig = async () => {
    setIsDownloading(true);
    try {
      const token = localStorage.getItem("neoserv_auth_token");
      const response = await fetch("/api/proxy/nginx-config", {
        headers: {
          "Authorization": `Bearer ${token}`,
        },
      });
      if (response.ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = "streaming-proxy.conf";
        document.body.appendChild(a);
        a.click();
        a.remove();
        window.URL.revokeObjectURL(url);
        toast({ title: "Nginx configuration downloaded" });
      } else {
        toast({ title: "Failed to download configuration", variant: "destructive" });
      }
    } catch {
      toast({ title: "Error downloading configuration", variant: "destructive" });
    } finally {
      setIsDownloading(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Server className="h-5 w-5" />
            External Streaming Proxy (Hybrid Mode)
          </CardTitle>
          <CardDescription>
            Configure an external Nginx server to handle streaming for better performance.
            Panel handles authentication; your server handles stream delivery.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit((data) => mutation.mutate(data))} className="space-y-4">
              <FormField
                control={form.control}
                name="externalProxyEnabled"
                render={({ field }) => (
                  <FormItem className="flex items-center justify-between rounded-lg border p-4">
                    <div>
                      <FormLabel>Enable External Proxy</FormLabel>
                      <FormDescription>
                        When enabled, playlists will point to your external Nginx server instead of this panel
                      </FormDescription>
                    </div>
                    <FormControl>
                      <Switch checked={field.value} onCheckedChange={field.onChange} data-testid="switch-external-proxy" />
                    </FormControl>
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="externalProxyUrl"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>External Proxy URL</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="https://streaming.yourdomain.com" 
                        {...field} 
                        data-testid="input-proxy-url" 
                      />
                    </FormControl>
                    <FormDescription>
                      The public URL of your Nginx streaming server (e.g., https://streaming.example.com)
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="proxySecretKey"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Proxy Secret Key</FormLabel>
                    <div className="flex gap-2">
                      <FormControl>
                        <Input 
                          type="password"
                          placeholder="Minimum 16 characters" 
                          {...field} 
                          data-testid="input-proxy-secret" 
                        />
                      </FormControl>
                      <Button 
                        type="button" 
                        variant="outline" 
                        onClick={generateSecretKey}
                        data-testid="button-generate-secret"
                      >
                        <Key className="h-4 w-4 mr-2" />
                        Generate
                      </Button>
                    </div>
                    <FormDescription>
                      Used to sign streaming tokens. Keep this secret and matching on both panel and Nginx.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="proxyTokenTtl"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Token TTL (seconds)</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        min={60} 
                        max={86400} 
                        {...field} 
                        data-testid="input-token-ttl" 
                      />
                    </FormControl>
                    <FormDescription>
                      How long streaming tokens are valid (default: 14400 = 4 hours)
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="flex justify-end gap-2 pt-4">
                <Button type="submit" disabled={mutation.isPending} data-testid="button-save-proxy">
                  <Save className="h-4 w-4 mr-2" />
                  {mutation.isPending ? "Saving..." : "Save Changes"}
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Download className="h-5 w-5" />
            Nginx Configuration
          </CardTitle>
          <CardDescription>
            Download a ready-to-use Nginx configuration for your streaming server
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="rounded-lg bg-muted p-4 text-sm space-y-2">
            <p className="font-medium">Setup Instructions:</p>
            <ol className="list-decimal list-inside space-y-1 text-muted-foreground">
              <li>Install Nginx on your VPS/server</li>
              <li>Download the configuration file below</li>
              <li>Update <code className="bg-background px-1 rounded">server_name</code> with your domain</li>
              <li>Configure SSL with certbot (recommended)</li>
              <li>Place config in <code className="bg-background px-1 rounded">/etc/nginx/sites-available/</code></li>
              <li>Enable: <code className="bg-background px-1 rounded">ln -s /etc/nginx/sites-available/streaming-proxy /etc/nginx/sites-enabled/</code></li>
              <li>Test and reload: <code className="bg-background px-1 rounded">nginx -t && systemctl reload nginx</code></li>
            </ol>
          </div>
          <Button 
            onClick={downloadNginxConfig} 
            disabled={isDownloading}
            variant="outline"
            data-testid="button-download-nginx"
          >
            {isDownloading ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                Downloading...
              </>
            ) : (
              <>
                <Download className="h-4 w-4 mr-2" />
                Download Nginx Config
              </>
            )}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}

function CloudflareDomainsSettings({ settings }: { settings: Record<string, string> }) {
  const { toast } = useToast();
  
  const form = useForm<CloudflareDomainsData>({
    resolver: zodResolver(cloudflareDomainsSchema),
    defaultValues: {
      panelDomain: "",
      panelPort: 443,
      streamingDomain: "",
      streamingPort: 80,
    },
  });

  useEffect(() => {
    if (settings) {
      form.reset({
        panelDomain: settings.panel_domain || "",
        panelPort: parseInt(settings.panel_port) || 443,
        streamingDomain: settings.streaming_domain || "",
        streamingPort: parseInt(settings.streaming_port) || 80,
      });
    }
  }, [settings, form]);

  const mutation = useMutation({
    mutationFn: async (data: CloudflareDomainsData) => {
      return apiRequest("POST", "/api/settings/domains", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/settings"] });
      toast({ title: "Domain settings saved" });
    },
    onError: () => {
      toast({ title: "Failed to save settings", variant: "destructive" });
    },
  });

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Cloud className="h-5 w-5" />
            Cloudflare Domain Configuration
          </CardTitle>
          <CardDescription>
            Configure separate domains for panel and streaming to work with Cloudflare
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="rounded-lg bg-muted p-4 text-sm space-y-2 mb-6">
            <p className="font-medium">Cloudflare Setup Instructions:</p>
            <ol className="list-decimal list-inside space-y-1 text-muted-foreground">
              <li><strong>Panel Domain</strong> (e.g., panel.example.com) - Enable Cloudflare proxy (orange cloud) for DDoS protection</li>
              <li><strong>Streaming Domain</strong> (e.g., stream.example.com) - Disable Cloudflare proxy (gray cloud / DNS only) to avoid stream blocking</li>
              <li>Both domains should point to the same server IP</li>
              <li>Playlists will use streaming domain for video URLs, panel domain for API/EPG</li>
            </ol>
          </div>
          <Form {...form}>
            <form onSubmit={form.handleSubmit((data) => mutation.mutate(data))} className="space-y-6">
              <div>
                <h3 className="text-lg font-medium mb-4 flex items-center gap-2">
                  <Globe className="h-4 w-4 text-orange-500" />
                  Panel Domain (Cloudflare Proxied)
                </h3>
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="panelDomain"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Domain</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="panel.example.com" 
                            {...field} 
                            data-testid="input-panel-domain" 
                          />
                        </FormControl>
                        <FormDescription>Your main panel domain with Cloudflare protection</FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="panelPort"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Port</FormLabel>
                        <FormControl>
                          <Input 
                            type="number" 
                            min={1} 
                            max={65535} 
                            {...field} 
                            data-testid="input-panel-port" 
                          />
                        </FormControl>
                        <FormDescription>Usually 443 for HTTPS</FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </div>

              <div>
                <h3 className="text-lg font-medium mb-4 flex items-center gap-2">
                  <Server className="h-4 w-4 text-gray-500" />
                  Streaming Domain (DNS Only - No Cloudflare Proxy)
                </h3>
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="streamingDomain"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Domain</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="stream.example.com" 
                            {...field} 
                            data-testid="input-streaming-domain" 
                          />
                        </FormControl>
                        <FormDescription>Subdomain for streaming (bypasses Cloudflare)</FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="streamingPort"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Port</FormLabel>
                        <FormControl>
                          <Input 
                            type="number" 
                            min={1} 
                            max={65535} 
                            {...field} 
                            data-testid="input-streaming-port" 
                          />
                        </FormControl>
                        <FormDescription>Usually 80 or 8080</FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </div>

              <div className="flex justify-end pt-4">
                <Button type="submit" disabled={mutation.isPending} data-testid="button-save-domains">
                  <Save className="h-4 w-4 mr-2" />
                  {mutation.isPending ? "Saving..." : "Save Changes"}
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}

function ServerSettings({ settings }: { settings: Record<string, string> }) {
  const { toast } = useToast();
  
  const form = useForm<ServerSettingsData>({
    resolver: zodResolver(serverSettingsSchema),
    defaultValues: {
      mainServerIp: "",
      mainServerPort: 22,
      mainServerUser: "root",
      mainServerPassword: "",
      loadBalancerIp: "",
      loadBalancerPort: 22,
      loadBalancerUser: "root",
      loadBalancerPassword: "",
    },
  });

  useEffect(() => {
    if (settings) {
      form.reset({
        mainServerIp: settings.main_server_ip || "",
        mainServerPort: parseInt(settings.main_server_port) || 22,
        mainServerUser: settings.main_server_user || "root",
        mainServerPassword: settings.main_server_password || "",
        loadBalancerIp: settings.load_balancer_ip || "",
        loadBalancerPort: parseInt(settings.load_balancer_port) || 22,
        loadBalancerUser: settings.load_balancer_user || "root",
        loadBalancerPassword: settings.load_balancer_password || "",
      });
    }
  }, [settings, form]);

  const mutation = useMutation({
    mutationFn: async (data: ServerSettingsData) => {
      return apiRequest("POST", "/api/settings/server", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/settings"] });
      toast({ title: "Server settings saved" });
    },
    onError: () => {
      toast({ title: "Failed to save settings", variant: "destructive" });
    },
  });

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <HardDrive className="h-5 w-5" />
          Server Credentials
        </CardTitle>
        <CardDescription>Configure main server and load balancer credentials</CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit((data) => mutation.mutate(data))} className="space-y-6">
            <div>
              <h3 className="text-lg font-medium mb-4">Main Server</h3>
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="mainServerIp"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Server IP/Hostname</FormLabel>
                      <FormControl>
                        <Input placeholder="192.168.1.1" {...field} data-testid="input-main-server-ip" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="mainServerPort"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>SSH Port</FormLabel>
                      <FormControl>
                        <Input type="number" {...field} data-testid="input-main-server-port" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="mainServerUser"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>SSH Username</FormLabel>
                      <FormControl>
                        <Input placeholder="root" {...field} data-testid="input-main-server-user" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="mainServerPassword"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>SSH Password</FormLabel>
                      <FormControl>
                        <Input type="password" {...field} data-testid="input-main-server-password" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </div>
            <Separator />
            <div>
              <h3 className="text-lg font-medium mb-4">Load Balancer (Optional)</h3>
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="loadBalancerIp"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Server IP/Hostname</FormLabel>
                      <FormControl>
                        <Input placeholder="192.168.1.2" {...field} data-testid="input-lb-ip" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="loadBalancerPort"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>SSH Port</FormLabel>
                      <FormControl>
                        <Input type="number" {...field} data-testid="input-lb-port" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="loadBalancerUser"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>SSH Username</FormLabel>
                      <FormControl>
                        <Input placeholder="root" {...field} data-testid="input-lb-user" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="loadBalancerPassword"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>SSH Password</FormLabel>
                      <FormControl>
                        <Input type="password" {...field} data-testid="input-lb-password" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </div>
            <div className="flex justify-end pt-4">
              <Button type="submit" disabled={mutation.isPending} data-testid="button-save-server">
                <Save className="h-4 w-4 mr-2" />
                {mutation.isPending ? "Saving..." : "Save Changes"}
              </Button>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}

function EmailSettings({ settings }: { settings: Record<string, string> }) {
  const { toast } = useToast();
  
  const form = useForm<EmailSettingsData>({
    resolver: zodResolver(emailSettingsSchema),
    defaultValues: {
      smtpHost: "",
      smtpPort: 587,
      smtpUser: "",
      smtpPassword: "",
      smtpFrom: "",
      smtpFromName: "",
      smtpSecure: true,
    },
  });

  useEffect(() => {
    if (settings) {
      form.reset({
        smtpHost: settings.smtp_host || "",
        smtpPort: parseInt(settings.smtp_port) || 587,
        smtpUser: settings.smtp_user || "",
        smtpPassword: settings.smtp_password || "",
        smtpFrom: settings.smtp_from || "",
        smtpFromName: settings.smtp_from_name || "",
        smtpSecure: settings.smtp_secure === "1",
      });
    }
  }, [settings, form]);

  const mutation = useMutation({
    mutationFn: async (data: EmailSettingsData) => {
      return apiRequest("POST", "/api/settings/email", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/settings"] });
      toast({ title: "Email settings saved" });
    },
    onError: () => {
      toast({ title: "Failed to save settings", variant: "destructive" });
    },
  });

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Mail className="h-5 w-5" />
          Email Settings
        </CardTitle>
        <CardDescription>Configure SMTP for email notifications</CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit((data) => mutation.mutate(data))} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="smtpHost"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>SMTP Host</FormLabel>
                    <FormControl>
                      <Input placeholder="smtp.gmail.com" {...field} data-testid="input-smtp-host" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="smtpPort"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>SMTP Port</FormLabel>
                    <FormControl>
                      <Input type="number" {...field} data-testid="input-smtp-port" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="smtpUser"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>SMTP Username</FormLabel>
                    <FormControl>
                      <Input {...field} data-testid="input-smtp-user" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="smtpPassword"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>SMTP Password</FormLabel>
                    <FormControl>
                      <Input type="password" {...field} data-testid="input-smtp-password" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="smtpFrom"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>From Email</FormLabel>
                    <FormControl>
                      <Input placeholder="noreply@example.com" {...field} data-testid="input-smtp-from" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="smtpFromName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>From Name</FormLabel>
                    <FormControl>
                      <Input placeholder="X NeoServ" {...field} data-testid="input-smtp-from-name" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            <FormField
              control={form.control}
              name="smtpSecure"
              render={({ field }) => (
                <FormItem className="flex items-center justify-between rounded-lg border p-4">
                  <div>
                    <FormLabel>Use TLS/SSL</FormLabel>
                    <FormDescription>Enable secure connection</FormDescription>
                  </div>
                  <FormControl>
                    <Switch checked={field.value} onCheckedChange={field.onChange} data-testid="switch-smtp-secure" />
                  </FormControl>
                </FormItem>
              )}
            />
            <div className="flex justify-end pt-4">
              <Button type="submit" disabled={mutation.isPending} data-testid="button-save-email">
                <Save className="h-4 w-4 mr-2" />
                {mutation.isPending ? "Saving..." : "Save Changes"}
              </Button>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}

function ApiSettings({ settings }: { settings: Record<string, string> }) {
  const { toast } = useToast();
  
  const form = useForm<ApiSettingsData>({
    resolver: zodResolver(apiSettingsSchema),
    defaultValues: {
      apiEnabled: true,
      apiPort: 8080,
      apiKey: "",
      playerApiEnabled: true,
      enigma2ApiEnabled: true,
      magApiEnabled: true,
      tmdbApiKey: "",
    },
  });

  useEffect(() => {
    if (settings) {
      form.reset({
        apiEnabled: settings.api_enabled !== "0",
        apiPort: parseInt(settings.api_port) || 8080,
        apiKey: settings.api_key || "",
        playerApiEnabled: settings.player_api_enabled !== "0",
        enigma2ApiEnabled: settings.enigma2_api_enabled !== "0",
        magApiEnabled: settings.mag_api_enabled !== "0",
        tmdbApiKey: settings.tmdb_api_key || "",
      });
    }
  }, [settings, form]);

  const mutation = useMutation({
    mutationFn: async (data: ApiSettingsData) => {
      return apiRequest("POST", "/api/settings/api", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/settings"] });
      toast({ title: "API settings saved" });
    },
    onError: () => {
      toast({ title: "Failed to save settings", variant: "destructive" });
    },
  });

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Key className="h-5 w-5" />
          API Settings
        </CardTitle>
        <CardDescription>Configure API access and compatibility</CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit((data) => mutation.mutate(data))} className="space-y-4">
            <FormField
              control={form.control}
              name="apiEnabled"
              render={({ field }) => (
                <FormItem className="flex items-center justify-between rounded-lg border p-4">
                  <div>
                    <FormLabel>Enable API</FormLabel>
                    <FormDescription>Allow external API access</FormDescription>
                  </div>
                  <FormControl>
                    <Switch checked={field.value} onCheckedChange={field.onChange} data-testid="switch-api-enabled" />
                  </FormControl>
                </FormItem>
              )}
            />
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="apiPort"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>API Port</FormLabel>
                    <FormControl>
                      <Input type="number" {...field} data-testid="input-api-port" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="apiKey"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>API Key</FormLabel>
                    <FormControl>
                      <Input placeholder="Leave empty to auto-generate" {...field} data-testid="input-api-key" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            <FormField
              control={form.control}
              name="tmdbApiKey"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>TMDB API Key</FormLabel>
                  <FormControl>
                    <Input placeholder="Enter your TMDB API key for movie/series metadata" {...field} data-testid="input-tmdb-api-key" />
                  </FormControl>
                  <FormDescription>Get your free API key at themoviedb.org</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            <Separator />
            <h3 className="text-lg font-medium">Compatibility APIs</h3>
            <FormField
              control={form.control}
              name="playerApiEnabled"
              render={({ field }) => (
                <FormItem className="flex items-center justify-between rounded-lg border p-4">
                  <div>
                    <FormLabel>Player API</FormLabel>
                    <FormDescription>X NeoServ Player compatibility</FormDescription>
                  </div>
                  <FormControl>
                    <Switch checked={field.value} onCheckedChange={field.onChange} data-testid="switch-player-api" />
                  </FormControl>
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="enigma2ApiEnabled"
              render={({ field }) => (
                <FormItem className="flex items-center justify-between rounded-lg border p-4">
                  <div>
                    <FormLabel>Enigma2 API</FormLabel>
                    <FormDescription>Enigma2 set-top box compatibility</FormDescription>
                  </div>
                  <FormControl>
                    <Switch checked={field.value} onCheckedChange={field.onChange} data-testid="switch-enigma2-api" />
                  </FormControl>
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="magApiEnabled"
              render={({ field }) => (
                <FormItem className="flex items-center justify-between rounded-lg border p-4">
                  <div>
                    <FormLabel>MAG API</FormLabel>
                    <FormDescription>MAG device compatibility</FormDescription>
                  </div>
                  <FormControl>
                    <Switch checked={field.value} onCheckedChange={field.onChange} data-testid="switch-mag-api" />
                  </FormControl>
                </FormItem>
              )}
            />
            <div className="flex justify-end pt-4">
              <Button type="submit" disabled={mutation.isPending} data-testid="button-save-api">
                <Save className="h-4 w-4 mr-2" />
                {mutation.isPending ? "Saving..." : "Save Changes"}
              </Button>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}

function TranscodingSettings({ settings }: { settings: Record<string, string> }) {
  const { toast } = useToast();
  
  const form = useForm<TranscodingSettingsData>({
    resolver: zodResolver(transcodingSettingsSchema),
    defaultValues: {
      transcodingEnabled: false,
      ffmpegPath: "/usr/bin/ffmpeg",
      defaultCodec: "libx264",
      hardwareAcceleration: false,
      maxTranscodingTasks: 4,
    },
  });

  useEffect(() => {
    if (settings) {
      form.reset({
        transcodingEnabled: settings.transcoding_enabled === "1",
        ffmpegPath: settings.ffmpeg_path || "/usr/bin/ffmpeg",
        defaultCodec: settings.default_codec || "libx264",
        hardwareAcceleration: settings.hardware_acceleration === "1",
        maxTranscodingTasks: parseInt(settings.max_transcoding_tasks) || 4,
      });
    }
  }, [settings, form]);

  const mutation = useMutation({
    mutationFn: async (data: TranscodingSettingsData) => {
      return apiRequest("POST", "/api/settings/transcoding", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/settings"] });
      toast({ title: "Transcoding settings saved" });
    },
    onError: () => {
      toast({ title: "Failed to save settings", variant: "destructive" });
    },
  });

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Video className="h-5 w-5" />
          Transcoding Settings
        </CardTitle>
        <CardDescription>Configure video transcoding options</CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit((data) => mutation.mutate(data))} className="space-y-4">
            <FormField
              control={form.control}
              name="transcodingEnabled"
              render={({ field }) => (
                <FormItem className="flex items-center justify-between rounded-lg border p-4">
                  <div>
                    <FormLabel>Enable Transcoding</FormLabel>
                    <FormDescription>Allow stream transcoding</FormDescription>
                  </div>
                  <FormControl>
                    <Switch checked={field.value} onCheckedChange={field.onChange} data-testid="switch-transcoding" />
                  </FormControl>
                </FormItem>
              )}
            />
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="ffmpegPath"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>FFmpeg Path</FormLabel>
                    <FormControl>
                      <Input {...field} data-testid="input-ffmpeg-path" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="defaultCodec"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Default Codec</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger data-testid="select-codec">
                          <SelectValue placeholder="Select codec" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="libx264">H.264 (libx264)</SelectItem>
                        <SelectItem value="libx265">H.265 (libx265)</SelectItem>
                        <SelectItem value="copy">Copy (no transcode)</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            <FormField
              control={form.control}
              name="hardwareAcceleration"
              render={({ field }) => (
                <FormItem className="flex items-center justify-between rounded-lg border p-4">
                  <div>
                    <FormLabel>Hardware Acceleration</FormLabel>
                    <FormDescription>Use GPU for transcoding (NVENC/VAAPI)</FormDescription>
                  </div>
                  <FormControl>
                    <Switch checked={field.value} onCheckedChange={field.onChange} data-testid="switch-hw-accel" />
                  </FormControl>
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="maxTranscodingTasks"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Max Concurrent Tasks</FormLabel>
                  <FormControl>
                    <Input type="number" min={1} max={32} {...field} data-testid="input-max-tasks" />
                  </FormControl>
                  <FormDescription>Maximum simultaneous transcoding jobs</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            <div className="flex justify-end pt-4">
              <Button type="submit" disabled={mutation.isPending} data-testid="button-save-transcoding">
                <Save className="h-4 w-4 mr-2" />
                {mutation.isPending ? "Saving..." : "Save Changes"}
              </Button>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}

function BackupSettings() {
  const { toast } = useToast();
  const [exportFormat, setExportFormat] = useState("neoserv");
  const [importFormat, setImportFormat] = useState("neoserv");
  const [importFile, setImportFile] = useState<File | null>(null);

  const exportMutation = useMutation({
    mutationFn: async (format: string) => {
      const response = await apiRequest("POST", `/api/backup/export?format=${format}`);
      return response.json();
    },
    onSuccess: (data) => {
      // Create and download the file
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `backup-${exportFormat}-${new Date().toISOString().split("T")[0]}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      toast({ title: "Export successful", description: `Database exported in ${exportFormat} format` });
    },
    onError: () => {
      toast({ title: "Export failed", variant: "destructive" });
    },
  });

  const importMutation = useMutation({
    mutationFn: async ({ file, format }: { file: File; format: string }) => {
      const formData = new FormData();
      formData.append("file", file);
      formData.append("format", format);
      const response = await fetch(`/api/backup/import?format=${format}`, {
        method: "POST",
        body: formData,
      });
      if (!response.ok) throw new Error("Import failed");
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries();
      toast({ 
        title: "Import successful", 
        description: `Imported ${data.imported?.users || 0} users, ${data.imported?.streams || 0} streams` 
      });
      setImportFile(null);
    },
    onError: () => {
      toast({ title: "Import failed", variant: "destructive" });
    },
  });

  const handleImport = () => {
    if (!importFile) {
      toast({ title: "Please select a file", variant: "destructive" });
      return;
    }
    importMutation.mutate({ file: importFile, format: importFormat });
  };

  const formats = [
    { value: "neoserv", label: "X NeoServ (Native)", description: "Full backup with all settings" },
    { value: "xui-one", label: "XUI.ONE", description: "Compatible with XUI.ONE panel" },
    { value: "xtream-codec", label: "Xtream Codec", description: "Standard Xtream Codes format" },
    { value: "1-stream", label: "1-Stream", description: "Compatible with 1-Stream panel" },
    { value: "nxt", label: "NXT Panel", description: "Compatible with NXT panel" },
  ];

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Download className="h-5 w-5" />
            Export Database
          </CardTitle>
          <CardDescription>Export your database to various panel formats</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">Export Format</label>
            <Select value={exportFormat} onValueChange={setExportFormat}>
              <SelectTrigger data-testid="select-export-format">
                <SelectValue placeholder="Select format" />
              </SelectTrigger>
              <SelectContent>
                {formats.map((f) => (
                  <SelectItem key={f.value} value={f.value}>
                    <div className="flex flex-col">
                      <span>{f.label}</span>
                      <span className="text-xs text-muted-foreground">{f.description}</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
            {formats.map((f) => (
              <Button
                key={f.value}
                variant={exportFormat === f.value ? "default" : "outline"}
                size="sm"
                onClick={() => setExportFormat(f.value)}
                className="text-xs"
                data-testid={`button-format-${f.value}`}
              >
                {f.label}
              </Button>
            ))}
          </div>

          <Separator />

          <div className="flex items-center justify-between gap-4 flex-wrap">
            <div className="text-sm text-muted-foreground">
              Export includes: Users, Streams, Movies, Series, Categories, Bouquets, Servers, EPG Sources
            </div>
            <Button 
              onClick={() => exportMutation.mutate(exportFormat)}
              disabled={exportMutation.isPending}
              data-testid="button-export"
            >
              {exportMutation.isPending ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Exporting...
                </>
              ) : (
                <>
                  <Download className="h-4 w-4 mr-2" />
                  Export Database
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Upload className="h-5 w-5" />
            Import Database
          </CardTitle>
          <CardDescription>Import data from another panel</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">Import Format</label>
            <Select value={importFormat} onValueChange={setImportFormat}>
              <SelectTrigger data-testid="select-import-format">
                <SelectValue placeholder="Select format" />
              </SelectTrigger>
              <SelectContent>
                {formats.map((f) => (
                  <SelectItem key={f.value} value={f.value}>
                    <div className="flex flex-col">
                      <span>{f.label}</span>
                      <span className="text-xs text-muted-foreground">{f.description}</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
            {formats.map((f) => (
              <Button
                key={f.value}
                variant={importFormat === f.value ? "default" : "outline"}
                size="sm"
                onClick={() => setImportFormat(f.value)}
                className="text-xs"
                data-testid={`button-import-format-${f.value}`}
              >
                {f.label}
              </Button>
            ))}
          </div>

          <Separator />

          <div className="space-y-2">
            <label className="text-sm font-medium">Select File</label>
            <div className="flex items-center gap-4">
              <Input
                type="file"
                accept=".json,.sql,.xml"
                onChange={(e) => setImportFile(e.target.files?.[0] || null)}
                className="flex-1"
                data-testid="input-import-file"
              />
              {importFile && (
                <span className="text-sm text-muted-foreground">
                  <FileJson className="h-4 w-4 inline mr-1" />
                  {importFile.name}
                </span>
              )}
            </div>
          </div>

          <div className="flex items-center justify-between gap-4 flex-wrap">
            <div className="text-sm text-muted-foreground">
              Supported formats: JSON, SQL dump, XML
            </div>
            <Button 
              onClick={handleImport}
              disabled={importMutation.isPending || !importFile}
              data-testid="button-import"
            >
              {importMutation.isPending ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Importing...
                </>
              ) : (
                <>
                  <Upload className="h-4 w-4 mr-2" />
                  Import Database
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Database className="h-5 w-5" />
            Database Management
          </CardTitle>
          <CardDescription>Manage database backups and maintenance</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Button variant="outline" data-testid="button-backup-db">
              <Download className="h-4 w-4 mr-2" />
              Backup Full Database
            </Button>
            <Button variant="outline" data-testid="button-restore-db">
              <Upload className="h-4 w-4 mr-2" />
              Restore from Backup
            </Button>
          </div>
          <Separator />
          <div className="text-sm text-muted-foreground">
            Last backup: Never
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export default function SettingsPage() {
  const { data: settingsArray, isLoading } = useQuery<AdminSetting[]>({
    queryKey: ["/api/settings"],
  });

  const settings = settingsArray ? parseSettings(settingsArray) : {};

  if (isLoading) {
    return (
      <div className="p-6 space-y-6">
        <div className="flex items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold">Settings</h1>
            <p className="text-muted-foreground">Configure panel settings</p>
          </div>
        </div>
        <div className="space-y-4">
          <Skeleton className="h-10 w-full" />
          <Skeleton className="h-[400px] w-full" />
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold">Settings</h1>
          <p className="text-muted-foreground">Configure panel settings</p>
        </div>
      </div>

      <Tabs defaultValue="general" className="space-y-6">
        <TabsList className="grid w-full grid-cols-10 gap-1">
          <TabsTrigger value="general" className="flex items-center gap-2" data-testid="tab-general">
            <Globe className="h-4 w-4" />
            <span className="hidden sm:inline">General</span>
          </TabsTrigger>
          <TabsTrigger value="security" className="flex items-center gap-2" data-testid="tab-security">
            <Shield className="h-4 w-4" />
            <span className="hidden sm:inline">Security</span>
          </TabsTrigger>
          <TabsTrigger value="streaming" className="flex items-center gap-2" data-testid="tab-streaming">
            <Server className="h-4 w-4" />
            <span className="hidden sm:inline">Streaming</span>
          </TabsTrigger>
          <TabsTrigger value="proxy" className="flex items-center gap-2" data-testid="tab-proxy">
            <Cloud className="h-4 w-4" />
            <span className="hidden sm:inline">Proxy</span>
          </TabsTrigger>
          <TabsTrigger value="domains" className="flex items-center gap-2" data-testid="tab-domains">
            <Globe className="h-4 w-4" />
            <span className="hidden sm:inline">Domains</span>
          </TabsTrigger>
          <TabsTrigger value="server" className="flex items-center gap-2" data-testid="tab-server">
            <HardDrive className="h-4 w-4" />
            <span className="hidden sm:inline">Server</span>
          </TabsTrigger>
          <TabsTrigger value="email" className="flex items-center gap-2" data-testid="tab-email">
            <Mail className="h-4 w-4" />
            <span className="hidden sm:inline">Email</span>
          </TabsTrigger>
          <TabsTrigger value="api" className="flex items-center gap-2" data-testid="tab-api">
            <Key className="h-4 w-4" />
            <span className="hidden sm:inline">API</span>
          </TabsTrigger>
          <TabsTrigger value="transcoding" className="flex items-center gap-2" data-testid="tab-transcoding">
            <Video className="h-4 w-4" />
            <span className="hidden sm:inline">Transcoding</span>
          </TabsTrigger>
          <TabsTrigger value="backup" className="flex items-center gap-2" data-testid="tab-backup">
            <Database className="h-4 w-4" />
            <span className="hidden sm:inline">Backup</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="general">
          <GeneralSettings settings={settings} />
        </TabsContent>

        <TabsContent value="security">
          <div className="space-y-6">
            <SecuritySettings settings={settings} />
            <TwoFactorSettings />
          </div>
        </TabsContent>

        <TabsContent value="streaming">
          <StreamingSettings settings={settings} />
        </TabsContent>

        <TabsContent value="proxy">
          <StreamingProxySettings settings={settings} />
        </TabsContent>

        <TabsContent value="domains">
          <CloudflareDomainsSettings settings={settings} />
        </TabsContent>

        <TabsContent value="server">
          <ServerSettings settings={settings} />
        </TabsContent>

        <TabsContent value="email">
          <EmailSettings settings={settings} />
        </TabsContent>

        <TabsContent value="api">
          <ApiSettings settings={settings} />
        </TabsContent>

        <TabsContent value="transcoding">
          <TranscodingSettings settings={settings} />
        </TabsContent>

        <TabsContent value="backup">
          <BackupSettings />
        </TabsContent>
      </Tabs>
    </div>
  );
}
