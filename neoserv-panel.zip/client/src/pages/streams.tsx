import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
  FormDescription,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Plus,
  Search,
  MoreHorizontal,
  Edit,
  Trash2,
  Tv,
  Play,
  Pause,
  ExternalLink,
  Copy,
  RotateCw,
  Square,
  Circle,
  Settings,
  Clock,
  Server,
  Zap,
  Shield,
  RefreshCw,
  Activity,
  Users,
  Check,
  AlertCircle,
  ChevronUp,
  ChevronDown,
  X,
  CheckSquare,
  Pencil,
} from "lucide-react";
import { Checkbox } from "@/components/ui/checkbox";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { DeleteConfirmation } from "@/components/delete-confirmation";
import type { StreamingServer } from "@shared/schema";

// Stream info interface for technical details
interface StreamInfo {
  resolution: string;
  videoCodec: string;
  audioCodec: string;
  fps: string;
  playbackSpeed: string;
}

// Mapped stream type from API (not the raw DB type)
interface Stream {
  id: number;
  name: string;
  streamType: string;
  categoryId: number | null;
  epgChannelId: string | null;
  language?: string | null;
  logoUrl: string;
  isActive: boolean;
  order: number;
  tvArchive: boolean;
  tvArchiveDuration: number;
  streamId: number;
  containerExtension: string;
  directSource?: number;
  hasSource?: boolean;
  hasBackupSources?: boolean;
  activeSourceIndex?: number;
  lastFailoverAt?: number | null;
  usingBackup?: boolean;
  streamUrl?: string;
  backupSources?: string[];
  userAgent?: string;
  status: "online" | "offline" | "restarting" | "error";
  serverName: string | null;
  serverId: number | null;
  uptimeSeconds: number;
  downtimeSeconds: number;
  bitrate: number | null;
  streamInfo: StreamInfo;
  outputFormats: string[];
  connectionCount: number;
  // Additional editing fields
  readNative?: number;
  genTimestamps?: number;
  customFfmpeg?: string;
  targetContainer?: string;
  autoRestart?: string;
  delayMinutes?: number;
  allowRecord?: number;
  enableTranscode?: number;
  transcodeProfileId?: number;
  transcodeCodec?: string;
  transcodeBitrate?: number;
  transcodeResolution?: string;
  forceServerId?: number;
}

interface Category {
  id: number;
  categoryName: string;
  categoryType: string;
  name?: string;
  type?: string;
}

const streamFormSchema = z.object({
  name: z.string().min(1, "Name is required"),
  streamUrl: z.string().optional().or(z.literal("")),
  backupSources: z.array(z.string()).default([]),
  categoryId: z.string().optional(),
  epgSourceId: z.string().optional(),
  epgChannelId: z.string().optional(),
  logoUrl: z.string().optional().or(z.literal("")),
  isActive: z.boolean(),
  order: z.coerce.number().default(0),
  userAgent: z.string().optional(),
  customFfmpeg: z.string().optional(),
  targetContainer: z.string().optional(),
  onDemand: z.boolean().default(false),
  directSource: z.boolean().default(false),
  readNative: z.boolean().default(true),
  loadBalancerId: z.string().optional(),
  proxyUrl: z.string().optional(),
  enableTranscode: z.boolean().default(false),
  transcodeProfileId: z.string().optional(),
  transcodeCodec: z.string().optional(),
  transcodeBitrate: z.coerce.number().optional(),
  transcodeResolution: z.string().optional(),
  autoQualityDetect: z.boolean().default(false),
  tvArchive: z.boolean().default(false),
  tvArchiveDuration: z.coerce.number().default(0),
  autoRestart: z.string().optional(),
  restartTime: z.string().optional(),
  delayMinutes: z.coerce.number().default(0),
  genTimestamps: z.boolean().default(true),
  allowRecord: z.boolean().default(false),
});

type StreamFormData = z.infer<typeof streamFormSchema>;

interface EpgSource {
  id: number;
  name: string;
}

interface EpgChannel {
  channelId: string;
  lang: string;
}

function StreamFormDialog({ 
  stream, 
  categories,
  servers,
  open, 
  onOpenChange 
}: { 
  stream?: Stream; 
  categories: Category[];
  servers: StreamingServer[];
  open: boolean; 
  onOpenChange: (open: boolean) => void;
}) {
  const { toast } = useToast();
  const isEditing = !!stream;
  const [selectedEpgSourceId, setSelectedEpgSourceId] = useState<string>("");

  const { data: epgSources } = useQuery<EpgSource[]>({
    queryKey: ["/api/epg"],
    enabled: open,
  });

  const { data: epgChannels, isLoading: loadingChannels } = useQuery<EpgChannel[]>({
    queryKey: ["/api/epg", selectedEpgSourceId, "channels"],
    queryFn: async () => {
      if (!selectedEpgSourceId) return [];
      const token = localStorage.getItem("neoserv_auth_token");
      const res = await fetch(`/api/epg/${selectedEpgSourceId}/channels`, { 
        headers: { "Authorization": `Bearer ${token}` }
      });
      if (!res.ok) return [];
      return res.json();
    },
    enabled: open && !!selectedEpgSourceId,
  });

  const [backupSources, setBackupSources] = useState<string[]>([]);
  
  const form = useForm<StreamFormData>({
    resolver: zodResolver(streamFormSchema),
    defaultValues: {
      name: "",
      streamUrl: "",
      backupSources: [],
      categoryId: "none",
      epgSourceId: "",
      epgChannelId: "",
      logoUrl: "",
      isActive: true,
      order: 0,
      userAgent: "",
      customFfmpeg: "",
      targetContainer: "mpegts",
      onDemand: false,
      directSource: false,
      readNative: true,
      loadBalancerId: "auto",
      proxyUrl: "",
      enableTranscode: false,
      transcodeProfileId: "",
      transcodeCodec: "libx264",
      transcodeBitrate: 0,
      transcodeResolution: "original",
      autoQualityDetect: false,
      tvArchive: false,
      tvArchiveDuration: 0,
      autoRestart: "never",
      restartTime: "",
      delayMinutes: 0,
      genTimestamps: true,
      allowRecord: false,
    },
  });

  // Reset form when stream changes or dialog opens
  useEffect(() => {
    if (open) {
      if (stream) {
        // Editing existing stream - use values from API
        const loadBalancerValue = stream.forceServerId && stream.forceServerId > 0 ? String(stream.forceServerId) : "auto";
        
        form.reset({
          name: stream.name || "",
          streamUrl: stream.streamUrl || "",
          backupSources: stream.backupSources || [],
          categoryId: stream.categoryId ? String(stream.categoryId) : "none",
          epgSourceId: "",
          epgChannelId: stream.epgChannelId || "",
          logoUrl: stream.logoUrl || "",
          isActive: stream.isActive ?? true,
          order: stream.order ?? 0,
          userAgent: stream.userAgent || "",
          customFfmpeg: stream.customFfmpeg || "",
          targetContainer: stream.targetContainer || "mpegts",
          onDemand: false,
          directSource: stream.directSource === 1,
          readNative: stream.readNative === 1,
          loadBalancerId: stream.forceServerId && stream.forceServerId > 0 ? String(stream.forceServerId) : "auto",
          proxyUrl: "",
          enableTranscode: stream.enableTranscode === 1,
          transcodeProfileId: stream.transcodeProfileId ? String(stream.transcodeProfileId) : "",
          transcodeCodec: stream.transcodeCodec || "libx264",
          transcodeBitrate: stream.transcodeBitrate || 0,
          transcodeResolution: stream.transcodeResolution || "original",
          autoQualityDetect: false,
          tvArchive: stream.tvArchive ?? false,
          tvArchiveDuration: stream.tvArchiveDuration ?? 0,
          autoRestart: stream.autoRestart || "never",
          restartTime: "",
          delayMinutes: stream.delayMinutes || 0,
          genTimestamps: stream.genTimestamps === 1,
          allowRecord: stream.allowRecord === 1,
        });
        // Force update the loadBalancerId after reset to ensure Select component updates
        setTimeout(() => {
          form.setValue("loadBalancerId", loadBalancerValue);
        }, 0);
      } else {
        // Creating new stream - use defaults
        form.reset({
          name: "",
          streamUrl: "",
          backupSources: [],
          categoryId: "none",
          epgSourceId: "",
          epgChannelId: "",
          logoUrl: "",
          isActive: true,
          order: 0,
          userAgent: "",
          customFfmpeg: "",
          targetContainer: "mpegts",
          onDemand: false,
          directSource: false,
          readNative: true,
          loadBalancerId: "auto",
          proxyUrl: "",
          enableTranscode: false,
          transcodeProfileId: "",
          transcodeCodec: "libx264",
          transcodeBitrate: 0,
          transcodeResolution: "original",
          autoQualityDetect: false,
          tvArchive: false,
          tvArchiveDuration: 0,
          autoRestart: "never",
          restartTime: "",
          delayMinutes: 0,
          genTimestamps: true,
          allowRecord: false,
        });
      }
      // Set backup sources state for display
      setBackupSources(stream?.backupSources || []);
    }
  }, [open, stream, form]);

  const mutation = useMutation({
    mutationFn: async (data: StreamFormData) => {
      // When editing, don't send empty streamUrl (preserve existing source)
      const payload = { ...data };
      if (isEditing && !payload.streamUrl) {
        delete (payload as any).streamUrl;
      }
      if (isEditing) {
        return apiRequest("PATCH", `/api/streams/${stream.id}`, payload);
      }
      return apiRequest("POST", "/api/streams", payload);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/streams"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({
        title: isEditing ? "Stream updated" : "Stream created",
      });
      onOpenChange(false);
      form.reset();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to save stream",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: StreamFormData) => {
    // Include backupSources from state
    mutation.mutate({ ...data, backupSources: backupSources.filter(s => s.trim()) });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh]">
        <DialogHeader>
          <DialogTitle>{isEditing ? "Edit Stream" : "Add New Stream"}</DialogTitle>
        </DialogHeader>
        <Form {...form} key={`${stream?.id || "new"}-${stream?.forceServerId || 0}`}>
          <form onSubmit={form.handleSubmit(onSubmit)}>
            <ScrollArea className="h-[60vh] pr-4">
              <Tabs defaultValue="basic" className="w-full">
                <TabsList className="grid w-full grid-cols-5 mb-4">
                  <TabsTrigger value="basic" data-testid="tab-basic">
                    <Tv className="h-4 w-4 mr-1" />
                    Basic
                  </TabsTrigger>
                  <TabsTrigger value="source" data-testid="tab-source">
                    <Server className="h-4 w-4 mr-1" />
                    Source
                  </TabsTrigger>
                  <TabsTrigger value="quality" data-testid="tab-quality">
                    <Zap className="h-4 w-4 mr-1" />
                    Quality
                  </TabsTrigger>
                  <TabsTrigger value="timeshift" data-testid="tab-timeshift">
                    <Clock className="h-4 w-4 mr-1" />
                    Timeshift
                  </TabsTrigger>
                  <TabsTrigger value="advanced" data-testid="tab-advanced">
                    <Settings className="h-4 w-4 mr-1" />
                    Advanced
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="basic" className="space-y-4">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Channel Name</FormLabel>
                        <FormControl>
                          <Input placeholder="BBC One" {...field} data-testid="input-stream-name" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="streamUrl"
                    render={({ field }) => (
                      <FormItem>
                        <div className="flex items-center gap-2">
                          <FormLabel>Stream URL</FormLabel>
                          {isEditing && stream?.hasSource && (
                            <Badge variant="default" className="text-xs">
                              <Check className="h-3 w-3 mr-1" />
                              Source Configured
                            </Badge>
                          )}
                          {isEditing && !stream?.hasSource && (
                            <Badge variant="destructive" className="text-xs">
                              <AlertCircle className="h-3 w-3 mr-1" />
                              No Source
                            </Badge>
                          )}
                        </div>
                        <FormControl>
                          <Input 
                            placeholder={isEditing ? "Leave empty to keep existing source" : "http://example.com/stream.m3u8"} 
                            {...field} 
                            data-testid="input-stream-url" 
                          />
                        </FormControl>
                        {isEditing && (
                          <FormDescription>
                            {stream?.hasSource 
                              ? "Source URL is already configured. Enter new URL only to replace it."
                              : "No source URL configured. Enter URL to add one."}
                          </FormDescription>
                        )}
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <div className="space-y-3">
                    <div className="flex items-center justify-between gap-2">
                      <FormLabel>Backup Sources</FormLabel>
                      <Button 
                        type="button" 
                        variant="outline" 
                        size="sm"
                        onClick={() => setBackupSources([...backupSources, ""])}
                        data-testid="button-add-backup-source"
                      >
                        <Plus className="h-4 w-4 mr-1" />
                        Add Row
                      </Button>
                    </div>
                    {backupSources.length === 0 && (
                      <p className="text-sm text-muted-foreground">No backup sources configured. Click "Add Row" to add failover URLs.</p>
                    )}
                    {backupSources.map((source, index) => (
                      <div key={index} className="flex items-center gap-2">
                        <div className="flex flex-col gap-1">
                          <Button
                            type="button"
                            variant="ghost"
                            size="icon"
                            className="h-6 w-6"
                            disabled={index === 0}
                            onClick={() => {
                              const newSources = [...backupSources];
                              [newSources[index - 1], newSources[index]] = [newSources[index], newSources[index - 1]];
                              setBackupSources(newSources);
                            }}
                            data-testid={`button-move-up-${index}`}
                          >
                            <ChevronUp className="h-3 w-3" />
                          </Button>
                          <Button
                            type="button"
                            variant="ghost"
                            size="icon"
                            className="h-6 w-6"
                            disabled={index === backupSources.length - 1}
                            onClick={() => {
                              const newSources = [...backupSources];
                              [newSources[index], newSources[index + 1]] = [newSources[index + 1], newSources[index]];
                              setBackupSources(newSources);
                            }}
                            data-testid={`button-move-down-${index}`}
                          >
                            <ChevronDown className="h-3 w-3" />
                          </Button>
                        </div>
                        <Input
                          placeholder="http://backup.example.com/stream.m3u8"
                          value={source}
                          onChange={(e) => {
                            const newSources = [...backupSources];
                            newSources[index] = e.target.value;
                            setBackupSources(newSources);
                          }}
                          className="flex-1"
                          data-testid={`input-backup-source-${index}`}
                        />
                        <Button
                          type="button"
                          variant="destructive"
                          size="icon"
                          onClick={() => {
                            setBackupSources(backupSources.filter((_, i) => i !== index));
                          }}
                          data-testid={`button-remove-backup-${index}`}
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                    ))}
                    <p className="text-xs text-muted-foreground">
                      Automatic failover - if primary source fails, backups will be tried in order
                    </p>
                  </div>
                  <FormField
                    control={form.control}
                    name="categoryId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Category</FormLabel>
                        <Select onValueChange={field.onChange} value={field.value || "none"}>
                          <FormControl>
                            <SelectTrigger data-testid="select-category">
                              <SelectValue placeholder="Select category" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="none">None</SelectItem>
                            {categories?.filter(c => c.categoryType === "live").map((cat) => (
                              <SelectItem key={cat.id} value={String(cat.id)}>{cat.categoryName}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="space-y-3 rounded-lg border p-3">
                    <h4 className="text-sm font-medium">EPG Settings</h4>
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="epgSourceId"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>EPG Source</FormLabel>
                            <Select 
                              onValueChange={(value) => {
                                field.onChange(value);
                                setSelectedEpgSourceId(value === "none" ? "" : value);
                                form.setValue("epgChannelId", "");
                              }} 
                              value={field.value || "none"}
                            >
                              <FormControl>
                                <SelectTrigger data-testid="select-epg-source">
                                  <SelectValue placeholder="Select EPG source" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="none">None</SelectItem>
                                {epgSources?.map((source) => (
                                  <SelectItem key={source.id} value={String(source.id)}>{source.name}</SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="epgChannelId"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Channel ID (EPG)</FormLabel>
                            <FormControl>
                              <div className="space-y-2">
                                <Input 
                                  placeholder="e.g. PopTV.svn, RTL.de" 
                                  value={field.value || ""} 
                                  onChange={(e) => field.onChange(e.target.value)}
                                  data-testid="input-epg-channel-id"
                                />
                                {selectedEpgSourceId && epgChannels && epgChannels.length > 0 && (
                                  <Select 
                                    onValueChange={(val) => val !== "none" && field.onChange(val)} 
                                    value=""
                                  >
                                    <SelectTrigger data-testid="select-epg-channel" className="text-muted-foreground">
                                      <SelectValue placeholder="Or select from EPG source..." />
                                    </SelectTrigger>
                                    <SelectContent>
                                      <SelectItem value="none">Cancel</SelectItem>
                                      {epgChannels.map((channel) => (
                                        <SelectItem key={channel.channelId} value={channel.channelId}>
                                          {channel.channelId} {channel.lang && `(${channel.lang})`}
                                        </SelectItem>
                                      ))}
                                    </SelectContent>
                                  </Select>
                                )}
                              </div>
                            </FormControl>
                            <FormDescription>
                              Enter Channel ID from XMLTV EPG source
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  </div>
                  <FormField
                    control={form.control}
                    name="logoUrl"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Logo URL</FormLabel>
                        <FormControl>
                          <Input placeholder="http://example.com/logo.png" {...field} data-testid="input-logo-url" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="order"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Sort Order</FormLabel>
                        <FormControl>
                          <Input type="number" placeholder="0" {...field} data-testid="input-order" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="isActive"
                    render={({ field }) => (
                      <FormItem className="flex items-center justify-between rounded-lg border p-3">
                        <div>
                          <FormLabel>Active</FormLabel>
                          <FormDescription>Enable this stream for users</FormDescription>
                        </div>
                        <FormControl>
                          <Switch checked={field.value} onCheckedChange={field.onChange} data-testid="switch-active" />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                </TabsContent>

                <TabsContent value="source" className="space-y-4">
                  <FormField
                    control={form.control}
                    name="userAgent"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>User Agent</FormLabel>
                        <FormControl>
                          <Input placeholder="Mozilla/5.0 (Windows NT 10.0; Win64; x64)..." {...field} data-testid="input-user-agent" />
                        </FormControl>
                        <FormDescription>Custom user agent for fetching the stream</FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="loadBalancerId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Load Balancer Server</FormLabel>
                        <Select onValueChange={field.onChange} value={field.value || "auto"}>
                          <FormControl>
                            <SelectTrigger data-testid="select-load-balancer">
                              <SelectValue placeholder="Auto / Any Server" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="auto">Auto / Any Server</SelectItem>
                            {servers?.map((srv) => (
                              <SelectItem key={srv.id} value={String(srv.id)}>{srv.serverName}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormDescription>Select which server handles this stream</FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="directSource"
                      render={({ field }) => (
                        <FormItem className="flex items-center justify-between rounded-lg border p-3">
                          <div>
                            <FormLabel>Direct Source</FormLabel>
                            <FormDescription>Bypass server processing</FormDescription>
                          </div>
                          <FormControl>
                            <Switch checked={field.value} onCheckedChange={field.onChange} data-testid="switch-direct-source" />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="onDemand"
                      render={({ field }) => (
                        <FormItem className="flex items-center justify-between rounded-lg border p-3">
                          <div>
                            <FormLabel>On Demand</FormLabel>
                            <FormDescription>Start only when requested</FormDescription>
                          </div>
                          <FormControl>
                            <Switch checked={field.value} onCheckedChange={field.onChange} data-testid="switch-on-demand" />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                  </div>
                  <div className="border rounded-lg p-4 space-y-4">
                    <div className="flex items-center gap-2 mb-2">
                      <Shield className="h-4 w-4" />
                      <h4 className="font-medium">Proxy Settings</h4>
                    </div>
                    <FormField
                      control={form.control}
                      name="proxyUrl"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Proxy URL</FormLabel>
                          <FormDescription>Stream will use this proxy IP when set</FormDescription>
                          <FormControl>
                            <Input placeholder="http://proxy.example.com:8080" {...field} data-testid="input-proxy-url" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </TabsContent>

                <TabsContent value="quality" className="space-y-4">
                  <FormField
                    control={form.control}
                    name="autoQualityDetect"
                    render={({ field }) => (
                      <FormItem className="flex items-center justify-between rounded-lg border p-3">
                        <div>
                          <FormLabel>Auto Quality Detection</FormLabel>
                          <FormDescription>Automatically detect and select best quality</FormDescription>
                        </div>
                        <FormControl>
                          <Switch checked={field.value} onCheckedChange={field.onChange} data-testid="switch-auto-quality" />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="targetContainer"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Target Container</FormLabel>
                        <Select onValueChange={field.onChange} value={field.value || "mpegts"}>
                          <FormControl>
                            <SelectTrigger data-testid="select-container">
                              <SelectValue placeholder="Select container" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="mpegts">MPEG-TS</SelectItem>
                            <SelectItem value="hls">HLS</SelectItem>
                            <SelectItem value="flv">FLV</SelectItem>
                            <SelectItem value="mp4">MP4</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <div className="border rounded-lg p-4 space-y-4">
                    <FormField
                      control={form.control}
                      name="enableTranscode"
                      render={({ field }) => (
                        <FormItem className="flex items-center justify-between rounded-lg border p-3">
                          <div>
                            <FormLabel>Enable Transcoding</FormLabel>
                            <FormDescription>Re-encode stream with custom settings</FormDescription>
                          </div>
                          <FormControl>
                            <Switch checked={field.value} onCheckedChange={field.onChange} data-testid="switch-transcode" />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                    {form.watch("enableTranscode") && (
                      <>
                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={form.control}
                            name="transcodeCodec"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Video Codec</FormLabel>
                                <Select onValueChange={field.onChange} value={field.value || "libx264"}>
                                  <FormControl>
                                    <SelectTrigger data-testid="select-codec">
                                      <SelectValue placeholder="Select codec" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent>
                                    <SelectItem value="libx264">H.264 (libx264)</SelectItem>
                                    <SelectItem value="libx265">H.265 (libx265)</SelectItem>
                                    <SelectItem value="h264_nvenc">H.264 NVENC (GPU)</SelectItem>
                                    <SelectItem value="hevc_nvenc">H.265 NVENC (GPU)</SelectItem>
                                    <SelectItem value="h264_vaapi">H.264 VAAPI</SelectItem>
                                    <SelectItem value="copy">Copy (No Re-encode)</SelectItem>
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={form.control}
                            name="transcodeBitrate"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Bitrate (kbps)</FormLabel>
                                <FormControl>
                                  <Input type="number" placeholder="3000" {...field} data-testid="input-bitrate" />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        <FormField
                          control={form.control}
                          name="transcodeResolution"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Resolution</FormLabel>
                              <Select onValueChange={field.onChange} value={field.value || "original"}>
                                <FormControl>
                                  <SelectTrigger data-testid="select-resolution">
                                    <SelectValue placeholder="Original" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="original">Original</SelectItem>
                                  <SelectItem value="1920x1080">1080p (1920x1080)</SelectItem>
                                  <SelectItem value="1280x720">720p (1280x720)</SelectItem>
                                  <SelectItem value="854x480">480p (854x480)</SelectItem>
                                  <SelectItem value="640x360">360p (640x360)</SelectItem>
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </>
                    )}
                  </div>
                </TabsContent>

                <TabsContent value="timeshift" className="space-y-4">
                  <FormField
                    control={form.control}
                    name="tvArchive"
                    render={({ field }) => (
                      <FormItem className="flex items-center justify-between rounded-lg border p-3">
                        <div>
                          <FormLabel>Enable Timeshift / TV Archive</FormLabel>
                          <FormDescription>Allow users to rewind and replay content</FormDescription>
                        </div>
                        <FormControl>
                          <Switch checked={field.value} onCheckedChange={field.onChange} data-testid="switch-timeshift" />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                  {form.watch("tvArchive") && (
                    <FormField
                      control={form.control}
                      name="tvArchiveDuration"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Archive Duration (Days)</FormLabel>
                          <FormControl>
                            <Input type="number" placeholder="7" {...field} data-testid="input-archive-days" />
                          </FormControl>
                          <FormDescription>How many days of content to keep available</FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  )}
                  <FormField
                    control={form.control}
                    name="allowRecord"
                    render={({ field }) => (
                      <FormItem className="flex items-center justify-between rounded-lg border p-3">
                        <div>
                          <FormLabel>Allow Recording</FormLabel>
                          <FormDescription>Let users record this stream</FormDescription>
                        </div>
                        <FormControl>
                          <Switch checked={field.value} onCheckedChange={field.onChange} data-testid="switch-record" />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                  <div className="border rounded-lg p-4 space-y-4">
                    <h4 className="font-medium flex items-center gap-2">
                      <RotateCw className="h-4 w-4" />
                      Auto Restart Schedule
                    </h4>
                    <FormField
                      control={form.control}
                      name="autoRestart"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Restart Interval</FormLabel>
                          <Select onValueChange={field.onChange} value={field.value || "never"}>
                            <FormControl>
                              <SelectTrigger data-testid="select-restart-interval">
                                <SelectValue placeholder="Never" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="never">Never</SelectItem>
                              <SelectItem value="hourly">Every Hour</SelectItem>
                              <SelectItem value="daily">Every Day</SelectItem>
                              <SelectItem value="weekly">Every Week</SelectItem>
                              <SelectItem value="custom">Custom Time</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    {form.watch("autoRestart") === "custom" && (
                      <FormField
                        control={form.control}
                        name="restartTime"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Restart Time (HH:MM)</FormLabel>
                            <FormControl>
                              <Input type="time" {...field} data-testid="input-restart-time" />
                            </FormControl>
                            <FormDescription>Daily restart at this time (server timezone)</FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    )}
                  </div>
                </TabsContent>

                <TabsContent value="advanced" className="space-y-4">
                  <FormField
                    control={form.control}
                    name="customFfmpeg"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Custom FFmpeg Parameters</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="-re -analyzeduration 5M -probesize 5M" 
                            className="font-mono text-sm min-h-[80px]"
                            {...field} 
                            data-testid="input-custom-ffmpeg" 
                          />
                        </FormControl>
                        <FormDescription>Advanced FFmpeg input/output parameters</FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="readNative"
                      render={({ field }) => (
                        <FormItem className="flex items-center justify-between rounded-lg border p-3">
                          <div>
                            <FormLabel>Read Native</FormLabel>
                            <FormDescription>Use native frame rate</FormDescription>
                          </div>
                          <FormControl>
                            <Switch checked={field.value} onCheckedChange={field.onChange} data-testid="switch-read-native" />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="genTimestamps"
                      render={({ field }) => (
                        <FormItem className="flex items-center justify-between rounded-lg border p-3">
                          <div>
                            <FormLabel>Gen Timestamps</FormLabel>
                            <FormDescription>Generate PTS/DTS</FormDescription>
                          </div>
                          <FormControl>
                            <Switch checked={field.value} onCheckedChange={field.onChange} data-testid="switch-gen-timestamps" />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                  </div>
                  <FormField
                    control={form.control}
                    name="delayMinutes"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Stream Delay (Minutes)</FormLabel>
                        <FormControl>
                          <Input type="number" placeholder="0" {...field} data-testid="input-delay" />
                        </FormControl>
                        <FormDescription>Add delay to live stream playback</FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </TabsContent>
              </Tabs>
            </ScrollArea>
            <div className="flex justify-end gap-2 pt-4 border-t mt-4">
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
                Cancel
              </Button>
              <Button type="submit" disabled={mutation.isPending} data-testid="button-save-stream">
                {mutation.isPending ? "Saving..." : isEditing ? "Update" : "Create"}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}

// Stream Player Dialog Component
function StreamPlayerDialog({
  stream,
  open,
  onOpenChange,
}: {
  stream: Stream | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const [playbackUrl, setPlaybackUrl] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isDirectStream, setIsDirectStream] = useState(false);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const hlsRef = useRef<any>(null);

  useEffect(() => {
    if (open && stream) {
      setIsLoading(true);
      setError(null);
      setPlaybackUrl(null);
      setIsDirectStream(false);
      
      const token = localStorage.getItem("neoserv_auth_token");
      fetch(`/api/streams/${stream.id}/play`, {
        headers: { "Authorization": `Bearer ${token}` }
      })
        .then(res => res.json())
        .then(data => {
          if (data.playbackUrl) {
            setPlaybackUrl(data.playbackUrl);
            setIsDirectStream(data.playbackUrl.includes('direct-stream'));
          } else {
            setError("No playback URL available");
          }
        })
        .catch(() => setError("Failed to get stream URL"))
        .finally(() => setIsLoading(false));
    }
    
    return () => {
      if (hlsRef.current) {
        hlsRef.current.destroy();
        hlsRef.current = null;
      }
    };
  }, [open, stream]);

  useEffect(() => {
    if (playbackUrl && videoRef.current && !isDirectStream) {
      const video = videoRef.current;
      
      if (playbackUrl.includes('.m3u8') || playbackUrl.includes('playlist')) {
        import('hls.js').then(({ default: Hls }) => {
          if (Hls.isSupported()) {
            if (hlsRef.current) {
              hlsRef.current.destroy();
            }
            const hls = new Hls();
            hlsRef.current = hls;
            hls.loadSource(playbackUrl);
            hls.attachMedia(video);
            hls.on(Hls.Events.MANIFEST_PARSED, () => {
              video.play().catch(() => {});
            });
            hls.on(Hls.Events.ERROR, (_event: any, data: any) => {
              if (data.fatal) {
                setError("HLS playback error");
              }
            });
          } else if (video.canPlayType('application/vnd.apple.mpegurl')) {
            video.src = playbackUrl;
            video.play().catch(() => {});
          }
        });
      } else {
        video.src = playbackUrl;
        video.play().catch(() => {});
      }
    }
  }, [playbackUrl, isDirectStream]);

  const copyUrl = () => {
    if (playbackUrl) {
      navigator.clipboard.writeText(playbackUrl);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Play className="h-5 w-5" />
            Stream Player - {stream?.name}
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          {isLoading && (
            <div className="flex items-center justify-center h-64 bg-muted rounded-lg">
              <RefreshCw className="h-8 w-8 animate-spin text-muted-foreground" />
            </div>
          )}
          
          {error && (
            <div className="flex flex-col items-center justify-center h-64 bg-muted rounded-lg">
              <AlertCircle className="h-12 w-12 text-destructive mb-2" />
              <p className="text-destructive">{error}</p>
            </div>
          )}
          
          {playbackUrl && !isLoading && (
            <>
              {isDirectStream ? (
                <div className="flex flex-col items-center justify-center h-64 bg-muted rounded-lg p-6 text-center">
                  <Tv className="h-12 w-12 text-muted-foreground mb-4" />
                  <p className="text-lg font-medium mb-2">Direct MPEG-TS Stream</p>
                  <p className="text-muted-foreground mb-4">
                    This stream uses direct MPEG-TS format which cannot be played in browser.
                    <br />Copy the URL and open it in VLC or another media player.
                  </p>
                  <div className="flex gap-2">
                    <Button onClick={copyUrl} data-testid="button-copy-vlc">
                      <Copy className="h-4 w-4 mr-2" />
                      Copy URL for VLC
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="relative bg-black rounded-lg overflow-hidden aspect-video">
                  <video
                    ref={videoRef}
                    controls
                    autoPlay
                    className="w-full h-full"
                    onError={() => setError("Failed to play stream")}
                  >
                    Your browser does not support video playback.
                  </video>
                </div>
              )}
              
              <div className="flex items-center gap-2">
                <Input 
                  value={playbackUrl} 
                  readOnly 
                  className="flex-1 font-mono text-xs"
                  data-testid="input-playback-url"
                />
                <Button variant="outline" size="icon" onClick={copyUrl} data-testid="button-copy-url">
                  <Copy className="h-4 w-4" />
                </Button>
                <Button variant="outline" size="icon" onClick={() => window.open(playbackUrl, "_blank")} data-testid="button-open-external">
                  <ExternalLink className="h-4 w-4" />
                </Button>
              </div>
              
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div className="space-y-1">
                  <p className="text-muted-foreground">Stream ID</p>
                  <p className="font-mono">{stream?.streamId}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-muted-foreground">Status</p>
                  <Badge variant={stream?.status === "online" ? "default" : "destructive"}>
                    {stream?.status}
                  </Badge>
                </div>
                <div className="space-y-1">
                  <p className="text-muted-foreground">Resolution</p>
                  <p>{stream?.streamInfo?.resolution || "N/A"}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-muted-foreground">Codec</p>
                  <p>{stream?.streamInfo?.videoCodec || "N/A"}</p>
                </div>
              </div>
            </>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

export default function StreamsPage() {
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [categoryFilter, setCategoryFilter] = useState<string>("all");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingStream, setEditingStream] = useState<Stream | undefined>();
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [streamToDelete, setStreamToDelete] = useState<Stream | null>(null);
  const [importDialogOpen, setImportDialogOpen] = useState(false);
  const [importFile, setImportFile] = useState<File | null>(null);
  const [importBouquetId, setImportBouquetId] = useState<string>("");
  const [playerOpen, setPlayerOpen] = useState(false);
  const [playingStream, setPlayingStream] = useState<Stream | null>(null);
  const [selectedIds, setSelectedIds] = useState<Set<number>>(new Set());
  const [massEditOpen, setMassEditOpen] = useState(false);
  const [bulkDeleteDialogOpen, setBulkDeleteDialogOpen] = useState(false);
  const { toast } = useToast();

  const { data: streams, isLoading } = useQuery<Stream[]>({
    queryKey: ["/api/streams"],
  });

  const { data: rawCategories = [] } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });
  
  // Normalize categories - API returns name/type but we need categoryName/categoryType
  const categories = rawCategories.map(c => ({
    ...c,
    categoryName: c.name || c.categoryName,
    categoryType: c.type || c.categoryType,
  }));

  const { data: servers = [] } = useQuery<StreamingServer[]>({
    queryKey: ["/api/servers"],
  });

  interface Bouquet {
    id: number;
    bouquetName: string;
  }

  const { data: bouquets = [] } = useQuery<Bouquet[]>({
    queryKey: ["/api/bouquets"],
  });

  const importMutation = useMutation({
    mutationFn: async ({ file, bouquetId }: { file: File; bouquetId: string }) => {
      const text = await file.text();
      return apiRequest("POST", "/api/streams/import", { 
        m3uContent: text, 
        bouquetId: bouquetId ? Number(bouquetId) : null 
      });
    },
    onSuccess: async (response) => {
      const data = await response.json();
      queryClient.invalidateQueries({ queryKey: ["/api/streams"] });
      queryClient.invalidateQueries({ queryKey: ["/api/bouquets"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({ 
        title: "Import Complete", 
        description: `Imported ${data.imported} streams${data.failed > 0 ? `, ${data.failed} failed` : ""}` 
      });
      setImportDialogOpen(false);
      setImportFile(null);
      setImportBouquetId("");
    },
    onError: (error: Error) => {
      toast({ title: "Import failed", description: error.message, variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest("DELETE", `/api/streams/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/streams"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({ title: "Stream deleted" });
      setDeleteDialogOpen(false);
      setStreamToDelete(null);
    },
  });

  const handleDeleteClick = (stream: Stream) => {
    setStreamToDelete(stream);
    setDeleteDialogOpen(true);
  };

  const confirmDelete = () => {
    if (streamToDelete) {
      deleteMutation.mutate(streamToDelete.id);
    }
  };

  const bulkDeleteMutation = useMutation({
    mutationFn: async (ids: number[]) => {
      return apiRequest("POST", "/api/streams/bulk/delete", { ids });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/streams"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({ title: "Streams deleted", description: `${selectedIds.size} streams have been deleted` });
      setSelectedIds(new Set());
      setBulkDeleteDialogOpen(false);
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to delete streams", variant: "destructive" });
    },
  });

  const confirmBulkDelete = () => {
    bulkDeleteMutation.mutate(Array.from(selectedIds));
  };

  const toggleMutation = useMutation({
    mutationFn: async ({ id, isActive }: { id: number; isActive: boolean }) => {
      return apiRequest("PATCH", `/api/streams/${id}`, { isActive });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/streams"] });
    },
  });

  const startMutation = useMutation({
    mutationFn: async (id: number) => apiRequest("POST", `/api/streams/${id}/start`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/streams"] });
      toast({ title: "Stream started" });
    },
  });

  const stopMutation = useMutation({
    mutationFn: async (id: number) => apiRequest("POST", `/api/streams/${id}/stop`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/streams"] });
      toast({ title: "Stream stopped" });
    },
  });

  const reloadMutation = useMutation({
    mutationFn: async (id: number) => apiRequest("POST", `/api/streams/${id}/reload`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/streams"] });
      toast({ title: "Stream reload triggered" });
    },
  });

  const healthCheckMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await apiRequest("POST", `/api/streams/${id}/health-check`);
      return res.json();
    },
    onSuccess: (data: any) => {
      queryClient.invalidateQueries({ queryKey: ["/api/streams"] });
      if (data.isOnline) {
        toast({ title: "Stream is online", description: `${data.resolution || ""} ${data.videoCodec || ""}` });
      } else {
        toast({ title: "Stream is offline", description: data.error, variant: "destructive" });
      }
    },
  });

  const healthCheckAllMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/streams/health-check-all");
      return res.json();
    },
    onSuccess: (data: any) => {
      queryClient.invalidateQueries({ queryKey: ["/api/streams"] });
      toast({ 
        title: "Health check complete", 
        description: `${data.online} online, ${data.offline} offline of ${data.total} streams` 
      });
    },
  });

  const massEditMutation = useMutation({
    mutationFn: async (data: { ids: number[]; updates: Record<string, any> }) => {
      return apiRequest("POST", "/api/streams/mass-update", data);
    },
    onSuccess: async (response) => {
      const data = await response.json();
      queryClient.invalidateQueries({ queryKey: ["/api/streams"] });
      setSelectedIds(new Set());
      setMassEditOpen(false);
      toast({ 
        title: "Mass update complete", 
        description: `Updated ${data.updated} streams` 
      });
    },
    onError: () => {
      toast({ title: "Mass update failed", variant: "destructive" });
    },
  });

  // Selection helpers
  const toggleSelect = (id: number) => {
    setSelectedIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  const selectAll = () => {
    if (filteredStreams) {
      setSelectedIds(new Set(filteredStreams.map(s => s.id)));
    }
  };

  const deselectAll = () => {
    setSelectedIds(new Set());
  };

  const playStream = (stream: Stream) => {
    setPlayingStream(stream);
    setPlayerOpen(true);
  };
  
  const playStreamExternal = async (id: number) => {
    try {
      const token = localStorage.getItem("neoserv_auth_token");
      const res = await fetch(`/api/streams/${id}/play`, { 
        headers: { "Authorization": `Bearer ${token}` }
      });
      const data = await res.json();
      if (data.playbackUrl) {
        window.open(data.playbackUrl, "_blank");
      }
    } catch (e) {
      toast({ title: "Failed to get stream URL", variant: "destructive" });
    }
  };

  const copyPlaybackUrl = async (id: number) => {
    try {
      const token = localStorage.getItem("neoserv_auth_token");
      const res = await fetch(`/api/streams/${id}/play`, { 
        headers: { "Authorization": `Bearer ${token}` }
      });
      const data = await res.json();
      if (data.playbackUrl) {
        navigator.clipboard.writeText(data.playbackUrl);
        toast({ title: "Playback URL copied" });
      }
    } catch (e) {
      toast({ title: "Failed to get playback URL", variant: "destructive" });
    }
  };

  const filteredStreams = streams?.filter(stream => {
    // Search filter
    if (search && !stream.name.toLowerCase().includes(search.toLowerCase())) return false;
    // Status filter
    if (statusFilter !== "all") {
      if (statusFilter === "online" && stream.status !== "online") return false;
      if (statusFilter === "offline" && stream.status !== "offline") return false;
      if (statusFilter === "error" && stream.status !== "error") return false;
      if (statusFilter === "stopped" && stream.isActive !== false) return false;
    }
    // Category filter
    if (categoryFilter !== "all" && stream.categoryId !== Number(categoryFilter)) return false;
    return true;
  })?.sort((a, b) => a.id - b.id);

  const allSelected = filteredStreams && filteredStreams.length > 0 && 
    filteredStreams.every(s => selectedIds.has(s.id));

  const activeCount = streams?.filter(s => s.status === "online").length || 0;
  const inactiveCount = (streams?.length || 0) - activeCount;

  const formatDuration = (seconds: number) => {
    if (seconds < 60) return `${seconds}s`;
    if (seconds < 3600) return `${Math.floor(seconds / 60)}m`;
    if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ${Math.floor((seconds % 3600) / 60)}m`;
    return `${Math.floor(seconds / 86400)}d ${Math.floor((seconds % 86400) / 3600)}h`;
  };
  
  const statusColors: Record<string, string> = {
    online: "text-emerald-500",
    offline: "text-red-500",
    restarting: "text-amber-500",
    error: "text-red-600",
    backup: "text-orange-500"
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-3xl font-bold tracking-tight" data-testid="page-title">Live TV Streams</h1>
          <p className="text-muted-foreground">Manage live television channels</p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <Button 
            variant="outline" 
            onClick={() => healthCheckAllMutation.mutate()}
            disabled={healthCheckAllMutation.isPending}
            data-testid="button-health-check-all"
          >
            {healthCheckAllMutation.isPending ? (
              <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
            ) : (
              <Activity className="h-4 w-4 mr-2" />
            )}
            Check All Health
          </Button>
          <Button variant="outline" onClick={() => setImportDialogOpen(true)} data-testid="button-import-playlist">
            <Plus className="h-4 w-4 mr-2" />
            Import Playlist
          </Button>
          <Button onClick={() => { setEditingStream(undefined); setDialogOpen(true); }} data-testid="button-add-stream">
            <Plus className="h-4 w-4 mr-2" />
            Add Stream
          </Button>
        </div>
      </div>

      <div className="grid gap-4 grid-cols-1 sm:grid-cols-3">
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 rounded-lg bg-primary/10">
              <Tv className="h-5 w-5 text-primary" />
            </div>
            <div>
              <p className="text-2xl font-bold">{streams?.length || 0}</p>
              <p className="text-sm text-muted-foreground">Total Streams</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 rounded-lg bg-emerald-500/10">
              <Play className="h-5 w-5 text-emerald-500" />
            </div>
            <div>
              <p className="text-2xl font-bold">{activeCount}</p>
              <p className="text-sm text-muted-foreground">Active</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 rounded-lg bg-amber-500/10">
              <Pause className="h-5 w-5 text-amber-500" />
            </div>
            <div>
              <p className="text-2xl font-bold">{inactiveCount}</p>
              <p className="text-sm text-muted-foreground">Inactive</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="flex flex-col gap-4 pb-4">
          <div className="flex flex-row items-center justify-between gap-4 flex-wrap">
            <div className="flex items-center gap-3 flex-wrap">
              <CardTitle>All Streams</CardTitle>
              {selectedIds.size > 0 && (
                <Badge variant="secondary">
                  {selectedIds.size} selected
                </Badge>
              )}
            </div>
            <div className="flex items-center gap-3 flex-wrap">
              {selectedIds.size > 0 && (
                <>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={deselectAll}
                    data-testid="button-deselect-all"
                  >
                    <X className="h-4 w-4 mr-1" />
                    Clear
                  </Button>
                  <Button 
                    variant="default" 
                    size="sm"
                    onClick={() => setMassEditOpen(true)}
                    data-testid="button-mass-edit"
                  >
                    <Pencil className="h-4 w-4 mr-1" />
                    Mass Edit ({selectedIds.size})
                  </Button>
                  <Button 
                    variant="destructive" 
                    size="sm"
                    onClick={() => setBulkDeleteDialogOpen(true)}
                    data-testid="button-bulk-delete"
                  >
                    <Trash2 className="h-4 w-4 mr-1" />
                    Delete ({selectedIds.size})
                  </Button>
                </>
              )}
              {filteredStreams && filteredStreams.length > 0 && selectedIds.size === 0 && (
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={selectAll}
                  data-testid="button-select-all"
                >
                  <CheckSquare className="h-4 w-4 mr-1" />
                  Select All ({filteredStreams.length})
                </Button>
              )}
              <div className="relative w-48">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search streams..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="pl-9"
                  data-testid="input-search-streams"
                />
              </div>
              <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                <SelectTrigger className="w-40" data-testid="select-category-filter">
                  <SelectValue placeholder="All Categories" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  {categories.filter(c => c.categoryType === "live").map(cat => (
                    <SelectItem key={cat.id} value={String(cat.id)}>{cat.categoryName}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-32" data-testid="select-status-filter">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="online">Online</SelectItem>
                  <SelectItem value="offline">Offline</SelectItem>
                  <SelectItem value="error">Error</SelectItem>
                  <SelectItem value="stopped">Stopped</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-2">
              {Array(5).fill(0).map((_, i) => (
                <Skeleton key={i} className="h-12 w-full" />
              ))}
            </div>
          ) : filteredStreams && filteredStreams.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-10">
                    <Checkbox 
                      checked={allSelected}
                      onCheckedChange={(checked) => checked ? selectAll() : deselectAll()}
                      data-testid="checkbox-select-all"
                    />
                  </TableHead>
                  <TableHead className="w-16">ID</TableHead>
                  <TableHead>Channel</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Connections</TableHead>
                  <TableHead>Server</TableHead>
                  <TableHead>Stream Info</TableHead>
                  <TableHead>Bitrate</TableHead>
                  <TableHead>Uptime</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredStreams.map((stream) => {
                  const streamInfo = stream.streamInfo || { resolution: "", videoCodec: "", audioCodec: "", fps: "", playbackSpeed: "" };
                  // Build info display only from non-empty values
                  const infoParts = [];
                  if (streamInfo.resolution && !streamInfo.resolution.includes("undefined")) infoParts.push(streamInfo.resolution);
                  if (streamInfo.videoCodec) infoParts.push(streamInfo.videoCodec);
                  if (streamInfo.audioCodec) infoParts.push(streamInfo.audioCodec);
                  if (streamInfo.fps) infoParts.push(`${streamInfo.fps} FPS`);
                  const infoDisplay = infoParts.length > 0 ? infoParts.join(" ") : "-";
                  
                  return (
                  <TableRow key={stream.id} data-testid={`stream-row-${stream.id}`}>
                    <TableCell>
                      <Checkbox 
                        checked={selectedIds.has(stream.id)}
                        onCheckedChange={() => toggleSelect(stream.id)}
                        data-testid={`checkbox-stream-${stream.id}`}
                      />
                    </TableCell>
                    <TableCell className="font-mono font-bold">{stream.id}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-3">
                        {stream.logoUrl ? (
                          <img 
                            src={stream.logoUrl} 
                            alt={stream.name}
                            className="h-8 w-8 rounded object-cover bg-muted"
                          />
                        ) : (
                          <div className="h-8 w-8 rounded bg-muted flex items-center justify-center">
                            <Tv className="h-4 w-4 text-muted-foreground" />
                          </div>
                        )}
                        <span className="font-medium">{stream.name}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-col gap-1">
                        <div className="flex items-center gap-2">
                          <Circle className={`h-3 w-3 fill-current ${stream.usingBackup ? statusColors.backup : statusColors[stream.status]}`} />
                          <span className="text-sm capitalize">{stream.status}</span>
                        </div>
                        {stream.usingBackup && (
                          <Badge variant="outline" className="text-xs text-orange-600 border-orange-300 dark:text-orange-400 dark:border-orange-700">
                            Backup #{stream.activeSourceIndex}
                          </Badge>
                        )}
                        {stream.hasBackupSources && !stream.usingBackup && stream.status === "online" && (
                          <span className="text-xs text-muted-foreground">Has backups</span>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Users className="h-4 w-4 text-muted-foreground" />
                        <span className="text-sm font-medium">{stream.connectionCount || 0}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Server className="h-4 w-4 text-muted-foreground" />
                        <span className="text-sm">{stream.serverName || "-"}</span>
                      </div>
                    </TableCell>
                    <TableCell className="font-mono text-xs text-muted-foreground">
                      {infoDisplay}
                    </TableCell>
                    <TableCell>
                      <span className="font-mono text-sm">
                        {stream.bitrate ? `${stream.bitrate} Kbps` : "-"}
                      </span>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <Clock className="h-4 w-4 text-muted-foreground" />
                        <span className="text-sm">
                          {stream.status === "online" 
                            ? formatDuration(stream.uptimeSeconds) 
                            : stream.downtimeSeconds > 0 
                              ? `Down ${formatDuration(stream.downtimeSeconds)}`
                              : "-"
                          }
                        </span>
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" data-testid={`button-stream-menu-${stream.id}`}>
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => playStream(stream)}>
                            <Play className="h-4 w-4 mr-2" />
                            Play
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => startMutation.mutate(stream.id)}>
                            <Play className="h-4 w-4 mr-2" />
                            Start
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => stopMutation.mutate(stream.id)}>
                            <Square className="h-4 w-4 mr-2" />
                            Stop
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => reloadMutation.mutate(stream.id)}>
                            <RotateCw className="h-4 w-4 mr-2" />
                            Reload
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => healthCheckMutation.mutate(stream.id)}>
                            <Activity className="h-4 w-4 mr-2" />
                            Check Health
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => copyPlaybackUrl(stream.id)}>
                            <Copy className="h-4 w-4 mr-2" />
                            Copy Playback URL
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => playStreamExternal(stream.id)}>
                            <ExternalLink className="h-4 w-4 mr-2" />
                            Open External
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => { setEditingStream(stream); setDialogOpen(true); }}>
                            <Edit className="h-4 w-4 mr-2" />
                            Edit
                          </DropdownMenuItem>
                          <DropdownMenuItem 
                            onClick={() => handleDeleteClick(stream)}
                            className="text-destructive"
                          >
                            <Trash2 className="h-4 w-4 mr-2" />
                            Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          ) : (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <Tv className="h-12 w-12 text-muted-foreground/50 mb-4" />
              <p className="text-muted-foreground">No streams found</p>
              <Button 
                variant="outline" 
                size="sm" 
                className="mt-4"
                onClick={() => { setEditingStream(undefined); setDialogOpen(true); }}
              >
                Add your first stream
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      <StreamFormDialog 
        stream={editingStream} 
        categories={categories}
        servers={servers}
        open={dialogOpen} 
        onOpenChange={setDialogOpen} 
      />

      <DeleteConfirmation
        open={deleteDialogOpen}
        onOpenChange={setDeleteDialogOpen}
        onConfirm={confirmDelete}
        title="Delete Stream"
        itemName={streamToDelete?.name}
      />

      <DeleteConfirmation
        open={bulkDeleteDialogOpen}
        onOpenChange={setBulkDeleteDialogOpen}
        onConfirm={confirmBulkDelete}
        title="Delete Streams"
        itemName={`${selectedIds.size} streams`}
      />

      <Dialog open={importDialogOpen} onOpenChange={setImportDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Import Playlist</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">M3U Playlist File</label>
              <Input
                type="file"
                accept=".m3u,.m3u8"
                onChange={(e) => setImportFile(e.target.files?.[0] || null)}
                data-testid="input-import-file"
              />
              <p className="text-xs text-muted-foreground">
                Upload an M3U or M3U8 playlist file
              </p>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Add to Bouquet (Optional)</label>
              <Select value={importBouquetId} onValueChange={setImportBouquetId}>
                <SelectTrigger data-testid="select-import-bouquet">
                  <SelectValue placeholder="Select bouquet..." />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">No Bouquet</SelectItem>
                  {bouquets.map((b) => (
                    <SelectItem key={b.id} value={String(b.id)}>
                      {b.bouquetName}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground">
                Optionally add all imported streams to a bouquet
              </p>
            </div>
          </div>
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setImportDialogOpen(false)}>
              Cancel
            </Button>
            <Button 
              onClick={() => {
                if (importFile) {
                  importMutation.mutate({ file: importFile, bouquetId: importBouquetId === "none" ? "" : importBouquetId });
                }
              }}
              disabled={!importFile || importMutation.isPending}
              data-testid="button-confirm-import"
            >
              {importMutation.isPending ? "Importing..." : "Import"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
      
      <StreamPlayerDialog
        stream={playingStream}
        open={playerOpen}
        onOpenChange={setPlayerOpen}
      />

      {/* Mass Edit Dialog */}
      <MassEditDialog
        open={massEditOpen}
        onOpenChange={setMassEditOpen}
        selectedCount={selectedIds.size}
        servers={servers}
        bouquets={bouquets}
        onSubmit={(updates) => {
          massEditMutation.mutate({ ids: Array.from(selectedIds), updates });
        }}
        isPending={massEditMutation.isPending}
      />
    </div>
  );
}

// Mass Edit Dialog Component
function MassEditDialog({
  open,
  onOpenChange,
  selectedCount,
  servers,
  bouquets,
  onSubmit,
  isPending,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  selectedCount: number;
  servers: StreamingServer[];
  bouquets: { id: number; bouquetName: string }[];
  onSubmit: (updates: Record<string, any>) => void;
  isPending: boolean;
}) {
  const [serverId, setServerId] = useState<string>("");
  const [userAgent, setUserAgent] = useState<string>("");
  const [bouquetId, setBouquetId] = useState<string>("");
  const [isActive, setIsActive] = useState<string>("");

  // Reset form when dialog opens
  useEffect(() => {
    if (open) {
      setServerId("");
      setUserAgent("");
      setBouquetId("");
      setIsActive("");
    }
  }, [open]);

  const handleSubmit = () => {
    const updates: Record<string, any> = {};
    
    if (serverId && serverId !== "no-change") {
      updates.forceServerId = serverId === "auto" ? null : Number(serverId);
    }
    if (userAgent) {
      updates.userAgent = userAgent;
    }
    if (bouquetId && bouquetId !== "no-change") {
      updates.bouquetId = bouquetId === "none" ? null : Number(bouquetId);
    }
    if (isActive && isActive !== "no-change") {
      updates.isActive = isActive === "true";
    }
    
    if (Object.keys(updates).length === 0) {
      return;
    }
    
    onSubmit(updates);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Mass Edit {selectedCount} Streams</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <p className="text-sm text-muted-foreground">
            Only fields you modify will be updated. Leave fields unchanged to keep current values.
          </p>
          
          <div className="space-y-2">
            <label className="text-sm font-medium">Server</label>
            <Select value={serverId} onValueChange={setServerId}>
              <SelectTrigger data-testid="mass-edit-server">
                <SelectValue placeholder="No change" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="no-change">No change</SelectItem>
                <SelectItem value="auto">Auto (Load Balancer)</SelectItem>
                {servers.map((s) => (
                  <SelectItem key={s.id} value={String(s.id)}>{s.serverName}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">User Agent</label>
            <Input
              placeholder="Leave empty for no change"
              value={userAgent}
              onChange={(e) => setUserAgent(e.target.value)}
              data-testid="mass-edit-useragent"
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Add to Bouquet</label>
            <Select value={bouquetId} onValueChange={setBouquetId}>
              <SelectTrigger data-testid="mass-edit-bouquet">
                <SelectValue placeholder="No change" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="no-change">No change</SelectItem>
                <SelectItem value="none">Remove from bouquet</SelectItem>
                {bouquets.map((b) => (
                  <SelectItem key={b.id} value={String(b.id)}>{b.bouquetName}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Status</label>
            <Select value={isActive} onValueChange={setIsActive}>
              <SelectTrigger data-testid="mass-edit-status">
                <SelectValue placeholder="No change" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="no-change">No change</SelectItem>
                <SelectItem value="true">Enable</SelectItem>
                <SelectItem value="false">Disable</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        
        <div className="flex justify-end gap-2">
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button 
            onClick={handleSubmit}
            disabled={isPending || (!serverId && !userAgent && !bouquetId && !isActive)}
            data-testid="button-confirm-mass-edit"
          >
            {isPending ? "Updating..." : `Update ${selectedCount} Streams`}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
