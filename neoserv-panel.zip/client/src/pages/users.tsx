import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
  FormDescription,
} from "@/components/ui/form";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Plus,
  Search,
  MoreHorizontal,
  Edit,
  Trash2,
  Users as UsersIcon,
  UserCheck,
  UserX,
  Clock,
  Copy,
  Download,
  Wand2,
  Ban,
  CheckCircle,
  CalendarPlus,
  RefreshCw,
  ChevronUp,
  ChevronDown,
  X,
} from "lucide-react";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { DeleteConfirmation } from "@/components/delete-confirmation";
import { useAuth } from "@/App";

interface Setting {
  id: number;
  type: string;
  value: string;
}

interface User {
  id: number;
  username: string;
  password: string;
  email: string | null;
  maxConnections: number;
  isAdmin: boolean;
  isReseller: boolean;
  isTrial: boolean;
  status: string;
  expirationDate: string | null;
  createdAt: string | null;
  notes: string | null;
  bouquetIds: number[];
  ownerId: number | null;
  allowedIps: string[];
  isMag: boolean;
  onlineConnections: number;
}

interface GeneratedLine {
  id: number;
  username: string;
  password: string;
  bouquet: string;
  expirationDate?: string;
}

// Fallback duration options (used when API not available)
const FALLBACK_DURATION_OPTIONS = [
  { label: "1 Month", days: 30, multiplier: 1 },
  { label: "3 Months", days: 90, multiplier: 3 },
  { label: "6 Months", days: 180, multiplier: 6 },
  { label: "1 Year", days: 365, multiplier: 12 },
];

const TEST_DURATION_OPTIONS = [
  { value: "24", label: "24 Hours", hours: 24 },
  { value: "48", label: "48 Hours", hours: 48 },
  { value: "72", label: "72 Hours", hours: 72 },
];

const userFormSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  email: z.string().email("Invalid email").optional().or(z.literal("")),
  maxConnections: z.coerce.number().min(1).max(10000),
  status: z.enum(["active", "expired", "banned"]),
  expirationDate: z.string().optional(),
  notes: z.string().optional(),
  duration: z.coerce.number().default(30),
  isTrial: z.boolean().default(false),
  testDuration: z.string().default("24"),
});

type UserFormData = z.infer<typeof userFormSchema>;

const generateLineSchema = z.object({
  expirationDays: z.coerce.number().min(1).max(365).default(30),
  maxConnections: z.coerce.number().min(1).max(10000).default(1),
  isTrial: z.boolean().default(false),
  bouquetIds: z.array(z.number()).default([]),
});

type GenerateLineData = z.infer<typeof generateLineSchema>;

interface Bouquet {
  id: number;
  bouquetName: string;
  bouquetOrder: number;
  isActive: boolean;
}

function UserFormDialog({ 
  user, 
  open, 
  onOpenChange 
}: { 
  user?: User; 
  open: boolean; 
  onOpenChange: (open: boolean) => void;
}) {
  const { toast } = useToast();
  const { user: authUser } = useAuth();
  const isReseller = authUser?.role === "reseller";
  const isEditing = !!user;
  const [selectedBouquets, setSelectedBouquets] = useState<number[]>(user?.bouquetIds || []);

  // Fetch bouquets for selection
  const { data: bouquets } = useQuery<Bouquet[]>({
    queryKey: ["/api/bouquets"],
  });
  
  // Fetch settings for credit pricing (resellers only) - always get fresh data
  const { data: settings } = useQuery<Setting[]>({
    queryKey: ["/api/settings"],
    enabled: isReseller && !isEditing,
    staleTime: 0,
    refetchOnMount: "always",
  });
  
  // Fetch duration options from admin settings - always get fresh data
  const { data: durationOptions } = useQuery<DurationOption[]>({
    queryKey: ["/api/settings/duration-options"],
    enabled: isReseller && !isEditing,
    staleTime: 0,
    refetchOnMount: "always",
  });
  
  // Use API duration options or fallback
  const activeDurationOptions = durationOptions?.length ? durationOptions : FALLBACK_DURATION_OPTIONS;
  
  const parsedBase = parseFloat(settings?.find(s => s.type === "credit_price_per_line")?.value || "1");
  const parsedPerConn = parseFloat(settings?.find(s => s.type === "credit_price_per_connection")?.value || "0");
  const basePricePerLine = Number.isFinite(parsedBase) ? parsedBase : 1;
  const pricePerConnection = Number.isFinite(parsedPerConn) ? parsedPerConn : 0;
  
  // Sort bouquets by order
  const sortedBouquets = bouquets?.filter(b => b.isActive).sort((a, b) => a.bouquetOrder - b.bouquetOrder) || [];

  const form = useForm<UserFormData>({
    resolver: zodResolver(userFormSchema),
    defaultValues: {
      username: user?.username || "",
      password: "",
      email: user?.email || "",
      maxConnections: user?.maxConnections || 1,
      status: (user?.status as "active" | "expired" | "banned") || "active",
      expirationDate: user?.expirationDate || "",
      notes: user?.notes || "",
      duration: 30,
      isTrial: user?.isTrial || false,
      testDuration: "24",
    },
  });

  // Watch form values for dynamic calculations
  const watchedDuration = form.watch("duration");
  const watchedIsTrial = form.watch("isTrial");
  const watchedTestDuration = form.watch("testDuration");
  const watchedMaxConnections = form.watch("maxConnections");
  
  // Calculate credit cost with multiplier from API settings
  const selectedDurationOption = activeDurationOptions.find(d => d.days === watchedDuration);
  const durationMultiplier = selectedDurationOption?.multiplier || 1;
  const connectionCost = basePricePerLine + (Math.max(0, (parseInt(String(watchedMaxConnections)) || 1) - 1) * pricePerConnection);
  const totalCreditCost = connectionCost * durationMultiplier;

  // Reset form when user changes or dialog opens
  useEffect(() => {
    if (open) {
      form.reset({
        username: user?.username || "",
        password: "",
        email: user?.email || "",
        maxConnections: user?.maxConnections || 1,
        status: (user?.status as "active" | "expired" | "banned") || "active",
        expirationDate: user?.expirationDate || "",
        notes: user?.notes || "",
        duration: 30,
        isTrial: user?.isTrial || false,
        testDuration: "24",
      });
      setSelectedBouquets(user?.bouquetIds || []);
    }
  }, [open, user]);

  const toggleBouquet = (bouquetId: number) => {
    setSelectedBouquets(prev => 
      prev.includes(bouquetId) 
        ? prev.filter(id => id !== bouquetId)
        : [...prev, bouquetId]
    );
  };
  
  const moveBouquetUp = (index: number) => {
    if (index === 0) return;
    setSelectedBouquets(prev => {
      const newArr = [...prev];
      [newArr[index - 1], newArr[index]] = [newArr[index], newArr[index - 1]];
      return newArr;
    });
  };
  
  const moveBouquetDown = (index: number) => {
    if (index === selectedBouquets.length - 1) return;
    setSelectedBouquets(prev => {
      const newArr = [...prev];
      [newArr[index], newArr[index + 1]] = [newArr[index + 1], newArr[index]];
      return newArr;
    });
  };

  const mutation = useMutation({
    mutationFn: async (data: UserFormData) => {
      // Calculate expiry date based on duration selection for resellers
      let calculatedExpiry = data.expirationDate;
      if (!isEditing && isReseller) {
        const now = new Date();
        if (data.isTrial) {
          const testHours = TEST_DURATION_OPTIONS.find(t => t.value === data.testDuration)?.hours || 24;
          now.setHours(now.getHours() + testHours);
        } else {
          // Use days from duration option
          const days = data.duration || 30;
          now.setDate(now.getDate() + days);
        }
        calculatedExpiry = now.toISOString().split("T")[0];
      }
      
      const payload = { 
        ...data, 
        bouquetIds: selectedBouquets,
        expirationDate: calculatedExpiry,
        isTrial: data.isTrial,
      };
      if (isEditing) {
        return apiRequest("PATCH", `/api/users/${user.id}`, payload);
      }
      return apiRequest("POST", "/api/users", payload);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({
        title: isEditing ? "User updated" : "User created",
        description: `Successfully ${isEditing ? "updated" : "created"} user`,
      });
      onOpenChange(false);
      setSelectedBouquets([]);
      form.reset();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to save user",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: UserFormData) => {
    mutation.mutate(data);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{isEditing ? "Edit User" : "Add New User"}</DialogTitle>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="username"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Username</FormLabel>
                  <FormControl>
                    <Input placeholder="username" {...field} data-testid="input-username" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="password"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{isEditing ? "New Password (leave blank to keep)" : "Password"}</FormLabel>
                  <FormControl>
                    <Input type="password" placeholder="********" {...field} data-testid="input-password" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Email (optional)</FormLabel>
                  <FormControl>
                    <Input type="email" placeholder="user@example.com" {...field} data-testid="input-email" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="maxConnections"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Max Connections</FormLabel>
                    <FormControl>
                      <Input type="number" min={1} max={10000} {...field} data-testid="input-max-connections" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="status"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Status</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value || "active"}>
                      <FormControl>
                        <SelectTrigger data-testid="select-status">
                          <SelectValue placeholder="Select status" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="active">Active</SelectItem>
                        <SelectItem value="expired">Expired</SelectItem>
                        <SelectItem value="banned">Banned</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            {isReseller && !isEditing ? (
              <>
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="isTrial"
                    render={({ field }) => (
                      <FormItem className="flex items-center justify-between rounded-lg border p-3">
                        <div className="space-y-0.5">
                          <FormLabel>Trial Account</FormLabel>
                          <FormDescription>Free test account</FormDescription>
                        </div>
                        <FormControl>
                          <Switch
                            checked={field.value}
                            onCheckedChange={field.onChange}
                            data-testid="switch-trial"
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                  
                  {watchedIsTrial ? (
                    <FormField
                      control={form.control}
                      name="testDuration"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Test Duration</FormLabel>
                          <Select onValueChange={field.onChange} value={field.value}>
                            <FormControl>
                              <SelectTrigger data-testid="select-test-duration">
                                <SelectValue placeholder="Select duration" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {TEST_DURATION_OPTIONS.map((opt) => (
                                <SelectItem key={opt.value} value={opt.value}>
                                  {opt.label}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  ) : (
                    <FormField
                      control={form.control}
                      name="duration"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Duration</FormLabel>
                          <Select 
                            onValueChange={(value) => field.onChange(parseInt(value))} 
                            value={field.value?.toString()}
                          >
                            <FormControl>
                              <SelectTrigger data-testid="select-duration">
                                <SelectValue placeholder="Select duration" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {activeDurationOptions.map((opt) => (
                                <SelectItem key={opt.days} value={opt.days.toString()}>
                                  {opt.label} ({opt.days} days)
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  )}
                </div>
              </>
            ) : (
              <FormField
                control={form.control}
                name="expirationDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Expiration Date</FormLabel>
                    <FormControl>
                      <Input type="date" {...field} data-testid="input-expiration" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            )}
            
            {/* Bouquet Selection */}
            <div className="space-y-2">
              <label className="text-sm font-medium">Bouquets (Live, Movies, Series)</label>
              <div className="border rounded-md max-h-32 overflow-y-auto">
                {sortedBouquets.length === 0 ? (
                  <div className="p-3 text-sm text-muted-foreground text-center">
                    No bouquets available
                  </div>
                ) : (
                  sortedBouquets.map((bouquet) => (
                    <div 
                      key={bouquet.id}
                      className="flex items-center gap-2 p-2 hover-elevate border-b last:border-b-0"
                    >
                      <Checkbox 
                        checked={selectedBouquets.includes(bouquet.id)}
                        onCheckedChange={() => toggleBouquet(bouquet.id)}
                        data-testid={`checkbox-user-bouquet-${bouquet.id}`}
                      />
                      <span className="flex-1 text-sm">{bouquet.bouquetName}</span>
                      <Badge variant="outline" className="text-xs">#{bouquet.bouquetOrder}</Badge>
                    </div>
                  ))
                )}
              </div>
              {selectedBouquets.length > 0 && (
                <div className="space-y-1">
                  <p className="text-xs text-muted-foreground">Selected ({selectedBouquets.length}):</p>
                  <div className="flex flex-wrap gap-1">
                    {selectedBouquets.map((id) => {
                      const b = sortedBouquets.find(bq => bq.id === id);
                      return (
                        <Badge key={id} variant="secondary" className="gap-1">
                          {b?.bouquetName}
                          <X 
                            className="h-3 w-3 cursor-pointer" 
                            onClick={() => toggleBouquet(id)}
                          />
                        </Badge>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
            
            {isReseller && !isEditing && (
              <div className="p-3 rounded-lg bg-orange-500/10 border border-orange-500/30">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">
                    {watchedIsTrial ? "Test (Free)" : `Cost (${selectedDurationOption?.label || "1 Month"}):`}
                  </span>
                  <span className="font-semibold text-lg text-orange-500">
                    {watchedIsTrial ? "€0.00" : `€${totalCreditCost.toFixed(2)}`}
                  </span>
                </div>
                {!watchedIsTrial && (
                  <div className="text-xs text-muted-foreground mt-1 space-y-0.5">
                    <p>Base: €{basePricePerLine.toFixed(2)}</p>
                    {(parseInt(String(watchedMaxConnections)) || 1) > 1 && pricePerConnection > 0 && (
                      <p>+ {Math.max(0, (parseInt(String(watchedMaxConnections)) || 1) - 1)} extra conn. x €{pricePerConnection.toFixed(2)} = €{((Math.max(0, (parseInt(String(watchedMaxConnections)) || 1) - 1)) * pricePerConnection).toFixed(2)}</p>
                    )}
                    <p>x {selectedDurationOption?.label || "1 Month"} = €{totalCreditCost.toFixed(2)}</p>
                  </div>
                )}
                {watchedIsTrial && (
                  <p className="text-xs text-muted-foreground mt-1">
                    Test accounts are free ({TEST_DURATION_OPTIONS.find(t => t.value === watchedTestDuration)?.label || "24 Hours"})
                  </p>
                )}
              </div>
            )}
            
            <div className="flex justify-end gap-2 pt-4">
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
                Cancel
              </Button>
              <Button type="submit" disabled={mutation.isPending} data-testid="button-save-user">
                {mutation.isPending ? "Saving..." : isEditing ? "Update" : "Create"}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}

interface DurationOption {
  label: string;
  days: number;
  multiplier: number;
}

interface PricingSettings {
  basePricePerLine: number;
  pricePerConnection: number;
}

function GenerateLineDialog({
  open,
  onOpenChange
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const { toast } = useToast();
  const [generatedLine, setGeneratedLine] = useState<GeneratedLine | null>(null);
  const [selectedBouquets, setSelectedBouquets] = useState<number[]>([]);

  // Fetch duration options - always get fresh data
  const { data: durationOptions } = useQuery<DurationOption[]>({
    queryKey: ["/api/settings/duration-options"],
    staleTime: 0,
    refetchOnMount: "always",
  });
  
  // Fetch pricing settings - always get fresh data (admin may have changed)
  const { data: settings } = useQuery<Array<{type: string; value: string}>>({
    queryKey: ["/api/settings"],
    staleTime: 0,
    refetchOnMount: "always",
  });
  
  // Fetch bouquets for selection
  const { data: bouquets } = useQuery<Bouquet[]>({
    queryKey: ["/api/bouquets"],
  });
  
  // Sort bouquets by order
  const sortedBouquets = bouquets?.filter(b => b.isActive).sort((a, b) => a.bouquetOrder - b.bouquetOrder) || [];
  
  const pricingSettings: PricingSettings = {
    basePricePerLine: settings?.find(s => s.type === "credit_price_per_line")?.value 
      ? parseFloat(settings.find(s => s.type === "credit_price_per_line")!.value) : 1,
    pricePerConnection: settings?.find(s => s.type === "credit_price_per_connection")?.value 
      ? parseFloat(settings.find(s => s.type === "credit_price_per_connection")!.value) : 0,
  };

  const form = useForm<GenerateLineData>({
    resolver: zodResolver(generateLineSchema),
    defaultValues: {
      expirationDays: 30,
      maxConnections: 1,
      isTrial: false,
      bouquetIds: [],
    },
  });
  
  // Watch form values for cost calculation
  const watchDays = form.watch("expirationDays");
  const watchConnections = form.watch("maxConnections");
  
  // Calculate cost preview
  const calculateCost = () => {
    const selectedOption = durationOptions?.find(o => o.days === watchDays);
    const multiplier = selectedOption?.multiplier || Math.max(1, watchDays / 30);
    const extraConnections = Math.max(0, (watchConnections || 1) - 1);
    const baseCredits = pricingSettings.basePricePerLine + (extraConnections * pricingSettings.pricePerConnection);
    return (baseCredits * multiplier).toFixed(2);
  };

  const mutation = useMutation({
    mutationFn: async (data: GenerateLineData) => {
      const res = await apiRequest("POST", "/api/users/generate", {
        ...data,
        bouquetIds: selectedBouquets,
      });
      return res.json();
    },
    onSuccess: (line: GeneratedLine) => {
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      queryClient.invalidateQueries({ queryKey: ["/api/reseller/info"] });
      setGeneratedLine(line);
      toast({ title: "Line generated successfully" });
    },
    onError: (error: any) => {
      toast({ 
        title: "Failed to generate line", 
        description: error?.message || "Check your credits balance",
        variant: "destructive" 
      });
    },
  });

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({ title: "Copied to clipboard" });
  };

  const handleClose = () => {
    setGeneratedLine(null);
    setSelectedBouquets([]);
    form.reset();
    onOpenChange(false);
  };
  
  const toggleBouquet = (bouquetId: number) => {
    setSelectedBouquets(prev => 
      prev.includes(bouquetId) 
        ? prev.filter(id => id !== bouquetId)
        : [...prev, bouquetId]
    );
  };
  
  const moveBouquetUp = (index: number) => {
    if (index === 0) return;
    setSelectedBouquets(prev => {
      const newArr = [...prev];
      [newArr[index - 1], newArr[index]] = [newArr[index], newArr[index - 1]];
      return newArr;
    });
  };
  
  const moveBouquetDown = (index: number) => {
    if (index === selectedBouquets.length - 1) return;
    setSelectedBouquets(prev => {
      const newArr = [...prev];
      [newArr[index], newArr[index + 1]] = [newArr[index + 1], newArr[index]];
      return newArr;
    });
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>Generate New Line</DialogTitle>
          <DialogDescription>
            Auto-generate username and password for a new user account
          </DialogDescription>
        </DialogHeader>
        {generatedLine ? (
          <div className="space-y-4">
            <div className="p-4 rounded-lg bg-muted space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">Username:</span>
                <div className="flex items-center gap-2">
                  <code className="font-mono text-sm">{generatedLine.username}</code>
                  <Button size="icon" variant="ghost" onClick={() => copyToClipboard(generatedLine.username)} data-testid="button-copy-username">
                    <Copy className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">Password:</span>
                <div className="flex items-center gap-2">
                  <code className="font-mono text-sm">{generatedLine.password}</code>
                  <Button size="icon" variant="ghost" onClick={() => copyToClipboard(generatedLine.password)} data-testid="button-copy-password">
                    <Copy className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">Expires:</span>
                <span className="text-sm">{generatedLine.expirationDate}</span>
              </div>
            </div>
            <Button className="w-full" onClick={() => copyToClipboard(`Username: ${generatedLine.username}\nPassword: ${generatedLine.password}`)} data-testid="button-copy-all">
              <Copy className="h-4 w-4 mr-2" />
              Copy All Credentials
            </Button>
            <div className="flex gap-2">
              <Button variant="outline" className="flex-1" onClick={() => setGeneratedLine(null)} data-testid="button-generate-another">
                <RefreshCw className="h-4 w-4 mr-2" />
                Generate Another
              </Button>
              <Button variant="outline" className="flex-1" onClick={handleClose}>
                Close
              </Button>
            </div>
          </div>
        ) : (
          <Form {...form}>
            <form onSubmit={form.handleSubmit((data) => mutation.mutate(data))} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="expirationDays"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Duration</FormLabel>
                      <Select 
                        onValueChange={(value) => field.onChange(parseInt(value))} 
                        value={field.value?.toString()}
                      >
                        <FormControl>
                          <SelectTrigger data-testid="select-duration">
                            <SelectValue placeholder="Select duration" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {durationOptions?.map((opt) => (
                            <SelectItem key={opt.days} value={opt.days.toString()}>
                              {opt.label} ({opt.days} days)
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="maxConnections"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Max Connections</FormLabel>
                      <FormControl>
                        <Input type="number" min={1} max={10000} {...field} data-testid="input-gen-connections" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <div className="p-3 rounded-lg bg-orange-500/10 border border-orange-500/30">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Cost:</span>
                  <span className="font-semibold text-lg text-orange-500">{calculateCost()} credits</span>
                </div>
                <div className="text-xs text-muted-foreground mt-1 space-y-0.5">
                  <p>Base: €{pricingSettings.basePricePerLine.toFixed(2)}</p>
                  {(watchConnections || 1) > 1 && pricingSettings.pricePerConnection > 0 && (
                    <p>+ {Math.max(0, (watchConnections || 1) - 1)} extra conn. x €{pricingSettings.pricePerConnection.toFixed(2)} = €{((Math.max(0, (watchConnections || 1) - 1)) * pricingSettings.pricePerConnection).toFixed(2)}</p>
                  )}
                  <p>x {durationOptions?.find(o => o.days === watchDays)?.label || "1 Month"} = €{calculateCost()}</p>
                </div>
              </div>
              
              <FormField
                control={form.control}
                name="isTrial"
                render={({ field }) => (
                  <FormItem className="flex items-center gap-2 space-y-0">
                    <FormControl>
                      <Checkbox checked={field.value} onCheckedChange={field.onChange} data-testid="checkbox-trial" />
                    </FormControl>
                    <FormLabel className="font-normal">Create as trial account</FormLabel>
                  </FormItem>
                )}
              />
              
              {/* Bouquet Selection */}
              <div className="space-y-2">
                <label className="text-sm font-medium">Bouquets (Live, Movies, Series)</label>
                <div className="border rounded-md max-h-40 overflow-y-auto">
                  {sortedBouquets.length === 0 ? (
                    <div className="p-3 text-sm text-muted-foreground text-center">
                      No bouquets available
                    </div>
                  ) : (
                    sortedBouquets.map((bouquet) => (
                      <div 
                        key={bouquet.id}
                        className="flex items-center gap-2 p-2 hover-elevate border-b last:border-b-0"
                      >
                        <Checkbox 
                          checked={selectedBouquets.includes(bouquet.id)}
                          onCheckedChange={() => toggleBouquet(bouquet.id)}
                          data-testid={`checkbox-bouquet-${bouquet.id}`}
                        />
                        <span className="flex-1 text-sm">{bouquet.bouquetName}</span>
                        <Badge variant="outline" className="text-xs">#{bouquet.bouquetOrder}</Badge>
                      </div>
                    ))
                  )}
                </div>
                {selectedBouquets.length > 0 && (
                  <div className="space-y-1">
                    <p className="text-xs text-muted-foreground">Selected ({selectedBouquets.length}):</p>
                    <div className="flex flex-wrap gap-1">
                      {selectedBouquets.map((id) => {
                        const b = sortedBouquets.find(bq => bq.id === id);
                        return (
                          <Badge key={id} variant="secondary" className="gap-1">
                            {b?.bouquetName}
                            <X 
                              className="h-3 w-3 cursor-pointer" 
                              onClick={() => toggleBouquet(id)}
                            />
                          </Badge>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>
              
              <div className="flex justify-end gap-2 pt-4">
                <Button type="button" variant="outline" onClick={handleClose}>
                  Cancel
                </Button>
                <Button type="submit" disabled={mutation.isPending} data-testid="button-generate">
                  {mutation.isPending ? "Generating..." : "Generate Line"}
                </Button>
              </div>
            </form>
          </Form>
        )}
      </DialogContent>
    </Dialog>
  );
}

export default function UsersPage() {
  const [search, setSearch] = useState("");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [generateDialogOpen, setGenerateDialogOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<User | undefined>();
  const [selectedIds, setSelectedIds] = useState<Set<number>>(new Set());
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [userToDelete, setUserToDelete] = useState<User | null>(null);
  const { toast } = useToast();

  const { data: users, isLoading } = useQuery<User[]>({
    queryKey: ["/api/users"],
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest("DELETE", `/api/users/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({ title: "User deleted" });
      setDeleteDialogOpen(false);
      setUserToDelete(null);
    },
  });

  const handleDeleteClick = (user: User) => {
    setUserToDelete(user);
    setDeleteDialogOpen(true);
  };

  const confirmDelete = () => {
    if (userToDelete) {
      deleteMutation.mutate(userToDelete.id);
    }
  };

  const bulkUpdateMutation = useMutation({
    mutationFn: async ({ ids, update }: { ids: number[]; update: Partial<User> }) => {
      return apiRequest("POST", "/api/users/bulk/update", { ids, update });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      setSelectedIds(new Set());
      toast({ title: "Users updated" });
    },
  });

  const bulkDeleteMutation = useMutation({
    mutationFn: async (ids: number[]) => {
      return apiRequest("POST", "/api/users/bulk/delete", { ids });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      setSelectedIds(new Set());
      toast({ title: "Users deleted" });
    },
  });

  const bulkExtendMutation = useMutation({
    mutationFn: async ({ ids, days }: { ids: number[]; days: number }) => {
      return apiRequest("POST", "/api/users/bulk/extend", { ids, days });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      setSelectedIds(new Set());
      toast({ title: "Expiration extended" });
    },
  });

  const banMutation = useMutation({
    mutationFn: async (id: number) => apiRequest("POST", `/api/users/${id}/ban`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      toast({ title: "User banned" });
    },
  });

  const enableMutation = useMutation({
    mutationFn: async (id: number) => apiRequest("POST", `/api/users/${id}/enable`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      toast({ title: "User enabled" });
    },
  });

  const disableMutation = useMutation({
    mutationFn: async (id: number) => apiRequest("POST", `/api/users/${id}/disable`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      toast({ title: "User disabled" });
    },
  });

  const killConnectionMutation = useMutation({
    mutationFn: async (id: number) => apiRequest("POST", `/api/users/${id}/kill`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/connections"] });
      toast({ title: "User connections killed" });
    },
  });

  const downloadPlaylist = async (userId: number, type: string) => {
    try {
      const token = localStorage.getItem("neoserv_auth_token");
      const response = await fetch(`/api/users/${userId}/playlist/${type}`, {
        headers: {
          "Authorization": `Bearer ${token}`,
        },
      });
      
      if (!response.ok) {
        throw new Error("Failed to download playlist");
      }
      
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `playlist_${type}.m3u`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      toast({ title: "Playlist downloaded" });
    } catch (error) {
      toast({ 
        title: "Download failed", 
        description: "Could not download playlist",
        variant: "destructive" 
      });
    }
  };

  const [showUrlModal, setShowUrlModal] = useState(false);
  const [modalUrl, setModalUrl] = useState("");
  const [modalType, setModalType] = useState("");

  const copyPlaylistUrl = async (user: User, type: string) => {
    const baseUrl = window.location.origin;
    let url = "";
    let displayType = type.toUpperCase();
    
    if (type === "m3u") {
      url = `${baseUrl}/get.php?username=${user.username}&password=${user.password}&type=m3u`;
    } else if (type === "m3u_plus") {
      url = `${baseUrl}/get.php?username=${user.username}&password=${user.password}&type=m3u_plus`;
    } else if (type === "xtream") {
      url = `${baseUrl}/player_api.php?username=${user.username}&password=${user.password}`;
    } else if (type === "mag") {
      // MAG/STB portal URL - uses /c/ which works for both /xmag/c/ and subdomain/c/
      url = `${baseUrl}/c/`;
      displayType = "MAG Portal";
    }
    
    // Try modern clipboard API first
    try {
      await navigator.clipboard.writeText(url);
      toast({
        title: "Copied!",
        description: `${displayType} URL copied to clipboard`,
      });
    } catch {
      // Fallback: show modal with URL for manual copy
      setModalUrl(url);
      setModalType(displayType);
      setShowUrlModal(true);
    }
  };

  const filteredUsers = users?.filter(user => 
    user.username.toLowerCase().includes(search.toLowerCase()) ||
    user.email?.toLowerCase().includes(search.toLowerCase())
  );

  const activeCount = users?.filter(u => u.status === "active").length || 0;
  const expiredCount = users?.filter(u => u.status === "expired").length || 0;
  const bannedCount = users?.filter(u => u.status === "banned").length || 0;

  const toggleSelectAll = () => {
    if (filteredUsers && selectedIds.size === filteredUsers.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(filteredUsers?.map(u => u.id) || []));
    }
  };

  const toggleSelect = (id: number) => {
    const newSet = new Set(selectedIds);
    if (newSet.has(id)) {
      newSet.delete(id);
    } else {
      newSet.add(id);
    }
    setSelectedIds(newSet);
  };

  const exportCSV = () => {
    if (!users) return;
    const headers = ["Username", "Email", "Status", "Max Connections", "Expiration Date", "Trial"];
    const rows = users.map(u => [
      u.username,
      u.email || "",
      u.status || "active",
      (u.maxConnections ?? 1).toString(),
      u.expirationDate || "",
      u.isTrial ? "Yes" : "No",
    ]);
    const csv = [headers.join(","), ...rows.map(r => r.join(","))].join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `users_${new Date().toISOString().split("T")[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    toast({ title: "Users exported to CSV" });
  };

  const extendExpiration = (days: number) => {
    const ids = Array.from(selectedIds);
    bulkExtendMutation.mutate({ ids, days });
  };

  const statusBadge = (status: string, isTrial?: boolean) => {
    const variants: Record<string, "default" | "secondary" | "destructive"> = {
      active: "default",
      expired: "secondary",
      banned: "destructive",
    };
    return (
      <div className="flex items-center gap-1">
        <Badge variant={variants[status] || "secondary"}>{status}</Badge>
        {isTrial && <Badge variant="outline">Trial</Badge>}
      </div>
    );
  };

  const copyCredentials = (user: User) => {
    navigator.clipboard.writeText(`Username: ${user.username}\nPassword: ********`);
    toast({ title: "Credentials copied to clipboard" });
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-3xl font-bold tracking-tight" data-testid="page-title">Users</h1>
          <p className="text-muted-foreground">Manage user accounts and subscriptions</p>
        </div>
        <div className="flex gap-2 flex-wrap">
          <Button variant="outline" onClick={exportCSV} data-testid="button-export-csv">
            <Download className="h-4 w-4 mr-2" />
            Export CSV
          </Button>
          <Button variant="outline" onClick={() => setGenerateDialogOpen(true)} data-testid="button-generate-line">
            <Wand2 className="h-4 w-4 mr-2" />
            Generate Line
          </Button>
          <Button onClick={() => { setEditingUser(undefined); setDialogOpen(true); }} data-testid="button-add-user">
            <Plus className="h-4 w-4 mr-2" />
            Add User
          </Button>
        </div>
      </div>

      <div className="grid gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 rounded-lg bg-primary/10">
              <UsersIcon className="h-5 w-5 text-primary" />
            </div>
            <div>
              <p className="text-2xl font-bold">{users?.length || 0}</p>
              <p className="text-sm text-muted-foreground">Total Users</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 rounded-lg bg-emerald-500/10">
              <UserCheck className="h-5 w-5 text-emerald-500" />
            </div>
            <div>
              <p className="text-2xl font-bold">{activeCount}</p>
              <p className="text-sm text-muted-foreground">Active</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 rounded-lg bg-amber-500/10">
              <Clock className="h-5 w-5 text-amber-500" />
            </div>
            <div>
              <p className="text-2xl font-bold">{expiredCount}</p>
              <p className="text-sm text-muted-foreground">Expired</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 rounded-lg bg-red-500/10">
              <UserX className="h-5 w-5 text-red-500" />
            </div>
            <div>
              <p className="text-2xl font-bold">{bannedCount}</p>
              <p className="text-sm text-muted-foreground">Banned</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {selectedIds.size > 0 && (
        <Card className="border-primary">
          <CardContent className="p-4 flex items-center justify-between gap-4 flex-wrap">
            <span className="font-medium">{selectedIds.size} user(s) selected</span>
            <div className="flex gap-2 flex-wrap">
              <Button 
                size="sm" 
                variant="outline" 
                onClick={() => bulkUpdateMutation.mutate({ ids: Array.from(selectedIds), update: { status: "active" } })}
                data-testid="button-bulk-enable"
              >
                <CheckCircle className="h-4 w-4 mr-2" />
                Enable
              </Button>
              <Button 
                size="sm" 
                variant="outline" 
                onClick={() => bulkUpdateMutation.mutate({ ids: Array.from(selectedIds), update: { status: "banned" } })}
                data-testid="button-bulk-disable"
              >
                <Ban className="h-4 w-4 mr-2" />
                Disable
              </Button>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button size="sm" variant="outline" data-testid="button-bulk-extend">
                    <CalendarPlus className="h-4 w-4 mr-2" />
                    Extend
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent>
                  <DropdownMenuItem onClick={() => extendExpiration(7)}>7 days</DropdownMenuItem>
                  <DropdownMenuItem onClick={() => extendExpiration(30)}>30 days</DropdownMenuItem>
                  <DropdownMenuItem onClick={() => extendExpiration(90)}>90 days</DropdownMenuItem>
                  <DropdownMenuItem onClick={() => extendExpiration(365)}>1 year</DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
              <Button 
                size="sm" 
                variant="destructive" 
                onClick={() => bulkDeleteMutation.mutate(Array.from(selectedIds))}
                data-testid="button-bulk-delete"
              >
                <Trash2 className="h-4 w-4 mr-2" />
                Delete
              </Button>
              <Button size="sm" variant="ghost" onClick={() => setSelectedIds(new Set())} data-testid="button-clear-selection">
                Clear
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader className="flex flex-row items-center justify-between gap-4 pb-4">
          <CardTitle>All Users</CardTitle>
          <div className="relative w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search users..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-9"
              data-testid="input-search-users"
            />
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-2">
              {Array(5).fill(0).map((_, i) => (
                <Skeleton key={i} className="h-12 w-full" />
              ))}
            </div>
          ) : filteredUsers && filteredUsers.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-12">
                    <Checkbox 
                      checked={filteredUsers.length > 0 && selectedIds.size === filteredUsers.length}
                      onCheckedChange={toggleSelectAll}
                      data-testid="checkbox-select-all"
                    />
                  </TableHead>
                  <TableHead>Username</TableHead>
                  <TableHead>Password</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Online</TableHead>
                  <TableHead>Connections</TableHead>
                  <TableHead>Expiration</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredUsers.map((user) => (
                  <TableRow key={user.id} data-testid={`user-row-${user.id}`}>
                    <TableCell>
                      <Checkbox 
                        checked={selectedIds.has(user.id)}
                        onCheckedChange={() => toggleSelect(user.id)}
                        data-testid={`checkbox-user-${user.id}`}
                      />
                    </TableCell>
                    <TableCell className="font-medium">{user.username}</TableCell>
                    <TableCell className="font-mono text-muted-foreground">{user.password}</TableCell>
                    <TableCell>{statusBadge(user.status || "active", user.isTrial ?? false)}</TableCell>
                    <TableCell>
                      {user.onlineConnections > 0 ? (
                        <Badge variant="default" className="bg-emerald-500 text-white">
                          <div className="w-2 h-2 rounded-full bg-white mr-1.5 animate-pulse" />
                          {user.onlineConnections}
                        </Badge>
                      ) : (
                        <span className="text-muted-foreground text-sm">Offline</span>
                      )}
                    </TableCell>
                    <TableCell>{user.maxConnections}</TableCell>
                    <TableCell className="text-muted-foreground">
                      {user.expirationDate || "Never"}
                    </TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" data-testid={`button-user-menu-${user.id}`}>
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => copyCredentials(user)}>
                            <Copy className="h-4 w-4 mr-2" />
                            Copy Credentials
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => { setEditingUser(user); setDialogOpen(true); }}>
                            <Edit className="h-4 w-4 mr-2" />
                            Edit
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => enableMutation.mutate(user.id)}>
                            <CheckCircle className="h-4 w-4 mr-2" />
                            Enable
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => disableMutation.mutate(user.id)}>
                            <UserX className="h-4 w-4 mr-2" />
                            Disable
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => banMutation.mutate(user.id)}>
                            <Ban className="h-4 w-4 mr-2" />
                            Ban
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => killConnectionMutation.mutate(user.id)}>
                            <RefreshCw className="h-4 w-4 mr-2" />
                            Kill Connections
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => downloadPlaylist(user.id, "m3u")}>
                            <Download className="h-4 w-4 mr-2" />
                            Download M3U
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => downloadPlaylist(user.id, "m3u_plus")}>
                            <Download className="h-4 w-4 mr-2" />
                            Download M3U Plus
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => copyPlaylistUrl(user, "m3u")}>
                            <Copy className="h-4 w-4 mr-2" />
                            Copy M3U URL
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => copyPlaylistUrl(user, "m3u_plus")}>
                            <Copy className="h-4 w-4 mr-2" />
                            Copy M3U Plus URL
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => copyPlaylistUrl(user, "xtream")}>
                            <Copy className="h-4 w-4 mr-2" />
                            Copy Xtream API URL
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => copyPlaylistUrl(user, "mag")}>
                            <Copy className="h-4 w-4 mr-2" />
                            Copy MAG Portal URL
                          </DropdownMenuItem>
                          <DropdownMenuItem 
                            onClick={() => handleDeleteClick(user)}
                            className="text-destructive"
                          >
                            <Trash2 className="h-4 w-4 mr-2" />
                            Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <UsersIcon className="h-12 w-12 text-muted-foreground/50 mb-4" />
              <p className="text-muted-foreground">No users found</p>
              <Button 
                variant="outline" 
                size="sm" 
                className="mt-4"
                onClick={() => { setEditingUser(undefined); setDialogOpen(true); }}
              >
                Add your first user
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      <UserFormDialog 
        user={editingUser} 
        open={dialogOpen} 
        onOpenChange={setDialogOpen} 
      />
      
      <GenerateLineDialog 
        open={generateDialogOpen} 
        onOpenChange={setGenerateDialogOpen} 
      />

      <DeleteConfirmation
        open={deleteDialogOpen}
        onOpenChange={setDeleteDialogOpen}
        onConfirm={confirmDelete}
        title="Delete User"
        itemName={userToDelete?.username}
      />

      {/* URL Copy Modal - Professional fallback for iOS */}
      <Dialog open={showUrlModal} onOpenChange={setShowUrlModal}>
        <DialogContent className="max-w-xl">
          <DialogHeader>
            <DialogTitle>{modalType} Playlist URL</DialogTitle>
            <DialogDescription>
              Long press to select the URL, then copy
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <Input
              readOnly
              value={modalUrl}
              className="font-mono text-xs"
              onFocus={(e) => e.target.select()}
              data-testid="input-playlist-url"
            />
            <div className="flex justify-end gap-2">
              <Button
                variant="outline"
                onClick={() => setShowUrlModal(false)}
                data-testid="button-close-modal"
              >
                Close
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
