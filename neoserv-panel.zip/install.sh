#!/bin/bash
# X NeoServ Panel - Interactive Install Script
# Works on Ubuntu 20.04/22.04/24.04 and Debian 11/12

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}"
echo "=============================================="
echo "     X NeoServ Panel - Installation"
echo "=============================================="
echo -e "${NC}"

# Check if running as root
if [ "$EUID" -ne 0 ]; then
  echo -e "${RED}Please run as root (sudo bash install.sh)${NC}"
  exit 1
fi

# Ask for database password
echo -e "${YELLOW}Enter a strong password for the database:${NC}"
read -s DB_PASSWORD
echo ""
if [ -z "$DB_PASSWORD" ]; then
  echo -e "${RED}Password cannot be empty!${NC}"
  exit 1
fi

# Ask for admin panel password
echo -e "${YELLOW}Enter password for admin panel login (username will be 'admin'):${NC}"
read -s ADMIN_PASSWORD
echo ""
if [ -z "$ADMIN_PASSWORD" ]; then
  ADMIN_PASSWORD="admin123"
  echo -e "${YELLOW}Using default password: admin123${NC}"
fi

# Ask for port
echo -e "${YELLOW}Enter port for panel (default 80):${NC}"
read PANEL_PORT
if [ -z "$PANEL_PORT" ]; then
  PANEL_PORT="80"
fi

# Ask if this is a client installation (needs license server)
echo ""
echo -e "${YELLOW}Is this a CLIENT installation that needs to validate licenses from a central server?${NC}"
echo -e "${YELLOW}(Press Enter for default: https://x.neoserv-panel.com, or type 'none' if this IS the license server):${NC}"
read LICENSE_SERVER_INPUT
if [ "$LICENSE_SERVER_INPUT" = "none" ] || [ "$LICENSE_SERVER_INPUT" = "NONE" ]; then
  LICENSE_SERVER_URL=""
  echo -e "${GREEN}This installation will be the LICENSE SERVER (can generate licenses)${NC}"
elif [ -n "$LICENSE_SERVER_INPUT" ]; then
  LICENSE_SERVER_URL="$LICENSE_SERVER_INPUT"
  echo -e "${GREEN}License server: $LICENSE_SERVER_URL${NC}"
else
  LICENSE_SERVER_URL="https://x.neoserv-panel.com"
  echo -e "${GREEN}License server: $LICENSE_SERVER_URL (default)${NC}"
fi

echo ""
echo -e "${GREEN}Starting installation...${NC}"
echo ""

# 1. System update & dependencies
echo -e "${BLUE}[1/9] Updating system and installing dependencies...${NC}"
apt update -qq
apt upgrade -y -qq
apt install -y -qq curl wget unzip git postgresql postgresql-contrib

# 2. Node.js 20
echo -e "${BLUE}[2/9] Installing Node.js 20...${NC}"
if ! command -v node &> /dev/null; then
  curl -fsSL https://deb.nodesource.com/setup_20.x | bash - > /dev/null 2>&1
  apt install -y -qq nodejs
fi
echo -e "${GREEN}Node.js $(node -v) installed${NC}"

# 3. Create directory
echo -e "${BLUE}[3/9] Setting up directories...${NC}"
mkdir -p /opt/neoserv
cd /opt/neoserv

# 4. Check for ZIP file or download
ZIP_FILE=""
if [ -f "neoserv-panel-v3.0.zip" ]; then
  ZIP_FILE="neoserv-panel-v3.0.zip"
elif [ -f "neoserv-panel-v3.zip" ]; then
  ZIP_FILE="neoserv-panel-v3.zip"
elif [ -f "neoserv-panel.zip" ]; then
  ZIP_FILE="neoserv-panel.zip"
fi

# Download if no ZIP found
if [ -z "$ZIP_FILE" ] && [ ! -f "package.json" ]; then
  echo -e "${BLUE}[4/9] Downloading NeoServ Panel...${NC}"
  wget -q --show-progress -O neoserv-panel.zip "https://neoserv-panel.com/v2/neoserv-panel.zip"
  if [ $? -eq 0 ]; then
    ZIP_FILE="neoserv-panel.zip"
    echo -e "${GREEN}Download complete${NC}"
  else
    echo -e "${RED}ERROR: Failed to download install package!${NC}"
    echo -e "${YELLOW}Please upload neoserv-panel.zip to /opt/neoserv/ manually.${NC}"
    exit 1
  fi
fi

if [ -n "$ZIP_FILE" ]; then
  echo -e "${BLUE}[4/9] Extracting files from $ZIP_FILE...${NC}"
  unzip -o -qq "$ZIP_FILE"
else
  echo -e "${BLUE}[4/9] Files already extracted...${NC}"
fi

# 5. PostgreSQL setup
echo -e "${BLUE}[5/9] Configuring PostgreSQL database...${NC}"
systemctl start postgresql
systemctl enable postgresql

# Create database and user
sudo -u postgres psql -c "DROP DATABASE IF EXISTS neoserv_panel;" 2>/dev/null || true
sudo -u postgres psql -c "DROP USER IF EXISTS neoserv;" 2>/dev/null || true
sudo -u postgres psql -c "CREATE USER neoserv WITH ENCRYPTED PASSWORD '$DB_PASSWORD';"
sudo -u postgres psql -c "CREATE DATABASE neoserv_panel OWNER neoserv;"
sudo -u postgres psql -d neoserv_panel -c "GRANT ALL ON SCHEMA public TO neoserv;"
echo -e "${GREEN}Database created successfully${NC}"

# 6. Generate session secret
SESSION_SECRET=$(openssl rand -hex 32)

# 7. Environment file
echo -e "${BLUE}[6/9] Creating environment configuration...${NC}"
cat > /opt/neoserv/.env <<EOF
DATABASE_URL=postgresql://neoserv:${DB_PASSWORD}@localhost:5432/neoserv_panel
SESSION_SECRET=${SESSION_SECRET}
NODE_ENV=production
PORT=${PANEL_PORT}
ADMIN_PASSWORD=${ADMIN_PASSWORD}
EOF

# Add LICENSE_SERVER_URL if this is a client installation
if [ -n "$LICENSE_SERVER_URL" ]; then
  echo "LICENSE_SERVER_URL=${LICENSE_SERVER_URL}" >> /opt/neoserv/.env
fi

chmod 600 /opt/neoserv/.env
echo -e "${GREEN}Environment configured${NC}"

# 8. Install & Build
echo -e "${BLUE}[7/9] Installing Node.js packages (this may take a few minutes)...${NC}"
cd /opt/neoserv
npm install --silent 2>/dev/null

echo -e "${BLUE}[8/9] Building application...${NC}"
npm run db:push 2>/dev/null
npm run build 2>/dev/null
echo -e "${GREEN}Application built successfully${NC}"

# 9. Systemd service
echo -e "${BLUE}[9/9] Creating system service...${NC}"
cat > /etc/systemd/system/neoserv.service <<EOF
[Unit]
Description=X NeoServ Panel
After=network.target postgresql.service

[Service]
Type=simple
User=root
WorkingDirectory=/opt/neoserv
EnvironmentFile=/opt/neoserv/.env
ExecStart=/usr/bin/node dist/index.cjs
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable neoserv
systemctl start neoserv

# Get server IP
SERVER_IP=$(hostname -I | awk '{print $1}')

echo ""
echo -e "${GREEN}=============================================="
echo "     Installation Complete!"
echo "==============================================${NC}"
echo ""
echo -e "${BLUE}Panel URL:${NC} http://${SERVER_IP}:${PANEL_PORT}"
echo -e "${BLUE}Username:${NC} admin"
echo -e "${BLUE}Password:${NC} ${ADMIN_PASSWORD}"
echo ""
echo -e "${YELLOW}Useful commands:${NC}"
echo "  systemctl status neoserv    - Check status"
echo "  systemctl restart neoserv   - Restart panel"
echo "  journalctl -u neoserv -f    - View logs"
echo ""
echo -e "${GREEN}Enjoy X NeoServ v3.0!${NC}"
echo ""

# Verify installation
sleep 3
if systemctl is-active --quiet neoserv; then
  echo -e "${GREEN}[✓] Service is running successfully!${NC}"
else
  echo -e "${RED}[!] Service may have failed to start. Check: journalctl -u neoserv${NC}"
fi
