CREATE TABLE "access_codes" (
	"id" serial PRIMARY KEY NOT NULL,
	"code" varchar(255),
	"type" integer DEFAULT 0,
	"enabled" integer DEFAULT 0,
	"is_admin" text,
	"is_reseller" text,
	"whitelist" text
);
--> statement-breakpoint
CREATE TABLE "access_output" (
	"access_output_id" serial PRIMARY KEY NOT NULL,
	"output_name" varchar(255) NOT NULL,
	"output_key" varchar(255) NOT NULL,
	"output_ext" varchar(255) NOT NULL
);
--> statement-breakpoint
CREATE TABLE "admin_settings" (
	"type" varchar(128) PRIMARY KEY NOT NULL,
	"value" text DEFAULT '' NOT NULL,
	"save_button_under_and_ontop" varchar(16) DEFAULT '1'
);
--> statement-breakpoint
CREATE TABLE "blocked_ips" (
	"id" serial PRIMARY KEY NOT NULL,
	"ip" varchar(39) NOT NULL,
	"notes" text DEFAULT '' NOT NULL,
	"date" integer NOT NULL,
	"attempts_blocked" integer DEFAULT 0 NOT NULL
);
--> statement-breakpoint
CREATE TABLE "blocked_user_agents" (
	"id" serial PRIMARY KEY NOT NULL,
	"user_agent" varchar(255) NOT NULL,
	"exact_match" integer DEFAULT 0 NOT NULL,
	"attempts_blocked" integer DEFAULT 0 NOT NULL
);
--> statement-breakpoint
CREATE TABLE "bouquets" (
	"id" serial PRIMARY KEY NOT NULL,
	"bouquet_name" text NOT NULL,
	"bouquet_channels" text DEFAULT '[]' NOT NULL,
	"bouquet_series" text DEFAULT '[]' NOT NULL,
	"bouquet_order" integer DEFAULT 0 NOT NULL,
	"bouquet_restrimer" integer DEFAULT 0,
	"bouquet_streams" text DEFAULT '[]' NOT NULL,
	"bouquet_radios" text DEFAULT '[]' NOT NULL,
	"bouquet_movies" text DEFAULT '[]' NOT NULL,
	"bouquet_no_restream" integer DEFAULT 0 NOT NULL
);
--> statement-breakpoint
CREATE TABLE "client_logs" (
	"id" serial PRIMARY KEY NOT NULL,
	"stream_id" integer,
	"user_id" integer,
	"client_status" varchar(255) NOT NULL,
	"query_string" text DEFAULT '',
	"user_agent" varchar(255) DEFAULT '',
	"ip" varchar(255) DEFAULT '',
	"extra_data" text DEFAULT '',
	"date" integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE "country" (
	"id" serial PRIMARY KEY NOT NULL,
	"codes" varchar(255)
);
--> statement-breakpoint
CREATE TABLE "credits_log" (
	"id" serial PRIMARY KEY NOT NULL,
	"target_id" integer NOT NULL,
	"admin_id" integer NOT NULL,
	"amount" real NOT NULL,
	"date" integer NOT NULL,
	"reason" text DEFAULT ''
);
--> statement-breakpoint
CREATE TABLE "cronjobs" (
	"id" serial PRIMARY KEY NOT NULL,
	"description" text DEFAULT '',
	"filename" varchar(255) NOT NULL,
	"run_per_mins" integer DEFAULT 1 NOT NULL,
	"run_per_hours" integer DEFAULT 0 NOT NULL,
	"enabled" integer DEFAULT 0 NOT NULL,
	"pid" integer DEFAULT 0 NOT NULL,
	"timestamp" integer
);
--> statement-breakpoint
CREATE TABLE "dashboard_statistics" (
	"id" serial PRIMARY KEY NOT NULL,
	"type" varchar(16) DEFAULT '' NOT NULL,
	"time" integer DEFAULT 0 NOT NULL,
	"count" integer DEFAULT 0 NOT NULL
);
--> statement-breakpoint
CREATE TABLE "devices" (
	"device_id" serial PRIMARY KEY NOT NULL,
	"device_name" varchar(255) NOT NULL,
	"device_key" varchar(255) NOT NULL,
	"device_filename" varchar(255) NOT NULL,
	"device_header" text DEFAULT '',
	"device_conf" text DEFAULT '',
	"device_footer" text DEFAULT '',
	"default_output" integer DEFAULT 0 NOT NULL,
	"copy_text" text
);
--> statement-breakpoint
CREATE TABLE "enigma2_actions" (
	"id" serial PRIMARY KEY NOT NULL,
	"device_id" integer NOT NULL,
	"type" text NOT NULL,
	"key" text NOT NULL,
	"command" text NOT NULL,
	"command2" text NOT NULL
);
--> statement-breakpoint
CREATE TABLE "enigma2_devices" (
	"device_id" serial PRIMARY KEY NOT NULL,
	"mac" varchar(255) NOT NULL,
	"user_id" integer NOT NULL,
	"modem_mac" varchar(255) DEFAULT '',
	"local_ip" varchar(255) DEFAULT '',
	"public_ip" varchar(255) DEFAULT '',
	"key_auth" varchar(255) DEFAULT '',
	"enigma_version" varchar(255) DEFAULT '',
	"cpu" varchar(255) DEFAULT '',
	"version" varchar(255) DEFAULT '',
	"lversion" text DEFAULT '',
	"token" varchar(32) DEFAULT '',
	"last_updated" integer NOT NULL,
	"watchdog_timeout" integer DEFAULT 0 NOT NULL,
	"lock_device" integer DEFAULT 0 NOT NULL,
	"telnet_enable" integer DEFAULT 1 NOT NULL,
	"ftp_enable" integer DEFAULT 1 NOT NULL,
	"ssh_enable" integer DEFAULT 1 NOT NULL,
	"dns" varchar(255) DEFAULT '',
	"original_mac" varchar(255) DEFAULT '',
	"rc" integer DEFAULT 1 NOT NULL
);
--> statement-breakpoint
CREATE TABLE "enigma2_failed" (
	"id" serial PRIMARY KEY NOT NULL,
	"original_mac" varchar(255) NOT NULL,
	"virtual_mac" varchar(255) NOT NULL,
	"date" integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE "epg" (
	"id" serial PRIMARY KEY NOT NULL,
	"epg_name" varchar(255) NOT NULL,
	"epg_file" varchar(300) DEFAULT '' NOT NULL,
	"integrity" varchar(255),
	"last_updated" integer,
	"days_keep" integer DEFAULT 7 NOT NULL,
	"data" text,
	"update_auto" integer DEFAULT 0 NOT NULL
);
--> statement-breakpoint
CREATE TABLE "epg_data" (
	"id" serial PRIMARY KEY NOT NULL,
	"epg_id" integer NOT NULL,
	"title" varchar(255) NOT NULL,
	"lang" varchar(10) NOT NULL,
	"start" integer NOT NULL,
	"end" integer,
	"description" text DEFAULT '',
	"channel_id" varchar(50) NOT NULL
);
--> statement-breakpoint
CREATE TABLE "epg_type" (
	"device_id" serial PRIMARY KEY NOT NULL,
	"device_name" varchar(255) NOT NULL,
	"device_key" varchar(255) NOT NULL
);
--> statement-breakpoint
CREATE TABLE "isp_addon" (
	"id" serial PRIMARY KEY NOT NULL,
	"isp" text NOT NULL,
	"blocked" integer DEFAULT 0 NOT NULL
);
--> statement-breakpoint
CREATE TABLE "languages" (
	"key" varchar(128) PRIMARY KEY NOT NULL,
	"language" text DEFAULT '' NOT NULL
);
--> statement-breakpoint
CREATE TABLE "lblock" (
	"id" serial PRIMARY KEY NOT NULL,
	"ip" varchar(45) NOT NULL,
	"created_at" integer
);
--> statement-breakpoint
CREATE TABLE "licence" (
	"id" serial PRIMARY KEY NOT NULL,
	"licence_key" varchar(29) NOT NULL,
	"show_message" integer NOT NULL,
	"update_available" integer DEFAULT 0 NOT NULL,
	"reshare_deny_addon" integer DEFAULT 0
);
--> statement-breakpoint
CREATE TABLE "links" (
	"id" serial PRIMARY KEY NOT NULL,
	"short" varchar(10) NOT NULL,
	"email" varchar(200) NOT NULL,
	"amount" varchar(10) DEFAULT '0' NOT NULL,
	"name" varchar(255) NOT NULL,
	"date" integer,
	"status" varchar(255) NOT NULL,
	"curr" varchar(10) DEFAULT 'USD' NOT NULL,
	"srv" integer DEFAULT 1 NOT NULL
);
--> statement-breakpoint
CREATE TABLE "login_flood" (
	"id" serial PRIMARY KEY NOT NULL,
	"username" varchar(128) DEFAULT '' NOT NULL,
	"ip" varchar(64) DEFAULT '' NOT NULL,
	"dateadded" integer
);
--> statement-breakpoint
CREATE TABLE "login_logs" (
	"id" serial PRIMARY KEY NOT NULL,
	"user_id" integer,
	"data" text DEFAULT '',
	"login_ip" varchar(255) DEFAULT '',
	"date" integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE "login_users" (
	"id" serial PRIMARY KEY NOT NULL,
	"owner" integer NOT NULL,
	"date" integer NOT NULL,
	"login_ip" varchar(255) DEFAULT '',
	"type" varchar(255) DEFAULT ''
);
--> statement-breakpoint
CREATE TABLE "mag_claims" (
	"id" serial PRIMARY KEY NOT NULL,
	"mag_id" integer NOT NULL,
	"stream_id" integer NOT NULL,
	"real_type" varchar(10) NOT NULL,
	"date" integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE "mag_devices" (
	"mag_id" serial PRIMARY KEY NOT NULL,
	"user_id" integer NOT NULL,
	"bright" integer DEFAULT 200 NOT NULL,
	"contrast" integer DEFAULT 127 NOT NULL,
	"saturation" integer DEFAULT 127 NOT NULL,
	"aspect" text DEFAULT '',
	"video_out" varchar(20) DEFAULT 'rca' NOT NULL,
	"volume" integer DEFAULT 50 NOT NULL,
	"playback_buffer_bytes" integer DEFAULT 0 NOT NULL,
	"playback_buffer_size" integer DEFAULT 0 NOT NULL,
	"audio_out" integer DEFAULT 1 NOT NULL,
	"mac" varchar(50) NOT NULL,
	"ip" varchar(20),
	"ls" varchar(20),
	"ver" varchar(300),
	"lang" varchar(50),
	"locale" varchar(30) DEFAULT 'en_GB.utf8' NOT NULL,
	"city_id" integer DEFAULT 0,
	"hd" integer DEFAULT 1 NOT NULL,
	"main_notify" integer DEFAULT 1 NOT NULL,
	"fav_itv_on" integer DEFAULT 0 NOT NULL,
	"now_playing_start" integer,
	"now_playing_type" integer DEFAULT 0 NOT NULL,
	"now_playing_content" varchar(50),
	"time_last_play_tv" integer,
	"time_last_play_video" integer,
	"hd_content" integer DEFAULT 1 NOT NULL,
	"image_version" varchar(350),
	"last_change_status" integer,
	"last_start" integer,
	"last_active" integer,
	"keep_alive" integer,
	"playback_limit" integer DEFAULT 3 NOT NULL,
	"screensaver_delay" integer DEFAULT 10 NOT NULL,
	"stb_type" varchar(20) DEFAULT '' NOT NULL,
	"sn" varchar(255),
	"last_watchdog" integer,
	"created" integer NOT NULL,
	"country" varchar(5),
	"plasma_saving" integer DEFAULT 0 NOT NULL,
	"ts_enabled" integer DEFAULT 0,
	"ts_enable_icon" integer DEFAULT 1 NOT NULL,
	"ts_path" varchar(35),
	"ts_max_length" integer DEFAULT 3600 NOT NULL,
	"ts_buffer_use" varchar(15) DEFAULT 'cyclic' NOT NULL,
	"ts_action_on_exit" varchar(20) DEFAULT 'no_save' NOT NULL,
	"ts_delay" varchar(20) DEFAULT 'on_pause' NOT NULL,
	"video_clock" varchar(10) DEFAULT 'Off' NOT NULL,
	"rtsp_type" integer DEFAULT 4 NOT NULL,
	"rtsp_flags" integer DEFAULT 0 NOT NULL,
	"stb_lang" varchar(15) DEFAULT 'en' NOT NULL,
	"display_menu_after_loading" integer DEFAULT 1 NOT NULL,
	"record_max_length" integer DEFAULT 180 NOT NULL,
	"plasma_saving_timeout" integer DEFAULT 600 NOT NULL,
	"now_playing_link_id" integer,
	"now_playing_streamer_id" integer,
	"device_id" varchar(255),
	"device_id2" varchar(255),
	"hw_version" varchar(255),
	"parent_password" varchar(20) DEFAULT '0000' NOT NULL,
	"spdif_mode" integer DEFAULT 1 NOT NULL,
	"show_after_loading" varchar(60) DEFAULT 'main_menu' NOT NULL,
	"play_in_preview_by_ok" integer DEFAULT 1 NOT NULL,
	"hdmi_event_reaction" integer DEFAULT 1 NOT NULL,
	"mag_player" varchar(20) DEFAULT 'ffmpeg',
	"play_in_preview_only_by_ok" varchar(10) DEFAULT 'true' NOT NULL,
	"watchdog_timeout" integer DEFAULT 0 NOT NULL,
	"fav_channels" text DEFAULT '',
	"tv_archive_continued" text DEFAULT '',
	"tv_channel_default_aspect" varchar(255) DEFAULT 'fit' NOT NULL,
	"last_itv_id" integer DEFAULT 0 NOT NULL,
	"units" varchar(20) DEFAULT 'metric',
	"token" varchar(32) DEFAULT '',
	"lock_device" integer DEFAULT 0 NOT NULL,
	"secret_key" varchar(128) DEFAULT '' NOT NULL
);
--> statement-breakpoint
CREATE TABLE "mag_events" (
	"id" serial PRIMARY KEY NOT NULL,
	"status" integer DEFAULT 0 NOT NULL,
	"mag_device_id" integer NOT NULL,
	"event" varchar(20) NOT NULL,
	"need_confirm" integer DEFAULT 0 NOT NULL,
	"msg" text DEFAULT '',
	"reboot_after_ok" integer DEFAULT 0 NOT NULL,
	"auto_hide_timeout" integer DEFAULT 0,
	"send_time" integer NOT NULL,
	"additional_services_on" integer DEFAULT 1 NOT NULL,
	"anec" integer DEFAULT 0 NOT NULL,
	"vclub" integer DEFAULT 0 NOT NULL
);
--> statement-breakpoint
CREATE TABLE "mag_logs" (
	"id" serial PRIMARY KEY NOT NULL,
	"mag_id" integer,
	"action" varchar(255) NOT NULL
);
--> statement-breakpoint
CREATE TABLE "member_groups" (
	"group_id" serial PRIMARY KEY NOT NULL,
	"group_name" text NOT NULL,
	"group_color" varchar(7) DEFAULT '#000000' NOT NULL,
	"is_banned" integer DEFAULT 0 NOT NULL,
	"is_admin" integer DEFAULT 0 NOT NULL,
	"is_reseller" integer DEFAULT 0 NOT NULL,
	"total_allowed_gen_trials" integer DEFAULT 0 NOT NULL,
	"total_allowed_gen_in" varchar(255) DEFAULT '',
	"delete_users" integer DEFAULT 0 NOT NULL,
	"allowed_pages" text DEFAULT '',
	"can_delete" integer DEFAULT 1 NOT NULL,
	"reseller_force_server" integer DEFAULT 0 NOT NULL,
	"create_sub_resellers_price" real DEFAULT 0 NOT NULL,
	"create_sub_resellers" integer DEFAULT 0 NOT NULL,
	"alter_packages_ids" integer DEFAULT 0 NOT NULL,
	"alter_packages_prices" integer DEFAULT 0 NOT NULL,
	"reseller_client_connection_logs" integer DEFAULT 0 NOT NULL,
	"reseller_assign_pass" integer DEFAULT 0 NOT NULL,
	"allow_change_pass" integer DEFAULT 0 NOT NULL,
	"allow_import" integer DEFAULT 0 NOT NULL,
	"allow_export" integer DEFAULT 0 NOT NULL,
	"reseller_trial_credit_allow" integer DEFAULT 0 NOT NULL,
	"edit_mac" integer DEFAULT 0 NOT NULL,
	"edit_isplock" integer DEFAULT 0 NOT NULL,
	"reset_stb_data" integer DEFAULT 0 NOT NULL,
	"reseller_bonus_package_inc" integer DEFAULT 0 NOT NULL,
	"allow_download" integer DEFAULT 1 NOT NULL,
	"minimum_trial_credits" integer DEFAULT 0 NOT NULL,
	"reseller_controls_streams" integer DEFAULT 0 NOT NULL,
	"reseller_can_select_bouquets" integer DEFAULT 0 NOT NULL,
	"allow_change_bouquets" integer DEFAULT 0 NOT NULL,
	"allow_change_restrictions" integer DEFAULT 0 NOT NULL,
	"disable_trial" integer DEFAULT 0 NOT NULL,
	"change_own_dns" integer DEFAULT 0 NOT NULL,
	"change_usernames" integer DEFAULT 0 NOT NULL,
	"change_passwords" integer DEFAULT 0 NOT NULL,
	"change_own_email" integer DEFAULT 0 NOT NULL,
	"reseller_dashboard_message" text DEFAULT '',
	"dashboard_message_active" integer DEFAULT 0 NOT NULL,
	"clear_isp" integer DEFAULT 0 NOT NULL,
	"allow_isp_lock" integer DEFAULT 0 NOT NULL,
	"can_delete_users" integer DEFAULT 0 NOT NULL,
	"can_send_mag_event" integer DEFAULT 0 NOT NULL,
	"can_edit" integer DEFAULT 0 NOT NULL,
	"allow_clear_device_infos" integer DEFAULT 0 NOT NULL,
	"reseller_uploads_vod" integer DEFAULT 0 NOT NULL,
	"reseller_restarts_streams" integer DEFAULT 0 NOT NULL
);
--> statement-breakpoint
CREATE TABLE "migration_files" (
	"id" serial PRIMARY KEY NOT NULL,
	"filename" varchar(255) NOT NULL,
	"created" integer
);
--> statement-breakpoint
CREATE TABLE "movie_containers" (
	"container_id" serial PRIMARY KEY NOT NULL,
	"container_extension" varchar(255) NOT NULL,
	"container_header" varchar(255) NOT NULL
);
--> statement-breakpoint
CREATE TABLE "packages" (
	"id" serial PRIMARY KEY NOT NULL,
	"package_name" varchar(255) NOT NULL,
	"is_trial" integer NOT NULL,
	"is_official" integer NOT NULL,
	"trial_credits" real NOT NULL,
	"official_credits" real NOT NULL,
	"trial_duration" integer NOT NULL,
	"trial_duration_in" varchar(255) NOT NULL,
	"official_duration" integer NOT NULL,
	"official_duration_in" varchar(255) NOT NULL,
	"groups" text DEFAULT '',
	"bouquets" text DEFAULT '',
	"can_gen_mag" integer DEFAULT 0 NOT NULL,
	"only_mag" integer DEFAULT 0 NOT NULL,
	"output_formats" text DEFAULT '',
	"is_isplock" integer DEFAULT 0 NOT NULL,
	"max_connections" integer DEFAULT 1 NOT NULL,
	"is_restreamer" integer DEFAULT 0 NOT NULL,
	"force_server_id" integer DEFAULT 0 NOT NULL,
	"can_gen_e2" integer DEFAULT 0 NOT NULL,
	"only_e2" integer DEFAULT 0 NOT NULL,
	"forced_country" varchar(2) DEFAULT '',
	"lock_device" integer DEFAULT 0 NOT NULL,
	"is_vpn" integer DEFAULT 0 NOT NULL,
	"vpn_credits" integer DEFAULT 0 NOT NULL
);
--> statement-breakpoint
CREATE TABLE "panel_logs" (
	"id" serial PRIMARY KEY NOT NULL,
	"log_message" text NOT NULL,
	"date" integer NOT NULL,
	"log_type" varchar(50),
	"log_data" text,
	"owner_id" integer,
	"owner_type" varchar(50)
);
--> statement-breakpoint
CREATE TABLE "payement_users" (
	"id" serial PRIMARY KEY NOT NULL,
	"id_user" integer NOT NULL,
	"mode_payement" varchar(255) NOT NULL,
	"montant" integer,
	"date_created" integer,
	"date_payement" integer,
	"description" text,
	"payed" integer DEFAULT 0 NOT NULL
);
--> statement-breakpoint
CREATE TABLE "recordings" (
	"id" serial PRIMARY KEY NOT NULL,
	"stream_id" integer,
	"created_id" integer,
	"category_id" text,
	"bouquets" text,
	"title" text,
	"description" text,
	"stream_icon" text,
	"start" integer,
	"end" integer,
	"source_id" integer,
	"archive" integer,
	"status" integer DEFAULT 0
);
--> statement-breakpoint
CREATE TABLE "reg_userlog" (
	"id" serial PRIMARY KEY NOT NULL,
	"owner" integer NOT NULL,
	"username" text NOT NULL,
	"password" text NOT NULL,
	"date" integer NOT NULL,
	"type" varchar(255) NOT NULL
);
--> statement-breakpoint
CREATE TABLE "reg_users" (
	"id" serial PRIMARY KEY NOT NULL,
	"username" varchar(50) NOT NULL,
	"password" varchar(255) NOT NULL,
	"email" varchar(255) DEFAULT '' NOT NULL,
	"ip" varchar(255),
	"date_registered" integer NOT NULL,
	"verify_key" text,
	"last_login" integer,
	"member_group_id" integer DEFAULT 1 NOT NULL,
	"verified" integer DEFAULT 0 NOT NULL,
	"credits" real DEFAULT 0 NOT NULL,
	"notes" text,
	"status" integer DEFAULT 1 NOT NULL,
	"default_lang" text DEFAULT 'en',
	"reseller_dns" text DEFAULT '',
	"owner_id" integer DEFAULT 0 NOT NULL,
	"override_packages" text,
	"google_2fa_sec" varchar(50) DEFAULT '',
	"dark_mode" integer DEFAULT 3 NOT NULL,
	"sidebar" integer DEFAULT 0 NOT NULL,
	"expanded_sidebar" integer DEFAULT 0 NOT NULL,
	"topbar_theme" text DEFAULT '',
	"navigation_theme" text DEFAULT '',
	"navigation_text_color" text DEFAULT '',
	"navigation_mode" integer DEFAULT 1 NOT NULL,
	"navigation_center" integer DEFAULT 0 NOT NULL,
	"navigation_methode" integer DEFAULT 0 NOT NULL,
	"dropbox" text DEFAULT ''
);
--> statement-breakpoint
CREATE TABLE "reseller_credentials" (
	"id" serial PRIMARY KEY NOT NULL,
	"member_id" varchar(30),
	"api_key" varchar(100) NOT NULL,
	"ip_allow" varchar(30)
);
--> statement-breakpoint
CREATE TABLE "reseller_imex" (
	"id" serial PRIMARY KEY NOT NULL,
	"reg_id" integer NOT NULL,
	"header" text NOT NULL,
	"data" text NOT NULL,
	"accepted" integer DEFAULT 0 NOT NULL,
	"finished" integer DEFAULT 0 NOT NULL,
	"bouquet_ids" text DEFAULT ''
);
--> statement-breakpoint
CREATE TABLE "reseller_info" (
	"id" serial PRIMARY KEY NOT NULL,
	"value" varchar(255) DEFAULT '' NOT NULL,
	"value_info" varchar(255) DEFAULT '' NOT NULL,
	"type" varchar(255)
);
--> statement-breakpoint
CREATE TABLE "reseller_news" (
	"news_id" serial PRIMARY KEY NOT NULL,
	"news_title" varchar(255) NOT NULL,
	"news_body" varchar(255) NOT NULL
);
--> statement-breakpoint
CREATE TABLE "restart_logs" (
	"id" serial PRIMARY KEY NOT NULL,
	"log_message" text NOT NULL,
	"date" integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE "rtmp_ips" (
	"id" serial PRIMARY KEY NOT NULL,
	"ip" varchar(255) NOT NULL,
	"notes" text DEFAULT ''
);
--> statement-breakpoint
CREATE TABLE "series" (
	"id" serial PRIMARY KEY NOT NULL,
	"title" varchar(255) NOT NULL,
	"category_id" integer,
	"cover" varchar(255) DEFAULT '',
	"cover_big" varchar(255) DEFAULT '',
	"genre" varchar(255) DEFAULT '',
	"plot" text DEFAULT '',
	"cast" text DEFAULT '',
	"rating" integer DEFAULT 0 NOT NULL,
	"director" varchar(255) DEFAULT '',
	"releaseDate" varchar(255) DEFAULT '',
	"last_modified" integer NOT NULL,
	"tmdb_id" integer DEFAULT 0 NOT NULL,
	"seasons" text DEFAULT '',
	"episode_run_time" integer DEFAULT 0 NOT NULL,
	"backdrop_path" text DEFAULT '',
	"youtube_trailer" text DEFAULT ''
);
--> statement-breakpoint
CREATE TABLE "series_episodes" (
	"id" serial PRIMARY KEY NOT NULL,
	"season_num" integer NOT NULL,
	"series_id" integer NOT NULL,
	"stream_id" integer NOT NULL,
	"sort" integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE "server_activity" (
	"id" serial PRIMARY KEY NOT NULL,
	"source_server_id" integer NOT NULL,
	"dest_server_id" integer NOT NULL,
	"stream_id" integer NOT NULL,
	"pid" integer,
	"bandwidth" integer DEFAULT 0 NOT NULL,
	"date_start" integer NOT NULL,
	"date_end" integer
);
--> statement-breakpoint
CREATE TABLE "signals" (
	"signal_id" serial PRIMARY KEY NOT NULL,
	"pid" integer NOT NULL,
	"server_id" integer NOT NULL,
	"rtmp" integer DEFAULT 0 NOT NULL,
	"time" integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE "stream_categories" (
	"id" serial PRIMARY KEY NOT NULL,
	"category_type" varchar(255) NOT NULL,
	"category_name" varchar(255) NOT NULL,
	"parent_id" integer DEFAULT 0 NOT NULL,
	"cat_order" integer DEFAULT 0 NOT NULL
);
--> statement-breakpoint
CREATE TABLE "stream_logs" (
	"id" serial PRIMARY KEY NOT NULL,
	"stream_id" integer NOT NULL,
	"server_id" integer NOT NULL,
	"date" integer NOT NULL,
	"error" varchar(500) NOT NULL
);
--> statement-breakpoint
CREATE TABLE "stream_stats" (
	"id" serial PRIMARY KEY NOT NULL,
	"stream_id" integer NOT NULL,
	"watched_seconds" bigint DEFAULT 0,
	"last_update" integer
);
--> statement-breakpoint
CREATE TABLE "stream_subcategories" (
	"sub_id" serial PRIMARY KEY NOT NULL,
	"parent_id" integer NOT NULL,
	"subcategory_name" varchar(255) NOT NULL
);
--> statement-breakpoint
CREATE TABLE "streaming_servers" (
	"id" serial PRIMARY KEY NOT NULL,
	"server_name" varchar(255) NOT NULL,
	"domain_name" varchar(255) NOT NULL,
	"server_ip" varchar(255),
	"datacenter" text,
	"vpn_ip" varchar(255) DEFAULT '',
	"ssh_password" text,
	"ssh_port" integer,
	"diff_time_main" integer DEFAULT 0 NOT NULL,
	"http_broadcast_port" integer DEFAULT 8080 NOT NULL,
	"total_clients" integer DEFAULT 0 NOT NULL,
	"system_os" varchar(255),
	"network_interface" varchar(255) DEFAULT '',
	"latency" real DEFAULT 0 NOT NULL,
	"status" integer DEFAULT -1 NOT NULL,
	"enable_geoip" integer DEFAULT 0 NOT NULL,
	"geoip_countries" text DEFAULT '',
	"last_check_ago" integer DEFAULT 0 NOT NULL,
	"can_delete" integer DEFAULT 1 NOT NULL,
	"server_hardware" text DEFAULT '',
	"total_services" integer DEFAULT 3 NOT NULL,
	"persistent_connections" integer DEFAULT 0 NOT NULL,
	"rtmp_port" integer DEFAULT 8001 NOT NULL,
	"geoip_type" varchar(13) DEFAULT 'low_priority' NOT NULL,
	"isp_names" text DEFAULT '',
	"isp_type" varchar(13) DEFAULT 'low_priority' NOT NULL,
	"enable_isp" integer DEFAULT 0 NOT NULL,
	"boost_fpm" integer DEFAULT 0 NOT NULL,
	"http_ports_add" text DEFAULT '',
	"network_guaranteed_speed" integer DEFAULT 0 NOT NULL,
	"https_broadcast_port" integer DEFAULT 25463 NOT NULL,
	"https_ports_add" text DEFAULT '',
	"whitelist_ips" text DEFAULT '',
	"watchdog_data" text DEFAULT '',
	"timeshift_only" integer DEFAULT 0 NOT NULL,
	"http_isp_port" integer DEFAULT 8805 NOT NULL,
	"enable_duplex" integer DEFAULT 0 NOT NULL,
	"https_enable_disable" integer DEFAULT 0 NOT NULL,
	"server_provider" text,
	"server_pass" text,
	"server_mail" text,
	"server_country" text,
	"server_url" text,
	"mag_portal" varchar(255) DEFAULT '',
	"http_panel_port" varchar(255) DEFAULT '',
	"proxy_enable" integer DEFAULT 0 NOT NULL,
	"proxy_data" text DEFAULT '',
	"proxy_ip" varchar(255),
	"position" integer DEFAULT 0 NOT NULL,
	"is_main" integer DEFAULT 0 NOT NULL
);
--> statement-breakpoint
CREATE TABLE "streams" (
	"id" serial PRIMARY KEY NOT NULL,
	"type" integer NOT NULL,
	"category_id" integer,
	"stream_display_name" text NOT NULL,
	"stream_source" text,
	"stream_icon" text DEFAULT '',
	"notes" text,
	"created_channel_location" integer,
	"enable_transcode" integer DEFAULT 0 NOT NULL,
	"transcode_attributes" text DEFAULT '',
	"custom_ffmpeg" text DEFAULT '',
	"movie_propeties" text,
	"movie_subtitles" text DEFAULT '',
	"read_native" integer DEFAULT 1 NOT NULL,
	"target_container" text,
	"stream_all" integer DEFAULT 0 NOT NULL,
	"remove_subtitles" integer DEFAULT 0 NOT NULL,
	"custom_sid" varchar(150),
	"epg_id" integer,
	"channel_id" varchar(255),
	"epg_lang" varchar(255),
	"order" integer DEFAULT 0 NOT NULL,
	"auto_restart" text DEFAULT '',
	"transcode_profile_id" integer DEFAULT 0 NOT NULL,
	"pids_create_channel" text DEFAULT '',
	"cchannel_rsources" text DEFAULT '',
	"gen_timestamps" integer DEFAULT 1 NOT NULL,
	"added" integer NOT NULL,
	"series_no" integer DEFAULT 0 NOT NULL,
	"direct_source" integer DEFAULT 0 NOT NULL,
	"tv_archive_duration" integer DEFAULT 0 NOT NULL,
	"tv_archive_server_id" integer DEFAULT 0 NOT NULL,
	"tv_archive_pid" integer DEFAULT 0 NOT NULL,
	"movie_symlink" integer DEFAULT 0 NOT NULL,
	"redirect_stream" integer DEFAULT 0 NOT NULL,
	"rtmp_output" integer DEFAULT 0 NOT NULL,
	"number" integer DEFAULT 0 NOT NULL,
	"allow_record" integer DEFAULT 0 NOT NULL,
	"probesize_ondemand" integer DEFAULT 512000 NOT NULL,
	"custom_map" text DEFAULT '',
	"external_push" text DEFAULT '',
	"delay_minutes" integer DEFAULT 0 NOT NULL,
	"shortcut" varchar(255),
	"not_allow_restream" integer DEFAULT 0 NOT NULL,
	"cc_info" text,
	"cc_epg" varchar(300),
	"no_restream_users" text DEFAULT '',
	"allow_restream_users" text DEFAULT '',
	"dash_restart" integer DEFAULT 0,
	"dash_provider" text,
	"decryption_key" varchar(255)
);
--> statement-breakpoint
CREATE TABLE "streams_arguments" (
	"id" serial PRIMARY KEY NOT NULL,
	"argument_cat" varchar(255) NOT NULL,
	"argument_name" varchar(255) NOT NULL,
	"argument_cmd" varchar(255) DEFAULT '' NOT NULL,
	"argument_type" varchar(255) DEFAULT 'text' NOT NULL,
	"argument_options" text
);
--> statement-breakpoint
CREATE TABLE "streams_copy" (
	"id" serial PRIMARY KEY NOT NULL,
	"type" integer NOT NULL,
	"category_id" integer,
	"stream_display_name" text NOT NULL,
	"stream_source" text,
	"stream_icon" text DEFAULT '',
	"notes" text
);
--> statement-breakpoint
CREATE TABLE "streams_options" (
	"id" serial PRIMARY KEY NOT NULL,
	"stream_id" integer NOT NULL,
	"argument_id" integer NOT NULL,
	"value" text
);
--> statement-breakpoint
CREATE TABLE "streams_providers" (
	"provider_id" serial PRIMARY KEY NOT NULL,
	"provider_name" varchar(255) NOT NULL,
	"provider_dns" varchar(255) NOT NULL,
	"username" varchar(100) DEFAULT '' NOT NULL,
	"password" varchar(100) DEFAULT '' NOT NULL,
	"conection" varchar(255) DEFAULT '',
	"current_conection" varchar(255) DEFAULT '',
	"owner" text DEFAULT '',
	"port" text DEFAULT '',
	"info" text DEFAULT '',
	"kontakt" text DEFAULT '',
	"json_data" text,
	"json_last_updated" integer,
	"json_streams" varchar(255),
	"legacy" integer DEFAULT 0,
	"enabled" integer DEFAULT 1,
	"hls" integer DEFAULT 0,
	"provider_ssl" integer DEFAULT 0,
	"pair_user_id" integer DEFAULT 0 NOT NULL
);
--> statement-breakpoint
CREATE TABLE "streams_providers2" (
	"provider_id" serial PRIMARY KEY NOT NULL,
	"provider_name" varchar(255) NOT NULL,
	"provider_dns" varchar(255) NOT NULL,
	"owner" varchar(100) DEFAULT '',
	"kontakt" varchar(100) DEFAULT '',
	"info" varchar(100) DEFAULT '',
	"conection" varchar(255) DEFAULT ''
);
--> statement-breakpoint
CREATE TABLE "streams_providers3" (
	"provider_id" serial PRIMARY KEY NOT NULL,
	"provider_name" varchar(255) NOT NULL,
	"provider_dns" varchar(255) NOT NULL,
	"listid" varchar(100) DEFAULT '',
	"username" varchar(100) DEFAULT '',
	"password" varchar(100) DEFAULT '',
	"conection" varchar(255) DEFAULT '',
	"cid" text DEFAULT '',
	"cld" text DEFAULT '',
	"uld" text DEFAULT ''
);
--> statement-breakpoint
CREATE TABLE "streams_providers4" (
	"provider_id" serial PRIMARY KEY NOT NULL,
	"provider_name" varchar(255) NOT NULL,
	"provider_dns" varchar(255) NOT NULL,
	"username" varchar(100) DEFAULT '',
	"password" varchar(100) DEFAULT '',
	"conection" varchar(255) DEFAULT '',
	"current_conection" varchar(255) DEFAULT '',
	"info" text DEFAULT '',
	"kontakt" text DEFAULT '',
	"owner" text DEFAULT ''
);
--> statement-breakpoint
CREATE TABLE "streams_seasons" (
	"season_id" serial PRIMARY KEY NOT NULL,
	"season_name" varchar(255) NOT NULL,
	"stream_id" integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE "streams_sys" (
	"server_stream_id" serial PRIMARY KEY NOT NULL,
	"stream_id" integer NOT NULL,
	"server_id" integer NOT NULL,
	"parent_id" integer,
	"pid" integer,
	"to_analyze" integer DEFAULT 0 NOT NULL,
	"stream_status" integer DEFAULT 0 NOT NULL,
	"stream_started" integer,
	"stream_stopped" integer,
	"stream_down" integer DEFAULT 0 NOT NULL,
	"stream_info" text DEFAULT '',
	"monitor_pid" integer,
	"current_source" text,
	"bitrate" integer,
	"progress_info" text DEFAULT '',
	"on_demand" integer DEFAULT 0 NOT NULL,
	"delay_pid" integer,
	"delay_available_at" integer,
	"manually_stopped" integer DEFAULT 0 NOT NULL
);
--> statement-breakpoint
CREATE TABLE "streams_types" (
	"type_id" serial PRIMARY KEY NOT NULL,
	"type_name" varchar(255) NOT NULL,
	"type_key" varchar(255) NOT NULL,
	"type_output" varchar(255) NOT NULL,
	"live" integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE "subreseller_setup" (
	"id" serial PRIMARY KEY NOT NULL,
	"reseller" integer DEFAULT 0 NOT NULL,
	"subreseller" integer DEFAULT 0 NOT NULL,
	"status" integer DEFAULT 1 NOT NULL,
	"dateadded" integer
);
--> statement-breakpoint
CREATE TABLE "suspicious_logs" (
	"id" serial PRIMARY KEY NOT NULL,
	"user_id" integer NOT NULL,
	"data" text DEFAULT '',
	"last_updated" integer
);
--> statement-breakpoint
CREATE TABLE "tbl_files" (
	"id" serial PRIMARY KEY NOT NULL,
	"filename" varchar(255) NOT NULL,
	"created" integer
);
--> statement-breakpoint
CREATE TABLE "tickets" (
	"id" serial PRIMARY KEY NOT NULL,
	"member_id" integer NOT NULL,
	"title" varchar(255) NOT NULL,
	"status" integer DEFAULT 1 NOT NULL,
	"admin_read" integer DEFAULT 0 NOT NULL,
	"user_read" integer DEFAULT 0 NOT NULL
);
--> statement-breakpoint
CREATE TABLE "tickets_replies" (
	"id" serial PRIMARY KEY NOT NULL,
	"ticket_id" integer NOT NULL,
	"admin_reply" integer DEFAULT 0 NOT NULL,
	"message" text DEFAULT '',
	"date" integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE "tmdb_async" (
	"id" serial PRIMARY KEY NOT NULL,
	"type" integer DEFAULT 0 NOT NULL,
	"stream_id" integer DEFAULT 0 NOT NULL,
	"status" integer DEFAULT 0 NOT NULL,
	"dateadded" integer
);
--> statement-breakpoint
CREATE TABLE "transcoding_profiles" (
	"profile_id" serial PRIMARY KEY NOT NULL,
	"profile_name" varchar(255) NOT NULL,
	"profile_options" text DEFAULT ''
);
--> statement-breakpoint
CREATE TABLE "user_activity" (
	"activity_id" serial PRIMARY KEY NOT NULL,
	"user_id" integer NOT NULL,
	"stream_id" integer NOT NULL,
	"server_id" integer NOT NULL,
	"user_agent" varchar(255),
	"user_ip" varchar(39) NOT NULL,
	"container" varchar(50) NOT NULL,
	"date_start" integer NOT NULL,
	"date_end" integer,
	"geoip_country_code" varchar(22) DEFAULT '',
	"isp" varchar(255) DEFAULT '',
	"external_device" varchar(255) DEFAULT '',
	"divergence" integer
);
--> statement-breakpoint
CREATE TABLE "user_activity_now" (
	"activity_id" serial PRIMARY KEY NOT NULL,
	"user_id" integer NOT NULL,
	"stream_id" integer NOT NULL,
	"server_id" integer NOT NULL,
	"user_agent" varchar(255),
	"user_ip" varchar(39) NOT NULL,
	"container" varchar(50) NOT NULL,
	"pid" integer,
	"date_start" integer NOT NULL,
	"date_end" integer,
	"geoip_country_code" varchar(22) DEFAULT '',
	"isp" varchar(255) DEFAULT '',
	"external_device" varchar(255) DEFAULT '',
	"divergence" integer,
	"hls_last_read" integer,
	"hls_end" integer DEFAULT 0 NOT NULL
);
--> statement-breakpoint
CREATE TABLE "user_output" (
	"id" serial PRIMARY KEY NOT NULL,
	"user_id" integer NOT NULL,
	"access_output_id" integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE "users" (
	"id" serial PRIMARY KEY NOT NULL,
	"member_id" integer,
	"username" varchar(255) NOT NULL,
	"password" varchar(255) NOT NULL,
	"exp_date" integer,
	"admin_enabled" integer DEFAULT 1 NOT NULL,
	"enabled" integer DEFAULT 1 NOT NULL,
	"admin_notes" text DEFAULT '',
	"reseller_notes" text DEFAULT '',
	"bouquet" text DEFAULT '[]',
	"max_connections" integer DEFAULT 1 NOT NULL,
	"is_restreamer" integer DEFAULT 0 NOT NULL,
	"allowed_ips" text DEFAULT '',
	"allowed_ua" text DEFAULT '',
	"is_trial" integer DEFAULT 0 NOT NULL,
	"created_at" integer NOT NULL,
	"created_by" integer DEFAULT 0 NOT NULL,
	"pair_id" integer,
	"is_mag" integer DEFAULT 0 NOT NULL,
	"is_e2" integer DEFAULT 0 NOT NULL,
	"force_server_id" integer DEFAULT 0 NOT NULL,
	"is_isplock" integer DEFAULT 0 NOT NULL,
	"as_number" varchar(30),
	"isp_desc" text,
	"forced_country" varchar(255) DEFAULT '',
	"is_stalker" integer DEFAULT 0 NOT NULL,
	"bypass_ua" integer DEFAULT 0 NOT NULL,
	"play_token" text DEFAULT '',
	"user_ip_visak" integer DEFAULT 0 NOT NULL,
	"last_online_start" integer,
	"last_online_end" integer,
	"last_online_stream_id" integer,
	"last_online_user_agent" varchar(255),
	"last_online_user_ip" varchar(39),
	"access_token" varchar(32),
	"paid" text DEFAULT '',
	"user_ip2" integer DEFAULT 0 NOT NULL,
	"bouquet_packeg" text DEFAULT '',
	"package_name" text DEFAULT '',
	"last_online_country_code" varchar(255),
	"test" integer DEFAULT 0 NOT NULL,
	"no_restream_ch" text DEFAULT '[]',
	"restream_ch" text DEFAULT '[]',
	"provider_domain" text DEFAULT ''
);
--> statement-breakpoint
CREATE TABLE "watch_categories" (
	"id" serial PRIMARY KEY NOT NULL,
	"type" varchar(16) DEFAULT '' NOT NULL,
	"category_name" varchar(255) NOT NULL
);
--> statement-breakpoint
CREATE TABLE "watch_folders" (
	"id" serial PRIMARY KEY NOT NULL,
	"folder_id" integer NOT NULL,
	"type" varchar(16) DEFAULT '' NOT NULL,
	"path" varchar(255) NOT NULL,
	"server_id" integer,
	"category_id" integer
);
--> statement-breakpoint
CREATE TABLE "watch_output" (
	"id" serial PRIMARY KEY NOT NULL,
	"type" varchar(16) DEFAULT '' NOT NULL,
	"output_id" integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE "watch_settings" (
	"id" serial PRIMARY KEY NOT NULL,
	"enabled" integer DEFAULT 0 NOT NULL,
	"sym_link" integer DEFAULT 0 NOT NULL,
	"scan_interval" integer DEFAULT 0 NOT NULL,
	"type" varchar(16) DEFAULT '' NOT NULL
);
--> statement-breakpoint
CREATE TABLE "xtream_main" (
	"id" serial PRIMARY KEY NOT NULL,
	"version" varchar(50),
	"install_date" integer
);
