import { useState, useEffect, createContext, useContext } from "react";
import { Switch, Route, useLocation } from "wouter";
import { queryClient, apiRequest, getQueryFn, clearAuthToken } from "./lib/queryClient";
import { QueryClientProvider, useQuery, useMutation } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/app-sidebar";
import { ThemeToggle } from "@/components/theme-toggle";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/dashboard";
import UsersPage from "@/pages/users";
import StreamsPage from "@/pages/streams";
import MoviesPage from "@/pages/movies";
import SeriesPage from "@/pages/series";
import CategoriesPage from "@/pages/categories";
import BouquetsPage from "@/pages/bouquets";
import ServersPage from "@/pages/servers";
import EpgPage from "@/pages/epg";
import ConnectionsPage from "@/pages/connections";
import SettingsPage from "@/pages/settings";
import SecurityPage from "@/pages/security";
import LoginPage from "@/pages/login";
import AdminsPage from "@/pages/admins";
import ResellersPage from "@/pages/resellers";
import MagDevicesPage from "@/pages/mag-devices";
import BackupPage from "@/pages/backup";
import LicensePage from "@/pages/license";
import CreditsLogPage from "@/pages/credits-log";
import ResellerProfilePage from "@/pages/reseller-profile";
import ResellerInfoPage from "@/pages/reseller-info";
import { Loader2, Plus, Play, Users, User, Settings, Database, Key, LogOut, ChevronDown } from "lucide-react";
import { PanelFooter } from "@/components/panel-footer";

type AuthUser = {
  id: string;
  username: string;
  email: string | null;
  role: string;
  credits: number;
} | null;

const AuthContext = createContext<{
  user: AuthUser;
  isLoading: boolean;
  refetch: () => void;
}>({
  user: null,
  isLoading: true,
  refetch: () => {},
});

export function useAuth() {
  return useContext(AuthContext);
}

function AuthProvider({ children }: { children: React.ReactNode }) {
  const { data: user, isLoading, refetch } = useQuery<AuthUser>({
    queryKey: ["/api/auth/me"],
    queryFn: getQueryFn({ on401: "returnNull" }),
    retry: false,
    staleTime: 0,
    refetchOnMount: true,
  });

  return (
    <AuthContext.Provider value={{ user: user || null, isLoading, refetch }}>
      {children}
    </AuthContext.Provider>
  );
}

function Router({ licenseExpired = false }: { licenseExpired?: boolean }) {
  // When license is expired, only allow access to license page
  if (licenseExpired) {
    return (
      <Switch>
        <Route path="/license" component={LicensePage} />
        <Route>{() => null}</Route>
      </Switch>
    );
  }

  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/users" component={UsersPage} />
      <Route path="/streams" component={StreamsPage} />
      <Route path="/movies" component={MoviesPage} />
      <Route path="/series" component={SeriesPage} />
      <Route path="/categories" component={CategoriesPage} />
      <Route path="/bouquets" component={BouquetsPage} />
      <Route path="/servers" component={ServersPage} />
      <Route path="/epg" component={EpgPage} />
      <Route path="/connections" component={ConnectionsPage} />
      <Route path="/settings" component={SettingsPage} />
      <Route path="/security" component={SecurityPage} />
      <Route path="/admins" component={AdminsPage} />
      <Route path="/resellers" component={ResellersPage} />
      <Route path="/mag-devices" component={MagDevicesPage} />
      <Route path="/backup" component={BackupPage} />
      <Route path="/license" component={LicensePage} />
      <Route path="/credits-log" component={CreditsLogPage} />
      <Route path="/reseller-profile" component={ResellerProfilePage} />
      <Route path="/reseller-info" component={ResellerInfoPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function AdminDropdown({ user }: { user: NonNullable<AuthUser> }) {
  const [, navigate] = useLocation();
  const { refetch } = useAuth();
  const isReseller = user.role === "reseller";

  const logoutMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", "/api/auth/logout");
    },
    onSuccess: () => {
      clearAuthToken();
      queryClient.clear();
      refetch();
    },
  });

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="sm" className="gap-2" data-testid="button-admin-menu">
          <span className="text-sm">
            Welcome back, <span className="text-orange-600 dark:text-orange-400 font-medium">{user.username}</span>
          </span>
          <ChevronDown className="h-4 w-4" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-56">
        <DropdownMenuLabel>{isReseller ? "Reseller Menu" : "Quick Actions"}</DropdownMenuLabel>
        {!isReseller && (
          <>
            <DropdownMenuItem 
              onClick={() => navigate("/users")} 
              className="text-orange-600 dark:text-orange-400 cursor-pointer"
              data-testid="menu-add-line"
            >
              <Plus className="h-4 w-4 mr-2" />
              Add Line
            </DropdownMenuItem>
            <DropdownMenuItem 
              onClick={() => navigate("/streams")} 
              className="cursor-pointer"
              data-testid="menu-add-channel"
            >
              <Play className="h-4 w-4 mr-2" />
              Add Channel
            </DropdownMenuItem>
            <DropdownMenuItem 
              onClick={() => navigate("/users")} 
              className="cursor-pointer"
              data-testid="menu-add-user"
            >
              <Users className="h-4 w-4 mr-2" />
              Add User
            </DropdownMenuItem>
            <DropdownMenuSeparator />
          </>
        )}
        <DropdownMenuItem 
          onClick={() => navigate(isReseller ? "/reseller-profile" : "/admins")} 
          className="cursor-pointer"
          data-testid="menu-user-profile"
        >
          <User className="h-4 w-4 mr-2" />
          {isReseller ? "My Profile" : "User Profile"}
        </DropdownMenuItem>
        {isReseller && (
          <DropdownMenuItem 
            onClick={() => navigate("/credits-log")} 
            className="cursor-pointer"
            data-testid="menu-credits-log"
          >
            <Database className="h-4 w-4 mr-2" />
            Credits Log
          </DropdownMenuItem>
        )}
        {!isReseller && (
          <>
            <DropdownMenuItem 
              onClick={() => navigate("/settings")} 
              className="cursor-pointer"
              data-testid="menu-general-settings"
            >
              <Settings className="h-4 w-4 mr-2" />
              General Settings
            </DropdownMenuItem>
            <DropdownMenuItem 
              onClick={() => navigate("/backup")} 
              className="cursor-pointer"
              data-testid="menu-backup-settings"
            >
              <Database className="h-4 w-4 mr-2" />
              Backup Settings
            </DropdownMenuItem>
            <DropdownMenuItem 
              onClick={() => navigate("/license")} 
              className="cursor-pointer"
              data-testid="menu-license"
            >
              <Key className="h-4 w-4 mr-2" />
              License
            </DropdownMenuItem>
          </>
        )}
        <DropdownMenuSeparator />
        <DropdownMenuItem 
          onClick={() => logoutMutation.mutate()} 
          className="text-red-600 dark:text-red-400 cursor-pointer"
          data-testid="menu-logout"
        >
          <LogOut className="h-4 w-4 mr-2" />
          Logout
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

interface LicenseStatus {
  licensed: boolean;
  licenseType?: string;
  status?: string;
  daysRemaining?: number | null;
  requiresActivation?: boolean;
}

function LicenseExpiredView() {
  return (
    <div className="flex h-screen w-full flex-col bg-background">
      <header className="flex items-center justify-between gap-4 px-4 h-14 border-b border-border bg-background shrink-0">
        <div className="flex items-center gap-2">
          <Key className="h-5 w-5 text-red-500" />
          <span className="font-semibold text-red-600 dark:text-red-400">License Expired</span>
        </div>
        <ThemeToggle />
      </header>
      <main className="flex-1 overflow-auto p-6">
        <div className="max-w-2xl mx-auto">
          <div className="text-center mb-8">
            <div className="w-20 h-20 mx-auto rounded-full bg-red-100 dark:bg-red-900/30 flex items-center justify-center mb-4">
              <Key className="h-10 w-10 text-red-500" />
            </div>
            <h1 className="text-2xl font-bold text-red-600 dark:text-red-400 mb-2">License Expired</h1>
            <p className="text-muted-foreground">
              Your license has expired. Please contact your administrator to renew your license.
            </p>
          </div>
          <LicensePage />
        </div>
      </main>
    </div>
  );
}

function AuthenticatedApp() {
  const { user, isLoading } = useAuth();
  const [location, setLocation] = useLocation();

  // Check license status
  const { data: licenseStatus, isLoading: licenseLoading } = useQuery<LicenseStatus>({
    queryKey: ["/api/license/status"],
    enabled: !!user,
  });

  if (isLoading || (user && licenseLoading)) {
    return (
      <div className="flex items-center justify-center h-screen bg-background">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return <LoginPage />;
  }

  // Check if NO license exists at all
  const noLicense = licenseStatus && !licenseStatus.licensed;
  
  // Check if license is expired (client licenses with daysRemaining <= 0)
  const isLicenseExpired = licenseStatus && 
    licenseStatus.licensed && 
    licenseStatus.licenseType === 'client' && 
    licenseStatus.daysRemaining !== null && 
    licenseStatus.daysRemaining !== undefined &&
    licenseStatus.daysRemaining <= 0;

  // If NO license or license is expired, show license page ONLY
  if (noLicense || isLicenseExpired) {
    return <LicensePage />;
  }

  const style = {
    "--sidebar-width": "16rem",
    "--sidebar-width-icon": "3rem",
  };

  return (
    <SidebarProvider style={style as React.CSSProperties}>
      <div className="flex h-screen w-full">
        <AppSidebar />
        <div className="flex flex-col flex-1 overflow-hidden">
          <header className="flex items-center justify-between gap-4 px-4 h-14 border-b border-border bg-background shrink-0">
            <SidebarTrigger data-testid="button-sidebar-toggle" />
            <div className="flex items-center gap-2">
              <AdminDropdown user={user} />
              <ThemeToggle />
            </div>
          </header>
          <main className="flex-1 overflow-auto bg-background flex flex-col">
            <div className="flex-1">
              <Router />
            </div>
            <PanelFooter />
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <AuthProvider>
          <AuthenticatedApp />
        </AuthProvider>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
