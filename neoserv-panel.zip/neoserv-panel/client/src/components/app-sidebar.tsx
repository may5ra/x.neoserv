import { Link, useLocation } from "wouter";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";

interface Branding {
  panelName: string;
  panelLogoUrl: string;
}

function useBranding() {
  return useQuery<Branding>({
    queryKey: ["/api/branding"],
    staleTime: 0,
    refetchOnMount: true,
    refetchOnWindowFocus: true,
  });
}
import { useAuth } from "@/App";
import {
  LayoutDashboard,
  Users,
  Tv,
  Film,
  Clapperboard,
  Package,
  Server,
  Calendar,
  Settings,
  Activity,
  Radio,
  LogOut,
  Shield,
  Monitor,
  Lock,
  Key,
  CreditCard,
  User,
  Info,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
  SidebarMenuSub,
  SidebarMenuSubItem,
  SidebarMenuSubButton,
  useSidebar,
} from "@/components/ui/sidebar";
import { useIsMobile } from "@/hooks/use-mobile";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import { Badge } from "@/components/ui/badge";

const mainNavItems = [
  {
    title: "Dashboard",
    url: "/",
    icon: LayoutDashboard,
  },
  {
    title: "Users",
    url: "/users",
    icon: Users,
  },
];

const resellerNavItems = [
  {
    title: "Dashboard",
    url: "/",
    icon: LayoutDashboard,
  },
  {
    title: "Lines",
    url: "/users",
    icon: Users,
  },
  {
    title: "MAG Devices",
    url: "/mag-devices",
    icon: Monitor,
  },
  {
    title: "Credits Log",
    url: "/credits-log",
    icon: CreditCard,
  },
  {
    title: "My Info",
    url: "/reseller-info",
    icon: Info,
  },
  {
    title: "Profile",
    url: "/reseller-profile",
    icon: User,
  },
];

const streamingItems = [
  {
    title: "Live TV",
    url: "/streams",
    icon: Tv,
  },
  {
    title: "Movies",
    url: "/movies",
    icon: Film,
  },
  {
    title: "Series",
    url: "/series",
    icon: Clapperboard,
  },
  {
    title: "Categories",
    url: "/categories",
    icon: Package,
  },
];

const managementItems = [
  {
    title: "Bouquets",
    url: "/bouquets",
    icon: Package,
  },
  {
    title: "MAG Devices",
    url: "/mag-devices",
    icon: Monitor,
  },
  {
    title: "Servers",
    url: "/servers",
    icon: Server,
  },
  {
    title: "EPG",
    url: "/epg",
    icon: Calendar,
  },
];

const systemItems = [
  {
    title: "License",
    url: "/license",
    icon: Key,
  },
  {
    title: "Admins",
    url: "/admins",
    icon: Shield,
  },
  {
    title: "Resellers",
    url: "/resellers",
    icon: Users,
  },
  {
    title: "Connections",
    url: "/connections",
    icon: Activity,
  },
  {
    title: "Security",
    url: "/security",
    icon: Lock,
  },
  {
    title: "Settings",
    url: "/settings",
    icon: Settings,
  },
];

export function AppSidebar() {
  const [location] = useLocation();
  const { user } = useAuth();
  const { setOpenMobile } = useSidebar();
  const isMobile = useIsMobile();
  
  const isAdmin = user?.role === "admin";
  const isReseller = user?.role === "reseller";
  
  // Resellers have completely different navigation
  if (isReseller) {
    return <ResellerSidebar user={user} location={location} />;
  }
  
  // Admin navigation items
  const filteredStreamingItems = streamingItems;
  const filteredManagementItems = managementItems;
  const filteredSystemItems = systemItems;
  
  const logoutMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", "/api/auth/logout", {});
    },
    onSuccess: () => {
      // Clear all queries and invalidate auth to trigger re-render to login page
      queryClient.clear();
      queryClient.invalidateQueries({ queryKey: ["/api/auth/me"] });
    },
  });

  const isActive = (url: string) => {
    if (url === "/") return location === "/";
    return location.startsWith(url);
  };

  const handleNavClick = () => {
    if (isMobile) {
      setOpenMobile(false);
    }
  };

  const { data: branding } = useBranding();
  const panelName = branding?.panelName || "X NeoServ";
  const panelLogoUrl = branding?.panelLogoUrl || "";

  return (
    <Sidebar>
      <SidebarHeader className="p-4 border-b border-sidebar-border">
        <Link href="/" onClick={handleNavClick} className="flex flex-col items-center gap-2">
          {panelLogoUrl ? (
            <>
              <img src={panelLogoUrl} alt={panelName} className="h-14 w-auto object-contain" />
              <span className="text-sm font-semibold text-muted-foreground">IPTV Management</span>
            </>
          ) : (
            <>
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-orange-500 to-rose-500">
                <Radio className="h-6 w-6 text-white" />
              </div>
              <div className="flex flex-col items-center">
                <span className="text-lg font-bold tracking-tight bg-gradient-to-r from-orange-400 to-rose-400 bg-clip-text text-transparent">{panelName}</span>
                <span className="text-xs text-muted-foreground">IPTV Management</span>
              </div>
            </>
          )}
        </Link>
      </SidebarHeader>

      <SidebarContent className="p-2">
        <SidebarGroup>
          <SidebarGroupLabel className="text-xs font-medium uppercase tracking-wide text-muted-foreground px-2">
            Main
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {mainNavItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton
                    asChild
                    isActive={isActive(item.url)}
                    data-testid={`nav-${item.title.toLowerCase()}`}
                  >
                    <Link href={item.url} onClick={handleNavClick}>
                      <item.icon className="h-4 w-4" />
                      <span>{item.title}</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        {filteredStreamingItems.length > 0 && (
          <SidebarGroup>
            <SidebarGroupLabel className="text-xs font-medium uppercase tracking-wide text-muted-foreground px-2">
              Streaming
            </SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                {filteredStreamingItems.map((item) => (
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton
                      asChild
                      isActive={isActive(item.url)}
                      data-testid={`nav-${item.title.toLowerCase().replace(' ', '-')}`}
                    >
                      <Link href={item.url} onClick={handleNavClick}>
                        <item.icon className="h-4 w-4" />
                        <span>{item.title}</span>
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                ))}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        )}

        {filteredManagementItems.length > 0 && (
          <SidebarGroup>
            <SidebarGroupLabel className="text-xs font-medium uppercase tracking-wide text-muted-foreground px-2">
              Management
            </SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                {filteredManagementItems.map((item) => (
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton
                      asChild
                      isActive={isActive(item.url)}
                      data-testid={`nav-${item.title.toLowerCase()}`}
                    >
                      <Link href={item.url} onClick={handleNavClick}>
                        <item.icon className="h-4 w-4" />
                        <span>{item.title}</span>
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                ))}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        )}

        {filteredSystemItems.length > 0 && (
          <SidebarGroup>
            <SidebarGroupLabel className="text-xs font-medium uppercase tracking-wide text-muted-foreground px-2">
              System
            </SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                {filteredSystemItems.map((item) => (
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton
                      asChild
                      isActive={isActive(item.url)}
                      data-testid={`nav-${item.title.toLowerCase()}`}
                    >
                      <Link href={item.url} onClick={handleNavClick}>
                        <item.icon className="h-4 w-4" />
                        <span>{item.title}</span>
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                ))}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        )}
      </SidebarContent>

      <SidebarFooter className="p-4 border-t border-sidebar-border">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-3 min-w-0">
            <div className="flex h-9 w-9 items-center justify-center rounded-full bg-primary/10 shrink-0">
              <Users className="h-4 w-4 text-primary" />
            </div>
            <div className="flex flex-col min-w-0">
              <span className="text-sm font-medium truncate">{user?.username || "Admin"}</span>
              <span className="text-xs text-muted-foreground capitalize">{user?.role || "Admin"}</span>
            </div>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => logoutMutation.mutate()}
            disabled={logoutMutation.isPending}
            data-testid="button-logout"
          >
            <LogOut className="h-4 w-4" />
          </Button>
        </div>
      </SidebarFooter>
    </Sidebar>
  );
}

function ResellerSidebar({ user, location }: { user: any; location: string }) {
  const { setOpenMobile } = useSidebar();
  const isMobile = useIsMobile();
  
  const logoutMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", "/api/auth/logout", {});
    },
    onSuccess: () => {
      queryClient.clear();
      queryClient.invalidateQueries({ queryKey: ["/api/auth/me"] });
    },
  });

  const isActive = (url: string) => {
    if (url === "/") return location === "/";
    return location.startsWith(url);
  };

  const handleNavClick = () => {
    if (isMobile) {
      setOpenMobile(false);
    }
  };

  const { data: branding } = useBranding();
  const panelName = branding?.panelName || "X NeoServ";
  const panelLogoUrl = branding?.panelLogoUrl || "";

  return (
    <Sidebar>
      <SidebarHeader className="p-4 border-b border-sidebar-border">
        <Link href="/" onClick={handleNavClick} className="flex flex-col items-center gap-2">
          {panelLogoUrl ? (
            <>
              <img src={panelLogoUrl} alt={panelName} className="h-14 w-auto object-contain" />
              <span className="text-sm font-semibold text-muted-foreground">Reseller Panel</span>
            </>
          ) : (
            <>
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-orange-500 to-rose-500">
                <Radio className="h-6 w-6 text-white" />
              </div>
              <div className="flex flex-col items-center">
                <span className="text-lg font-bold tracking-tight bg-gradient-to-r from-orange-400 to-rose-400 bg-clip-text text-transparent">{panelName}</span>
                <span className="text-xs text-muted-foreground">Reseller Panel</span>
              </div>
            </>
          )}
        </Link>
      </SidebarHeader>

      <SidebarContent className="p-2">
        <SidebarGroup>
          <SidebarGroupLabel className="text-xs font-medium uppercase tracking-wide text-muted-foreground px-2">
            Reseller
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {resellerNavItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton
                    asChild
                    isActive={isActive(item.url)}
                    data-testid={`nav-${item.title.toLowerCase().replace(' ', '-')}`}
                  >
                    <Link href={item.url} onClick={handleNavClick}>
                      <item.icon className="h-4 w-4" />
                      <span>{item.title}</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter className="p-4 border-t border-sidebar-border">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-3 min-w-0">
            <div className="flex h-9 w-9 items-center justify-center rounded-full bg-orange-500/10 shrink-0">
              <User className="h-4 w-4 text-orange-500" />
            </div>
            <div className="flex flex-col min-w-0">
              <span className="text-sm font-medium truncate">{user?.username || "Reseller"}</span>
              <span className="text-xs text-muted-foreground">Reseller</span>
            </div>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => logoutMutation.mutate()}
            disabled={logoutMutation.isPending}
            data-testid="button-logout"
          >
            <LogOut className="h-4 w-4" />
          </Button>
        </div>
      </SidebarFooter>
    </Sidebar>
  );
}
