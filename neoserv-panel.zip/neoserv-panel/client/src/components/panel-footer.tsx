import { useQuery } from "@tanstack/react-query";

export const PANEL_VERSION = "3.0";

interface Branding {
  panelName: string;
  panelLogoUrl: string;
}

export function PanelFooter() {
  const { data: branding } = useQuery<Branding>({
    queryKey: ["/api/branding"],
    staleTime: 0,
    refetchOnMount: true,
    refetchOnWindowFocus: true,
  });
  
  const panelName = branding?.panelName || "X NeoServ";

  return (
    <footer className="mt-auto pt-6 pb-4 px-6 border-t bg-muted/30">
      <div className="text-center space-y-2">
        <p className="text-sm font-medium text-muted-foreground">
          {panelName} v{PANEL_VERSION} - Developed by NeoServSolutions
        </p>
        <p className="text-xs text-muted-foreground/70 max-w-4xl mx-auto">
          DISCLAIMER: This software is intended solely for managing legal IPTV content. 
          The developer does not provide, distribute or support illegal streaming content. 
          The user is fully responsible for the content transmitted through this software 
          and must ensure compliance with all applicable copyright and broadcasting laws 
          in their jurisdiction. The developer assumes no liability for unlawful use of this software.
        </p>
        <p className="text-xs text-muted-foreground/60">
          2025 All rights reserved. Unauthorized use is prohibited.
        </p>
      </div>
    </footer>
  );
}
