import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useState } from "react";
import {
  Search,
  Activity,
  Wifi,
  Globe,
  Tv,
  Film,
  Clapperboard,
  RefreshCw,
  Users,
  Clock,
  MapPin,
} from "lucide-react";
interface Connection {
  id: number;
  username?: string;
  streamName?: string;
  streamType?: string | null;
  ipAddress?: string;
  country?: string;
  countryCode?: string;
  dateStart?: number;
}

function formatElapsedTime(dateStart: number | null | undefined): string {
  if (!dateStart) return "0:00:00";
  const now = Math.floor(Date.now() / 1000);
  const elapsed = now - dateStart;
  if (elapsed < 0) return "0:00:00";
  
  const hours = Math.floor(elapsed / 3600);
  const minutes = Math.floor((elapsed % 3600) / 60);
  const seconds = elapsed % 60;
  
  return `${hours}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
}

export default function ConnectionsPage() {
  const [search, setSearch] = useState("");

  const { data: connections, isLoading, refetch } = useQuery<Connection[]>({
    queryKey: ["/api/connections"],
    refetchInterval: 10000,
  });

  const filteredConnections = connections?.filter(conn => 
    conn.username?.toLowerCase().includes(search.toLowerCase()) ||
    conn.streamName?.toLowerCase().includes(search.toLowerCase()) ||
    conn.ipAddress?.toLowerCase().includes(search.toLowerCase())
  );

  const liveCount = connections?.filter(c => c.streamType === "live").length || 0;
  const movieCount = connections?.filter(c => c.streamType === "movie").length || 0;
  const seriesCount = connections?.filter(c => c.streamType === "series").length || 0;

  const getStreamTypeIcon = (type: string | null | undefined) => {
    switch (type) {
      case "live": return <Tv className="h-4 w-4 text-blue-500" />;
      case "movie": return <Film className="h-4 w-4 text-purple-500" />;
      case "series": return <Clapperboard className="h-4 w-4 text-emerald-500" />;
      default: return <Wifi className="h-4 w-4 text-muted-foreground" />;
    }
  };

  const getStreamTypeBadge = (type: string | null | undefined) => {
    const variants: Record<string, "default" | "secondary" | "outline"> = {
      live: "default",
      movie: "secondary",
      series: "outline",
    };
    return (
      <Badge variant={variants[type || ""] || "outline"} className="text-xs">
        {type || "Unknown"}
      </Badge>
    );
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-3xl font-bold tracking-tight" data-testid="page-title">Live Connections</h1>
          <p className="text-muted-foreground">Monitor active streaming sessions</p>
        </div>
        <Button variant="outline" size="sm" onClick={() => refetch()} data-testid="button-refresh-connections">
          <RefreshCw className="h-4 w-4 mr-2" />
          Refresh
        </Button>
      </div>

      <div className="grid gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 rounded-lg bg-primary/10">
              <Activity className="h-5 w-5 text-primary" />
            </div>
            <div>
              <p className="text-2xl font-bold">{connections?.length || 0}</p>
              <p className="text-sm text-muted-foreground">Total Connections</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 rounded-lg bg-blue-500/10">
              <Tv className="h-5 w-5 text-blue-500" />
            </div>
            <div>
              <p className="text-2xl font-bold">{liveCount}</p>
              <p className="text-sm text-muted-foreground">Live TV</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 rounded-lg bg-purple-500/10">
              <Film className="h-5 w-5 text-purple-500" />
            </div>
            <div>
              <p className="text-2xl font-bold">{movieCount}</p>
              <p className="text-sm text-muted-foreground">Movies</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 rounded-lg bg-emerald-500/10">
              <Clapperboard className="h-5 w-5 text-emerald-500" />
            </div>
            <div>
              <p className="text-2xl font-bold">{seriesCount}</p>
              <p className="text-sm text-muted-foreground">Series</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between gap-4 pb-4">
          <CardTitle className="flex items-center gap-2">
            Active Sessions
            <Badge variant="outline" className="ml-2">
              Auto-refresh: 10s
            </Badge>
          </CardTitle>
          <div className="relative w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search connections..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-9"
              data-testid="input-search-connections"
            />
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-2">
              {Array(5).fill(0).map((_, i) => (
                <Skeleton key={i} className="h-12 w-full" />
              ))}
            </div>
          ) : filteredConnections && filteredConnections.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>User</TableHead>
                  <TableHead>Stream</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Location</TableHead>
                  <TableHead>IP Address</TableHead>
                  <TableHead>Started</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredConnections.map((connection) => (
                  <TableRow key={connection.id} data-testid={`connection-row-${connection.id}`}>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center">
                          <Users className="h-4 w-4 text-primary" />
                        </div>
                        <span className="font-medium">{connection.username}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        {getStreamTypeIcon(connection.streamType)}
                        <span className="truncate max-w-[200px]">{connection.streamName}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      {getStreamTypeBadge(connection.streamType)}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <Globe className="h-4 w-4" />
                        <span>{connection.country || connection.countryCode || "Unknown"}</span>
                      </div>
                    </TableCell>
                    <TableCell className="font-mono text-sm text-muted-foreground">
                      {connection.ipAddress}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <Clock className="h-4 w-4" />
                        <span className="text-sm">{formatElapsedTime(connection.dateStart)}</span>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <Wifi className="h-12 w-12 text-muted-foreground/50 mb-4" />
              <h3 className="text-lg font-medium mb-1">No active connections</h3>
              <p className="text-muted-foreground">Connections will appear here when users start streaming</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
