import { useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
  FormDescription,
} from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { User, Globe, Mail, Save, Loader2, Server, Info } from "lucide-react";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Alert, AlertDescription } from "@/components/ui/alert";

const profileSchema = z.object({
  email: z.string().email("Invalid email").optional().or(z.literal("")),
  resellerDns: z.string().optional().or(z.literal("")),
  notes: z.string().optional().or(z.literal("")),
});

type ProfileData = z.infer<typeof profileSchema>;

interface ResellerProfile {
  id: number;
  username: string;
  email: string;
  credits: number;
  resellerDns: string;
  notes: string;
}

export default function ResellerProfile() {
  const { toast } = useToast();

  const { data: profile, isLoading } = useQuery<ResellerProfile>({
    queryKey: ["/api/resellers/me/profile"],
  });

  const form = useForm<ProfileData>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      email: "",
      resellerDns: "",
      notes: "",
    },
  });

  useEffect(() => {
    if (profile) {
      form.reset({
        email: profile.email || "",
        resellerDns: profile.resellerDns || "",
        notes: profile.notes || "",
      });
    }
  }, [profile, form]);

  const mutation = useMutation({
    mutationFn: async (data: ProfileData) => {
      return apiRequest("PATCH", "/api/resellers/me/profile", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/resellers/me/profile"] });
      toast({
        title: "Profile updated",
        description: "Your profile has been saved successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update profile.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: ProfileData) => {
    mutation.mutate(data);
  };

  if (isLoading) {
    return (
      <div className="p-6 space-y-6">
        <div className="bg-gradient-to-r from-emerald-500 to-teal-600 rounded-lg p-6 text-white">
          <Skeleton className="h-8 w-48 bg-white/20" />
          <Skeleton className="h-4 w-64 mt-2 bg-white/20" />
        </div>
        <Card>
          <CardContent className="p-6">
            <Skeleton className="h-64 w-full" />
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <div className="bg-gradient-to-r from-emerald-500 to-teal-600 rounded-lg p-6 text-white">
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <User className="h-6 w-6" />
          Profile
        </h1>
        <p className="text-white/80 mt-1">Manage your reseller profile and DNS settings</p>
      </div>

      <Alert className="bg-blue-500/10 border-blue-500/20">
        <Info className="h-4 w-4 text-blue-500" />
        <AlertDescription className="text-blue-700 dark:text-blue-300">
          By setting up DNS, all the lines you provide your customers with are labeled with your private hostname.
          Warning! Changing DNS may cause interruptions for current users and you need to provide new URLs to them.
        </AlertDescription>
      </Alert>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <User className="h-5 w-5" />
            Account Information
          </CardTitle>
          <CardDescription>
            Username: <span className="font-semibold">{profile?.username}</span>
            <span className="mx-2">|</span>
            Credits: <span className="font-semibold text-emerald-600">{profile?.credits}</span>
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="flex items-center gap-2">
                      <Mail className="h-4 w-4" />
                      Email
                    </FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="your@email.com" 
                        {...field} 
                        data-testid="input-email"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="resellerDns"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="flex items-center gap-2">
                      <Globe className="h-4 w-4" />
                      DNS Host
                    </FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="your-dns.example.com" 
                        {...field} 
                        data-testid="input-dns"
                      />
                    </FormControl>
                    <FormDescription>
                      Custom DNS hostname for your client playlists
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="notes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Notes</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="Personal notes..." 
                        {...field} 
                        data-testid="input-notes"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <Button 
                type="submit" 
                disabled={mutation.isPending}
                data-testid="button-save-profile"
              >
                {mutation.isPending ? (
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                ) : (
                  <Save className="h-4 w-4 mr-2" />
                )}
                Save Changes
              </Button>
            </form>
          </Form>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Server className="h-5 w-5" />
            Summary
          </CardTitle>
          <CardDescription>
            Define your own DNS first (hostname and domain)
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4">
            <div className="p-4 bg-muted/50 rounded-lg">
              <p className="text-sm text-muted-foreground mb-1">Stream Hostname</p>
              <p className="font-mono text-sm">
                {profile?.resellerDns ? `http://${profile.resellerDns}:8080` : "Not configured"}
              </p>
            </div>
            <div className="p-4 bg-muted/50 rounded-lg">
              <p className="text-sm text-muted-foreground mb-1">MAG Portal</p>
              <p className="font-mono text-sm">
                {profile?.resellerDns ? `http://${profile.resellerDns}:8080/c/` : "Not configured"}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
