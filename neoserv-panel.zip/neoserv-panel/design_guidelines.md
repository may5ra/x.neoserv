# X NeoServ Control Panel - Design Guidelines

## Design Approach
**System-Based Approach**: Modern admin dashboard inspired by **Vercel Dashboard** + **Linear's** typography + **Tailwind UI's** component patterns. Focus on clarity, efficiency, and professional aesthetics for system administration.

## Typography System
- **Primary Font**: Inter (Google Fonts)
- **Monospace**: JetBrains Mono (for code/logs)
- **Hierarchy**:
  - Page titles: text-3xl font-bold
  - Section headers: text-xl font-semibold
  - Card titles: text-lg font-medium
  - Body text: text-sm
  - Labels/captions: text-xs font-medium uppercase tracking-wide

## Layout & Spacing System
**Core Spacing Units**: 2, 4, 6, 8, 12, 16, 24 (Tailwind units)
- Container padding: px-6 lg:px-8
- Card padding: p-6
- Section gaps: space-y-8
- Grid gaps: gap-6
- Form field spacing: space-y-4

**Layout Structure**:
- Fixed sidebar (w-64) with navigation tree
- Main content area (flex-1) with max-w-7xl constraint
- Top navigation bar (h-16) with breadcrumbs and user menu
- Responsive: sidebar collapses to overlay on mobile

## Component Library

### Navigation
- **Sidebar**: Multi-level collapsible tree navigation with icons, active state indicators, nested items with pl-8 indentation
- **Top Bar**: Logo, breadcrumb trail, search bar (w-96), notification bell, user dropdown menu
- **Tabs**: Underline style with active indicator, used for sub-navigation within pages

### Dashboard Cards
- **Stat Cards**: Grid of 2x2 or 4-column layout showing key metrics (CPU, RAM, Disk, Network)
- **Chart Cards**: Full-width or 2-column graphs with time range selectors
- **Action Cards**: Quick access panels with icon buttons for common tasks
- All cards: Consistent shadow-sm, rounded-lg borders

### Data Display
- **Tables**: Striped rows, sortable headers, row actions dropdown, pagination with 25/50/100 items per page
- **Lists**: Divided list items with leading icons, trailing badges, clickable rows
- **Code Blocks**: Syntax-highlighted output with copy button, line numbers for logs
- **Status Indicators**: Dot badges (running/stopped/error states) with labels

### Forms & Inputs
- **Text Inputs**: Full-width with labels above, helper text below, validation states
- **Select Dropdowns**: Native with custom styling, grouped options support
- **Toggle Switches**: For on/off settings with inline labels
- **Button Groups**: Segmented controls for related actions
- **File Upload**: Drag-and-drop zone with file list preview

### Interactive Elements
- **Action Buttons**: Primary (install/start/stop), Secondary (configure), Destructive (delete/reset)
- **Icon Buttons**: Toolbar actions (refresh, filter, export)
- **Dropdown Menus**: Context menus and batch actions
- **Modal Dialogs**: Confirmation prompts, settings panels (max-w-2xl)
- **Slide-overs**: Side panels for detailed views/forms (w-96)

### Feedback Components
- **Toast Notifications**: Top-right positioned, auto-dismiss success/error messages
- **Progress Bars**: Linear progress for operations, circular for loading states
- **Skeleton Loaders**: Content placeholders during data fetch
- **Empty States**: Centered illustrations with action CTAs when no data

### System Monitoring
- **Real-time Graphs**: Line charts for CPU/memory usage, sparklines for quick metrics
- **Log Viewers**: Scrollable terminal-style output with timestamp columns
- **Activity Timeline**: Chronological event list with timestamps and user attribution

## Specific Features Implementation

### Installation Wizard
- Multi-step form (4-5 steps) with progress indicator at top
- Each step: Card-based layout with clear instructions, validation before next
- Final step: Summary review with edit buttons

### Service Management
- Grid/list toggle view of services
- Each service card: Status badge, action buttons (start/stop/restart), resource usage metrics
- Bulk actions: Select multiple services, toolbar appears with batch operations

### Configuration Editor
- Two-pane layout: navigation tree (left), form fields (right)
- Auto-save indicator, reset to defaults button
- Grouped settings with collapsible sections

### System Logs
- Full-width table with filters (date range, severity, service)
- Search functionality with regex support
- Export to file option

## Images
**No hero images** - This is a utility dashboard. Use system icons throughout (Heroicons via CDN).

## Animations
**Minimal animations** - Only functional feedback:
- Hover states: Subtle brightness/shadow changes (150ms ease)
- Modal/drawer entry: Slide-in (200ms ease-out)
- Loading spinners: Continuous rotation for active operations
- NO scroll animations or decorative motion

## Accessibility
- All interactive elements keyboard navigable (tab order logical)
- ARIA labels on icon-only buttons
- Focus visible rings on all inputs/buttons
- High contrast text throughout (meeting WCAG AA)