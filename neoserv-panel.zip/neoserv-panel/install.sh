#!/bin/bash
set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}"
echo "╔═══════════════════════════════════════════════════════════╗"
echo "║           X NeoServ v3.0 - Panel Installation             ║"
echo "╚═══════════════════════════════════════════════════════════╝"
echo -e "${NC}"

INSTALL_DIR="/opt/neoserv"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo -e "${RED}[ERROR] Please run as root: sudo bash install.sh${NC}"
    exit 1
fi

echo -e "${YELLOW}[1/7] Checking system requirements...${NC}"

# Check and install Node.js
if ! command -v node &> /dev/null; then
    echo -e "${YELLOW}Installing Node.js 20...${NC}"
    curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
    apt-get install -y nodejs
fi

NODE_VERSION=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
if [ "$NODE_VERSION" -lt 18 ]; then
    echo -e "${YELLOW}Upgrading Node.js to v20...${NC}"
    curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
    apt-get install -y nodejs
fi
echo -e "${GREEN}Node.js: $(node -v)${NC}"

# Install PostgreSQL if needed
if ! command -v psql &> /dev/null; then
    echo -e "${YELLOW}Installing PostgreSQL...${NC}"
    apt-get update
    apt-get install -y postgresql postgresql-contrib
    systemctl enable postgresql
    systemctl start postgresql
fi
echo -e "${GREEN}PostgreSQL: installed${NC}"

echo -e "${YELLOW}[2/7] Creating installation directory...${NC}"
mkdir -p "$INSTALL_DIR"

echo -e "${YELLOW}[3/7] Copying files...${NC}"
cp -r "$SCRIPT_DIR"/* "$INSTALL_DIR/"
rm -f "$INSTALL_DIR/install.sh"

echo -e "${YELLOW}[4/7] Setting up database...${NC}"
# Generate random password
DB_PASSWORD=$(openssl rand -base64 32 | tr -dc 'a-zA-Z0-9' | head -c 24)
DB_NAME="neoserv"
DB_USER="neoserv"

# Create database and user
sudo -u postgres psql -c "DROP DATABASE IF EXISTS $DB_NAME;" 2>/dev/null || true
sudo -u postgres psql -c "DROP USER IF EXISTS $DB_USER;" 2>/dev/null || true
sudo -u postgres psql -c "CREATE USER $DB_USER WITH PASSWORD '$DB_PASSWORD';"
sudo -u postgres psql -c "CREATE DATABASE $DB_NAME OWNER $DB_USER;"
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE $DB_NAME TO $DB_USER;"

DATABASE_URL="postgresql://$DB_USER:$DB_PASSWORD@localhost:5432/$DB_NAME"
echo -e "${GREEN}Database created: $DB_NAME${NC}"

echo -e "${YELLOW}[5/7] Installing dependencies...${NC}"
cd "$INSTALL_DIR"
npm ci --omit=dev 2>/dev/null || npm install --omit=dev

echo -e "${YELLOW}[6/7] Initializing database schema...${NC}"
export DATABASE_URL="$DATABASE_URL"
npm run db:push || true

# Generate session secret
SESSION_SECRET=$(openssl rand -base64 48 | tr -dc 'a-zA-Z0-9' | head -c 64)

echo -e "${YELLOW}[7/7] Creating systemd service...${NC}"
cat > /etc/systemd/system/neoserv.service << EOF
[Unit]
Description=X NeoServ Control Panel
After=network.target postgresql.service

[Service]
Type=simple
User=root
WorkingDirectory=$INSTALL_DIR
ExecStart=/usr/bin/node $INSTALL_DIR/dist/index.cjs
Restart=always
RestartSec=10
Environment=NODE_ENV=production
Environment=PORT=5000
Environment=DATABASE_URL=$DATABASE_URL
Environment=SESSION_SECRET=$SESSION_SECRET

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable neoserv
systemctl start neoserv

# Wait for service to start
sleep 3

# Check service status
if systemctl is-active --quiet neoserv; then
    echo -e "${GREEN}"
    echo "╔═══════════════════════════════════════════════════════════╗"
    echo "║              INSTALLATION COMPLETE                        ║"
    echo "╠═══════════════════════════════════════════════════════════╣"
    echo "║                                                           ║"
    echo "║  Panel URL: http://$(hostname -I | awk '{print $1}'):5000 ║"
    echo "║                                                           ║"
    echo "║  Default Login:                                           ║"
    echo "║    Username: admin                                        ║"
    echo "║    Password: admin                                        ║"
    echo "║                                                           ║"
    echo "║  Commands:                                                ║"
    echo "║    Status:  systemctl status neoserv                      ║"
    echo "║    Logs:    journalctl -u neoserv -f                      ║"
    echo "║    Restart: systemctl restart neoserv                     ║"
    echo "║                                                           ║"
    echo "╚═══════════════════════════════════════════════════════════╝"
    echo -e "${NC}"
else
    echo -e "${RED}[ERROR] Service failed to start. Check logs:${NC}"
    echo "journalctl -u neoserv -n 50"
    journalctl -u neoserv -n 20
    exit 1
fi
