#!/bin/bash
set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

INSTALL_DIR="/opt/neoserv"
DB_NAME="neoserv"
DB_USER="neoserv"
DB_PASS=$(openssl rand -hex 16)
SESSION_SECRET=$(openssl rand -hex 32)

log() { echo -e "${GREEN}[NEOSERV]${NC} $1"; }
error() { echo -e "${RED}[ERROR]${NC} $1"; exit 1; }

echo ""
echo -e "${BLUE}╔═══════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║         X NeoServ Control Panel v3.0 - Installer          ║${NC}"
echo -e "${BLUE}╚═══════════════════════════════════════════════════════════╝${NC}"
echo ""

[[ $EUID -ne 0 ]] && error "Run as root: sudo bash install.sh"

if [ -f /etc/os-release ]; then . /etc/os-release; OS=$ID; VER=$VERSION_ID; else error "Cannot detect OS"; fi
log "Detected: $OS $VER"

case $OS in ubuntu|debian) ;; *) error "Unsupported OS. Use Ubuntu 20.04+ or Debian 11+" ;; esac

log "Updating system..."
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq && apt-get upgrade -y -qq

log "Installing dependencies..."
apt-get -y -qq install curl wget gnupg2 ca-certificates lsb-release build-essential git unzip ffmpeg

log "Installing Node.js 20..."
if ! command -v node &> /dev/null || [[ $(node -v | cut -d'v' -f2 | cut -d'.' -f1) -lt 20 ]]; then
    curl -fsSL https://deb.nodesource.com/setup_20.x | bash - > /dev/null 2>&1
    apt-get -y -qq install nodejs
fi
log "Node.js $(node -v) installed"

log "Installing PostgreSQL..."
apt-get -y -qq install postgresql postgresql-contrib 2>/dev/null || true
systemctl start postgresql && systemctl enable postgresql
sleep 2

log "Setting up database..."
sudo -u postgres psql -c "DROP DATABASE IF EXISTS $DB_NAME;" 2>/dev/null || true
sudo -u postgres psql -c "DROP USER IF EXISTS $DB_USER;" 2>/dev/null || true
sudo -u postgres psql -c "CREATE USER $DB_USER WITH PASSWORD '$DB_PASS';"
sudo -u postgres psql -c "CREATE DATABASE $DB_NAME OWNER $DB_USER;"
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE $DB_NAME TO $DB_USER;"

log "Setting up installation directory..."
rm -rf $INSTALL_DIR && mkdir -p $INSTALL_DIR
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cp -r "$SCRIPT_DIR"/* $INSTALL_DIR/
rm -f $INSTALL_DIR/install.sh
cd $INSTALL_DIR

log "Creating environment..."
cat > .env << EOF
DATABASE_URL=postgresql://$DB_USER:$DB_PASS@localhost:5432/$DB_NAME
SESSION_SECRET=$SESSION_SECRET
NODE_ENV=production
PORT=5000
EOF

log "Installing npm packages (this takes a few minutes)..."
npm install --legacy-peer-deps 2>&1 | tail -3

log "Building application..."
npm run build 2>&1 | tail -3

log "Setting up database schema..."
npm run db:push 2>&1 | tail -2 || npm run db:push --force 2>&1 | tail -2

log "Creating systemd service..."
cat > /etc/systemd/system/neoserv.service << EOF
[Unit]
Description=X NeoServ Control Panel
After=network.target postgresql.service

[Service]
Type=simple
User=root
WorkingDirectory=$INSTALL_DIR
ExecStart=/usr/bin/node $INSTALL_DIR/dist/index.js
Restart=always
RestartSec=5
Environment=NODE_ENV=production
EnvironmentFile=$INSTALL_DIR/.env

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload && systemctl enable neoserv && systemctl start neoserv
ufw allow 5000/tcp 2>/dev/null || true
sleep 3

SERVER_IP=$(curl -s ifconfig.me 2>/dev/null || hostname -I | awk '{print $1}')

echo ""
echo -e "${GREEN}╔═══════════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║           Installation Complete!                          ║${NC}"
echo -e "${GREEN}╚═══════════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "  ${BLUE}Panel URL:${NC}      http://$SERVER_IP:5000"
echo -e "  ${BLUE}Admin Login:${NC}    admin / admin123"
echo ""
echo -e "  ${YELLOW}Database:${NC} $DB_NAME / $DB_USER / $DB_PASS"
echo ""
echo -e "  ${YELLOW}Commands:${NC}"
echo -e "    systemctl status neoserv"
echo -e "    systemctl restart neoserv"
echo -e "    journalctl -u neoserv -f"
echo ""

cat > $INSTALL_DIR/credentials.txt << EOF
Panel URL: http://$SERVER_IP:5000
Admin: admin / admin123
Database: $DB_NAME / $DB_USER / $DB_PASS
EOF
chmod 600 $INSTALL_DIR/credentials.txt
log "Credentials saved to $INSTALL_DIR/credentials.txt"
