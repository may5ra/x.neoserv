#!/bin/bash
set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

echo -e "${BLUE}"
echo "╔═══════════════════════════════════════════════════════════╗"
echo "║           X NeoServ v3.0 - Panel Installation             ║"
echo "╚═══════════════════════════════════════════════════════════╝"
echo -e "${NC}"

INSTALL_DIR="/opt/neoserv"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
CREDS_FILE="/root/.neoserv-credentials"

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo -e "${RED}[ERROR] Please run as root: sudo bash install.sh${NC}"
    exit 1
fi

echo -e "${YELLOW}[1/8] Checking system requirements...${NC}"

# Check and install Node.js
if ! command -v node &> /dev/null; then
    echo -e "${YELLOW}Installing Node.js 20...${NC}"
    curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
    apt-get install -y nodejs
fi

NODE_VERSION=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
if [ "$NODE_VERSION" -lt 18 ]; then
    echo -e "${YELLOW}Upgrading Node.js to v20...${NC}"
    curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
    apt-get install -y nodejs
fi
echo -e "${GREEN}Node.js: $(node -v)${NC}"

# Install PostgreSQL if needed
if ! command -v psql &> /dev/null; then
    echo -e "${YELLOW}Installing PostgreSQL...${NC}"
    apt-get update
    apt-get install -y postgresql postgresql-contrib
    systemctl enable postgresql
    systemctl start postgresql
fi
echo -e "${GREEN}PostgreSQL: installed${NC}"

echo -e "${YELLOW}[2/8] Creating installation directory...${NC}"
mkdir -p "$INSTALL_DIR"

echo -e "${YELLOW}[3/8] Copying files...${NC}"
cp -r "$SCRIPT_DIR"/* "$INSTALL_DIR/"
rm -f "$INSTALL_DIR/install.sh"

echo -e "${YELLOW}[4/8] Setting up database...${NC}"
# Generate secure random password
DB_PASSWORD=$(openssl rand -base64 32 | tr -dc 'a-zA-Z0-9' | head -c 24)
DB_NAME="neoserv"
DB_USER="neoserv"

# Create database and user
sudo -u postgres psql -c "DROP DATABASE IF EXISTS $DB_NAME;" 2>/dev/null || true
sudo -u postgres psql -c "DROP USER IF EXISTS $DB_USER;" 2>/dev/null || true
sudo -u postgres psql -c "CREATE USER $DB_USER WITH PASSWORD '$DB_PASSWORD';"
sudo -u postgres psql -c "CREATE DATABASE $DB_NAME OWNER $DB_USER;"
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE $DB_NAME TO $DB_USER;"

DATABASE_URL="postgresql://$DB_USER:$DB_PASSWORD@localhost:5432/$DB_NAME"
echo -e "${GREEN}Database created: $DB_NAME${NC}"

echo -e "${YELLOW}[5/8] Installing dependencies...${NC}"
cd "$INSTALL_DIR"
npm ci --omit=dev 2>/dev/null || npm install --omit=dev

echo -e "${YELLOW}[6/8] Initializing database schema...${NC}"
export DATABASE_URL="$DATABASE_URL"
npm run db:push || true

# Generate secure secrets
SESSION_SECRET=$(openssl rand -base64 48 | tr -dc 'a-zA-Z0-9' | head -c 64)
DEVELOPER_KEY=$(openssl rand -base64 32 | tr -dc 'a-zA-Z0-9' | head -c 32)

echo -e "${YELLOW}[7/8] Creating systemd service...${NC}"
cat > /etc/systemd/system/neoserv.service << EOF
[Unit]
Description=X NeoServ Control Panel
After=network.target postgresql.service

[Service]
Type=simple
User=root
WorkingDirectory=$INSTALL_DIR
ExecStart=/usr/bin/node $INSTALL_DIR/dist/index.cjs
Restart=always
RestartSec=10
Environment=NODE_ENV=production
Environment=PORT=5000
Environment=DATABASE_URL=$DATABASE_URL
Environment=SESSION_SECRET=$SESSION_SECRET
Environment=DEVELOPER_KEY=$DEVELOPER_KEY

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable neoserv

echo -e "${YELLOW}[8/8] Starting panel service...${NC}"
systemctl start neoserv

# Wait for service to start
sleep 3

# Save credentials to secure file
cat > "$CREDS_FILE" << EOF
#########################################
# X NeoServ v3.0 - Installation Credentials
# Generated: $(date)
# KEEP THIS FILE SECURE!
#########################################

DATABASE_URL=$DATABASE_URL
DATABASE_USER=$DB_USER
DATABASE_PASSWORD=$DB_PASSWORD
DATABASE_NAME=$DB_NAME
SESSION_SECRET=$SESSION_SECRET
DEVELOPER_KEY=$DEVELOPER_KEY

# Panel URL
PANEL_URL=http://$(hostname -I | awk '{print $1}'):5000

# Default admin login (change after first login!)
ADMIN_USER=admin
ADMIN_PASS=admin
EOF
chmod 600 "$CREDS_FILE"

# Get server IP
SERVER_IP=$(hostname -I | awk '{print $1}')

# Check service status
if systemctl is-active --quiet neoserv; then
    echo -e "${GREEN}"
    echo "╔═══════════════════════════════════════════════════════════════════╗"
    echo "║                   INSTALLATION COMPLETE                           ║"
    echo "╠═══════════════════════════════════════════════════════════════════╣"
    echo -e "║                                                                   ║"
    echo -e "║  ${CYAN}Panel URL:${NC} ${GREEN}http://$SERVER_IP:5000                          ${GREEN}║"
    echo -e "║                                                                   ║"
    echo -e "║  ${CYAN}FIRST LOGIN:${NC}                                                    ${GREEN}║"
    echo -e "║    1. Open panel in browser                                      ║"
    echo -e "║    2. You will see LICENSE ACTIVATION page                       ║"
    echo -e "║    3. Use Developer tab with key below to activate               ║"
    echo -e "║                                                                   ║"
    echo -e "║  ${CYAN}Developer Key:${NC} ${YELLOW}$DEVELOPER_KEY${GREEN}             ║"
    echo -e "║                                                                   ║"
    echo -e "║  ${CYAN}After license activation, login with:${NC}                          ${GREEN}║"
    echo -e "║    Username: ${YELLOW}admin${GREEN}                                               ║"
    echo -e "║    Password: ${YELLOW}admin${GREEN}                                               ║"
    echo -e "║                                                                   ║"
    echo -e "║  ${RED}IMPORTANT: Change admin password after first login!${GREEN}            ║"
    echo -e "║                                                                   ║"
    echo -e "║  ${CYAN}All credentials saved to:${NC} ${YELLOW}$CREDS_FILE${GREEN}       ║"
    echo -e "║                                                                   ║"
    echo -e "║  ${CYAN}Commands:${NC}                                                       ${GREEN}║"
    echo -e "║    Status:  systemctl status neoserv                             ║"
    echo -e "║    Logs:    journalctl -u neoserv -f                             ║"
    echo -e "║    Restart: systemctl restart neoserv                            ║"
    echo "║                                                                   ║"
    echo "╚═══════════════════════════════════════════════════════════════════╝"
    echo -e "${NC}"
else
    echo -e "${RED}[ERROR] Service failed to start. Check logs:${NC}"
    echo "journalctl -u neoserv -n 50"
    journalctl -u neoserv -n 20
    exit 1
fi
