import { pgTable, serial, text, integer, boolean, varchar, timestamp, doublePrecision, bigint, real, jsonb, primaryKey, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Stream type constants (matching streams_types)
export const STREAM_TYPE_LIVE = 1;
export const STREAM_TYPE_MOVIE = 2;
export const STREAM_TYPE_CREATED_LIVE = 3;
export const STREAM_TYPE_RADIO = 4;
export const STREAM_TYPE_SERIES = 5;

// ===============================
// ACCESS & AUTH TABLES
// ===============================

export const accessCodes = pgTable("access_codes", {
  id: serial("id").primaryKey(),
  code: varchar("code", { length: 255 }),
  type: integer("type").default(0),
  enabled: integer("enabled").default(0),
  isAdmin: text("is_admin"),
  isReseller: text("is_reseller"),
  whitelist: text("whitelist"),
});

export const accessOutput = pgTable("access_output", {
  accessOutputId: serial("access_output_id").primaryKey(),
  outputName: varchar("output_name", { length: 255 }).notNull(),
  outputKey: varchar("output_key", { length: 255 }).notNull(),
  outputExt: varchar("output_ext", { length: 255 }).notNull(),
});

export const blockedIps = pgTable("blocked_ips", {
  id: serial("id").primaryKey(),
  ip: varchar("ip", { length: 39 }).notNull(),
  notes: text("notes").notNull().default(""),
  date: integer("date").notNull(),
  attemptsBlocked: integer("attempts_blocked").notNull().default(0),
});

export const blockedUserAgents = pgTable("blocked_user_agents", {
  id: serial("id").primaryKey(),
  userAgent: varchar("user_agent", { length: 255 }).notNull(),
  exactMatch: integer("exact_match").notNull().default(0),
  attemptsBlocked: integer("attempts_blocked").notNull().default(0),
});

export const allowedIps = pgTable("allowed_ips", {
  id: serial("id").primaryKey(),
  ip: varchar("ip", { length: 39 }).notNull(),
  notes: text("notes").notNull().default(""),
  date: integer("date").notNull(),
});

export const lblock = pgTable("lblock", {
  id: serial("id").primaryKey(),
  ip: varchar("ip", { length: 45 }).notNull(),
  createdAt: integer("created_at"),
});

// Auth tokens for persistent login sessions
export const authTokens = pgTable("auth_tokens", {
  token: varchar("token", { length: 64 }).primaryKey(),
  adminId: integer("admin_id").notNull(),
  adminUsername: varchar("admin_username", { length: 50 }).notNull(),
  adminRole: varchar("admin_role", { length: 20 }).notNull(),
  expiresAt: bigint("expires_at", { mode: "number" }).notNull(),
  createdAt: bigint("created_at", { mode: "number" }).notNull(),
  ipAddress: varchar("ip_address", { length: 45 }), // Session IP binding for security
}, (table) => ({
  expiresAtIdx: index("auth_tokens_expires_at_idx").on(table.expiresAt),
  adminIdIdx: index("auth_tokens_admin_id_idx").on(table.adminId),
}));

export type AuthToken = typeof authTokens.$inferSelect;

// ===============================
// ADMIN & SETTINGS TABLES
// ===============================

export const adminSettings = pgTable("admin_settings", {
  type: varchar("type", { length: 128 }).primaryKey(),
  value: text("value").notNull().default(""),
  saveButtonUnderAndOntop: varchar("save_button_under_and_ontop", { length: 16 }).default("1"),
});

export const regUsers = pgTable("reg_users", {
  id: serial("id").primaryKey(),
  username: varchar("username", { length: 50 }).notNull(),
  password: varchar("password", { length: 255 }).notNull(),
  email: varchar("email", { length: 255 }).notNull(),
  ip: varchar("ip", { length: 255 }),
  dateRegistered: integer("date_registered").notNull(),
  verifyKey: text("verify_key"),
  lastLogin: integer("last_login"),
  memberGroupId: integer("member_group_id").notNull(),
  verified: integer("verified").notNull().default(0),
  credits: real("credits").notNull().default(0),
  notes: text("notes"),
  status: integer("status").notNull().default(1),
  defaultLang: text("default_lang").notNull(),
  resellerDns: text("reseller_dns").notNull(),
  ownerId: integer("owner_id").notNull().default(0),
  overridePackages: text("override_packages"),
  google2faSec: varchar("google_2fa_sec", { length: 50 }).notNull(),
  darkMode: integer("dark_mode").notNull().default(3),
  sidebar: integer("sidebar").notNull().default(0),
  expandedSidebar: integer("expanded_sidebar").notNull().default(0),
  topbarTheme: text("topbar_theme").notNull(),
  navigationTheme: text("navigation_theme").notNull(),
  navigationTextColor: text("navigation_text_color").notNull(),
  navigationMode: integer("navigation_mode").notNull().default(1),
  navigationCenter: integer("navigation_center").notNull().default(0),
  navigationMethode: integer("navigation_methode").notNull().default(0),
  dropbox: text("dropbox").notNull(),
}, (table) => ({
  memberGroupIdIdx: index("reg_users_member_group_id_idx").on(table.memberGroupId),
  usernameIdx: index("reg_users_username_idx").on(table.username),
  passwordIdx: index("reg_users_password_idx").on(table.password),
}));

export const regUserlog = pgTable("reg_userlog", {
  id: serial("id").primaryKey(),
  owner: integer("owner").notNull(),
  username: text("username").notNull(),
  password: text("password").notNull(),
  date: integer("date").notNull(),
  type: varchar("type", { length: 255 }).notNull(),
});

// Credit transaction log for resellers
export const creditTransactions = pgTable("credit_transactions", {
  id: serial("id").primaryKey(),
  resellerId: integer("reseller_id").notNull(),
  adminId: integer("admin_id"), // Admin who added credits (null if system/self)
  amount: real("amount").notNull(), // positive = add, negative = deduct
  type: varchar("type", { length: 50 }).notNull(), // "add", "deduct", "line_create", "mag_create", etc.
  reason: text("reason").notNull().default(""),
  balanceAfter: real("balance_after").notNull(),
  createdAt: integer("created_at").notNull(),
}, (table) => ({
  resellerIdIdx: index("credit_transactions_reseller_id_idx").on(table.resellerId),
  createdAtIdx: index("credit_transactions_created_at_idx").on(table.createdAt),
}));

export type CreditTransaction = typeof creditTransactions.$inferSelect;
export type InsertCreditTransaction = typeof creditTransactions.$inferInsert;

export const memberGroups = pgTable("member_groups", {
  groupId: serial("group_id").primaryKey(),
  groupName: text("group_name").notNull(),
  groupColor: varchar("group_color", { length: 7 }).notNull().default("#000000"),
  isBanned: integer("is_banned").notNull().default(0),
  isAdmin: integer("is_admin").notNull().default(0),
  isReseller: integer("is_reseller").notNull().default(0),
  totalAllowedGenTrials: integer("total_allowed_gen_trials").notNull().default(0),
  totalAllowedGenIn: varchar("total_allowed_gen_in", { length: 255 }).default(""),
  deleteUsers: integer("delete_users").notNull().default(0),
  allowedPages: text("allowed_pages").default(""),
  canDelete: integer("can_delete").notNull().default(1),
  resellerForceServer: integer("reseller_force_server").notNull().default(0),
  createSubResellersPrice: real("create_sub_resellers_price").notNull().default(0),
  createSubResellers: integer("create_sub_resellers").notNull().default(0),
  alterPackagesIds: integer("alter_packages_ids").notNull().default(0),
  alterPackagesPrices: integer("alter_packages_prices").notNull().default(0),
  resellerClientConnectionLogs: integer("reseller_client_connection_logs").notNull().default(0),
  resellerAssignPass: integer("reseller_assign_pass").notNull().default(0),
  allowChangePass: integer("allow_change_pass").notNull().default(0),
  allowImport: integer("allow_import").notNull().default(0),
  allowExport: integer("allow_export").notNull().default(0),
  resellerTrialCreditAllow: integer("reseller_trial_credit_allow").notNull().default(0),
  editMac: integer("edit_mac").notNull().default(0),
  editIsplock: integer("edit_isplock").notNull().default(0),
  resetStbData: integer("reset_stb_data").notNull().default(0),
  resellerBonusPackageInc: integer("reseller_bonus_package_inc").notNull().default(0),
  allowDownload: integer("allow_download").notNull().default(1),
  minimumTrialCredits: integer("minimum_trial_credits").notNull().default(0),
  resellerControlsStreams: integer("reseller_controls_streams").notNull().default(0),
  resellerCanSelectBouquets: integer("reseller_can_select_bouquets").notNull().default(0),
  allowChangeBouquets: integer("allow_change_bouquets").notNull().default(0),
  allowChangeRestrictions: integer("allow_change_restrictions").notNull().default(0),
  disableTrial: integer("disable_trial").notNull().default(0),
  changeOwnDns: integer("change_own_dns").notNull().default(0),
  changeUsernames: integer("change_usernames").notNull().default(0),
  changePasswords: integer("change_passwords").notNull().default(0),
  changeOwnEmail: integer("change_own_email").notNull().default(0),
  resellerDashboardMessage: text("reseller_dashboard_message").default(""),
  dashboardMessageActive: integer("dashboard_message_active").notNull().default(0),
  clearIsp: integer("clear_isp").notNull().default(0),
  allowIspLock: integer("allow_isp_lock").notNull().default(0),
  canDeleteUsers: integer("can_delete_users").notNull().default(0),
  canSendMagEvent: integer("can_send_mag_event").notNull().default(0),
  canEdit: integer("can_edit").notNull().default(0),
  allowClearDeviceInfos: integer("allow_clear_device_infos").notNull().default(0),
  resellerUploadsVod: integer("reseller_uploads_vod").notNull().default(0),
  resellerRestartsStreams: integer("reseller_restarts_streams").notNull().default(0),
});

export const resellerCredentials = pgTable("reseller_credentials", {
  id: serial("id").primaryKey(),
  memberId: varchar("member_id", { length: 30 }),
  apiKey: varchar("api_key", { length: 100 }).notNull(),
  ipAllow: varchar("ip_allow", { length: 30 }),
});

export const resellerImex = pgTable("reseller_imex", {
  id: serial("id").primaryKey(),
  regId: integer("reg_id").notNull(),
  header: text("header").notNull(),
  data: text("data").notNull(),
  accepted: integer("accepted").notNull().default(0),
  finished: integer("finished").notNull().default(0),
  bouquetIds: text("bouquet_ids").default(""),
});

export const resellerNews = pgTable("reseller_news", {
  newsId: serial("news_id").primaryKey(),
  newsTitle: varchar("news_title", { length: 255 }).notNull(),
  newsBody: varchar("news_body", { length: 255 }).notNull(),
});

export const resellerInfo = pgTable("reseller_info", {
  id: serial("id").primaryKey(),
  value: varchar("value", { length: 255 }).notNull().default(""),
  valueInfo: varchar("value_info", { length: 255 }).notNull().default(""),
  type: varchar("type", { length: 255 }),
});

export const subreseller_setup = pgTable("subreseller_setup", {
  id: serial("id").primaryKey(),
  reseller: integer("reseller").notNull().default(0),
  subreseller: integer("subreseller").notNull().default(0),
  status: integer("status").notNull().default(1),
  dateadded: integer("dateadded"),
});

// ===============================
// USERS TABLE (IPTV Subscribers)
// ===============================

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  memberId: integer("member_id"),
  username: varchar("username", { length: 255 }).notNull(),
  password: varchar("password", { length: 255 }).notNull(),
  expDate: integer("exp_date"),
  adminEnabled: integer("admin_enabled").notNull().default(1),
  enabled: integer("enabled").notNull().default(1),
  adminNotes: text("admin_notes").notNull(),
  resellerNotes: text("reseller_notes").notNull(),
  bouquet: text("bouquet").notNull(),
  maxConnections: integer("max_connections").notNull().default(1),
  isRestreamer: integer("is_restreamer").notNull().default(0),
  allowedIps: text("allowed_ips").notNull(),
  allowedUa: text("allowed_ua").notNull(),
  isTrial: integer("is_trial").notNull().default(0),
  createdAt: integer("created_at").notNull(),
  createdBy: integer("created_by").notNull(),
  pairId: integer("pair_id"),
  isMag: integer("is_mag").notNull().default(0),
  isE2: integer("is_e2").notNull().default(0),
  forceServerId: integer("force_server_id").notNull().default(0),
  isIsplock: integer("is_isplock").notNull().default(0),
  asNumber: varchar("as_number", { length: 30 }),
  ispDesc: text("isp_desc"),
  forcedCountry: varchar("forced_country", { length: 255 }).notNull(),
  isStalker: integer("is_stalker").notNull().default(0),
  bypassUa: integer("bypass_ua").notNull().default(0),
  playToken: text("play_token").notNull(),
  userIpVisak: integer("user_ip_visak").notNull().default(0),
  lastOnlineStart: integer("last_online_start"),
  lastOnlineEnd: integer("last_online_end"),
  lastOnlineStreamId: integer("last_online_stream_id"),
  lastOnlineUserAgent: varchar("last_online_user_agent", { length: 255 }),
  lastOnlineUserIp: varchar("last_online_user_ip", { length: 39 }),
  accessToken: varchar("access_token", { length: 32 }),
  paid: text("paid").notNull(),
  userIp2: integer("user_ip2").notNull().default(0),
  bouquetPackeg: text("bouquet_packeg").notNull(),
  packageName: text("package_name").notNull(),
  lastOnlineCountryCode: varchar("last_online_country_code", { length: 255 }),
  test: integer("test").notNull(),
  noRestreamCh: text("no_restream_ch").notNull().default("[]"),
  restreamCh: text("restream_ch").notNull().default("[]"),
  providerDomain: text("provider_domain").notNull(),
}, (table) => ({
  memberIdIdx: index("users_member_id_idx").on(table.memberId),
  expDateIdx: index("users_exp_date_idx").on(table.expDate),
  isRestreamerIdx: index("users_is_restreamer_idx").on(table.isRestreamer),
  adminEnabledIdx: index("users_admin_enabled_idx").on(table.adminEnabled),
  enabledIdx: index("users_enabled_idx").on(table.enabled),
  isTrialIdx: index("users_is_trial_idx").on(table.isTrial),
  createdAtIdx: index("users_created_at_idx").on(table.createdAt),
  createdByIdx: index("users_created_by_idx").on(table.createdBy),
  pairIdIdx: index("users_pair_id_idx").on(table.pairId),
  isMagIdx: index("users_is_mag_idx").on(table.isMag),
  usernameIdx: index("users_username_idx").on(table.username),
  passwordIdx: index("users_password_idx").on(table.password),
  isE2Idx: index("users_is_e2_idx").on(table.isE2),
  lastOnlineStartIdx: index("users_last_online_start_idx").on(table.lastOnlineStart),
  lastOnlineEndIdx: index("users_last_online_end_idx").on(table.lastOnlineEnd),
  lastOnlineStreamIdIdx: index("users_last_online_stream_id_idx").on(table.lastOnlineStreamId),
  lastOnlineUserAgentIdx: index("users_last_online_user_agent_idx").on(table.lastOnlineUserAgent),
  lastOnlineUserIpIdx: index("users_last_online_user_ip_idx").on(table.lastOnlineUserIp),
}));

// ===============================
// STREAMS TABLE (Live/VOD/Radio)
// ===============================

export const streams = pgTable("streams", {
  id: serial("id").primaryKey(),
  type: integer("type").notNull(),
  categoryId: integer("category_id"),
  streamDisplayName: text("stream_display_name").notNull(),
  streamSource: text("stream_source"),
  backupSources: text("backup_sources").array().default([]),
  streamIcon: text("stream_icon").notNull(),
  notes: text("notes"),
  createdChannelLocation: integer("created_channel_location"),
  enableTranscode: integer("enable_transcode").notNull().default(0),
  transcodeAttributes: text("transcode_attributes").notNull(),
  customFfmpeg: text("custom_ffmpeg").notNull(),
  moviePropeties: text("movie_propeties"),
  movieSubtitles: text("movie_subtitles").notNull(),
  readNative: integer("read_native").notNull().default(1),
  targetContainer: text("target_container"),
  streamAll: integer("stream_all").notNull().default(0),
  removeSubtitles: integer("remove_subtitles").notNull().default(0),
  customSid: varchar("custom_sid", { length: 150 }),
  epgId: integer("epg_id"),
  channelId: varchar("channel_id", { length: 255 }),
  epgLang: varchar("epg_lang", { length: 255 }),
  order: integer("order").notNull().default(0),
  autoRestart: text("auto_restart").notNull(),
  transcodeProfileId: integer("transcode_profile_id").notNull().default(0),
  pidsCreateChannel: text("pids_create_channel").notNull(),
  cchannelRsources: text("cchannel_rsources").notNull(),
  genTimestamps: integer("gen_timestamps").notNull().default(1),
  added: integer("added").notNull(),
  seriesNo: integer("series_no").notNull().default(0),
  directSource: integer("direct_source").notNull().default(0),
  tvArchiveDuration: integer("tv_archive_duration").notNull().default(0),
  tvArchiveServerId: integer("tv_archive_server_id").notNull().default(0),
  tvArchivePid: integer("tv_archive_pid").notNull().default(0),
  movieSymlink: integer("movie_symlink").notNull().default(0),
  redirectStream: integer("redirect_stream").notNull().default(0),
  rtmpOutput: integer("rtmp_output").notNull().default(0),
  number: integer("number").notNull(),
  allowRecord: integer("allow_record").notNull().default(0),
  probesizeOndemand: integer("probesize_ondemand").notNull().default(512000),
  customMap: text("custom_map").notNull(),
  externalPush: text("external_push").notNull(),
  delayMinutes: integer("delay_minutes").notNull().default(0),
  shortcut: varchar("shortcut", { length: 255 }),
  notAllowRestream: integer("not_allow_restream").notNull().default(0),
  ccInfo: text("cc_info"),
  ccEpg: varchar("cc_epg", { length: 300 }),
  noRestreamUsers: text("no_restream_users").notNull(),
  allowRestreamUsers: text("allow_restream_users").notNull(),
  dashRestart: integer("dash_restart").default(0),
  dashProvider: text("dash_provider"),
  decryptionKey: varchar("decryption_key", { length: 255 }),
  userAgent: varchar("user_agent", { length: 255 }),
  forceServerId: integer("force_server_id").notNull().default(0),
}, (table) => ({
  typeIdx: index("streams_type_idx").on(table.type),
  categoryIdIdx: index("streams_category_id_idx").on(table.categoryId),
  createdChannelLocationIdx: index("streams_created_channel_location_idx").on(table.createdChannelLocation),
  enableTranscodeIdx: index("streams_enable_transcode_idx").on(table.enableTranscode),
  readNativeIdx: index("streams_read_native_idx").on(table.readNative),
  epgIdIdx: index("streams_epg_id_idx").on(table.epgId),
  channelIdIdx: index("streams_channel_id_idx").on(table.channelId),
  transcodeProfileIdIdx: index("streams_transcode_profile_id_idx").on(table.transcodeProfileId),
  orderIdx: index("streams_order_idx").on(table.order),
  directSourceIdx: index("streams_direct_source_idx").on(table.directSource),
  rtmpOutputIdx: index("streams_rtmp_output_idx").on(table.rtmpOutput),
}));

export const streamsCopy = pgTable("streams_copy", {
  id: serial("id").primaryKey(),
  type: integer("type").notNull(),
  categoryId: integer("category_id"),
  streamDisplayName: text("stream_display_name").notNull(),
  streamSource: text("stream_source"),
  streamIcon: text("stream_icon").default(""),
  notes: text("notes"),
});

export const streamsArguments = pgTable("streams_arguments", {
  id: serial("id").primaryKey(),
  argumentCat: varchar("argument_cat", { length: 255 }).notNull(),
  argumentName: varchar("argument_name", { length: 255 }).notNull(),
  argumentCmd: varchar("argument_cmd", { length: 255 }).notNull().default(""),
  argumentType: varchar("argument_type", { length: 255 }).notNull().default("text"),
  argumentOptions: text("argument_options"),
});

export const streamsOptions = pgTable("streams_options", {
  id: serial("id").primaryKey(),
  streamId: integer("stream_id").notNull(),
  argumentId: integer("argument_id").notNull(),
  value: text("value"),
});

export const streamsSys = pgTable("streams_sys", {
  serverStreamId: serial("server_stream_id").primaryKey(),
  streamId: integer("stream_id").notNull(),
  serverId: integer("server_id").notNull(),
  parentId: integer("parent_id"),
  pid: integer("pid"),
  toAnalyze: integer("to_analyze").notNull().default(0),
  streamStatus: integer("stream_status").notNull().default(0),
  streamStarted: integer("stream_started"),
  streamStopped: integer("stream_stopped"),
  streamDown: integer("stream_down").notNull().default(0),
  streamInfo: text("stream_info").default(""),
  monitorPid: integer("monitor_pid"),
  currentSource: text("current_source"),
  activeSourceIndex: integer("active_source_index").notNull().default(0),
  lastFailoverAt: integer("last_failover_at"),
  bitrate: integer("bitrate"),
  progressInfo: text("progress_info").default(""),
  onDemand: integer("on_demand").notNull().default(0),
  delayPid: integer("delay_pid"),
  delayAvailableAt: integer("delay_available_at"),
  manuallyStopped: integer("manually_stopped").notNull().default(0),
});

export const streamsSeasons = pgTable("streams_seasons", {
  seasonId: serial("season_id").primaryKey(),
  seasonName: varchar("season_name", { length: 255 }).notNull(),
  streamId: integer("stream_id").notNull(),
});

export const streamsTypes = pgTable("streams_types", {
  typeId: serial("type_id").primaryKey(),
  typeName: varchar("type_name", { length: 255 }).notNull(),
  typeKey: varchar("type_key", { length: 255 }).notNull(),
  typeOutput: varchar("type_output", { length: 255 }).notNull(),
  live: integer("live").notNull(),
});

export const streamStats = pgTable("stream_stats", {
  id: serial("id").primaryKey(),
  streamId: integer("stream_id").notNull(),
  watchedSeconds: bigint("watched_seconds", { mode: "number" }).default(0),
  lastUpdate: integer("last_update"),
});

export const streamLogs = pgTable("stream_logs", {
  id: serial("id").primaryKey(),
  streamId: integer("stream_id").notNull(),
  serverId: integer("server_id").notNull(),
  date: integer("date").notNull(),
  error: varchar("error", { length: 500 }).notNull(),
});

// ===============================
// SERIES TABLES
// ===============================

export const series = pgTable("series", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  categoryId: integer("category_id"),
  cover: varchar("cover", { length: 255 }).default(""),
  coverBig: varchar("cover_big", { length: 255 }).default(""),
  genre: varchar("genre", { length: 255 }).default(""),
  plot: text("plot").default(""),
  cast: text("cast").default(""),
  rating: integer("rating").notNull().default(0),
  director: varchar("director", { length: 255 }).default(""),
  releaseDate: varchar("releaseDate", { length: 255 }).default(""),
  lastModified: integer("last_modified").notNull(),
  tmdbId: integer("tmdb_id").notNull().default(0),
  seasons: text("seasons").default(""),
  episodeRunTime: integer("episode_run_time").notNull().default(0),
  backdropPath: text("backdrop_path").default(""),
  youtubeTrailer: text("youtube_trailer").default(""),
});

export const seriesEpisodes = pgTable("series_episodes", {
  id: serial("id").primaryKey(),
  seasonNum: integer("season_num").notNull(),
  seriesId: integer("series_id").notNull(),
  streamId: integer("stream_id").notNull(),
  sort: integer("sort").notNull(),
});

// ===============================
// CATEGORIES & BOUQUETS
// ===============================

export const streamCategories = pgTable("stream_categories", {
  id: serial("id").primaryKey(),
  categoryType: varchar("category_type", { length: 255 }).notNull(),
  categoryName: varchar("category_name", { length: 255 }).notNull(),
  parentId: integer("parent_id").notNull().default(0),
  catOrder: integer("cat_order").notNull().default(0),
});

export const streamSubcategories = pgTable("stream_subcategories", {
  subId: serial("sub_id").primaryKey(),
  parentId: integer("parent_id").notNull(),
  subcategoryName: varchar("subcategory_name", { length: 255 }).notNull(),
});

export const bouquets = pgTable("bouquets", {
  id: serial("id").primaryKey(),
  bouquetName: text("bouquet_name").notNull(),
  bouquetChannels: text("bouquet_channels").notNull().default("[]"),
  bouquetSeries: text("bouquet_series").notNull().default("[]"),
  bouquetOrder: integer("bouquet_order").notNull().default(0),
  bouquetRestrimer: integer("bouquet_restrimer").default(0),
  bouquetStreams: text("bouquet_streams").notNull().default("[]"),
  bouquetRadios: text("bouquet_radios").notNull().default("[]"),
  bouquetMovies: text("bouquet_movies").notNull().default("[]"),
  bouquetNoRestream: integer("bouquet_no_restream").notNull().default(0),
});

export const packages = pgTable("packages", {
  id: serial("id").primaryKey(),
  packageName: varchar("package_name", { length: 255 }).notNull(),
  isTrial: integer("is_trial").notNull(),
  isOfficial: integer("is_official").notNull(),
  trialCredits: real("trial_credits").notNull(),
  officialCredits: real("official_credits").notNull(),
  trialDuration: integer("trial_duration").notNull(),
  trialDurationIn: varchar("trial_duration_in", { length: 255 }).notNull(),
  officialDuration: integer("official_duration").notNull(),
  officialDurationIn: varchar("official_duration_in", { length: 255 }).notNull(),
  groups: text("groups").default(""),
  bouquets: text("bouquets").default(""),
  canGenMag: integer("can_gen_mag").notNull().default(0),
  onlyMag: integer("only_mag").notNull().default(0),
  outputFormats: text("output_formats").default(""),
  isIsplock: integer("is_isplock").notNull().default(0),
  maxConnections: integer("max_connections").notNull().default(1),
  isRestreamer: integer("is_restreamer").notNull().default(0),
  forceServerId: integer("force_server_id").notNull().default(0),
  canGenE2: integer("can_gen_e2").notNull().default(0),
  onlyE2: integer("only_e2").notNull().default(0),
  forcedCountry: varchar("forced_country", { length: 2 }).default(""),
  lockDevice: integer("lock_device").notNull().default(0),
  isVpn: integer("is_vpn").notNull().default(0),
  vpnCredits: integer("vpn_credits").notNull().default(0),
});

// ===============================
// SERVERS
// ===============================

export const streamingServers = pgTable("streaming_servers", {
  id: serial("id").primaryKey(),
  serverName: varchar("server_name", { length: 255 }).notNull(),
  domainName: varchar("domain_name", { length: 255 }).notNull(),
  serverIp: varchar("server_ip", { length: 255 }),
  datacenter: text("datacenter"),
  vpnIp: varchar("vpn_ip", { length: 255 }).default(""),
  sshPassword: text("ssh_password"),
  sshPort: integer("ssh_port"),
  diffTimeMain: integer("diff_time_main").notNull().default(0),
  httpBroadcastPort: integer("http_broadcast_port").notNull().default(8080),
  totalClients: integer("total_clients").notNull().default(0),
  maxClients: integer("max_clients").notNull().default(1000),
  systemOs: varchar("system_os", { length: 255 }),
  networkInterface: varchar("network_interface", { length: 255 }).default(""),
  latency: real("latency").notNull().default(0),
  status: integer("status").notNull().default(-1),
  enableGeoip: integer("enable_geoip").notNull().default(0),
  geoipCountries: text("geoip_countries").default(""),
  lastCheckAgo: integer("last_check_ago").notNull().default(0),
  canDelete: integer("can_delete").notNull().default(1),
  serverHardware: text("server_hardware").default(""),
  totalServices: integer("total_services").notNull().default(3),
  persistentConnections: integer("persistent_connections").notNull().default(0),
  rtmpPort: integer("rtmp_port").notNull().default(8001),
  geoipType: varchar("geoip_type", { length: 13 }).notNull().default("low_priority"),
  ispNames: text("isp_names").default(""),
  ispType: varchar("isp_type", { length: 13 }).notNull().default("low_priority"),
  enableIsp: integer("enable_isp").notNull().default(0),
  boostFpm: integer("boost_fpm").notNull().default(0),
  httpPortsAdd: text("http_ports_add").default(""),
  networkGuaranteedSpeed: integer("network_guaranteed_speed").notNull().default(0),
  httpsBroadcastPort: integer("https_broadcast_port").notNull().default(25463),
  httpsPortsAdd: text("https_ports_add").default(""),
  networkSpeed: integer("network_speed").notNull().default(1000),
  whitelistIps: text("whitelist_ips").default(""),
  watchdogData: text("watchdog_data").default(""),
  timeshiftOnly: integer("timeshift_only").notNull().default(0),
  httpIspPort: integer("http_isp_port").notNull().default(8805),
  enableDuplex: integer("enable_duplex").notNull().default(0),
  httpsEnableDisable: integer("https_enable_disable").notNull().default(0),
  serverProvider: text("server_provider"),
  serverPass: text("server_pass"),
  serverMail: text("server_mail"),
  serverCountry: text("server_country"),
  serverUrl: text("server_url"),
  magPortal: varchar("mag_portal", { length: 255 }).default(""),
  httpPanelPort: varchar("http_panel_port", { length: 255 }).default(""),
  proxyEnable: integer("proxy_enable").notNull().default(0),
  proxyData: text("proxy_data").default(""),
  proxyIp: varchar("proxy_ip", { length: 255 }),
  position: integer("position").notNull().default(0),
  isMain: integer("is_main").notNull().default(0),
  serverToken: varchar("server_token", { length: 128 }).default(""),
});

export const serverActivity = pgTable("server_activity", {
  id: serial("id").primaryKey(),
  sourceServerId: integer("source_server_id").notNull(),
  destServerId: integer("dest_server_id").notNull(),
  streamId: integer("stream_id").notNull(),
  pid: integer("pid"),
  bandwidth: integer("bandwidth").notNull().default(0),
  dateStart: integer("date_start").notNull(),
  dateEnd: integer("date_end"),
});

// Server Installation Tasks - Track remote server setup progress
export const serverInstallTasks = pgTable("server_install_tasks", {
  id: serial("id").primaryKey(),
  serverId: integer("server_id").notNull(),
  status: varchar("status", { length: 50 }).notNull().default("pending"), // pending, running, completed, failed
  currentStep: varchar("current_step", { length: 255 }),
  totalSteps: integer("total_steps").notNull().default(10),
  completedSteps: integer("completed_steps").notNull().default(0),
  logs: text("logs").default(""),
  errorMessage: text("error_message"),
  startedAt: integer("started_at"),
  completedAt: integer("completed_at"),
  createdAt: integer("created_at").notNull(),
});

// Server Metrics - Historical resource monitoring data
export const serverMetrics = pgTable("server_metrics", {
  id: serial("id").primaryKey(),
  serverId: integer("server_id").notNull(),
  cpuUsage: real("cpu_usage").notNull().default(0),
  cpuCores: integer("cpu_cores").notNull().default(1),
  memoryUsage: real("memory_usage").notNull().default(0),
  memoryTotal: bigint("memory_total", { mode: "number" }).notNull().default(0),
  diskUsage: real("disk_usage").notNull().default(0),
  diskTotal: bigint("disk_total", { mode: "number" }).notNull().default(0),
  ioWait: real("io_wait").notNull().default(0),
  networkIn: bigint("network_in", { mode: "number" }).notNull().default(0),
  networkOut: bigint("network_out", { mode: "number" }).notNull().default(0),
  activeConnections: integer("active_connections").notNull().default(0),
  onlineStreams: integer("online_streams").notNull().default(0),
  timestamp: integer("timestamp").notNull(),
}, (table) => ({
  serverIdIdx: index("server_metrics_server_id_idx").on(table.serverId),
  timestampIdx: index("server_metrics_timestamp_idx").on(table.timestamp),
}));

// Server Domains - Multiple domains/IPs per server
export const serverDomains = pgTable("server_domains", {
  id: serial("id").primaryKey(),
  serverId: integer("server_id").notNull(),
  domainType: varchar("domain_type", { length: 20 }).notNull().default("domain"), // domain, ip, private_ip
  domainValue: varchar("domain_value", { length: 255 }).notNull(),
  isActive: integer("is_active").notNull().default(1),
  sslEnabled: integer("ssl_enabled").notNull().default(0),
  sslCert: text("ssl_cert"),
  sslKey: text("ssl_key"),
  sslExpiry: integer("ssl_expiry"),
  createdAt: integer("created_at").notNull(),
}, (table) => ({
  serverIdIdx: index("server_domains_server_id_idx").on(table.serverId),
}));

// Server Performance Settings - Separate table for detailed performance configs
export const serverPerformance = pgTable("server_performance", {
  id: serial("id").primaryKey(),
  serverId: integer("server_id").notNull().unique(),
  phpVersion: varchar("php_version", { length: 20 }).default("8.1"),
  phpServices: integer("php_services").notNull().default(20),
  rateLimitPerSecond: integer("rate_limit_per_second").notNull().default(0),
  rateLimitBurstQueue: integer("rate_limit_burst_queue").notNull().default(0),
  cpuGovernor: varchar("cpu_governor", { length: 50 }).default("performance"),
  customSysctl: text("custom_sysctl").default(""),
  disableRamdisk: integer("disable_ramdisk").notNull().default(0),
  createdAt: integer("created_at").notNull(),
  updatedAt: integer("updated_at"),
});

// ===============================
// EPG TABLES
// ===============================

export const epg = pgTable("epg", {
  id: serial("id").primaryKey(),
  epgName: varchar("epg_name", { length: 255 }).notNull(),
  epgFile: varchar("epg_file", { length: 300 }).notNull().default(""),
  integrity: varchar("integrity", { length: 255 }),
  lastUpdated: integer("last_updated"),
  daysKeep: integer("days_keep").notNull().default(7),
  data: text("data"),
  updateAuto: integer("update_auto").notNull().default(0),
});

export const epgData = pgTable("epg_data", {
  id: serial("id").primaryKey(),
  epgId: integer("epg_id").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  lang: varchar("lang", { length: 10 }).notNull(),
  start: integer("start").notNull(),
  end: integer("end"),
  description: text("description").default(""),
  channelId: varchar("channel_id", { length: 50 }).notNull(),
});

export const epgType = pgTable("epg_type", {
  deviceId: serial("device_id").primaryKey(),
  deviceName: varchar("device_name", { length: 255 }).notNull(),
  deviceKey: varchar("device_key", { length: 255 }).notNull(),
});

// ===============================
// MAG DEVICES
// ===============================

export const magDevices = pgTable("mag_devices", {
  magId: serial("mag_id").primaryKey(),
  userId: integer("user_id").notNull(),
  bright: integer("bright").notNull().default(200),
  contrast: integer("contrast").notNull().default(127),
  saturation: integer("saturation").notNull().default(127),
  aspect: text("aspect").default(""),
  videoOut: varchar("video_out", { length: 20 }).notNull().default("rca"),
  volume: integer("volume").notNull().default(50),
  playbackBufferBytes: integer("playback_buffer_bytes").notNull().default(0),
  playbackBufferSize: integer("playback_buffer_size").notNull().default(0),
  audioOut: integer("audio_out").notNull().default(1),
  mac: varchar("mac", { length: 50 }).notNull(),
  ip: varchar("ip", { length: 20 }),
  ls: varchar("ls", { length: 20 }),
  ver: varchar("ver", { length: 300 }),
  lang: varchar("lang", { length: 50 }),
  locale: varchar("locale", { length: 30 }).notNull().default("en_GB.utf8"),
  cityId: integer("city_id").default(0),
  hd: integer("hd").notNull().default(1),
  mainNotify: integer("main_notify").notNull().default(1),
  favItvOn: integer("fav_itv_on").notNull().default(0),
  nowPlayingStart: integer("now_playing_start"),
  nowPlayingType: integer("now_playing_type").notNull().default(0),
  nowPlayingContent: varchar("now_playing_content", { length: 50 }),
  timeLastPlayTv: integer("time_last_play_tv"),
  timeLastPlayVideo: integer("time_last_play_video"),
  hdContent: integer("hd_content").notNull().default(1),
  imageVersion: varchar("image_version", { length: 350 }),
  lastChangeStatus: integer("last_change_status"),
  lastStart: integer("last_start"),
  lastActive: integer("last_active"),
  keepAlive: integer("keep_alive"),
  playbackLimit: integer("playback_limit").notNull().default(3),
  screensaverDelay: integer("screensaver_delay").notNull().default(10),
  stbType: varchar("stb_type", { length: 20 }).notNull().default(""),
  sn: varchar("sn", { length: 255 }),
  lastWatchdog: integer("last_watchdog"),
  created: integer("created").notNull(),
  country: varchar("country", { length: 5 }),
  plasmaSaving: integer("plasma_saving").notNull().default(0),
  tsEnabled: integer("ts_enabled").default(0),
  tsEnableIcon: integer("ts_enable_icon").notNull().default(1),
  tsPath: varchar("ts_path", { length: 35 }),
  tsMaxLength: integer("ts_max_length").notNull().default(3600),
  tsBufferUse: varchar("ts_buffer_use", { length: 15 }).notNull().default("cyclic"),
  tsActionOnExit: varchar("ts_action_on_exit", { length: 20 }).notNull().default("no_save"),
  tsDelay: varchar("ts_delay", { length: 20 }).notNull().default("on_pause"),
  videoClock: varchar("video_clock", { length: 10 }).notNull().default("Off"),
  rtspType: integer("rtsp_type").notNull().default(4),
  rtspFlags: integer("rtsp_flags").notNull().default(0),
  stbLang: varchar("stb_lang", { length: 15 }).notNull().default("en"),
  displayMenuAfterLoading: integer("display_menu_after_loading").notNull().default(1),
  recordMaxLength: integer("record_max_length").notNull().default(180),
  plasmaSavingTimeout: integer("plasma_saving_timeout").notNull().default(600),
  nowPlayingLinkId: integer("now_playing_link_id"),
  nowPlayingStreamerId: integer("now_playing_streamer_id"),
  deviceId: varchar("device_id", { length: 255 }),
  deviceId2: varchar("device_id2", { length: 255 }),
  hwVersion: varchar("hw_version", { length: 255 }),
  parentPassword: varchar("parent_password", { length: 20 }).notNull().default("0000"),
  spdifMode: integer("spdif_mode").notNull().default(1),
  showAfterLoading: varchar("show_after_loading", { length: 60 }).notNull().default("main_menu"),
  playInPreviewByOk: integer("play_in_preview_by_ok").notNull().default(1),
  hdmiEventReaction: integer("hdmi_event_reaction").notNull().default(1),
  magPlayer: varchar("mag_player", { length: 20 }).default("ffmpeg"),
  playInPreviewOnlyByOk: varchar("play_in_preview_only_by_ok", { length: 10 }).notNull().default("true"),
  watchdogTimeout: integer("watchdog_timeout").notNull().default(0),
  favChannels: text("fav_channels").default(""),
  tvArchiveContinued: text("tv_archive_continued").default(""),
  tvChannelDefaultAspect: varchar("tv_channel_default_aspect", { length: 255 }).notNull().default("fit"),
  lastItvId: integer("last_itv_id").notNull().default(0),
  units: varchar("units", { length: 20 }).default("metric"),
  token: varchar("token", { length: 32 }).default(""),
  lockDevice: integer("lock_device").notNull().default(0),
  secretKey: varchar("secret_key", { length: 128 }).notNull().default(""),
  bouquetIds: text("bouquet_ids").default("[]"),
  expiry: varchar("expiry", { length: 20 }),
  isTrial: integer("is_trial").notNull().default(0),
  adminNotes: text("admin_notes").default(""),
  resellerNotes: text("reseller_notes").default(""),
  lockToIsp: integer("lock_to_isp").notNull().default(0),
});

export const magClaims = pgTable("mag_claims", {
  id: serial("id").primaryKey(),
  magId: integer("mag_id").notNull(),
  streamId: integer("stream_id").notNull(),
  realType: varchar("real_type", { length: 10 }).notNull(),
  date: integer("date").notNull(),
});

export const magEvents = pgTable("mag_events", {
  id: serial("id").primaryKey(),
  status: integer("status").notNull().default(0),
  magDeviceId: integer("mag_device_id").notNull(),
  event: varchar("event", { length: 20 }).notNull(),
  needConfirm: integer("need_confirm").notNull().default(0),
  msg: text("msg").default(""),
  rebootAfterOk: integer("reboot_after_ok").notNull().default(0),
  autoHideTimeout: integer("auto_hide_timeout").default(0),
  sendTime: integer("send_time").notNull(),
  additionalServicesOn: integer("additional_services_on").notNull().default(1),
  anec: integer("anec").notNull().default(0),
  vclub: integer("vclub").notNull().default(0),
});

export const magLogs = pgTable("mag_logs", {
  id: serial("id").primaryKey(),
  magId: integer("mag_id"),
  action: varchar("action", { length: 255 }).notNull(),
});

// ===============================
// ENIGMA2 TABLES
// ===============================

export const enigma2Actions = pgTable("enigma2_actions", {
  id: serial("id").primaryKey(),
  deviceId: integer("device_id").notNull(),
  type: text("type").notNull(),
  key: text("key").notNull(),
  command: text("command").notNull(),
  command2: text("command2").notNull(),
});

export const enigma2Devices = pgTable("enigma2_devices", {
  deviceId: serial("device_id").primaryKey(),
  mac: varchar("mac", { length: 255 }).notNull(),
  userId: integer("user_id").notNull(),
  modemMac: varchar("modem_mac", { length: 255 }).default(""),
  localIp: varchar("local_ip", { length: 255 }).default(""),
  publicIp: varchar("public_ip", { length: 255 }).default(""),
  keyAuth: varchar("key_auth", { length: 255 }).default(""),
  enigmaVersion: varchar("enigma_version", { length: 255 }).default(""),
  cpu: varchar("cpu", { length: 255 }).default(""),
  version: varchar("version", { length: 255 }).default(""),
  lversion: text("lversion").default(""),
  token: varchar("token", { length: 32 }).default(""),
  lastUpdated: integer("last_updated").notNull(),
  watchdogTimeout: integer("watchdog_timeout").notNull().default(0),
  lockDevice: integer("lock_device").notNull().default(0),
  telnetEnable: integer("telnet_enable").notNull().default(1),
  ftpEnable: integer("ftp_enable").notNull().default(1),
  sshEnable: integer("ssh_enable").notNull().default(1),
  dns: varchar("dns", { length: 255 }).default(""),
  originalMac: varchar("original_mac", { length: 255 }).default(""),
  rc: integer("rc").notNull().default(1),
});

export const enigma2Failed = pgTable("enigma2_failed", {
  id: serial("id").primaryKey(),
  originalMac: varchar("original_mac", { length: 255 }).notNull(),
  virtualMac: varchar("virtual_mac", { length: 255 }).notNull(),
  date: integer("date").notNull(),
});

// ===============================
// USER ACTIVITY TABLES
// ===============================

export const userActivity = pgTable("user_activity", {
  activityId: serial("activity_id").primaryKey(),
  userId: integer("user_id").notNull(),
  streamId: integer("stream_id").notNull(),
  serverId: integer("server_id").notNull(),
  userAgent: varchar("user_agent", { length: 255 }),
  userIp: varchar("user_ip", { length: 39 }).notNull(),
  container: varchar("container", { length: 50 }).notNull(),
  dateStart: integer("date_start").notNull(),
  dateEnd: integer("date_end"),
  geoipCountryCode: varchar("geoip_country_code", { length: 22 }).default(""),
  isp: varchar("isp", { length: 255 }).default(""),
  externalDevice: varchar("external_device", { length: 255 }).default(""),
  divergence: integer("divergence"),
});

export const userActivityNow = pgTable("user_activity_now", {
  activityId: serial("activity_id").primaryKey(),
  userId: integer("user_id").notNull(),
  streamId: integer("stream_id").notNull(),
  serverId: integer("server_id").notNull(),
  userAgent: varchar("user_agent", { length: 255 }),
  userIp: varchar("user_ip", { length: 39 }).notNull(),
  container: varchar("container", { length: 50 }).notNull(),
  pid: integer("pid"),
  dateStart: integer("date_start").notNull(),
  dateEnd: integer("date_end"),
  geoipCountryCode: varchar("geoip_country_code", { length: 22 }).default(""),
  isp: varchar("isp", { length: 255 }).default(""),
  externalDevice: varchar("external_device", { length: 255 }).default(""),
  divergence: integer("divergence"),
  hlsLastRead: integer("hls_last_read"),
  hlsEnd: integer("hls_end").notNull().default(0),
});

export const userOutput = pgTable("user_output", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  accessOutputId: integer("access_output_id").notNull(),
});

// ===============================
// LOGS TABLES
// ===============================

export const panelLogs = pgTable("panel_logs", {
  id: serial("id").primaryKey(),
  logMessage: text("log_message").notNull(),
  date: integer("date").notNull(),
  logType: varchar("log_type", { length: 50 }),
  logData: text("log_data"),
  ownerId: integer("owner_id"),
  ownerType: varchar("owner_type", { length: 50 }),
});

export const clientLogs = pgTable("client_logs", {
  id: serial("id").primaryKey(),
  streamId: integer("stream_id"),
  userId: integer("user_id"),
  clientStatus: varchar("client_status", { length: 255 }).notNull(),
  queryString: text("query_string").default(""),
  userAgent: varchar("user_agent", { length: 255 }).default(""),
  ip: varchar("ip", { length: 255 }).default(""),
  extraData: text("extra_data").default(""),
  date: integer("date").notNull(),
});

export const loginLogs = pgTable("login_logs", {
  id: serial("id").primaryKey(),
  userId: integer("user_id"),
  data: text("data").default(""),
  loginIp: varchar("login_ip", { length: 255 }).default(""),
  date: integer("date").notNull(),
});

export const loginFlood = pgTable("login_flood", {
  id: serial("id").primaryKey(),
  username: varchar("username", { length: 128 }).notNull().default(""),
  ip: varchar("ip", { length: 64 }).notNull().default(""),
  dateadded: integer("dateadded"),
});

export const loginUsers = pgTable("login_users", {
  id: serial("id").primaryKey(),
  owner: integer("owner").notNull(),
  date: integer("date").notNull(),
  loginIp: varchar("login_ip", { length: 255 }).default(""),
  type: varchar("type", { length: 255 }).default(""),
});

export const suspiciousLogs = pgTable("suspicious_logs", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  data: text("data").default(""),
  lastUpdated: integer("last_updated"),
});

export const restartLogs = pgTable("restart_logs", {
  id: serial("id").primaryKey(),
  logMessage: text("log_message").notNull(),
  date: integer("date").notNull(),
});

// ===============================
// DEVICES & TRANSCODING
// ===============================

export const devices = pgTable("devices", {
  deviceId: serial("device_id").primaryKey(),
  deviceName: varchar("device_name", { length: 255 }).notNull(),
  deviceKey: varchar("device_key", { length: 255 }).notNull(),
  deviceFilename: varchar("device_filename", { length: 255 }).notNull(),
  deviceHeader: text("device_header").default(""),
  deviceConf: text("device_conf").default(""),
  deviceFooter: text("device_footer").default(""),
  defaultOutput: integer("default_output").notNull().default(0),
  copyText: text("copy_text"),
});

export const transcodingProfiles = pgTable("transcoding_profiles", {
  profileId: serial("profile_id").primaryKey(),
  profileName: varchar("profile_name", { length: 255 }).notNull(),
  profileOptions: text("profile_options").default(""),
});

export const movieContainers = pgTable("movie_containers", {
  containerId: serial("container_id").primaryKey(),
  containerExtension: varchar("container_extension", { length: 255 }).notNull(),
  containerHeader: varchar("container_header", { length: 255 }).notNull(),
});

// ===============================
// PROVIDERS TABLES
// ===============================

export const streamsProviders = pgTable("streams_providers", {
  providerId: serial("provider_id").primaryKey(),
  providerName: varchar("provider_name", { length: 255 }).notNull(),
  providerDns: varchar("provider_dns", { length: 255 }).notNull(),
  username: varchar("username", { length: 100 }).notNull().default(""),
  password: varchar("password", { length: 100 }).notNull().default(""),
  conection: varchar("conection", { length: 255 }).default(""),
  currentConection: varchar("current_conection", { length: 255 }).default(""),
  owner: text("owner").default(""),
  port: text("port").default(""),
  info: text("info").default(""),
  kontakt: text("kontakt").default(""),
  jsonData: text("json_data"),
  jsonLastUpdated: integer("json_last_updated"),
  jsonStreams: varchar("json_streams", { length: 255 }),
  legacy: integer("legacy").default(0),
  enabled: integer("enabled").default(1),
  hls: integer("hls").default(0),
  providerSsl: integer("provider_ssl").default(0),
  pairUserId: integer("pair_user_id").notNull().default(0),
});

export const streamsProviders2 = pgTable("streams_providers2", {
  providerId: serial("provider_id").primaryKey(),
  providerName: varchar("provider_name", { length: 255 }).notNull(),
  providerDns: varchar("provider_dns", { length: 255 }).notNull(),
  owner: varchar("owner", { length: 100 }).default(""),
  kontakt: varchar("kontakt", { length: 100 }).default(""),
  info: varchar("info", { length: 100 }).default(""),
  conection: varchar("conection", { length: 255 }).default(""),
});

export const streamsProviders3 = pgTable("streams_providers3", {
  providerId: serial("provider_id").primaryKey(),
  providerName: varchar("provider_name", { length: 255 }).notNull(),
  providerDns: varchar("provider_dns", { length: 255 }).notNull(),
  listid: varchar("listid", { length: 100 }).default(""),
  username: varchar("username", { length: 100 }).default(""),
  password: varchar("password", { length: 100 }).default(""),
  conection: varchar("conection", { length: 255 }).default(""),
  cid: text("cid").default(""),
  cld: text("cld").default(""),
  uld: text("uld").default(""),
});

export const streamsProviders4 = pgTable("streams_providers4", {
  providerId: serial("provider_id").primaryKey(),
  providerName: varchar("provider_name", { length: 255 }).notNull(),
  providerDns: varchar("provider_dns", { length: 255 }).notNull(),
  username: varchar("username", { length: 100 }).default(""),
  password: varchar("password", { length: 100 }).default(""),
  conection: varchar("conection", { length: 255 }).default(""),
  currentConection: varchar("current_conection", { length: 255 }).default(""),
  info: text("info").default(""),
  kontakt: text("kontakt").default(""),
  owner: text("owner").default(""),
});

// ===============================
// MISC TABLES
// ===============================

export const country = pgTable("country", {
  id: serial("id").primaryKey(),
  codes: varchar("codes", { length: 255 }),
});

export const languages = pgTable("languages", {
  key: varchar("key", { length: 128 }).primaryKey(),
  language: text("language").notNull().default(""),
});

export const licence = pgTable("licence", {
  id: serial("id").primaryKey(),
  licenceKey: varchar("licence_key", { length: 29 }).notNull(),
  showMessage: integer("show_message").notNull(),
  updateAvailable: integer("update_available").notNull().default(0),
  reshareDenyAddon: integer("reshare_deny_addon").default(0),
});

export const links = pgTable("links", {
  id: serial("id").primaryKey(),
  short: varchar("short", { length: 10 }).notNull(),
  email: varchar("email", { length: 200 }).notNull(),
  amount: varchar("amount", { length: 10 }).notNull().default("0"),
  name: varchar("name", { length: 255 }).notNull(),
  date: integer("date"),
  status: varchar("status", { length: 255 }).notNull(),
  curr: varchar("curr", { length: 10 }).notNull().default("USD"),
  srv: integer("srv").notNull().default(1),
});

export const cronjobs = pgTable("cronjobs", {
  id: serial("id").primaryKey(),
  description: text("description").default(""),
  filename: varchar("filename", { length: 255 }).notNull(),
  runPerMins: integer("run_per_mins").notNull().default(1),
  runPerHours: integer("run_per_hours").notNull().default(0),
  enabled: integer("enabled").notNull().default(0),
  pid: integer("pid").notNull().default(0),
  timestamp: integer("timestamp"),
});

export const creditsLog = pgTable("credits_log", {
  id: serial("id").primaryKey(),
  targetId: integer("target_id").notNull(),
  adminId: integer("admin_id").notNull(),
  amount: real("amount").notNull(),
  date: integer("date").notNull(),
  reason: text("reason").default(""),
});

export const ispAddon = pgTable("isp_addon", {
  id: serial("id").primaryKey(),
  isp: text("isp").notNull(),
  blocked: integer("blocked").notNull().default(0),
});

export const rtmpIps = pgTable("rtmp_ips", {
  id: serial("id").primaryKey(),
  ip: varchar("ip", { length: 255 }).notNull(),
  notes: text("notes").default(""),
});

export const signals = pgTable("signals", {
  signalId: serial("signal_id").primaryKey(),
  pid: integer("pid").notNull(),
  serverId: integer("server_id").notNull(),
  rtmp: integer("rtmp").notNull().default(0),
  time: integer("time").notNull(),
});

export const dashboardStatistics = pgTable("dashboard_statistics", {
  id: serial("id").primaryKey(),
  type: varchar("type", { length: 16 }).notNull().default(""),
  time: integer("time").notNull().default(0),
  count: integer("count").notNull().default(0),
});

export const migrationFiles = pgTable("migration_files", {
  id: serial("id").primaryKey(),
  filename: varchar("filename", { length: 255 }).notNull(),
  created: integer("created"),
});

export const tblFiles = pgTable("tbl_files", {
  id: serial("id").primaryKey(),
  filename: varchar("filename", { length: 255 }).notNull(),
  created: integer("created"),
});

export const payementUsers = pgTable("payement_users", {
  id: serial("id").primaryKey(),
  idUser: integer("id_user").notNull(),
  modePayement: varchar("mode_payement", { length: 255 }).notNull(),
  montant: integer("montant"),
  dateCreated: integer("date_created"),
  datePayement: integer("date_payement"),
  description: text("description"),
  payed: integer("payed").notNull().default(0),
});

export const recordings = pgTable("recordings", {
  id: serial("id").primaryKey(),
  streamId: integer("stream_id"),
  createdId: integer("created_id"),
  categoryId: text("category_id"),
  bouquets: text("bouquets"),
  title: text("title"),
  description: text("description"),
  streamIcon: text("stream_icon"),
  start: integer("start"),
  end: integer("end"),
  sourceId: integer("source_id"),
  archive: integer("archive"),
  status: integer("status").default(0),
});

export const tickets = pgTable("tickets", {
  id: serial("id").primaryKey(),
  memberId: integer("member_id").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  status: integer("status").notNull().default(1),
  adminRead: integer("admin_read").notNull().default(0),
  userRead: integer("user_read").notNull().default(0),
});

export const ticketsReplies = pgTable("tickets_replies", {
  id: serial("id").primaryKey(),
  ticketId: integer("ticket_id").notNull(),
  adminReply: integer("admin_reply").notNull().default(0),
  message: text("message").default(""),
  date: integer("date").notNull(),
});

export const tmdbAsync = pgTable("tmdb_async", {
  id: serial("id").primaryKey(),
  type: integer("type").notNull().default(0),
  streamId: integer("stream_id").notNull().default(0),
  status: integer("status").notNull().default(0),
  dateadded: integer("dateadded"),
});

export const watchCategories = pgTable("watch_categories", {
  id: serial("id").primaryKey(),
  type: varchar("type", { length: 16 }).notNull().default(""),
  categoryName: varchar("category_name", { length: 255 }).notNull(),
});

export const watchFolders = pgTable("watch_folders", {
  id: serial("id").primaryKey(),
  folderId: integer("folder_id").notNull(),
  type: varchar("type", { length: 16 }).notNull().default(""),
  path: varchar("path", { length: 255 }).notNull(),
  serverId: integer("server_id"),
  categoryId: integer("category_id"),
});

export const watchOutput = pgTable("watch_output", {
  id: serial("id").primaryKey(),
  type: varchar("type", { length: 16 }).notNull().default(""),
  outputId: integer("output_id").notNull(),
});

export const watchSettings = pgTable("watch_settings", {
  id: serial("id").primaryKey(),
  enabled: integer("enabled").notNull().default(0),
  symLink: integer("sym_link").notNull().default(0),
  scanInterval: integer("scan_interval").notNull().default(0),
  type: varchar("type", { length: 16 }).notNull().default(""),
});

export const xtreamMain = pgTable("xtream_main", {
  id: serial("id").primaryKey(),
  version: varchar("version", { length: 50 }),
  installDate: integer("install_date"),
});

// ===============================
// ZOD SCHEMAS FOR VALIDATION
// ===============================

// Auth & Admin schemas
export const insertRegUserSchema = createInsertSchema(regUsers).omit({ id: true, dateRegistered: true });
export const insertMemberGroupSchema = createInsertSchema(memberGroups).omit({ groupId: true });

// User schemas
export const insertUserSchema = createInsertSchema(users).omit({ id: true, createdAt: true });

// Stream schemas
export const insertStreamSchema = createInsertSchema(streams).omit({ id: true, added: true });

// Series schemas
export const insertSeriesSchema = createInsertSchema(series).omit({ id: true, lastModified: true });
export const insertSeriesEpisodeSchema = createInsertSchema(seriesEpisodes).omit({ id: true });

// Category schemas
export const insertStreamCategorySchema = createInsertSchema(streamCategories).omit({ id: true });

// Bouquet schemas
export const insertBouquetSchema = createInsertSchema(bouquets).omit({ id: true });
export const insertPackageSchema = createInsertSchema(packages).omit({ id: true });

// Server schemas
export const insertStreamingServerSchema = createInsertSchema(streamingServers).omit({ id: true });
export const insertServerInstallTaskSchema = createInsertSchema(serverInstallTasks).omit({ id: true });
export const insertServerMetricsSchema = createInsertSchema(serverMetrics).omit({ id: true });
export const insertServerDomainSchema = createInsertSchema(serverDomains).omit({ id: true });
export const insertServerPerformanceSchema = createInsertSchema(serverPerformance).omit({ id: true });

// EPG schemas
export const insertEpgSchema = createInsertSchema(epg).omit({ id: true });
export const insertEpgDataSchema = createInsertSchema(epgData).omit({ id: true });

// MAG schemas
export const insertMagDeviceSchema = createInsertSchema(magDevices).omit({ magId: true, created: true });
export const insertMagEventSchema = createInsertSchema(magEvents).omit({ id: true });

// Activity schemas
export const insertUserActivitySchema = createInsertSchema(userActivity).omit({ activityId: true });
export const insertUserActivityNowSchema = createInsertSchema(userActivityNow).omit({ activityId: true });

// Log schemas
export const insertPanelLogSchema = createInsertSchema(panelLogs).omit({ id: true, date: true });
export const insertClientLogSchema = createInsertSchema(clientLogs).omit({ id: true });

// Security schemas (blocked IPs)
export const insertBlockedIpSchema = createInsertSchema(blockedIps).omit({ id: true });
export const insertBlockedUserAgentSchema = createInsertSchema(blockedUserAgents).omit({ id: true });
export const insertAllowedIpSchema = createInsertSchema(allowedIps).omit({ id: true });

// Device schemas
export const insertDeviceSchema = createInsertSchema(devices).omit({ deviceId: true });
export const insertTranscodingProfileSchema = createInsertSchema(transcodingProfiles).omit({ profileId: true });

// Ticket schemas
export const insertTicketSchema = createInsertSchema(tickets).omit({ id: true });
export const insertTicketReplySchema = createInsertSchema(ticketsReplies).omit({ id: true });

// Provider schemas
export const insertStreamsProviderSchema = createInsertSchema(streamsProviders).omit({ providerId: true });

// Login schema
export const loginSchema = z.object({
  username: z.string().min(1),
  password: z.string().min(1),
});

// ===============================
// TYPE EXPORTS
// ===============================

export type RegUser = typeof regUsers.$inferSelect;
export type InsertRegUser = z.infer<typeof insertRegUserSchema>;

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Stream = typeof streams.$inferSelect;
export type InsertStream = z.infer<typeof insertStreamSchema>;

export type Series = typeof series.$inferSelect;
export type InsertSeries = z.infer<typeof insertSeriesSchema>;

export type SeriesEpisode = typeof seriesEpisodes.$inferSelect;
export type InsertSeriesEpisode = z.infer<typeof insertSeriesEpisodeSchema>;

export type StreamCategory = typeof streamCategories.$inferSelect;
export type InsertStreamCategory = z.infer<typeof insertStreamCategorySchema>;

export type Bouquet = typeof bouquets.$inferSelect;
export type InsertBouquet = z.infer<typeof insertBouquetSchema>;

export type Package = typeof packages.$inferSelect;
export type InsertPackage = z.infer<typeof insertPackageSchema>;

export type StreamingServer = typeof streamingServers.$inferSelect;
export type InsertStreamingServer = z.infer<typeof insertStreamingServerSchema>;

export type ServerInstallTask = typeof serverInstallTasks.$inferSelect;
export type InsertServerInstallTask = z.infer<typeof insertServerInstallTaskSchema>;

export type ServerMetrics = typeof serverMetrics.$inferSelect;
export type InsertServerMetrics = z.infer<typeof insertServerMetricsSchema>;

export type ServerDomain = typeof serverDomains.$inferSelect;
export type InsertServerDomain = z.infer<typeof insertServerDomainSchema>;

export type ServerPerformance = typeof serverPerformance.$inferSelect;
export type InsertServerPerformance = z.infer<typeof insertServerPerformanceSchema>;

export type Epg = typeof epg.$inferSelect;
export type InsertEpg = z.infer<typeof insertEpgSchema>;

export type EpgData = typeof epgData.$inferSelect;
export type InsertEpgData = z.infer<typeof insertEpgDataSchema>;

export type MagDevice = typeof magDevices.$inferSelect;
export type InsertMagDevice = z.infer<typeof insertMagDeviceSchema>;

export type MagEvent = typeof magEvents.$inferSelect;
export type InsertMagEvent = z.infer<typeof insertMagEventSchema>;

export type UserActivity = typeof userActivity.$inferSelect;
export type InsertUserActivity = z.infer<typeof insertUserActivitySchema>;

export type UserActivityNow = typeof userActivityNow.$inferSelect;
export type InsertUserActivityNow = z.infer<typeof insertUserActivityNowSchema>;

export type PanelLog = typeof panelLogs.$inferSelect;
export type InsertPanelLog = z.infer<typeof insertPanelLogSchema>;

export type Device = typeof devices.$inferSelect;
export type InsertDevice = z.infer<typeof insertDeviceSchema>;

export type TranscodingProfile = typeof transcodingProfiles.$inferSelect;
export type InsertTranscodingProfile = z.infer<typeof insertTranscodingProfileSchema>;

export type MemberGroup = typeof memberGroups.$inferSelect;
export type InsertMemberGroup = z.infer<typeof insertMemberGroupSchema>;

export type Ticket = typeof tickets.$inferSelect;
export type InsertTicket = z.infer<typeof insertTicketSchema>;

export type AdminSetting = typeof adminSettings.$inferSelect;

export type StreamsProvider = typeof streamsProviders.$inferSelect;
export type InsertStreamsProvider = z.infer<typeof insertStreamsProviderSchema>;

export type BlockedIp = typeof blockedIps.$inferSelect;
export type InsertBlockedIp = z.infer<typeof insertBlockedIpSchema>;

export type BlockedUserAgent = typeof blockedUserAgents.$inferSelect;
export type InsertBlockedUserAgent = z.infer<typeof insertBlockedUserAgentSchema>;

export type AllowedIp = typeof allowedIps.$inferSelect;
export type InsertAllowedIp = z.infer<typeof insertAllowedIpSchema>;

// Stream system status types
export type StreamsSys = typeof streamsSys.$inferSelect;
export const insertStreamsSysSchema = createInsertSchema(streamsSys).omit({ serverStreamId: true });
export type InsertStreamsSys = z.infer<typeof insertStreamsSysSchema>;

// Parsed stream info for frontend display
export interface ParsedStreamInfo {
  resolution: string;
  videoCodec: string;
  audioCodec: string;
  fps: string;
  playbackSpeed: string;
}

// Stream status response for API
export interface StreamStatusResponse {
  streamId: number;
  serverId: number | null;
  serverName: string | null;
  status: "online" | "offline" | "restarting" | "error";
  streamStarted: number | null;
  streamStopped: number | null;
  uptimeSeconds: number;
  downtimeSeconds: number;
  bitrate: number | null;
  streamInfo: ParsedStreamInfo;
  outputFormats: string[];
  activeSourceIndex: number;
  lastFailoverAt: number | null;
}

// Dashboard stats type
export interface DashboardStats {
  totalUsers: number;
  activeUsers: number;
  expiredUsers: number;
  bannedUsers: number;
  trialUsers: number;
  totalConnections: number;
  totalStreams: number;
  activeStreams: number;
  offlineStreams: number;
  totalMovies: number;
  totalSeries: number;
  totalEpisodes: number;
  totalServers: number;
  onlineServers: number;
  offlineServers: number;
  totalBandwidthIn: number;
  totalBandwidthOut: number;
  totalResellers: number;
}

// Generated line type
export interface GeneratedLine {
  username: string;
  password: string;
  m3uUrl: string;
  expirationDate: string;
}

// ===============================
// LICENSE SYSTEM
// ===============================

export const licenses = pgTable("licenses", {
  id: serial("id").primaryKey(),
  licenseKey: varchar("license_key", { length: 50 }).notNull().unique(),
  licenseType: varchar("license_type", { length: 20 }).notNull().default("client"),
  email: varchar("email", { length: 255 }).notNull(),
  status: varchar("status", { length: 20 }).notNull().default("active"),
  durationDays: integer("duration_days").notNull().default(30),
  createdAt: integer("created_at").notNull(),
  expiresAt: integer("expires_at"),
  activatedAt: integer("activated_at"),
  lastCheckedAt: integer("last_checked_at"),
  domain: varchar("domain", { length: 255 }),
  ip: varchar("ip", { length: 45 }),
  notes: text("notes"),
  generatedBy: integer("generated_by"),
  // Server binding fields for single-server protection
  boundServerId: varchar("bound_server_id", { length: 255 }),
  boundServerHostname: varchar("bound_server_hostname", { length: 255 }),
  boundServerIp: varchar("bound_server_ip", { length: 45 }),
  boundAt: integer("bound_at"),
});

export const insertLicenseSchema = createInsertSchema(licenses).omit({ id: true });
export type License = typeof licenses.$inferSelect;
export type InsertLicense = z.infer<typeof insertLicenseSchema>;
