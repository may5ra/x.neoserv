#!/usr/bin/env node
// X NeoServ Standalone LB Proxy v7 - EDIT SERVER_ID and SERVER_TOKEN below
const http = require('http');
const https = require('https');
const url = require('url');
const os = require('os');
const fs = require('fs');

// ===== EDIT THESE VALUES =====
const MAIN_SERVER = 'http://146.59.83.139:5000';  // Your main panel IP:port
const SERVER_ID = 6;  // Your server ID from panel
const SERVER_TOKEN = 'YOUR_SERVER_TOKEN_HERE';  // Get from panel -> Servers -> Edit
// =============================

const PORT = 80;
const MAX_REDIRECTS = 5;

const tokenCache = new Map();
const TOKEN_CACHE_TTL = 24 * 60 * 60 * 1000;
const sourceCache = new Map();
const SOURCE_CACHE_TTL = 60 * 60 * 1000;

const httpAgent = new http.Agent({ keepAlive: true, maxSockets: 2048, maxFreeSockets: 256, timeout: 15000, keepAliveMsecs: 30000 });
const httpsAgent = new https.Agent({ keepAlive: true, maxSockets: 2048, maxFreeSockets: 256, timeout: 15000, keepAliveMsecs: 30000, rejectUnauthorized: false });

const dnsCache = new Map();
const DNS_CACHE_TTL = 300000;
function cachedLookup(hostname, opts, cb) {
  const cached = dnsCache.get(hostname);
  if (cached && Date.now() < cached.expires) return cb(null, cached.address, cached.family);
  require('dns').lookup(hostname, opts, (err, address, family) => {
    if (!err) dnsCache.set(hostname, { address, family, expires: Date.now() + DNS_CACHE_TTL });
    cb(err, address, family);
  });
}

async function validateWithMain(username, password, streamId, type) {
  return new Promise((resolve, reject) => {
    const reqUrl = MAIN_SERVER + '/internal/lb/validate?username=' + encodeURIComponent(username) + '&password=' + encodeURIComponent(password) + '&streamId=' + streamId + '&type=' + type;
    http.get(reqUrl, { headers: { 'X-LB-Token': SERVER_TOKEN, 'X-LB-Server-Id': SERVER_ID.toString() }, agent: httpAgent }, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        if (res.statusCode === 200) { try { resolve(JSON.parse(data)); } catch { reject(new Error('Invalid JSON')); } }
        else { reject(new Error('Status ' + res.statusCode)); }
      });
    }).on('error', reject);
  });
}

function encodeAbsoluteUrl(td, u) { const i = td.absoluteUrlCounter++; td.absoluteUrls.set(i, u); return '_abs_' + i; }
function decodeAbsoluteUrl(td, e) { const m = e.match(/^_abs_(\d+)$/); return m ? td.absoluteUrls.get(parseInt(m[1], 10)) : null; }

async function getTokenData(username, password, streamId, type) {
  const cacheKey = username + ':' + password + ':' + type + ':' + streamId;
  const sourceCacheKey = type + ':' + streamId;
  let td = tokenCache.get(cacheKey);
  if (!td || Date.now() > td.expires) {
    const cachedSource = sourceCache.get(sourceCacheKey);
    let sourceUrl, userId;
    if (cachedSource && Date.now() < cachedSource.expires) {
      const v = await validateWithMain(username, password, streamId, type);
      if (!v.sourceUrl) throw new Error('No source URL');
      sourceUrl = cachedSource.url; userId = v.userId;
      console.log('[LB] FAST: cached source for stream', streamId);
    } else {
      const v = await validateWithMain(username, password, streamId, type);
      if (!v.sourceUrl) throw new Error('No source URL');
      sourceUrl = v.sourceUrl; userId = v.userId;
      sourceCache.set(sourceCacheKey, { url: sourceUrl, expires: Date.now() + SOURCE_CACHE_TTL });
      console.log('[LB] Cached source for stream', streamId);
    }
    td = { sourceUrl, baseUrl: sourceUrl.substring(0, sourceUrl.lastIndexOf('/') + 1), absoluteUrls: new Map(), absoluteUrlCounter: 0, expires: Date.now() + TOKEN_CACHE_TTL, userId, streamId: parseInt(streamId) };
    tokenCache.set(cacheKey, td);
  }
  return { tokenData: td, cacheKey };
}

function getClientIp(req) {
  const xff = req.headers['x-forwarded-for'];
  if (xff) return xff.split(',')[0].trim();
  return req.socket?.remoteAddress || req.connection?.remoteAddress || '0.0.0.0';
}

let lastHeartbeat = new Map();
function sendHeartbeat(userId, streamId, clientIp, userAgent) {
  if (!userId || !streamId) return;
  const key = userId + ':' + streamId;
  const now = Date.now();
  if (lastHeartbeat.has(key) && now - lastHeartbeat.get(key) < 10000) return;
  lastHeartbeat.set(key, now);
  const postData = JSON.stringify({ userId, streamId, clientIp: clientIp || '0.0.0.0', userAgent: userAgent || 'LB Proxy' });
  const req = http.request({
    hostname: new url.URL(MAIN_SERVER).hostname, port: new url.URL(MAIN_SERVER).port || 80,
    path: '/internal/lb/heartbeat', method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(postData), 'X-LB-Token': SERVER_TOKEN, 'X-LB-Server-Id': SERVER_ID.toString() },
    agent: httpAgent, timeout: 5000
  }, (res) => { res.on('data', () => {}); res.on('end', () => { if (res.statusCode === 200) console.log('[LB] Heartbeat OK: user=' + userId + ' stream=' + streamId + ' ip=' + clientIp); }); });
  req.on('error', (e) => console.log('[LB] Heartbeat error:', e.message));
  req.write(postData); req.end();
}

function proxyHlsPlaylist(sourceUrl, cacheKey, td, res, req, forcedPrefix, maxRedir) {
  if (maxRedir === undefined) maxRedir = MAX_REDIRECTS;
  if (maxRedir <= 0) { if (!res.headersSent) { res.writeHead(502); res.end('Too many redirects'); } return; }
  let parsed; try { parsed = new url.URL(sourceUrl); } catch { res.writeHead(400); res.end('Invalid URL'); return; }
  const isHttps = parsed.protocol === 'https:';
  const client = isHttps ? https : http;
  const agent = isHttps ? httpsAgent : httpAgent;
  const proxyReq = client.request({ 
    hostname: parsed.hostname, port: parsed.port || (isHttps ? 443 : 80), path: parsed.pathname + parsed.search, 
    method: 'GET', agent, timeout: 5000, lookup: cachedLookup,
    headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36', 'Accept': '*/*', 'Connection': 'keep-alive', 'Accept-Encoding': 'identity' } 
  }, (proxyRes) => {
    if (proxyRes.statusCode >= 300 && proxyRes.statusCode < 400 && proxyRes.headers.location) {
      const loc = proxyRes.headers.location;
      const rUrl = loc.startsWith('http') ? loc : new url.URL(loc, sourceUrl).href;
      td.baseUrl = rUrl.substring(0, rUrl.lastIndexOf('/') + 1);
      return proxyHlsPlaylist(rUrl, cacheKey, td, res, req, forcedPrefix, maxRedir - 1);
    }
    if (proxyRes.statusCode >= 400) { res.writeHead(proxyRes.statusCode); res.end('Source error'); return; }
    let pathPrefix = forcedPrefix !== null && forcedPrefix !== undefined ? forcedPrefix : (() => { const d = sourceUrl.substring(0, sourceUrl.lastIndexOf('/') + 1); return d.startsWith(td.baseUrl) ? d.substring(td.baseUrl.length) : ''; })();
    let body = ''; proxyRes.setEncoding('utf8');
    proxyRes.on('data', c => body += c);
    proxyRes.on('end', () => {
      const rw = u => u.startsWith('http://') || u.startsWith('https://') ? '/_lb_/' + cacheKey + '/' + encodeAbsoluteUrl(td, u) : '/_lb_/' + cacheKey + '/' + pathPrefix + u;
      const rewritten = body.split('\n').map(l => { 
        const t = l.trim(); 
        if (!t) return l; 
        if (t.startsWith('#EXT-X-MEDIA:') && t.includes('URI=')) {
          let ml = l.replace(/URI="([^"]+)"/g, (m, u) => 'URI="' + rw(u) + '"');
          if (t.includes('TYPE=SUBTITLES')) {
            if (ml.includes('DEFAULT=NO')) ml = ml.replace(/DEFAULT=NO/g, 'DEFAULT=YES');
            else if (!ml.includes('DEFAULT=')) ml = ml.replace('#EXT-X-MEDIA:', '#EXT-X-MEDIA:DEFAULT=YES,');
            if (ml.includes('AUTOSELECT=NO')) ml = ml.replace(/AUTOSELECT=NO/g, 'AUTOSELECT=YES');
            else if (!ml.includes('AUTOSELECT=')) ml = ml.replace('#EXT-X-MEDIA:', '#EXT-X-MEDIA:AUTOSELECT=YES,');
          }
          return ml;
        }
        if (t.startsWith('#')) return l.replace(/URI="([^"]+)"/g, (m, u) => 'URI="' + rw(u) + '"'); 
        return rw(t); 
      }).join('\n');
      res.writeHead(200, { 'Content-Type': 'application/vnd.apple.mpegurl', 'Cache-Control': 'no-store', 'Access-Control-Allow-Origin': '*' });
      res.end(rewritten);
    });
  });
  proxyReq.on('error', () => { if (!res.headersSent) { res.writeHead(502); res.end('Source unavailable'); } });
  proxyReq.on('timeout', () => { proxyReq.destroy(); if (!res.headersSent) { res.writeHead(504); res.end('Timeout'); } });
  req.on('close', () => proxyReq.destroy());
  proxyReq.end();
}

function proxySegment(segUrl, res, req, maxRedir) {
  if (maxRedir === undefined) maxRedir = MAX_REDIRECTS;
  if (maxRedir <= 0) { if (!res.headersSent) { res.writeHead(502); res.end('Too many redirects'); } return; }
  let parsed; try { parsed = new url.URL(segUrl); } catch { res.writeHead(400); res.end('Invalid URL'); return; }
  const isHttps = parsed.protocol === 'https:';
  const client = isHttps ? https : http;
  const agent = isHttps ? httpsAgent : httpAgent;
  const proxyReq = client.request({ 
    hostname: parsed.hostname, port: parsed.port || (isHttps ? 443 : 80), path: parsed.pathname + parsed.search, 
    method: 'GET', agent, timeout: 15000, lookup: cachedLookup,
    headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36', 'Accept': '*/*', 'Connection': 'keep-alive' } 
  }, (proxyRes) => {
    if (proxyRes.statusCode >= 300 && proxyRes.statusCode < 400 && proxyRes.headers.location) {
      const loc = proxyRes.headers.location;
      return proxySegment(loc.startsWith('http') ? loc : new url.URL(loc, segUrl).href, res, req, maxRedir - 1);
    }
    if (proxyRes.statusCode >= 400) { res.writeHead(proxyRes.statusCode); res.end('Source error'); return; }
    const h = { 'Content-Type': proxyRes.headers['content-type'] || 'video/mp2t', 'Cache-Control': 'no-cache', 'Access-Control-Allow-Origin': '*' };
    if (proxyRes.headers['content-length']) h['Content-Length'] = proxyRes.headers['content-length'];
    res.writeHead(200, h);
    // Track network bytes
    proxyRes.on('data', (chunk) => { networkBytesIn += chunk.length; networkBytesOut += chunk.length; });
    proxyRes.pipe(res);
  });
  proxyReq.on('error', () => { if (!res.headersSent) { res.writeHead(502); res.end('Source unavailable'); } });
  proxyReq.on('timeout', () => { proxyReq.destroy(); if (!res.headersSent) { res.writeHead(504); res.end('Timeout'); } });
  req.on('close', () => proxyReq.destroy());
  proxyReq.end();
}

// Direct TS stream proxy - NO timeout for continuous streams (XUI format)
function proxyDirectTsStream(streamUrl, res, req, maxRedir) {
  if (maxRedir === undefined) maxRedir = MAX_REDIRECTS;
  if (maxRedir <= 0) { if (!res.headersSent) { res.writeHead(502); res.end('Too many redirects'); } return; }
  let parsed; try { parsed = new url.URL(streamUrl); } catch { res.writeHead(400); res.end('Invalid URL'); return; }
  const isHttps = parsed.protocol === 'https:';
  const client = isHttps ? https : http;
  const agent = isHttps ? httpsAgent : httpAgent;
  console.log('[LB] Direct TS stream:', streamUrl.substring(0, 60));
  const proxyReq = client.request({ 
    hostname: parsed.hostname, port: parsed.port || (isHttps ? 443 : 80), path: parsed.pathname + parsed.search, 
    method: 'GET', agent, lookup: cachedLookup,
    headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36', 'Accept': '*/*', 'Connection': 'keep-alive' } 
  }, (proxyRes) => {
    if (proxyRes.statusCode >= 300 && proxyRes.statusCode < 400 && proxyRes.headers.location) {
      const loc = proxyRes.headers.location;
      return proxyDirectTsStream(loc.startsWith('http') ? loc : new url.URL(loc, streamUrl).href, res, req, maxRedir - 1);
    }
    if (proxyRes.statusCode >= 400) { res.writeHead(proxyRes.statusCode); res.end('Source error'); return; }
    const h = { 'Content-Type': 'video/mp2t', 'Cache-Control': 'no-cache, no-store', 'Access-Control-Allow-Origin': '*', 'Connection': 'keep-alive' };
    res.writeHead(200, h);
    // Track network bytes for direct TS streams
    proxyRes.on('data', (chunk) => { networkBytesIn += chunk.length; networkBytesOut += chunk.length; });
    proxyRes.pipe(res);
    proxyRes.on('error', () => { proxyReq.destroy(); });
  });
  proxyReq.on('error', () => { if (!res.headersSent) { res.writeHead(502); res.end('Source unavailable'); } });
  req.on('close', () => { proxyReq.destroy(); });
  proxyReq.end();
}

http.createServer(async (req, res) => {
  const path = req.url || '/';
  const clientIp = getClientIp(req);
  const userAgent = req.headers['user-agent'] || 'Unknown';

  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Range');
  res.setHeader('Access-Control-Expose-Headers', 'Content-Length, Content-Range');
  
  if (req.method === 'OPTIONS') { res.writeHead(204); res.end(); return; }

  // Internal HLS segment/playlist proxy
  const lbM = path.match(/^\/_lb_\/([^\/]+:[^\/]+:[^\/]+:\d+)\/(.*)$/);
  if (lbM) {
    const [, ck, seg] = lbM; const td = tokenCache.get(ck);
    if (!td) { res.writeHead(401); res.end('Session expired'); return; }
    sendHeartbeat(td.userId, td.streamId, clientIp, userAgent);
    const segDir = seg.includes('/') ? seg.substring(0, seg.lastIndexOf('/') + 1) : '';
    let segUrl; const dec = decodeAbsoluteUrl(td, seg);
    if (dec) segUrl = dec;
    else if (seg.startsWith('_abs_')) { res.writeHead(404); res.end('Not found'); return; }
    else if (seg.includes('://')) { res.writeHead(400); res.end('Invalid'); return; }
    else { try { const r = new url.URL(seg, td.baseUrl); if (r.host !== new url.URL(td.sourceUrl).host) { res.writeHead(400); res.end('Bad host'); return; } segUrl = r.href; } catch { res.writeHead(400); res.end('Bad path'); return; } }
    console.log('[LB]', seg.substring(0, 40), '->', segUrl.substring(0, 60));
    if (seg.endsWith('.m3u8') || seg.endsWith('.m3u') || (dec && (dec.endsWith('.m3u8') || dec.endsWith('.m3u')))) proxyHlsPlaylist(segUrl, ck, td, res, req, segDir);
    else proxySegment(segUrl, res, req);
    return;
  }

  // Live streaming - supports both HLS (.m3u8) and direct TS streams
  // Also supports multi-bitrate paths like /live/user/pass/123/Video-5M/manifest.m3u8
  const liveM = path.match(/^\/live\/([^\/]+)\/([^\/]+)\/(\d+)(?:\.(m3u8|ts)|\/.*\.(m3u8|ts))$/);
  if (liveM) {
    try {
      const ext = liveM[4] || liveM[5]; // Either direct ext or subfolder ext
      const { tokenData: td, cacheKey: ck } = await getTokenData(liveM[1], liveM[2], parseInt(liveM[3]), 'live');
      sendHeartbeat(td.userId, td.streamId, clientIp, userAgent);
      console.log('[LB] Live', liveM[3], 'ext:', ext, 'src:', td.sourceUrl.substring(0, 50), 'ip:', clientIp);
      // Check source type - NOT the requested extension
      const srcLower = td.sourceUrl.toLowerCase();
      const isHlsSource = srcLower.includes('.m3u8') || srcLower.includes('.m3u');
      const isDirectTsSource = !isHlsSource && (srcLower.includes('.ts') || srcLower.includes('/ts'));
      
      if (isHlsSource) {
        // HLS source - always proxy as HLS playlist regardless of requested ext
        proxyHlsPlaylist(td.sourceUrl, ck, td, res, req, null);
      } else if (isDirectTsSource) {
        // Direct TS stream (XUI format) - continuous proxy without timeout
        proxyDirectTsStream(td.sourceUrl, res, req);
      } else {
        // Unknown format - try segment proxy
        proxySegment(td.sourceUrl, res, req);
      }
    } catch (e) {
      console.log('[LB] Err:', e.message);
      res.writeHead(403); res.end('Denied');
    }
    return;
  }

  // Movie streaming
  const movM = path.match(/^\/movie\/([^\/]+)\/([^\/]+)\/(\d+)\.(m3u8|mp4|mkv|avi)$/);
  if (movM) {
    try {
      const { tokenData: td, cacheKey: ck } = await getTokenData(movM[1], movM[2], parseInt(movM[3]), 'movie');
      sendHeartbeat(td.userId, td.streamId, clientIp, userAgent);
      console.log('[LB] Movie', movM[3], 'ip:', clientIp);
      if (movM[4] === 'm3u8') proxyHlsPlaylist(td.sourceUrl, ck, td, res, req, null);
      else proxySegment(td.sourceUrl, res, req);
    } catch (e) {
      console.log('[LB] Err:', e.message);
      res.writeHead(403); res.end('Denied');
    }
    return;
  }

  if (path === '/health' || path === '/') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ status: 'ok', serverId: SERVER_ID, sessions: tokenCache.size }));
    return;
  }
  res.writeHead(404); res.end('Not found');
}).listen(PORT, '0.0.0.0', () => console.log('[LB Proxy v7] Server ' + SERVER_ID + ' on port ' + PORT + ' -> ' + MAIN_SERVER));

setInterval(() => { const n = Date.now(); for (const [k, v] of tokenCache.entries()) if (v.expires < n) { console.log('[LB] Expired:', k); tokenCache.delete(k); } for (const [k, t] of lastHeartbeat.entries()) if (n - t > 120000) lastHeartbeat.delete(k); }, 60000);

// ===== METRICS REPORTING =====
let networkBytesIn = 0;
let networkBytesOut = 0;
let lastCpuInfo = os.cpus();

function getCpuUsage() {
  const cpus = os.cpus();
  let totalIdle = 0, totalTick = 0;
  let lastTotalIdle = 0, lastTotalTick = 0;
  cpus.forEach((cpu, i) => {
    for (const type in cpu.times) totalTick += cpu.times[type];
    totalIdle += cpu.times.idle;
    if (lastCpuInfo[i]) {
      for (const type in lastCpuInfo[i].times) lastTotalTick += lastCpuInfo[i].times[type];
      lastTotalIdle += lastCpuInfo[i].times.idle;
    }
  });
  lastCpuInfo = cpus;
  const idleDiff = totalIdle - lastTotalIdle;
  const totalDiff = totalTick - lastTotalTick;
  return totalDiff > 0 ? Math.round((1 - idleDiff / totalDiff) * 100) : 0;
}

function getMemoryUsage() {
  const total = os.totalmem();
  const free = os.freemem();
  return Math.round(((total - free) / total) * 100);
}

function getDiskUsage() {
  try {
    const { execSync } = require('child_process');
    const df = execSync("df -P / | tail -1 | awk '{print $5}'", { encoding: 'utf8', timeout: 5000 });
    return parseInt(df.replace('%', '').trim()) || 0;
  } catch { return 0; }
}

function reportMetrics() {
  const cpuUsage = getCpuUsage();
  const memoryUsage = getMemoryUsage();
  const diskUsage = getDiskUsage();
  const activeConnections = tokenCache.size;
  const networkIn = networkBytesIn;
  const networkOut = networkBytesOut;
  
  const postData = JSON.stringify({ cpuUsage, memoryUsage, diskUsage, activeConnections, networkIn, networkOut });
  const parsedMain = new url.URL(MAIN_SERVER);
  
  const req = http.request({
    hostname: parsedMain.hostname,
    port: parsedMain.port || 80,
    path: '/internal/lb/metrics',
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(postData), 'X-LB-Token': SERVER_TOKEN, 'X-LB-Server-Id': SERVER_ID.toString() },
    agent: httpAgent,
    timeout: 10000
  }, (res) => {
    res.on('data', () => {});
    res.on('end', () => {
      if (res.statusCode === 200) console.log('[LB] Metrics: CPU=' + cpuUsage + '% RAM=' + memoryUsage + '% Disk=' + diskUsage + '% Sessions=' + activeConnections + ' NetIn=' + Math.round(networkIn/1024) + 'KB NetOut=' + Math.round(networkOut/1024) + 'KB');
      else console.log('[LB] Metrics failed:', res.statusCode);
    });
  });
  req.on('error', (e) => console.log('[LB] Metrics error:', e.message));
  req.write(postData);
  req.end();
  
  // Reset network counters
  networkBytesIn = 0;
  networkBytesOut = 0;
}

// Report metrics every 15 seconds
setInterval(reportMetrics, 15000);
// Initial report after 5 seconds
setTimeout(reportMetrics, 5000);

console.log('[LB Proxy v7] Started with metrics reporting');
