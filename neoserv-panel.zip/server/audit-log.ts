import { db } from "./db";
import { auditLogs, InsertAuditLog } from "@shared/schema";
import { desc, eq, and, gte, lte, like, or } from "drizzle-orm";

export type AuditAction = 
  | "login" | "logout" | "login_failed"
  | "user_create" | "user_update" | "user_delete" | "user_ban" | "user_enable" | "user_disable"
  | "stream_create" | "stream_update" | "stream_delete" | "stream_start" | "stream_stop" | "stream_restart"
  | "category_create" | "category_update" | "category_delete"
  | "bouquet_create" | "bouquet_update" | "bouquet_delete"
  | "server_create" | "server_update" | "server_delete"
  | "series_create" | "series_update" | "series_delete"
  | "epg_create" | "epg_update" | "epg_delete" | "epg_refresh"
  | "mag_create" | "mag_update" | "mag_delete"
  | "reseller_create" | "reseller_update" | "reseller_delete" | "reseller_credits"
  | "package_create" | "package_update" | "package_delete"
  | "settings_update"
  | "connection_kill"
  | "migration_import"
  | "playlist_download";

export type TargetType = 
  | "user" | "stream" | "category" | "bouquet" | "server" 
  | "series" | "epg" | "mag_device" | "reseller" | "package" 
  | "settings" | "connection" | "system";

interface LogParams {
  adminId: number;
  adminUsername: string;
  adminRole: string;
  action: AuditAction;
  targetType: TargetType;
  targetId?: number;
  targetName?: string;
  details?: string | Record<string, any>;
  ipAddress?: string;
  userAgent?: string;
}

export async function logAudit(params: LogParams): Promise<void> {
  try {
    const details = typeof params.details === 'object' 
      ? JSON.stringify(params.details) 
      : params.details;

    await db.insert(auditLogs).values({
      adminId: params.adminId,
      adminUsername: params.adminUsername,
      adminRole: params.adminRole,
      action: params.action,
      targetType: params.targetType,
      targetId: params.targetId ?? null,
      targetName: params.targetName ?? null,
      details: details ?? null,
      ipAddress: params.ipAddress ?? null,
      userAgent: params.userAgent ?? null,
      createdAt: Math.floor(Date.now() / 1000),
    });
  } catch (error) {
    console.error("[AUDIT] Failed to log:", error);
  }
}

export interface AuditLogFilters {
  adminId?: number;
  action?: string;
  targetType?: string;
  startDate?: number;
  endDate?: number;
  search?: string;
  limit?: number;
  offset?: number;
}

export async function getAuditLogs(filters: AuditLogFilters = {}) {
  const conditions = [];

  if (filters.adminId) {
    conditions.push(eq(auditLogs.adminId, filters.adminId));
  }
  if (filters.action) {
    conditions.push(eq(auditLogs.action, filters.action));
  }
  if (filters.targetType) {
    conditions.push(eq(auditLogs.targetType, filters.targetType));
  }
  if (filters.startDate) {
    conditions.push(gte(auditLogs.createdAt, filters.startDate));
  }
  if (filters.endDate) {
    conditions.push(lte(auditLogs.createdAt, filters.endDate));
  }
  if (filters.search) {
    conditions.push(
      or(
        like(auditLogs.adminUsername, `%${filters.search}%`),
        like(auditLogs.targetName, `%${filters.search}%`),
        like(auditLogs.details, `%${filters.search}%`)
      )
    );
  }

  const limit = filters.limit || 100;
  const offset = filters.offset || 0;

  const logs = await db
    .select()
    .from(auditLogs)
    .where(conditions.length > 0 ? and(...conditions) : undefined)
    .orderBy(desc(auditLogs.createdAt))
    .limit(limit)
    .offset(offset);

  return logs;
}

// Helper to create audit log from Express request
export function logAuditFromRequest(
  req: { adminId?: number; adminUsername?: string; adminRole?: string; ip?: string; socket?: { remoteAddress?: string }; headers?: Record<string, any> },
  payload: {
    action: AuditAction;
    targetType: TargetType;
    targetId?: number;
    targetName?: string;
    details?: string;
  }
): void {
  const ip = req.ip || req.socket?.remoteAddress || "unknown";
  // Normalize IPv6-mapped IPv4
  const normalizedIp = ip.startsWith("::ffff:") ? ip.slice(7) : ip;
  
  logAudit({
    adminId: req.adminId || 0,
    adminUsername: req.adminUsername || "system",
    adminRole: req.adminRole || "unknown",
    action: payload.action,
    targetType: payload.targetType,
    targetId: payload.targetId,
    targetName: payload.targetName,
    details: payload.details,
    ipAddress: normalizedIp,
    userAgent: req.headers?.["user-agent"] || undefined,
  });
}

export async function getAuditLogStats() {
  const now = Math.floor(Date.now() / 1000);
  const oneDayAgo = now - 86400;
  const oneWeekAgo = now - 604800;

  const todayLogs = await db
    .select()
    .from(auditLogs)
    .where(gte(auditLogs.createdAt, oneDayAgo));

  const weekLogs = await db
    .select()
    .from(auditLogs)
    .where(gte(auditLogs.createdAt, oneWeekAgo));

  const actionCounts: Record<string, number> = {};
  const adminCounts: Record<string, number> = {};

  for (const log of weekLogs) {
    actionCounts[log.action] = (actionCounts[log.action] || 0) + 1;
    adminCounts[log.adminUsername] = (adminCounts[log.adminUsername] || 0) + 1;
  }

  return {
    todayCount: todayLogs.length,
    weekCount: weekLogs.length,
    topActions: Object.entries(actionCounts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5),
    topAdmins: Object.entries(adminCounts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5),
  };
}
