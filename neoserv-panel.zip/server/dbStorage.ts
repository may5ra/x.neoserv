import bcrypt from "bcryptjs";
import crypto from "crypto";
import { eq, and, or, desc, sql, inArray, gt, lt, gte, lte } from "drizzle-orm";

// GeoIP cache to avoid repeated API calls
const geoipCache = new Map<string, { country: string; countryCode: string; timestamp: number }>();
const GEOIP_CACHE_TTL = 3600000; // 1 hour

// GeoIP lookup using ip-api.com (free, no API key required)
async function lookupGeoIP(ip: string): Promise<{ country: string; countryCode: string }> {
  // Check cache first
  const cached = geoipCache.get(ip);
  if (cached && Date.now() - cached.timestamp < GEOIP_CACHE_TTL) {
    return { country: cached.country, countryCode: cached.countryCode };
  }
  
  try {
    // Skip private/local IPs
    if (ip.startsWith("10.") || ip.startsWith("192.168.") || ip.startsWith("172.") || 
        ip === "127.0.0.1" || ip === "::1" || ip.startsWith("::ffff:127.")) {
      return { country: "Local", countryCode: "LO" };
    }
    
    // Clean IPv6-mapped IPv4 addresses
    const cleanIp = ip.replace("::ffff:", "");
    
    const response = await fetch(`http://ip-api.com/json/${cleanIp}?fields=status,country,countryCode`);
    const data = await response.json();
    
    if (data.status === "success") {
      const result = { country: data.country || "", countryCode: data.countryCode || "" };
      geoipCache.set(ip, { ...result, timestamp: Date.now() });
      return result;
    }
  } catch (error) {
    console.log(`[GEOIP] Lookup failed for ${ip}:`, error);
  }
  
  return { country: "", countryCode: "" };
}
import { db } from "./db";
import {
  regUsers, users, streams, series, seriesEpisodes, streamCategories,
  bouquets, streamingServers, epg, epgData, userActivityNow, userActivity,
  magDevices, panelLogs, adminSettings, accessOutput, streamsTypes,
  blockedIps, blockedUserAgents, allowedIps, streamsSys,
  serverInstallTasks, serverMetrics, serverDomains, serverPerformance,
  licenses, authTokens, creditTransactions,
  STREAM_TYPE_LIVE, STREAM_TYPE_MOVIE, STREAM_TYPE_SERIES
} from "@shared/schema";
import type {
  RegUser, InsertRegUser,
  User, InsertUser,
  Stream, InsertStream,
  Series, InsertSeries,
  SeriesEpisode, InsertSeriesEpisode,
  StreamCategory, InsertStreamCategory,
  Bouquet, InsertBouquet,
  StreamingServer, InsertStreamingServer,
  Epg, InsertEpg,
  EpgData, InsertEpgData,
  UserActivityNow, InsertUserActivityNow,
  UserActivity, InsertUserActivity,
  MagDevice, InsertMagDevice,
  PanelLog, InsertPanelLog,
  BlockedIp, InsertBlockedIp,
  BlockedUserAgent, InsertBlockedUserAgent,
  AllowedIp, InsertAllowedIp,
  AdminSetting,
  DashboardStats,
  GeneratedLine,
  StreamStatusResponse,
  InsertStreamsSys,
  ParsedStreamInfo,
  ServerInstallTask, InsertServerInstallTask,
  ServerMetrics, InsertServerMetrics,
  ServerDomain, InsertServerDomain,
  ServerPerformance, InsertServerPerformance,
  License, InsertLicense,
  CreditTransaction, InsertCreditTransaction,
} from "@shared/schema";

const SALT_ROUNDS = 10;

function generateUsername(): string {
  const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
  let result = '';
  for (let i = 0; i < 8; i++) {
    result += chars[Math.floor(Math.random() * chars.length)];
  }
  return result;
}

function generatePassword(): string {
  const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let result = '';
  for (let i = 0; i < 12; i++) {
    result += chars[Math.floor(Math.random() * chars.length)];
  }
  return result;
}

// Generate signed proxy URL for external Nginx streaming
// URL format: {baseUrl}/stream/{streamId}/{token}/{signature}/playlist.m3u8
// Token format: base64url(userId:username:expiry:random)
// Signature: HMAC-SHA256(token:streamId) truncated to 16 hex chars
async function createSignedProxyUrl(
  baseProxyUrl: string,
  secretKey: string,
  userId: number,
  username: string,
  streamId: number,
  streamType: 'live' | 'movie',
  ttlSeconds: number
): Promise<string> {
  // Use milliseconds for expiry (like the generate-url endpoint)
  const expiry = Date.now() + (ttlSeconds * 1000);
  const random = crypto.randomBytes(4).toString('hex');
  
  // Token payload: userId:username:expiry:random (matches validation endpoint)
  const tokenPayload = `${userId}:${username}:${expiry}:${random}`;
  const token = Buffer.from(tokenPayload).toString('base64url');
  
  // HMAC-SHA256 signature matching /api/proxy/validate expectations
  // Signature is computed on: token:streamId
  const signature = crypto
    .createHmac('sha256', secretKey)
    .update(`${token}:${streamId}`)
    .digest('hex')
    .substring(0, 16); // First 16 chars for shorter URLs
  
  // Format: {baseUrl}/stream/{streamId}/{token}/{signature}
  // Nginx regex will extract these parts and forward to auth endpoint
  return `${baseProxyUrl}/stream/${streamId}/${token}/${signature}`;
}

export class DatabaseStorage {
  private initialized = false;

  async initialize() {
    if (this.initialized) return;
    
    const existingAdmins = await db.select().from(regUsers).limit(1);
    if (existingAdmins.length === 0) {
      await this.seedData();
    }
    this.initialized = true;
  }

  private async seedData() {
    const hashedPassword = await bcrypt.hash("admin123", SALT_ROUNDS);
    const now = Math.floor(Date.now() / 1000);
    
    await db.insert(regUsers).values({
      username: "admin",
      password: hashedPassword,
      email: "admin@example.com",
      memberGroupId: 1,
      credits: 1000,
      status: 1,
      verified: 1,
      dateRegistered: now,
      defaultLang: "en",
      resellerDns: "",
      google2faSec: "",
      topbarTheme: "",
      navigationTheme: "",
      navigationTextColor: "",
      dropbox: "",
    });

    const liveCats = [
      { categoryType: "live", categoryName: "Sports", catOrder: 1 },
      { categoryType: "live", categoryName: "News", catOrder: 2 },
      { categoryType: "live", categoryName: "Entertainment", catOrder: 3 },
    ];
    const movieCats = [
      { categoryType: "movie", categoryName: "Action", catOrder: 1 },
      { categoryType: "movie", categoryName: "Comedy", catOrder: 2 },
    ];
    const seriesCats = [
      { categoryType: "series", categoryName: "Drama", catOrder: 1 },
    ];
    
    for (const cat of [...liveCats, ...movieCats, ...seriesCats]) {
      await db.insert(streamCategories).values(cat);
    }

    await db.insert(streamingServers).values({
      serverName: "Main Server",
      domainName: "iptv.local",
      serverIp: "127.0.0.1",
      httpBroadcastPort: 80,
      httpsBroadcastPort: 443,
      rtmpPort: 1935,
      status: 1,
      isMain: 1,
    });

    await db.insert(bouquets).values({
      bouquetName: "Full Package",
      bouquetChannels: "[]",
      bouquetMovies: "[]",
      bouquetSeries: "[]",
      bouquetStreams: "[]",
      bouquetRadios: "[]",
      bouquetOrder: 0,
    });

    await db.insert(accessOutput).values([
      { outputName: "HLS", outputKey: "m3u8", outputExt: "m3u8" },
      { outputName: "MPEGTS", outputKey: "ts", outputExt: "ts" },
      { outputName: "RTMP", outputKey: "rtmp", outputExt: "" },
    ]);

    await db.insert(streamsTypes).values([
      { typeName: "Live Streams", typeKey: "live", typeOutput: "live", live: 1 },
      { typeName: "Movies", typeKey: "movie", typeOutput: "movie", live: 0 },
      { typeName: "Created Live Channels", typeKey: "created_live", typeOutput: "live", live: 1 },
      { typeName: "Radio", typeKey: "radio_streams", typeOutput: "live", live: 1 },
      { typeName: "TV Series", typeKey: "series", typeOutput: "series", live: 0 },
    ]);

    const defaultSettings = [
      { type: "panel_name", value: "XC Panel" },
      { type: "panel_url", value: "http://localhost:5000" },
      { type: "timezone", value: "UTC" },
      { type: "default_language", value: "en" },
      // Cloudflare-compatible dual domain setup
      { type: "panel_domain", value: "" },        // Main domain (Cloudflare proxied - orange cloud)
      { type: "panel_port", value: "443" },       // Panel port (usually 443 for HTTPS)
      { type: "streaming_domain", value: "" },    // Streaming subdomain (DNS only - gray cloud)
      { type: "streaming_port", value: "80" },    // Streaming port
    ];
    
    for (const setting of defaultSettings) {
      await db.insert(adminSettings).values(setting);
    }
  }

  // Admin (reg_users) methods
  async getAdmins(): Promise<RegUser[]> {
    return db.select().from(regUsers);
  }

  async getAdmin(id: number): Promise<RegUser | undefined> {
    const [admin] = await db.select().from(regUsers).where(eq(regUsers.id, id));
    return admin;
  }

  async getAdminByUsername(username: string): Promise<RegUser | undefined> {
    const [admin] = await db.select().from(regUsers).where(eq(regUsers.username, username));
    return admin;
  }

  async createAdmin(admin: Partial<InsertRegUser> & { username: string; password: string }): Promise<RegUser> {
    const hashedPassword = await bcrypt.hash(admin.password, SALT_ROUNDS);
    const [newAdmin] = await db.insert(regUsers).values({
      username: admin.username,
      password: hashedPassword,
      email: admin.email || "",
      memberGroupId: admin.memberGroupId ?? 1,
      credits: admin.credits ?? 0,
      status: admin.status ?? 1,
      notes: admin.notes || null,
      dateRegistered: Math.floor(Date.now() / 1000),
      defaultLang: admin.defaultLang ?? "en",
      resellerDns: admin.resellerDns ?? "",
      google2faSec: admin.google2faSec ?? "",
      topbarTheme: admin.topbarTheme ?? "",
      navigationTheme: admin.navigationTheme ?? "",
      navigationTextColor: admin.navigationTextColor ?? "",
      dropbox: admin.dropbox ?? "",
    } as any).returning();
    return newAdmin;
  }

  async updateAdmin(id: number, admin: Partial<InsertRegUser>): Promise<RegUser | undefined> {
    const updateData = { ...admin };
    if (admin.password) {
      updateData.password = await bcrypt.hash(admin.password, SALT_ROUNDS);
    }
    const [updated] = await db.update(regUsers).set(updateData).where(eq(regUsers.id, id)).returning();
    return updated;
  }

  async deleteAdmin(id: number): Promise<boolean> {
    const result = await db.delete(regUsers).where(eq(regUsers.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  // User methods
  async getUsers(ownerId?: number): Promise<User[]> {
    if (ownerId) {
      return db.select().from(users).where(eq(users.memberId, ownerId));
    }
    return db.select().from(users);
  }

  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(user: Partial<InsertUser> & { username: string; password: string }): Promise<User> {
    const now = Math.floor(Date.now() / 1000);
    const [newUser] = await db.insert(users).values({
      username: user.username,
      password: user.password,
      adminNotes: user.adminNotes ?? "",
      resellerNotes: user.resellerNotes ?? "",
      bouquet: user.bouquet ?? "[]",
      allowedIps: user.allowedIps ?? "",
      allowedUa: user.allowedUa ?? "",
      createdBy: user.createdBy ?? 0,
      forcedCountry: user.forcedCountry ?? "",
      playToken: user.playToken ?? "",
      paid: user.paid ?? "",
      bouquetPackeg: user.bouquetPackeg ?? "",
      packageName: user.packageName ?? "",
      test: user.test ?? 0,
      providerDomain: user.providerDomain ?? "",
      maxConnections: user.maxConnections ?? 1,
      memberId: user.memberId ?? null,
      isTrial: user.isTrial ?? 0,
      enabled: user.enabled ?? 1,
      adminEnabled: user.adminEnabled ?? 1,
      expDate: user.expDate ?? null,
      createdAt: now,
    }).returning();
    return newUser;
  }

  async updateUser(id: number, user: Partial<InsertUser>): Promise<User | undefined> {
    const [updated] = await db.update(users).set(user).where(eq(users.id, id)).returning();
    return updated;
  }

  async deleteUser(id: number): Promise<boolean> {
    const result = await db.delete(users).where(eq(users.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async bulkCreateUsers(usersData: InsertUser[]): Promise<User[]> {
    const created: User[] = [];
    for (const user of usersData) {
      created.push(await this.createUser(user));
    }
    return created;
  }

  async bulkUpdateUsers(ids: number[], update: Partial<InsertUser>): Promise<number> {
    const result = await db.update(users).set(update).where(inArray(users.id, ids));
    return result.rowCount ?? 0;
  }

  async bulkDeleteUsers(ids: number[]): Promise<number> {
    const result = await db.delete(users).where(inArray(users.id, ids));
    return result.rowCount ?? 0;
  }

  async bulkExtendExpiration(ids: number[], days: number): Promise<number> {
    let count = 0;
    const secondsToAdd = days * 24 * 60 * 60;
    for (const id of ids) {
      const user = await this.getUser(id);
      if (user) {
        const now = Math.floor(Date.now() / 1000);
        const currentExp = user.expDate || now;
        const baseExp = currentExp > now ? currentExp : now;
        await this.updateUser(id, { expDate: baseExp + secondsToAdd });
        count++;
      }
    }
    return count;
  }

  async generateLine(options: { expirationDays: number; maxConnections: number; bouquetIds?: number[]; ownerId?: number; isTrial?: boolean }): Promise<GeneratedLine> {
    const username = generateUsername();
    const password = generatePassword();
    const now = Math.floor(Date.now() / 1000);
    const expDate = now + (options.expirationDays * 24 * 60 * 60);
    
    await this.createUser({
      username,
      password,
      maxConnections: options.maxConnections,
      bouquet: JSON.stringify(options.bouquetIds || []),
      memberId: options.ownerId || null,
      isTrial: options.isTrial ? 1 : 0,
      enabled: 1,
      adminEnabled: 1,
      expDate,
      createdBy: options.ownerId || 0,
    });

    const serverSetting = await this.getSetting("panel_url");
    const serverUrl = serverSetting?.value || "http://localhost:5000";
    const expDateStr = new Date(expDate * 1000).toISOString().split("T")[0];
    
    return {
      username,
      password,
      m3uUrl: `${serverUrl}/get.php?username=${username}&password=${password}&type=m3u_plus&output=ts`,
      expirationDate: expDateStr,
    };
  }

  async killUserConnections(userId: number): Promise<number> {
    const result = await db.delete(userActivityNow).where(eq(userActivityNow.userId, userId));
    return result.rowCount ?? 0;
  }

  // Stream methods
  async getStreams(type?: number): Promise<Stream[]> {
    if (type !== undefined) {
      return db.select().from(streams).where(eq(streams.type, type));
    }
    return db.select().from(streams);
  }

  async getStream(id: number): Promise<Stream | undefined> {
    const [stream] = await db.select().from(streams).where(eq(streams.id, id));
    return stream;
  }

  async createStream(stream: Partial<InsertStream> & { type: number; streamDisplayName: string; onDemand?: number; proxyEnable?: number; proxyIp?: string | null }): Promise<Stream> {
    const [newStream] = await db.insert(streams).values({
      type: stream.type,
      streamDisplayName: stream.streamDisplayName,
      streamSource: stream.streamSource ?? null,
      backupSources: stream.backupSources ?? [],
      streamIcon: stream.streamIcon ?? "",
      categoryId: stream.categoryId ?? null,
      channelId: stream.channelId ?? null,
      epgLang: stream.epgLang ?? "",
      notes: stream.notes ?? null,
      transcodeAttributes: stream.transcodeAttributes ?? "",
      customFfmpeg: stream.customFfmpeg ?? "",
      movieSubtitles: stream.movieSubtitles ?? "",
      autoRestart: stream.autoRestart ?? "",
      pidsCreateChannel: stream.pidsCreateChannel ?? "",
      cchannelRsources: stream.cchannelRsources ?? "",
      number: stream.number ?? 0,
      customMap: stream.customMap ?? "",
      externalPush: stream.externalPush ?? "",
      noRestreamUsers: stream.noRestreamUsers ?? "",
      allowRestreamUsers: stream.allowRestreamUsers ?? "",
      order: stream.order ?? 0,
      tvArchiveDuration: stream.tvArchiveDuration ?? 0,
      added: Math.floor(Date.now() / 1000),
      directSource: stream.directSource ?? 0,
      readNative: stream.readNative ?? 1,
      genTimestamps: stream.genTimestamps ?? 1,
      enableTranscode: stream.enableTranscode ?? 0,
      transcodeProfileId: stream.transcodeProfileId ?? 0,
      allowRecord: stream.allowRecord ?? 0,
      delayMinutes: stream.delayMinutes ?? 0,
      targetContainer: stream.targetContainer ?? null,
      userAgent: stream.userAgent ?? null,
      onDemand: stream.onDemand ?? 0,
      proxyEnable: stream.proxyEnable ?? 0,
      proxyIp: stream.proxyIp ?? null,
    } as any).returning();
    return newStream;
  }

  async updateStream(id: number, stream: Partial<InsertStream>): Promise<Stream | undefined> {
    const [updated] = await db.update(streams).set(stream).where(eq(streams.id, id)).returning();
    return updated;
  }

  async deleteStream(id: number): Promise<boolean> {
    const result = await db.delete(streams).where(eq(streams.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  // Series methods
  async getSeries(): Promise<Series[]> {
    return db.select().from(series);
  }

  async getSeriesById(id: number): Promise<Series | undefined> {
    const [s] = await db.select().from(series).where(eq(series.id, id));
    return s;
  }

  async createSeries(seriesData: InsertSeries): Promise<Series> {
    const [newSeries] = await db.insert(series).values({
      ...seriesData,
      lastModified: Math.floor(Date.now() / 1000),
    }).returning();
    return newSeries;
  }

  async updateSeries(id: number, seriesData: Partial<InsertSeries>): Promise<Series | undefined> {
    const [updated] = await db.update(series).set({
      ...seriesData,
      lastModified: Math.floor(Date.now() / 1000),
    }).where(eq(series.id, id)).returning();
    return updated;
  }

  async deleteSeries(id: number): Promise<boolean> {
    await db.delete(seriesEpisodes).where(eq(seriesEpisodes.seriesId, id));
    const result = await db.delete(series).where(eq(series.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  // Series Episodes methods
  async getSeriesEpisodes(seriesId?: number): Promise<SeriesEpisode[]> {
    if (seriesId) {
      return db.select().from(seriesEpisodes).where(eq(seriesEpisodes.seriesId, seriesId));
    }
    return db.select().from(seriesEpisodes);
  }

  async getSeriesEpisode(id: number): Promise<SeriesEpisode | undefined> {
    const [episode] = await db.select().from(seriesEpisodes).where(eq(seriesEpisodes.id, id));
    return episode;
  }

  async createSeriesEpisode(episode: InsertSeriesEpisode): Promise<SeriesEpisode> {
    const [newEpisode] = await db.insert(seriesEpisodes).values(episode).returning();
    return newEpisode;
  }

  async updateSeriesEpisode(id: number, episode: Partial<InsertSeriesEpisode>): Promise<SeriesEpisode | undefined> {
    const [updated] = await db.update(seriesEpisodes).set(episode).where(eq(seriesEpisodes.id, id)).returning();
    return updated;
  }

  async deleteSeriesEpisode(id: number): Promise<boolean> {
    const result = await db.delete(seriesEpisodes).where(eq(seriesEpisodes.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  // Category methods
  async getCategories(type?: string): Promise<StreamCategory[]> {
    if (type) {
      return db.select().from(streamCategories).where(eq(streamCategories.categoryType, type));
    }
    return db.select().from(streamCategories);
  }

  async getCategory(id: number): Promise<StreamCategory | undefined> {
    const [category] = await db.select().from(streamCategories).where(eq(streamCategories.id, id));
    return category;
  }

  async createCategory(category: InsertStreamCategory): Promise<StreamCategory> {
    const [newCategory] = await db.insert(streamCategories).values(category).returning();
    return newCategory;
  }

  async updateCategory(id: number, category: Partial<InsertStreamCategory>): Promise<StreamCategory | undefined> {
    const [updated] = await db.update(streamCategories).set(category).where(eq(streamCategories.id, id)).returning();
    return updated;
  }

  async deleteCategory(id: number): Promise<boolean> {
    const result = await db.delete(streamCategories).where(eq(streamCategories.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  // Bouquet methods
  async getBouquets(): Promise<Bouquet[]> {
    return db.select().from(bouquets);
  }

  async getBouquet(id: number): Promise<Bouquet | undefined> {
    const [bouquet] = await db.select().from(bouquets).where(eq(bouquets.id, id));
    return bouquet;
  }

  async createBouquet(bouquet: InsertBouquet): Promise<Bouquet> {
    const [newBouquet] = await db.insert(bouquets).values(bouquet).returning();
    return newBouquet;
  }

  async updateBouquet(id: number, bouquet: Partial<InsertBouquet>): Promise<Bouquet | undefined> {
    const [updated] = await db.update(bouquets).set(bouquet).where(eq(bouquets.id, id)).returning();
    return updated;
  }

  async deleteBouquet(id: number): Promise<boolean> {
    const result = await db.delete(bouquets).where(eq(bouquets.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  // Server methods
  async getServers(): Promise<StreamingServer[]> {
    return db.select().from(streamingServers);
  }

  async getServer(id: number): Promise<StreamingServer | undefined> {
    const [server] = await db.select().from(streamingServers).where(eq(streamingServers.id, id));
    return server;
  }

  async createServer(server: InsertStreamingServer): Promise<StreamingServer> {
    const [newServer] = await db.insert(streamingServers).values(server).returning();
    return newServer;
  }

  async updateServer(id: number, server: Partial<InsertStreamingServer>): Promise<StreamingServer | undefined> {
    const [updated] = await db.update(streamingServers).set(server).where(eq(streamingServers.id, id)).returning();
    return updated;
  }

  async deleteServer(id: number): Promise<boolean> {
    const result = await db.delete(streamingServers).where(eq(streamingServers.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  // EPG methods
  async getEpgSources(): Promise<Epg[]> {
    return db.select().from(epg);
  }

  async getEpgSource(id: number): Promise<Epg | undefined> {
    const [source] = await db.select().from(epg).where(eq(epg.id, id));
    return source;
  }

  async createEpgSource(epgSource: InsertEpg): Promise<Epg> {
    const [newEpg] = await db.insert(epg).values(epgSource).returning();
    return newEpg;
  }

  async updateEpgSource(id: number, epgSource: Partial<InsertEpg>): Promise<Epg | undefined> {
    const [updated] = await db.update(epg).set(epgSource).where(eq(epg.id, id)).returning();
    return updated;
  }

  async deleteEpgSource(id: number): Promise<boolean> {
    const result = await db.delete(epg).where(eq(epg.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async getEpgChannels(epgId: number): Promise<{ channelId: string; lang: string }[]> {
    const channels = await db
      .selectDistinct({ channelId: epgData.channelId, lang: epgData.lang })
      .from(epgData)
      .where(eq(epgData.epgId, epgId));
    return channels;
  }

  // EPG Data methods - program listings
  async getEpgDataByChannel(channelId: string, startTime?: number, endTime?: number): Promise<EpgData[]> {
    const now = Math.floor(Date.now() / 1000);
    const start = startTime || now;
    const end = endTime || (now + 86400 * 7); // Default 7 days
    
    return db.select().from(epgData)
      .where(
        and(
          eq(epgData.channelId, channelId),
          gte(epgData.start, start),
          lte(epgData.start, end)
        )
      )
      .orderBy(epgData.start);
  }

  async getEpgDataNowPlaying(channelId: string): Promise<EpgData | undefined> {
    const now = Math.floor(Date.now() / 1000);
    
    const [current] = await db.select().from(epgData)
      .where(
        and(
          eq(epgData.channelId, channelId),
          lte(epgData.start, now),
          gte(epgData.end, now)
        )
      )
      .limit(1);
    
    return current;
  }

  async getAllEpgData(): Promise<EpgData[]> {
    const now = Math.floor(Date.now() / 1000);
    const weekFromNow = now + 86400 * 7;
    
    return db.select().from(epgData)
      .where(
        and(
          gte(epgData.start, now - 3600), // Include programs started within last hour
          lte(epgData.start, weekFromNow)
        )
      )
      .orderBy(epgData.channelId, epgData.start);
  }

  async saveEpgData(data: InsertEpgData[]): Promise<number> {
    if (data.length === 0) return 0;
    
    // Insert in batches of 500
    const batchSize = 500;
    let inserted = 0;
    
    for (let i = 0; i < data.length; i += batchSize) {
      const batch = data.slice(i, i + batchSize);
      await db.insert(epgData).values(batch);
      inserted += batch.length;
    }
    
    return inserted;
  }

  async clearEpgData(epgId?: number): Promise<number> {
    if (epgId) {
      const result = await db.delete(epgData).where(eq(epgData.epgId, epgId));
      return result.rowCount ?? 0;
    }
    const result = await db.delete(epgData);
    return result.rowCount ?? 0;
  }

  // Connection methods (user_activity_now)
  async getConnections(): Promise<UserActivityNow[]> {
    return db.select().from(userActivityNow);
  }

  async getConnectionsByStream(streamId: number): Promise<UserActivityNow[]> {
    return db.select().from(userActivityNow).where(eq(userActivityNow.streamId, streamId));
  }

  async getConnectionsByUser(userId: number): Promise<UserActivityNow[]> {
    return db.select().from(userActivityNow).where(eq(userActivityNow.userId, userId));
  }

  async countUserConnections(userId: number): Promise<number> {
    const connections = await db.select().from(userActivityNow).where(eq(userActivityNow.userId, userId));
    return connections.length;
  }

  async getConnection(id: number): Promise<UserActivityNow | undefined> {
    const [connection] = await db.select().from(userActivityNow).where(eq(userActivityNow.activityId, id));
    return connection;
  }

  async createConnection(connection: InsertUserActivityNow): Promise<UserActivityNow> {
    const [newConnection] = await db.insert(userActivityNow).values({
      ...connection,
      dateStart: Math.floor(Date.now() / 1000),
    }).returning();
    return newConnection;
  }

  async deleteConnection(id: number): Promise<boolean> {
    const result = await db.delete(userActivityNow).where(eq(userActivityNow.activityId, id));
    return (result.rowCount ?? 0) > 0;
  }

  async killAllConnections(userId?: number): Promise<number> {
    if (userId) {
      const result = await db.delete(userActivityNow).where(eq(userActivityNow.userId, userId));
      return result.rowCount ?? 0;
    }
    const result = await db.delete(userActivityNow);
    return result.rowCount ?? 0;
  }

  // Touch connection - update heartbeat timestamp
  async touchConnection(activityId: number): Promise<void> {
    const now = Math.floor(Date.now() / 1000);
    await db.update(userActivityNow)
      .set({ hlsLastRead: now })
      .where(eq(userActivityNow.activityId, activityId));
  }

  // Touch connection by user+stream - update heartbeat timestamp, IP, userAgent, serverId, and geoip
  async touchConnectionByUserStream(userId: number, streamId: number, serverId?: number, clientIp?: string, userAgent?: string, geoipCountryCode?: string | null): Promise<void> {
    const now = Math.floor(Date.now() / 1000);
    
    // Build update object - always update hlsLastRead
    const updateData: any = { hlsLastRead: now };
    if (clientIp && clientIp !== '0.0.0.0') {
      updateData.userIp = clientIp;
    }
    if (userAgent && userAgent !== 'LB Proxy' && userAgent !== 'Unknown') {
      updateData.userAgent = userAgent;
    }
    if (serverId !== undefined) {
      updateData.serverId = serverId;
    }
    if (geoipCountryCode) {
      updateData.geoipCountryCode = geoipCountryCode;
    }
    
    // Update ANY connection for this user+stream (avoid duplicates)
    await db.update(userActivityNow)
      .set(updateData)
      .where(and(
        eq(userActivityNow.userId, userId),
        eq(userActivityNow.streamId, streamId)
      ));
  }

  // Expire stale connections - remove connections older than maxAgeSeconds
  async expireStaleConnections(userId: number, maxAgeSeconds: number = 60): Promise<number> {
    const cutoff = Math.floor(Date.now() / 1000) - maxAgeSeconds;
    // Delete connections where hlsLastRead is null (never updated) and dateStart is old
    // OR where hlsLastRead exists and is old
    const result = await db.delete(userActivityNow).where(
      and(
        eq(userActivityNow.userId, userId),
        or(
          and(
            sql`${userActivityNow.hlsLastRead} IS NULL`,
            lt(userActivityNow.dateStart, cutoff)
          ),
          lt(userActivityNow.hlsLastRead, cutoff)
        )
      )
    );
    return result.rowCount ?? 0;
  }

  // Replace connection from same IP - handles channel switching
  // If user switches to different stream from same IP, delete old connection first
  async replaceConnectionFromSameIp(userId: number, userIp: string, streamId: number): Promise<boolean> {
    const now = Math.floor(Date.now() / 1000);
    
    // Find existing connection from same user+IP (any stream)
    const [existing] = await db.select().from(userActivityNow).where(
      and(
        eq(userActivityNow.userId, userId),
        eq(userActivityNow.userIp, userIp)
      )
    );
    
    if (existing) {
      if (existing.streamId === streamId) {
        // Same stream on same IP - just refresh the timestamp (playlist refresh)
        await db.update(userActivityNow)
          .set({ hlsLastRead: now })
          .where(eq(userActivityNow.activityId, existing.activityId));
        return true; // Connection was refreshed
      } else {
        // Different stream from same IP - channel switch!
        // Delete old connection so new one can be created
        await db.delete(userActivityNow)
          .where(eq(userActivityNow.activityId, existing.activityId));
        console.log(`[CONNECTION] Channel switch: user ${userId} from stream ${existing.streamId} to ${streamId}`);
        return false; // Return false so new connection is created
      }
    }
    return false; // No existing connection - will create new one
  }

  // Replace MAG connection - MAG uses single connection model, always replace without blocking
  async replaceOrCreateMagConnection(magMac: string, userId: number, streamId: number, userIp: string, userAgent: string): Promise<void> {
    const now = Math.floor(Date.now() / 1000);
    
    // Lookup GeoIP for country code
    const geoData = await lookupGeoIP(userIp);
    
    // Find existing connection for this user (MAG always has 1 connection)
    const [existing] = await db.select().from(userActivityNow).where(
      eq(userActivityNow.userId, userId)
    );
    
    if (existing) {
      // Update existing connection to new stream - never block!
      await db.update(userActivityNow)
        .set({ 
          streamId: streamId, 
          dateStart: now,
          hlsLastRead: now,
          userIp: userIp,
          userAgent: userAgent,
          geoipCountryCode: geoData.countryCode || null,
        })
        .where(eq(userActivityNow.activityId, existing.activityId));
    } else {
      // Create new connection
      await db.insert(userActivityNow).values({
        userId: userId,
        streamId: streamId,
        serverId: 1,
        userIp: userIp,
        userAgent: userAgent,
        container: "ts",
        dateStart: now,
        hlsLastRead: now,
        geoipCountryCode: geoData.countryCode || null,
      });
    }
  }

  // MAG Device methods
  async getMagDevices(): Promise<MagDevice[]> {
    return db.select().from(magDevices);
  }

  async getMagDevice(id: number): Promise<MagDevice | undefined> {
    const [device] = await db.select().from(magDevices).where(eq(magDevices.magId, id));
    return device;
  }

  async getMagDeviceByMac(mac: string): Promise<MagDevice | undefined> {
    // Normalize MAC address for comparison (remove colons and uppercase)
    const normalizedInput = mac.toUpperCase().replace(/:/g, "");
    
    // Fetch all devices and compare normalized MAC addresses
    const devices = await db.select().from(magDevices);
    return devices.find(d => d.mac.toUpperCase().replace(/:/g, "") === normalizedInput);
  }

  async createMagDevice(device: InsertMagDevice): Promise<MagDevice> {
    const deviceWithDefaults = {
      ...device,
      created: Math.floor(Date.now() / 1000),
    };
    const [newDevice] = await db.insert(magDevices).values(deviceWithDefaults).returning();
    return newDevice;
  }

  async updateMagDevice(id: number, device: Partial<InsertMagDevice>): Promise<MagDevice | undefined> {
    const [updated] = await db.update(magDevices).set(device).where(eq(magDevices.magId, id)).returning();
    return updated;
  }

  async deleteMagDevice(id: number): Promise<boolean> {
    const result = await db.delete(magDevices).where(eq(magDevices.magId, id));
    return (result.rowCount ?? 0) > 0;
  }

  // Activity logs (panel_logs)
  async getActivityLogs(limit = 100, filters?: { adminId?: number; action?: string }): Promise<PanelLog[]> {
    let query = db.select().from(panelLogs);
    
    if (filters?.adminId) {
      query = query.where(eq(panelLogs.ownerId, filters.adminId)) as any;
    }
    
    return query.orderBy(desc(panelLogs.date)).limit(limit);
  }

  async createActivityLog(log: InsertPanelLog): Promise<PanelLog> {
    const [newLog] = await db.insert(panelLogs).values({
      ...log,
      date: Math.floor(Date.now() / 1000),
    }).returning();
    return newLog;
  }

  // Settings methods (admin_settings)
  async getSettings(): Promise<AdminSetting[]> {
    return db.select().from(adminSettings);
  }

  async getSetting(key: string): Promise<AdminSetting | undefined> {
    const [setting] = await db.select().from(adminSettings).where(eq(adminSettings.type, key));
    return setting;
  }

  async setSetting(key: string, value: string): Promise<AdminSetting> {
    const existing = await this.getSetting(key);
    if (existing) {
      const [updated] = await db.update(adminSettings).set({ value }).where(eq(adminSettings.type, key)).returning();
      return updated;
    }
    const [newSetting] = await db.insert(adminSettings).values({ type: key, value }).returning();
    return newSetting;
  }

  // Blocked IPs (Security)
  async getBlockedIps(): Promise<BlockedIp[]> {
    return db.select().from(blockedIps);
  }

  async getBlockedIp(id: number): Promise<BlockedIp | undefined> {
    const [ip] = await db.select().from(blockedIps).where(eq(blockedIps.id, id));
    return ip;
  }

  async createBlockedIp(data: InsertBlockedIp): Promise<BlockedIp> {
    const [ip] = await db.insert(blockedIps).values({
      ip: data.ip,
      notes: data.notes || "",
      date: data.date || Math.floor(Date.now() / 1000),
      attemptsBlocked: data.attemptsBlocked || 0,
    }).returning();
    return ip;
  }

  async deleteBlockedIp(id: number): Promise<boolean> {
    const result = await db.delete(blockedIps).where(eq(blockedIps.id, id)).returning();
    return result.length > 0;
  }

  // Blocked User Agents
  async getBlockedUserAgents(): Promise<BlockedUserAgent[]> {
    return db.select().from(blockedUserAgents);
  }

  async getBlockedUserAgent(id: number): Promise<BlockedUserAgent | undefined> {
    const [ua] = await db.select().from(blockedUserAgents).where(eq(blockedUserAgents.id, id));
    return ua;
  }

  async createBlockedUserAgent(data: InsertBlockedUserAgent): Promise<BlockedUserAgent> {
    const [ua] = await db.insert(blockedUserAgents).values({
      userAgent: data.userAgent,
      exactMatch: data.exactMatch || 0,
      attemptsBlocked: data.attemptsBlocked || 0,
    }).returning();
    return ua;
  }

  async deleteBlockedUserAgent(id: number): Promise<boolean> {
    const result = await db.delete(blockedUserAgents).where(eq(blockedUserAgents.id, id)).returning();
    return result.length > 0;
  }

  // Allowed IPs (Whitelist)
  async getAllowedIps(): Promise<AllowedIp[]> {
    return db.select().from(allowedIps);
  }

  async getAllowedIp(id: number): Promise<AllowedIp | undefined> {
    const [ip] = await db.select().from(allowedIps).where(eq(allowedIps.id, id));
    return ip;
  }

  async createAllowedIp(data: InsertAllowedIp): Promise<AllowedIp> {
    const [ip] = await db.insert(allowedIps).values({
      ip: data.ip,
      notes: data.notes || "",
      date: data.date || Math.floor(Date.now() / 1000),
    }).returning();
    return ip;
  }

  async deleteAllowedIp(id: number): Promise<boolean> {
    const result = await db.delete(allowedIps).where(eq(allowedIps.id, id)).returning();
    return result.length > 0;
  }

  private normalizeIp(ip: string): string {
    if (ip.startsWith('::ffff:')) {
      return ip.substring(7);
    }
    return ip;
  }

  async isIpAllowed(ip: string): Promise<boolean> {
    const allowedList = await this.getAllowedIps();
    if (allowedList.length === 0) {
      return true;
    }
    const normalizedIp = this.normalizeIp(ip);
    return allowedList.some(allowed => {
      const allowedIp = allowed.ip;
      if (allowedIp.endsWith('.*')) {
        const prefix = allowedIp.slice(0, -1);
        return normalizedIp.startsWith(prefix);
      }
      return normalizedIp === allowedIp;
    });
  }

  async isIpBlocked(ip: string): Promise<boolean> {
    const blockedList = await this.getBlockedIps();
    const normalizedIp = this.normalizeIp(ip);
    return blockedList.some(blocked => {
      const blockedIp = blocked.ip;
      if (blockedIp.endsWith('.*')) {
        const prefix = blockedIp.slice(0, -1);
        return normalizedIp.startsWith(prefix);
      }
      return normalizedIp === blockedIp;
    });
  }

  // Stream status helper - parse streamInfo JSON/text
  private parseStreamInfo(streamInfoText: string | null): ParsedStreamInfo {
    const defaultInfo: ParsedStreamInfo = {
      resolution: "",
      videoCodec: "",
      audioCodec: "",
      fps: "",
      playbackSpeed: ""
    };
    
    if (!streamInfoText) return defaultInfo;
    
    try {
      const info = JSON.parse(streamInfoText);
      // Fix precedence: check resolution first, then fallback to width x height
      let resolution = "";
      if (info.resolution) {
        resolution = info.resolution;
      } else if (info.width && info.height) {
        resolution = `${info.width}x${info.height}`;
      }
      return {
        resolution,
        videoCodec: info.videoCodec || info.video_codec || info.codec || "",
        audioCodec: info.audioCodec || info.audio_codec || "",
        fps: info.fps || info.framerate || "",
        playbackSpeed: info.speed || info.playbackSpeed || ""
      };
    } catch {
      // Try parsing as key=value format
      const result = { ...defaultInfo };
      const pairs = streamInfoText.split(/[,\n]/);
      for (const pair of pairs) {
        const [key, value] = pair.split('=').map(s => s?.trim());
        if (key && value) {
          if (key.toLowerCase().includes('resolution') || key === 'size') result.resolution = value;
          if (key.toLowerCase().includes('video') || key === 'vcodec') result.videoCodec = value;
          if (key.toLowerCase().includes('audio') || key === 'acodec') result.audioCodec = value;
          if (key.toLowerCase().includes('fps') || key === 'framerate') result.fps = value;
          if (key.toLowerCase().includes('speed')) result.playbackSpeed = value;
        }
      }
      return result;
    }
  }

  // Get stream status for multiple streams
  async getStreamStatuses(streamIds?: number[]): Promise<StreamStatusResponse[]> {
    const now = Math.floor(Date.now() / 1000);
    
    // Get all stream system records (or filter by IDs)
    let sysRecords;
    if (streamIds && streamIds.length > 0) {
      sysRecords = await db.select().from(streamsSys).where(inArray(streamsSys.streamId, streamIds));
    } else {
      sysRecords = await db.select().from(streamsSys);
    }
    
    // Get server info for mapping
    const servers = await this.getServers();
    const serverMap = new Map(servers.map(s => [s.id, s]));
    
    // Map system records to status responses
    return sysRecords.map(sys => {
      const server = sys.serverId ? serverMap.get(sys.serverId) : null;
      
      // Determine status from streamStatus field (0=offline, 1=online, 2=restarting)
      let status: "online" | "offline" | "restarting" | "error" = "offline";
      if (sys.streamStatus === 1) status = "online";
      else if (sys.streamStatus === 2) status = "restarting";
      else if (sys.streamDown === 1) status = "error";
      
      // Calculate uptime/downtime
      let uptimeSeconds = 0;
      let downtimeSeconds = 0;
      
      if (status === "online" && sys.streamStarted) {
        uptimeSeconds = now - sys.streamStarted;
      } else if ((status === "offline" || status === "error") && sys.streamStopped) {
        downtimeSeconds = now - sys.streamStopped;
      }
      
      return {
        streamId: sys.streamId,
        serverId: sys.serverId,
        serverName: server?.serverName || null,
        status,
        streamStarted: sys.streamStarted,
        streamStopped: sys.streamStopped,
        uptimeSeconds: Math.max(0, uptimeSeconds),
        downtimeSeconds: Math.max(0, downtimeSeconds),
        bitrate: sys.bitrate,
        streamInfo: this.parseStreamInfo(sys.streamInfo),
        outputFormats: ["ts", "m3u8"],
        activeSourceIndex: sys.activeSourceIndex ?? 0,
        lastFailoverAt: sys.lastFailoverAt ?? null,
      };
    });
  }

  // Get status for a single stream
  async getStreamStatus(streamId: number): Promise<StreamStatusResponse | undefined> {
    const statuses = await this.getStreamStatuses([streamId]);
    return statuses[0];
  }

  // Update stream status
  async updateStreamStatus(streamId: number, status: Partial<InsertStreamsSys>): Promise<boolean> {
    const existing = await db.select().from(streamsSys).where(eq(streamsSys.streamId, streamId)).limit(1);
    
    // Filter out undefined values to prevent overwriting existing data
    const cleanStatus: Partial<InsertStreamsSys> = {};
    for (const [key, value] of Object.entries(status)) {
      if (value !== undefined) {
        (cleanStatus as any)[key] = value;
      }
    }
    
    if (existing.length === 0) {
      // Create new record
      await db.insert(streamsSys).values({
        streamId,
        serverId: cleanStatus.serverId || 1,
        streamStatus: cleanStatus.streamStatus ?? 0,
        streamStarted: cleanStatus.streamStarted,
        streamStopped: cleanStatus.streamStopped,
        streamDown: cleanStatus.streamDown ?? 0,
        streamInfo: cleanStatus.streamInfo || "",
        bitrate: cleanStatus.bitrate,
        progressInfo: cleanStatus.progressInfo || "",
        onDemand: cleanStatus.onDemand ?? 0,
        toAnalyze: cleanStatus.toAnalyze ?? 0,
        activeSourceIndex: cleanStatus.activeSourceIndex ?? 0,
        lastFailoverAt: cleanStatus.lastFailoverAt,
        currentSource: cleanStatus.currentSource,
      });
    } else {
      await db.update(streamsSys).set(cleanStatus).where(eq(streamsSys.streamId, streamId));
    }
    
    return true;
  }

  // Dashboard stats
  async getDashboardStats(ownerId?: number): Promise<DashboardStats> {
    const now = Math.floor(Date.now() / 1000);
    // For resellers, only get their own users
    const allUsers = await this.getUsers(ownerId);
    const allStreams = await this.getStreams();
    const allSeries = await this.getSeries();
    const allServers = await this.getServers();
    const allConnections = await this.getConnections();
    const allAdmins = await this.getAdmins();

    const liveStreams = allStreams.filter(s => s.type === STREAM_TYPE_LIVE);
    const movies = allStreams.filter(s => s.type === STREAM_TYPE_MOVIE);

    // For resellers, filter connections to only their users
    const userIds = new Set(allUsers.map(u => u.id));
    const resellerConnections = ownerId 
      ? allConnections.filter(c => userIds.has(c.userId))
      : allConnections;

    // Count unique users currently watching (have active connections)
    const uniqueWatchingUserIds = new Set(resellerConnections.map(c => c.userId));
    const usersWatchingNow = uniqueWatchingUserIds.size;

    // Count streams that have active connections (viewers)
    const uniqueActiveStreamIds = new Set(resellerConnections.filter(c => {
      const stream = allStreams.find(s => s.id === c.streamId);
      return stream?.type === STREAM_TYPE_LIVE;
    }).map(c => c.streamId));
    const streamsWithViewers = uniqueActiveStreamIds.size;

    // Server status: status=1 is online, status=0 is offline, status=-1 is unchecked
    const onlineServers = allServers.filter(s => s.status === 1).length;
    const offlineServers = allServers.filter(s => s.status === 0).length;

    // For resellers, don't show stream/server counts (they don't have access)
    const isReseller = !!ownerId;

    return {
      totalUsers: allUsers.length,
      activeUsers: usersWatchingNow, // Users currently watching streams RIGHT NOW
      expiredUsers: allUsers.filter(u => u.expDate !== null && u.expDate <= now).length,
      bannedUsers: allUsers.filter(u => u.enabled === 0 || u.adminEnabled === 0).length,
      trialUsers: allUsers.filter(u => u.isTrial === 1).length,
      totalConnections: resellerConnections.length,
      totalStreams: isReseller ? 0 : liveStreams.length,
      activeStreams: isReseller ? 0 : streamsWithViewers,
      offlineStreams: isReseller ? 0 : liveStreams.length - streamsWithViewers,
      totalMovies: isReseller ? 0 : movies.length,
      totalSeries: isReseller ? 0 : allSeries.length,
      totalEpisodes: isReseller ? 0 : (await this.getSeriesEpisodes()).length,
      totalServers: isReseller ? 0 : allServers.length,
      onlineServers: isReseller ? 0 : onlineServers,
      offlineServers: isReseller ? 0 : offlineServers,
      totalBandwidthIn: 0,
      totalBandwidthOut: 0,
      totalResellers: isReseller ? 0 : allAdmins.filter(a => a.memberGroupId === 2).length,
    };
  }

  // Playlist generation - filters by user's assigned bouquets
  // Supports Cloudflare setup: panel domain (proxied) vs streaming domain (DNS only)
  // Supports Reseller DNS: if user was created by reseller with custom DNS, use that
  async generatePlaylist(userId: number, format: string, type: string): Promise<string> {
    const user = await this.getUser(userId);
    if (!user) return "";

    // Get panel URL for EPG and API endpoints
    const serverSetting = await this.getSetting("panel_url");
    const panelUrl = serverSetting?.value || "http://iptv.local";
    
    // Check if user belongs to a reseller with custom DNS
    let resellerDns = "";
    if (user.memberId) {
      const reseller = await this.getAdmin(user.memberId);
      if (reseller && reseller.resellerDns) {
        resellerDns = reseller.resellerDns;
      }
    }
    
    // Get streaming domain settings (Cloudflare DNS-only subdomain for streams)
    const streamingDomainSetting = await this.getSetting("streaming_domain");
    const streamingPortSetting = await this.getSetting("streaming_port");
    const streamingDomain = streamingDomainSetting?.value || "";
    const streamingPort = streamingPortSetting?.value || "80";
    
    // Priority: Reseller DNS > Streaming Domain > Panel URL
    let streamingUrl: string;
    if (resellerDns) {
      // Use reseller's custom DNS - assume http unless starts with https://
      if (resellerDns.startsWith("http://") || resellerDns.startsWith("https://")) {
        streamingUrl = resellerDns.replace(/\/$/, ""); // Remove trailing slash
      } else {
        streamingUrl = `http://${resellerDns}`;
      }
    } else if (streamingDomain) {
      const protocol = streamingPort === "443" ? "https" : "http";
      const portSuffix = (streamingPort === "80" || streamingPort === "443") ? "" : `:${streamingPort}`;
      streamingUrl = `${protocol}://${streamingDomain}${portSuffix}`;
    } else {
      streamingUrl = panelUrl;
    }
    
    // For EPG URL, also use reseller DNS if available
    const epgBaseUrl = resellerDns ? streamingUrl : panelUrl;
    
    // Check if external proxy is enabled (token-based authentication)
    const externalProxyEnabledSetting = await this.getSetting("external_proxy_enabled");
    const externalProxyEnabled = externalProxyEnabledSetting?.value === "1";
    const externalProxyUrlSetting = await this.getSetting("external_proxy_url");
    const externalProxyUrl = externalProxyUrlSetting?.value || "";
    const secretKeySetting = await this.getSetting("proxy_secret_key");
    const secretKey = secretKeySetting?.value || "";
    const ttlSetting = await this.getSetting("proxy_token_ttl");
    const tokenTtl = parseInt(ttlSetting?.value || "14400");
    
    // Use external proxy if enabled and properly configured
    const useExternalProxy = externalProxyEnabled && externalProxyUrl && secretKey;
    
    // Get user's assigned bouquets
    let userBouquetIds: number[] = [];
    try {
      if (user.bouquet) {
        userBouquetIds = JSON.parse(user.bouquet).map((id: number | string) => Number(id));
      }
    } catch {
      userBouquetIds = [];
    }

    // Get all bouquets and filter by user's assignments
    const allBouquets = await this.getBouquets();
    const userBouquets = userBouquetIds.length > 0 
      ? allBouquets.filter(b => userBouquetIds.includes(b.id)).sort((a, b) => a.bouquetOrder - b.bouquetOrder)
      : allBouquets.sort((a, b) => a.bouquetOrder - b.bouquetOrder);

    // Collect allowed stream IDs from bouquets (in order)
    const allowedLiveIds: number[] = [];
    const allowedMovieIds: number[] = [];
    
    for (const bouquet of userBouquets) {
      try {
        const channelIds = bouquet.bouquetChannels ? JSON.parse(bouquet.bouquetChannels) : [];
        const movieIds = bouquet.bouquetMovies ? JSON.parse(bouquet.bouquetMovies) : [];
        
        for (const id of channelIds) {
          if (!allowedLiveIds.includes(Number(id))) allowedLiveIds.push(Number(id));
        }
        for (const id of movieIds) {
          if (!allowedMovieIds.includes(Number(id))) allowedMovieIds.push(Number(id));
        }
      } catch {
        // Skip malformed bouquet data
      }
    }
    
    // Add EPG URL to M3U header (EPG uses panel domain)
    const epgUrl = `${epgBaseUrl}/xmltv.php?username=${user.username}&password=${user.password}`;
    let content = `#EXTM3U url-tvg="${epgUrl}"\n`;
    
    if (type === "live" || type === "all") {
      const liveStreams = await this.getStreams(STREAM_TYPE_LIVE);
      const categories = await this.getCategories("live");
      const categoryMap = new Map(categories.map(c => [c.id, c.categoryName]));
      
      // Filter and order by bouquet assignment
      const orderedStreams = allowedLiveIds.length > 0
        ? allowedLiveIds.map(id => liveStreams.find(s => s.id === id)).filter(Boolean) as typeof liveStreams
        : liveStreams;
      
      for (const stream of orderedStreams) {
        const categoryName = stream.categoryId ? categoryMap.get(stream.categoryId) || "Uncategorized" : "Uncategorized";
        content += `#EXTINF:-1 tvg-id="${stream.channelId || ""}" tvg-logo="${stream.streamIcon || ""}" group-title="${categoryName}",${stream.streamDisplayName}\n`;
        
        if (useExternalProxy) {
          // Generate signed URL pointing to external Nginx proxy
          const proxyUrl = await createSignedProxyUrl(externalProxyUrl, secretKey, user.id, user.username, stream.id, 'live', tokenTtl);
          content += proxyUrl + "\n";
        } else {
          // Use streaming domain for direct streaming (bypasses Cloudflare)
          content += `${streamingUrl}/live/${user.username}/${user.password}/${stream.id}.ts\n`;
        }
      }
    }
    
    if (type === "vod" || type === "all") {
      const movies = await this.getStreams(STREAM_TYPE_MOVIE);
      const categories = await this.getCategories("movie");
      const categoryMap = new Map(categories.map(c => [c.id, c.categoryName]));
      
      // Filter and order by bouquet assignment
      const orderedMovies = allowedMovieIds.length > 0
        ? allowedMovieIds.map(id => movies.find(m => m.id === id)).filter(Boolean) as typeof movies
        : movies;
      
      for (const movie of orderedMovies) {
        const categoryName = movie.categoryId ? categoryMap.get(movie.categoryId) || "Uncategorized" : "Uncategorized";
        content += `#EXTINF:-1 tvg-logo="${movie.streamIcon || ""}" group-title="${categoryName}",${movie.streamDisplayName}\n`;
        
        if (useExternalProxy) {
          // Generate signed URL pointing to external Nginx proxy
          const proxyUrl = await createSignedProxyUrl(externalProxyUrl, secretKey, user.id, user.username, movie.id, 'movie', tokenTtl);
          content += proxyUrl + "\n";
        } else {
          // Use streaming domain for direct streaming (bypasses Cloudflare)
          content += `${streamingUrl}/movie/${user.username}/${user.password}/${movie.id}.mp4\n`;
        }
      }
    }
    
    return content;
  }

  // Enigma2 playlist generation
  // Supports Cloudflare setup: panel domain (proxied) vs streaming domain (DNS only)
  async generateEnigma2Playlist(userId: number): Promise<string> {
    const user = await this.getUser(userId);
    if (!user) return "";

    // Get panel URL for API endpoints
    const serverSetting = await this.getSetting("panel_url");
    const panelUrl = serverSetting?.value || "http://iptv.local";
    
    // Get streaming domain settings (Cloudflare DNS-only subdomain for streams)
    const streamingDomainSetting = await this.getSetting("streaming_domain");
    const streamingPortSetting = await this.getSetting("streaming_port");
    const streamingDomain = streamingDomainSetting?.value || "";
    const streamingPort = streamingPortSetting?.value || "80";
    
    // Build streaming URL: use streaming subdomain if configured, otherwise use panel URL
    let streamingUrl: string;
    if (streamingDomain) {
      const protocol = streamingPort === "443" ? "https" : "http";
      const portSuffix = (streamingPort === "80" || streamingPort === "443") ? "" : `:${streamingPort}`;
      streamingUrl = `${protocol}://${streamingDomain}${portSuffix}`;
    } else {
      streamingUrl = panelUrl;
    }
    
    // Check if external proxy is enabled (token-based authentication)
    const externalProxyEnabledSetting = await this.getSetting("external_proxy_enabled");
    const externalProxyEnabled = externalProxyEnabledSetting?.value === "1";
    const externalProxyUrlSetting = await this.getSetting("external_proxy_url");
    const externalProxyUrl = externalProxyUrlSetting?.value || "";
    const secretKeySetting = await this.getSetting("proxy_secret_key");
    const secretKey = secretKeySetting?.value || "";
    const ttlSetting = await this.getSetting("proxy_token_ttl");
    const tokenTtl = parseInt(ttlSetting?.value || "14400");
    
    // Use external proxy if enabled and properly configured
    const useExternalProxy = externalProxyEnabled && externalProxyUrl && secretKey;
    
    // Get user's assigned bouquets
    let userBouquetIds: number[] = [];
    try {
      if (user.bouquet) {
        userBouquetIds = JSON.parse(user.bouquet).map((id: number | string) => Number(id));
      }
    } catch {
      userBouquetIds = [];
    }

    // Get all bouquets and filter by user's assignments
    const allBouquets = await this.getBouquets();
    const userBouquets = userBouquetIds.length > 0 
      ? allBouquets.filter(b => userBouquetIds.includes(b.id)).sort((a, b) => a.bouquetOrder - b.bouquetOrder)
      : allBouquets.sort((a, b) => a.bouquetOrder - b.bouquetOrder);

    // Collect allowed stream IDs from bouquets (in order)
    const allowedLiveIds: number[] = [];
    
    for (const bouquet of userBouquets) {
      try {
        const channelIds = bouquet.bouquetChannels ? JSON.parse(bouquet.bouquetChannels) : [];
        for (const id of channelIds) {
          if (!allowedLiveIds.includes(Number(id))) allowedLiveIds.push(Number(id));
        }
      } catch {
        // Skip malformed bouquet data
      }
    }
    
    let content = `#NAME ${user.username}\n`;
    
    const liveStreams = await this.getStreams(STREAM_TYPE_LIVE);
    
    // Filter and order by bouquet assignment
    const orderedStreams = allowedLiveIds.length > 0
      ? allowedLiveIds.map(id => liveStreams.find(s => s.id === id)).filter(Boolean) as typeof liveStreams
      : liveStreams;
    
    for (const stream of orderedStreams) {
      // Enigma2 bouquet format: #SERVICE type:flags:sid:tsid:onid:ns:parentcid:parentpid:URL
      // For IPTV streams we use type 4097 (service type for streaming)
      let streamUrl: string;
      if (useExternalProxy) {
        streamUrl = await createSignedProxyUrl(externalProxyUrl, secretKey, user.id, user.username, stream.id, 'live', tokenTtl);
      } else {
        streamUrl = `${streamingUrl}/live/${user.username}/${user.password}/${stream.id}.ts`;
      }
      content += `#SERVICE 4097:0:1:0:0:0:0:0:0:0:${encodeURIComponent(streamUrl)}:${stream.streamDisplayName}\n`;
      content += `#DESCRIPTION ${stream.streamDisplayName}\n`;
    }
    
    return content;
  }

  // Server Install Tasks
  async createServerInstallTask(data: InsertServerInstallTask): Promise<ServerInstallTask> {
    const [task] = await db.insert(serverInstallTasks).values(data).returning();
    return task;
  }

  async getServerInstallTask(id: number): Promise<ServerInstallTask | undefined> {
    const [task] = await db.select().from(serverInstallTasks).where(eq(serverInstallTasks.id, id));
    return task;
  }

  async getServerInstallTaskByServerId(serverId: number): Promise<ServerInstallTask | undefined> {
    const [task] = await db.select().from(serverInstallTasks)
      .where(eq(serverInstallTasks.serverId, serverId))
      .orderBy(desc(serverInstallTasks.createdAt));
    return task;
  }

  async updateServerInstallTask(id: number, data: Partial<InsertServerInstallTask>): Promise<ServerInstallTask | undefined> {
    const [task] = await db.update(serverInstallTasks).set(data).where(eq(serverInstallTasks.id, id)).returning();
    return task;
  }

  async updateServerInstallTaskByServerId(serverId: number, data: Partial<InsertServerInstallTask>): Promise<ServerInstallTask | undefined> {
    const [task] = await db.update(serverInstallTasks).set(data).where(eq(serverInstallTasks.serverId, serverId)).returning();
    return task;
  }

  // Server Domains
  async getServerDomains(serverId: number): Promise<ServerDomain[]> {
    return await db.select().from(serverDomains).where(eq(serverDomains.serverId, serverId));
  }

  async createServerDomain(data: InsertServerDomain): Promise<ServerDomain> {
    const [domain] = await db.insert(serverDomains).values(data).returning();
    return domain;
  }

  async deleteServerDomain(id: number): Promise<boolean> {
    const result = await db.delete(serverDomains).where(eq(serverDomains.id, id));
    return true;
  }

  // Server Performance
  async getServerPerformance(serverId: number): Promise<ServerPerformance | undefined> {
    const [perf] = await db.select().from(serverPerformance).where(eq(serverPerformance.serverId, serverId));
    return perf;
  }

  async createOrUpdateServerPerformance(serverId: number, data: Partial<InsertServerPerformance>): Promise<ServerPerformance> {
    const existing = await this.getServerPerformance(serverId);
    if (existing) {
      const [updated] = await db.update(serverPerformance)
        .set({ ...data, updatedAt: Math.floor(Date.now() / 1000) })
        .where(eq(serverPerformance.serverId, serverId))
        .returning();
      return updated;
    } else {
      const [created] = await db.insert(serverPerformance)
        .values({ ...data, serverId, createdAt: Math.floor(Date.now() / 1000) } as InsertServerPerformance)
        .returning();
      return created;
    }
  }

  // Server Metrics (historical data)
  async addServerMetrics(data: InsertServerMetrics): Promise<ServerMetrics> {
    const [metrics] = await db.insert(serverMetrics).values(data).returning();
    return metrics;
  }

  async getServerMetricsHistory(serverId: number, limit: number = 100): Promise<ServerMetrics[]> {
    return await db.select().from(serverMetrics)
      .where(eq(serverMetrics.serverId, serverId))
      .orderBy(desc(serverMetrics.timestamp))
      .limit(limit);
  }

  // License Management
  async getLicenses(): Promise<License[]> {
    return await db.select().from(licenses).orderBy(desc(licenses.createdAt));
  }

  async getLicense(id: number): Promise<License | undefined> {
    const [license] = await db.select().from(licenses).where(eq(licenses.id, id));
    return license;
  }

  async getLicenseByKey(key: string): Promise<License | undefined> {
    const [license] = await db.select().from(licenses).where(eq(licenses.licenseKey, key));
    return license;
  }

  async createLicense(license: InsertLicense): Promise<License> {
    const [created] = await db.insert(licenses).values(license).returning();
    return created;
  }

  async updateLicense(id: number, license: Partial<InsertLicense>): Promise<License | undefined> {
    const [updated] = await db.update(licenses).set(license).where(eq(licenses.id, id)).returning();
    return updated;
  }

  async deleteLicense(id: number): Promise<boolean> {
    await db.delete(licenses).where(eq(licenses.id, id));
    return true;
  }

  async validateLicense(key: string): Promise<{ valid: boolean; license?: License; error?: string }> {
    const license = await this.getLicenseByKey(key);
    
    if (!license) {
      return { valid: false, error: "License key not found" };
    }

    if (license.status === "revoked") {
      return { valid: false, error: "License has been revoked" };
    }

    if (license.status === "expired") {
      return { valid: false, error: "License has expired" };
    }

    // Check expiration for non-developer licenses
    if (license.licenseType !== "developer" && license.expiresAt) {
      const now = Math.floor(Date.now() / 1000);
      if (now > license.expiresAt) {
        await this.updateLicense(license.id, { status: "expired" });
        return { valid: false, error: "License has expired" };
      }
    }

    // Update last checked timestamp
    await this.updateLicense(license.id, { lastCheckedAt: Math.floor(Date.now() / 1000) });

    return { valid: true, license };
  }

  async getActiveLicense(): Promise<License | undefined> {
    // First check for developer license
    const [devLicense] = await db.select().from(licenses)
      .where(and(
        eq(licenses.licenseType, "developer"),
        eq(licenses.status, "active")
      ));
    
    if (devLicense) return devLicense;

    // Check for active client license
    const now = Math.floor(Date.now() / 1000);
    const [clientLicense] = await db.select().from(licenses)
      .where(and(
        eq(licenses.status, "active"),
        gt(licenses.expiresAt, now)
      ));
    
    return clientLicense;
  }

  // Auth Tokens - persistent login sessions stored in database with IP binding
  async getAuthToken(token: string): Promise<{ adminId: number; adminUsername: string; adminRole: string; expiresAt: number; ipAddress?: string | null } | undefined> {
    const [result] = await db.select().from(authTokens).where(eq(authTokens.token, token));
    if (!result) return undefined;
    
    // Check if expired
    if (Date.now() > result.expiresAt) {
      await this.deleteAuthToken(token);
      return undefined;
    }
    
    return {
      adminId: result.adminId,
      adminUsername: result.adminUsername,
      adminRole: result.adminRole,
      expiresAt: result.expiresAt,
      ipAddress: result.ipAddress,
    };
  }

  async createAuthToken(token: string, data: { adminId: number; adminUsername: string; adminRole: string; expiresAt: number; ipAddress?: string }): Promise<void> {
    await db.insert(authTokens).values({
      token,
      adminId: data.adminId,
      adminUsername: data.adminUsername,
      adminRole: data.adminRole,
      expiresAt: data.expiresAt,
      createdAt: Date.now(),
      ipAddress: data.ipAddress || null,
    });
  }

  async deleteAuthToken(token: string): Promise<void> {
    await db.delete(authTokens).where(eq(authTokens.token, token));
  }

  async deleteExpiredAuthTokens(): Promise<number> {
    const now = Date.now();
    const result = await db.delete(authTokens).where(lt(authTokens.expiresAt, now));
    return result.rowCount || 0;
  }

  // Credit Transactions
  async getCreditTransactions(resellerId: number): Promise<CreditTransaction[]> {
    const results = await db.select()
      .from(creditTransactions)
      .where(eq(creditTransactions.resellerId, resellerId))
      .orderBy(desc(creditTransactions.createdAt));
    return results;
  }

  async addCreditTransaction(transaction: InsertCreditTransaction): Promise<CreditTransaction> {
    const [result] = await db.insert(creditTransactions).values(transaction).returning();
    return result;
  }

  // Network Traffic History (aggregated from all servers)
  async getNetworkTrafficHistory(minutes: number = 60): Promise<{ time: string; input: number; output: number }[]> {
    const cutoff = Math.floor(Date.now() / 1000) - (minutes * 60);
    
    // Get metrics aggregated by timestamp, sum across all servers
    const results = await db.select({
      timestamp: serverMetrics.timestamp,
      networkIn: serverMetrics.networkIn,
      networkOut: serverMetrics.networkOut,
    })
      .from(serverMetrics)
      .where(gte(serverMetrics.timestamp, cutoff))
      .orderBy(serverMetrics.timestamp);
    
    
    // Group by minute and aggregate
    const grouped = new Map<number, { input: number; output: number }>();
    for (const row of results) {
      const minuteBucket = Math.floor(row.timestamp / 60) * 60;
      const existing = grouped.get(minuteBucket) || { input: 0, output: 0 };
      existing.input += row.networkIn || 0;
      existing.output += row.networkOut || 0;
      grouped.set(minuteBucket, existing);
    }
    
    // Convert to array with formatted time
    return Array.from(grouped.entries())
      .sort((a, b) => a[0] - b[0])
      .map(([ts, data]) => ({
        time: new Date(ts * 1000).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
        input: Math.round(data.input / 1024), // Convert to KB
        output: Math.round(data.output / 1024),
      }));
  }

  // Connections by Country (aggregated from active connections)
  async getConnectionsByCountry(): Promise<{ country: string; countryCode: string; count: number; percent: number }[]> {
    const connections = await this.getConnections();
    
    
    // Count by country code
    const countByCountry = new Map<string, { country: string; count: number }>();
    
    for (const conn of connections) {
      const code = conn.geoipCountryCode || 'Unknown';
      const existing = countByCountry.get(code) || { country: code, count: 0 };
      existing.count++;
      countByCountry.set(code, existing);
    }
    
    const total = connections.length || 1;
    
    // Convert to array and sort by count
    return Array.from(countByCountry.entries())
      .map(([code, data]) => ({
        country: data.country,
        countryCode: code,
        count: data.count,
        percent: Math.round((data.count / total) * 100),
      }))
      .sort((a, b) => b.count - a.count);
  }
}

export const dbStorage = new DatabaseStorage();
