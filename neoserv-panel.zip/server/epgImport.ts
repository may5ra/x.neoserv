import https from "https";
import http from "http";
import { createGunzip } from "zlib";
import { parseString } from "xml2js";
import { db } from "./db";
import { epgData, epg } from "@shared/schema";
import { eq } from "drizzle-orm";
import { execFile } from "child_process";
import { writeFileSync, readFileSync, unlinkSync } from "fs";
import { tmpdir } from "os";
import { join } from "path";

interface XmltvChannel {
  $: { id: string };
  "display-name"?: Array<{ _: string; $?: { lang?: string } } | string>;
  icon?: Array<{ $: { src: string } }>;
}

interface XmltvProgramme {
  $: {
    start: string;
    stop: string;
    channel: string;
  };
  title?: Array<{ _: string; $?: { lang?: string } } | string>;
  desc?: Array<{ _: string; $?: { lang?: string } } | string>;
  category?: Array<{ _: string; $?: { lang?: string } } | string>;
}

interface XmltvData {
  tv?: {
    channel?: XmltvChannel[];
    programme?: XmltvProgramme[];
  };
}

function parseXmltvDate(dateStr: string): number {
  const year = parseInt(dateStr.substring(0, 4));
  const month = parseInt(dateStr.substring(4, 6)) - 1;
  const day = parseInt(dateStr.substring(6, 8));
  const hour = parseInt(dateStr.substring(8, 10));
  const min = parseInt(dateStr.substring(10, 12));
  const sec = parseInt(dateStr.substring(12, 14)) || 0;
  
  const date = new Date(Date.UTC(year, month, day, hour, min, sec));
  return Math.floor(date.getTime() / 1000);
}

function extractText(item: { _: string; $?: { lang?: string } } | string | undefined): string {
  if (!item) return "";
  if (typeof item === "string") return item;
  return item._ || "";
}

function extractLang(item: { _: string; $?: { lang?: string } } | string | undefined): string {
  if (!item) return "";
  if (typeof item === "string") return "";
  return item.$?.lang || "";
}

async function fetchUrl(url: string): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    const protocol = url.startsWith("https") ? https : http;
    const request = protocol.get(url, { 
      headers: { 
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        "Accept-Encoding": "gzip, deflate"
      },
      timeout: 120000
    }, (response) => {
      if (response.statusCode === 301 || response.statusCode === 302) {
        const redirectUrl = response.headers.location;
        if (redirectUrl) {
          return fetchUrl(redirectUrl).then(resolve).catch(reject);
        }
      }
      
      if (response.statusCode !== 200) {
        reject(new Error(`HTTP ${response.statusCode}`));
        return;
      }

      const chunks: Buffer[] = [];
      response.on("data", (chunk) => chunks.push(chunk));
      response.on("end", () => resolve(Buffer.concat(chunks)));
      response.on("error", reject);
    });
    
    request.on("error", reject);
    request.on("timeout", () => {
      request.destroy();
      reject(new Error("Request timeout"));
    });
  });
}

async function decompressData(data: Buffer, url: string): Promise<string> {
  if (url.endsWith(".xz")) {
    console.log("[EPG Import] Decompressing XZ file using system xz...");
    return new Promise((resolve, reject) => {
      const tempFile = join(tmpdir(), `epg_${Date.now()}.xz`);
      const outFile = tempFile.replace(".xz", "");
      try {
        writeFileSync(tempFile, data);
        execFile("xz", ["-d", "-k", "-f", tempFile], { timeout: 120000 }, (error, _stdout, stderr) => {
          try {
            if (error) {
              unlinkSync(tempFile);
              reject(new Error(`XZ decompression failed: ${stderr || error.message}`));
              return;
            }
            const result = readFileSync(outFile, "utf-8");
            unlinkSync(tempFile);
            unlinkSync(outFile);
            resolve(result);
          } catch (cleanupError) {
            reject(cleanupError);
          }
        });
      } catch (writeError) {
        reject(writeError);
      }
    });
  } else if (url.endsWith(".gz")) {
    console.log("[EPG Import] Decompressing GZ file...");
    return new Promise((resolve, reject) => {
      const gunzip = createGunzip();
      const chunks: Buffer[] = [];
      
      gunzip.on("data", (chunk) => chunks.push(chunk));
      gunzip.on("end", () => resolve(Buffer.concat(chunks).toString("utf-8")));
      gunzip.on("error", reject);
      
      gunzip.write(data);
      gunzip.end();
    });
  } else {
    console.log("[EPG Import] No decompression needed (plain XML)");
    return data.toString("utf-8");
  }
}

async function parseXmltv(xmlContent: string): Promise<XmltvData> {
  return new Promise((resolve, reject) => {
    parseString(xmlContent, { 
      explicitArray: true,
      trim: true,
      normalizeTags: false,
      attrValueProcessors: [(value: string) => value]
    }, (err, result) => {
      if (err) {
        reject(err);
      } else {
        resolve(result as XmltvData);
      }
    });
  });
}

export async function importEpgSource(epgSourceId: number): Promise<{ 
  success: boolean; 
  channelsCount: number; 
  programmesCount: number;
  error?: string;
}> {
  console.log(`[EPG Import] Starting import for EPG source ID: ${epgSourceId}`);
  
  const [epgSource] = await db.select().from(epg).where(eq(epg.id, epgSourceId));
  
  if (!epgSource) {
    return { success: false, channelsCount: 0, programmesCount: 0, error: "EPG source not found" };
  }
  
  const sourceUrl = epgSource.epgFile;
  console.log(`[EPG Import] Fetching: ${sourceUrl}`);
  
  try {
    const rawData = await fetchUrl(sourceUrl);
    console.log(`[EPG Import] Downloaded ${rawData.length} bytes`);
    
    const MAX_DOWNLOAD_SIZE = 100 * 1024 * 1024;
    if (rawData.length > MAX_DOWNLOAD_SIZE) {
      return { success: false, channelsCount: 0, programmesCount: 0, error: "EPG file too large (max 100MB)" };
    }
    
    const xmlContent = await decompressData(rawData, sourceUrl);
    console.log(`[EPG Import] Decompressed to ${xmlContent.length} characters`);
    
    const MAX_XML_SIZE = 500 * 1024 * 1024;
    if (xmlContent.length > MAX_XML_SIZE) {
      return { success: false, channelsCount: 0, programmesCount: 0, error: "Decompressed EPG too large (max 500MB)" };
    }
    
    const xmlData = await parseXmltv(xmlContent);
    console.log("[EPG Import] Parsed XMLTV data");
    
    if (!xmlData.tv) {
      return { success: false, channelsCount: 0, programmesCount: 0, error: "Invalid XMLTV format - no <tv> element" };
    }
    
    const channels = xmlData.tv.channel || [];
    const programmes = xmlData.tv.programme || [];
    
    console.log(`[EPG Import] Found ${channels.length} channels and ${programmes.length} programmes`);
    
    const channelMap = new Map<string, { name: string; lang: string; icon?: string }>();
    for (const channel of channels) {
      const channelId = channel.$.id;
      const displayName = channel["display-name"]?.[0];
      const name = extractText(displayName);
      const lang = extractLang(displayName);
      const icon = channel.icon?.[0]?.$.src;
      channelMap.set(channelId, { name, lang, icon });
    }
    
    const allRows: Array<{
      epgId: number;
      channelId: string;
      title: string;
      description: string;
      lang: string;
      start: number;
      end: number;
    }> = [];
    
    // First, add a placeholder entry for each channel so they appear in the dropdown
    // even if there are no programmes for them yet
    channelMap.forEach((channelInfo, channelId) => {
      allRows.push({
        epgId: epgSourceId,
        channelId: channelId,
        title: channelInfo.name || channelId, // Use channel name or ID as placeholder
        description: "",
        lang: channelInfo.lang || "",
        start: 0, // placeholder time
        end: 0,
      });
    });
    
    // Then add all actual programmes
    for (const prog of programmes) {
      const channelId = prog.$.channel;
      const channelInfo = channelMap.get(channelId);
      const title = extractText(prog.title?.[0]);
      if (!title) continue;
      const desc = extractText(prog.desc?.[0]);
      const lang = extractLang(prog.title?.[0]) || channelInfo?.lang || "";
      
      allRows.push({
        epgId: epgSourceId,
        channelId: channelId,
        title: title,
        description: desc,
        lang: lang,
        start: parseXmltvDate(prog.$.start),
        end: parseXmltvDate(prog.$.stop),
      });
    }
    
    console.log(`[EPG Import] Prepared ${allRows.length} rows for insertion`);
    
    await db.delete(epgData).where(eq(epgData.epgId, epgSourceId));
    console.log(`[EPG Import] Cleared old EPG data for source ${epgSourceId}`);
    
    const batchSize = 500;
    let insertedCount = 0;
    
    for (let i = 0; i < allRows.length; i += batchSize) {
      const batch = allRows.slice(i, i + batchSize);
      await db.insert(epgData).values(batch);
      insertedCount += batch.length;
      
      if (i % 5000 === 0 && i > 0) {
        console.log(`[EPG Import] Inserted ${insertedCount} programmes...`);
      }
    }
    
    await db.update(epg)
      .set({ lastUpdated: Math.floor(Date.now() / 1000) })
      .where(eq(epg.id, epgSourceId));
    
    console.log(`[EPG Import] Complete! Channels: ${channels.length}, Programmes: ${insertedCount}`);
    
    return { 
      success: true, 
      channelsCount: channels.length, 
      programmesCount: insertedCount 
    };
    
  } catch (error) {
    const errorMsg = error instanceof Error ? error.message : "Unknown error";
    console.error(`[EPG Import] Error: ${errorMsg}`);
    return { success: false, channelsCount: 0, programmesCount: 0, error: errorMsg };
  }
}
