import type { Express, Request, Response, NextFunction } from "express";
import type { Server } from "http";
import { execFile, exec } from "child_process";
import { promisify } from "util";
import http from "http";
import https from "https";
import os from "os";
import { URL } from "url";
import { pipeline, PassThrough } from "stream";
import { Agent as UndiciAgent, request as undiciRequest } from "undici";
import { Client as SSHClient } from "ssh2";
import helmet from "helmet";
import { authenticator } from "otplib";
import QRCode from "qrcode";

const execAsync = promisify(exec);

// Simple IP geolocation cache
const geoCache = new Map<string, { country: string; countryCode: string; city: string; expires: number }>();

// Get country from IP address using ip-api.com (free, no API key needed)
async function getGeoLocation(ip: string): Promise<{ country: string; countryCode: string; city: string }> {
  // Check cache first
  const cached = geoCache.get(ip);
  if (cached && cached.expires > Date.now()) {
    return { country: cached.country, countryCode: cached.countryCode, city: cached.city };
  }
  
  // Skip private/local IPs
  if (ip.startsWith("127.") || ip.startsWith("192.168.") || ip.startsWith("10.") || ip === "::1") {
    return { country: "Local", countryCode: "LO", city: "" };
  }
  
  try {
    const response = await fetch(`http://ip-api.com/json/${ip}?fields=status,country,countryCode,city`);
    if (response.ok) {
      const data = await response.json();
      if (data.status === "success") {
        const result = { country: data.country || "", countryCode: data.countryCode || "", city: data.city || "" };
        // Cache for 24 hours
        geoCache.set(ip, { ...result, expires: Date.now() + 24 * 60 * 60 * 1000 });
        return result;
      }
    }
  } catch (err) {
    console.log(`[GEO] Failed to lookup ${ip}:`, err);
  }
  
  return { country: "", countryCode: "", city: "" };
}

// Get server ID from request - checks for LB Server ID header, defaults to 1 (main)
function getServerIdFromRequest(req: Request): number {
  const lbServerId = req.headers["x-lb-server-id"] as string;
  if (lbServerId) {
    const id = parseInt(lbServerId);
    if (!isNaN(id) && id > 0) {
      return id;
    }
  }
  return 1; // Default to main server
}

// Round-robin load balancer selection
// Distributes streams across all online LB servers
let lbRoundRobinIndex = 0;
interface LBServer {
  id: number;
  serverIp: string | null;
  domainName: string | null;
  httpBroadcastPort: number;
  httpsBroadcastPort: number;
  httpsEnableDisable: number;
  serverName: string;
}
let cachedLBServers: LBServer[] = [];
let lbCacheExpiry = 0;

// ===============================
// REAL-TIME BITRATE TRACKING
// ===============================
// Track bytes transferred per stream for bitrate calculation
interface StreamTrafficData {
  bytes: number;
  lastUpdate: number;
  bitrate: number; // Kbps
}
const streamTrafficMap = new Map<number, StreamTrafficData>();
let bitrateStorageRef: any = null; // Will be set when routes are registered

// Record bytes transferred for a stream
function recordStreamBytes(streamId: number, bytes: number): void {
  const now = Date.now();
  const existing = streamTrafficMap.get(streamId);
  
  if (existing) {
    existing.bytes += bytes;
    
    // Calculate bitrate every 5 seconds
    const elapsed = (now - existing.lastUpdate) / 1000;
    if (elapsed >= 5) {
      // Kbps = (bytes * 8) / (seconds * 1000)
      existing.bitrate = Math.round((existing.bytes * 8) / (elapsed * 1000));
      existing.bytes = 0;
      existing.lastUpdate = now;
    }
  } else {
    streamTrafficMap.set(streamId, {
      bytes,
      lastUpdate: now,
      bitrate: 0,
    });
  }
}

// Get current bitrate for a stream
function getStreamBitrate(streamId: number): number {
  return streamTrafficMap.get(streamId)?.bitrate || 0;
}

// Background task to save bitrates to database every 10 seconds
let bitrateUpdateInterval: NodeJS.Timeout | null = null;
function startBitrateUpdater(storage: any): void {
  bitrateStorageRef = storage;
  if (bitrateUpdateInterval) return;
  
  bitrateUpdateInterval = setInterval(async () => {
    if (!bitrateStorageRef) return;
    
    const updates: Array<{ streamId: number; bitrate: number }> = [];
    const entries = Array.from(streamTrafficMap.entries());
    for (let i = 0; i < entries.length; i++) {
      const [streamId, data] = entries[i];
      if (data.bitrate > 0) {
        updates.push({ streamId, bitrate: data.bitrate });
      }
    }
    
    // Batch update bitrates in database
    for (const { streamId, bitrate } of updates) {
      try {
        await bitrateStorageRef.updateStreamStatus(streamId, { bitrate });
      } catch (err) {
        // Silently ignore errors to not spam logs
      }
    }
  }, 10000); // Every 10 seconds
}

async function getOnlineLBServers(storage: any): Promise<LBServer[]> {
  const now = Date.now();
  // Cache LB servers for 30 seconds to reduce DB queries
  if (cachedLBServers.length > 0 && now < lbCacheExpiry) {
    console.log(`[LB] Using cached LB servers: ${cachedLBServers.length}`);
    return cachedLBServers;
  }
  
  const allServers = await storage.getServers();
  console.log(`[LB] All servers:`, allServers.map((s: any) => ({ id: s.id, name: s.serverName, isMain: s.isMain, status: s.status, ip: s.serverIp, domain: s.domainName })));
  
  // Filter: isMain !== 1 (is LB), status === 1 (online), has serverIp OR domainName
  cachedLBServers = allServers.filter((s: any) => 
    s.isMain !== 1 && s.status === 1 && (s.serverIp || s.domainName)
  );
  console.log(`[LB] Filtered LB servers: ${cachedLBServers.length}`, cachedLBServers.map((s: any) => s.serverName));
  lbCacheExpiry = now + 30000; // 30 second cache
  return cachedLBServers;
}

function selectLoadBalancer(lbServers: LBServer[]): LBServer | null {
  if (lbServers.length === 0) return null;
  
  // Round-robin selection
  lbRoundRobinIndex = (lbRoundRobinIndex + 1) % lbServers.length;
  return lbServers[lbRoundRobinIndex];
}

function buildLBRedirectUrl(lbServer: LBServer, path: string): string {
  const useHttps = lbServer.httpsEnableDisable === 1;
  const protocol = useHttps ? "https" : "http";
  const port = useHttps ? lbServer.httpsBroadcastPort : lbServer.httpBroadcastPort;
  const host = lbServer.serverIp || lbServer.domainName;
  const portSuffix = (protocol === "https" && port === 443) || (protocol === "http" && port === 80) ? "" : `:${port}`;
  return `${protocol}://${host}${portSuffix}${path}`;
}

// SSH helper - execute command on remote server with configurable timeout
async function sshExec(
  config: { host: string; port: number; username: string; password: string }, 
  command: string,
  timeout: number = 180000 // 3 minute default for long commands
): Promise<{ stdout: string; stderr: string }> {
  return new Promise((resolve, reject) => {
    const conn = new SSHClient();
    let stdout = "";
    let stderr = "";
    let finished = false;
    
    // Overall timeout for the entire command
    const timer = setTimeout(() => {
      if (!finished) {
        finished = true;
        conn.end();
        reject(new Error(`SSH command timed out after ${timeout/1000}s`));
      }
    }, timeout);
    
    conn.on("ready", () => {
      conn.exec(command, (err, stream) => {
        if (err) {
          clearTimeout(timer);
          finished = true;
          conn.end();
          return reject(err);
        }
        stream.on("close", (code: number) => {
          clearTimeout(timer);
          if (finished) return;
          finished = true;
          conn.end();
          if (code !== 0 && stderr && !stdout.includes('STEP: COMPLETED')) {
            reject(new Error(`Command failed with code ${code}: ${stderr.substring(0, 500)}`));
          } else {
            resolve({ stdout, stderr });
          }
        })
        .on("data", (data: Buffer) => { stdout += data.toString(); })
        .stderr.on("data", (data: Buffer) => { stderr += data.toString(); });
      });
    })
    .on("error", (err) => {
      clearTimeout(timer);
      if (!finished) {
        finished = true;
        reject(err);
      }
    })
    .connect({
      host: config.host,
      port: config.port,
      username: config.username,
      password: config.password,
      readyTimeout: 30000,
    });
  });
}

// Generate XtreamCodes-style nginx.conf for LB server - high performance streaming
function generateLBNginxConf(serverId: number, mainServerIp: string): string {
  return `# X NeoServ LB Server ${serverId} - XtreamCodes-style nginx.conf
user www-data;
worker_processes auto;
worker_rlimit_nofile 300000;
pid /run/nginx.pid;

include /etc/nginx/modules-enabled/*.conf;

events {
    worker_connections 16000;
    use epoll;
    accept_mutex on;
    multi_accept on;
}

thread_pool pool_stream threads=32 max_queue=0;

http {
    include /etc/nginx/mime.types;
    default_type application/octet-stream;

    # Performance settings
    sendfile on;
    tcp_nopush on;
    tcp_nodelay on;
    reset_timedout_connection on;
    gzip off;
    access_log off;
    keepalive_timeout 65;
    send_timeout 20m;
    sendfile_max_chunk 512k;
    lingering_close off;
    aio threads=pool_stream;
    
    # Timeouts
    client_body_timeout 13s;
    client_header_timeout 13s;
    client_max_body_size 10m;
    
    # Rate limiting
    limit_req_zone \\$binary_remote_addr zone=api:30m rate=30r/s;
    
    # Upstream for auth service
    upstream auth_service {
        server 127.0.0.1:3000;
        keepalive 256;
    }
    
    # Upstream for main panel server
    upstream main_panel {
        server ${mainServerIp}:5000;
        keepalive 64;
    }
    
    # Proxy cache for HLS segments
    proxy_cache_path /var/cache/nginx/hls levels=1:2 keys_zone=hls_cache:100m max_size=20g inactive=5m use_temp_path=off;
    
    server {
        listen 80 default_server;
        listen [::]:80 default_server;
        server_name _;
        server_tokens off;
        
        # Health check
        location = /health {
            return 200 '{"status":"ok","serverId":${serverId}}';
            add_header Content-Type application/json;
        }
        
        # Live streaming - auth then proxy to source via auth service
        location ~ ^/live/([^/]+)/([^/]+)/(\\d+)\\.(m3u8|ts)$ {
            set \\$username \\$1;
            set \\$password \\$2;
            set \\$stream_id \\$3;
            set \\$extension \\$4;
            
            proxy_pass http://auth_service/stream/live/\\$username/\\$password/\\$stream_id.\\$extension;
            proxy_http_version 1.1;
            proxy_set_header Host \\$host;
            proxy_set_header X-Real-IP \\$remote_addr;
            proxy_set_header X-Forwarded-For \\$proxy_add_x_forwarded_for;
            proxy_read_timeout 300s;
            proxy_connect_timeout 10s;
            proxy_buffering on;
            proxy_buffer_size 512k;
            proxy_buffers 32 512k;
            proxy_busy_buffers_size 1024k;
        }
        
        # Movie streaming
        location ~ ^/movie/([^/]+)/([^/]+)/(\\d+)\\.(m3u8|mp4|mkv|avi)$ {
            set \\$username \\$1;
            set \\$password \\$2;
            set \\$vod_id \\$3;
            set \\$extension \\$4;
            
            proxy_pass http://auth_service/stream/movie/\\$username/\\$password/\\$vod_id.\\$extension;
            proxy_http_version 1.1;
            proxy_set_header Host \\$host;
            proxy_set_header X-Real-IP \\$remote_addr;
            proxy_set_header X-Forwarded-For \\$proxy_add_x_forwarded_for;
            proxy_read_timeout 600s;
            proxy_connect_timeout 10s;
            proxy_buffering on;
            proxy_buffer_size 1m;
            proxy_buffers 16 1m;
        }
        
        # Internal HLS proxy segments (rewritten URLs from auth service)
        location ~ ^/_lb_/ {
            proxy_pass http://auth_service;
            proxy_http_version 1.1;
            proxy_set_header Host \\$host;
            proxy_read_timeout 300s;
            proxy_buffering on;
            proxy_buffer_size 512k;
            proxy_buffers 32 512k;
            
            # Cache segments for 5 seconds
            proxy_cache hls_cache;
            proxy_cache_valid 200 5s;
            proxy_cache_use_stale error timeout updating;
            add_header X-Cache-Status \\$upstream_cache_status;
        }
        
        # Nginx status for monitoring
        location = /nginx_status {
            stub_status on;
            allow 127.0.0.1;
            deny all;
        }
        
        # Fallback: proxy all other requests (API, portal, player_api.php, etc.) to main server
        location / {
            proxy_pass http://main_panel;
            proxy_http_version 1.1;
            proxy_set_header Upgrade \\$http_upgrade;
            proxy_set_header Connection 'upgrade';
            proxy_set_header Host \\$host;
            proxy_set_header X-Real-IP \\$remote_addr;
            proxy_set_header X-Forwarded-For \\$proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto \\$scheme;
            proxy_cache_bypass \\$http_upgrade;
            proxy_read_timeout 300s;
            proxy_connect_timeout 75s;
        }
    }
}`;
}

// Generate standalone Node.js proxy for LB - runs directly on port 80 (NO nginx)
function generateStandaloneLBProxy(mainServerIp: string, serverId: number, serverToken: string): string {
  return `#!/usr/bin/env node
// X NeoServ Standalone LB Proxy v6 - Server ID ${serverId}
// Runs DIRECTLY on port 80 - NO nginx needed (proven architecture for channel switching)
const http = require('http');
const https = require('https');
const url = require('url');
const os = require('os');
const fs = require('fs');

const MAIN_SERVER = 'http://${mainServerIp}:5000';
const SERVER_ID = ${serverId};
const SERVER_TOKEN = '${serverToken}';
const PORT = 80;  // Direct port 80 - NO nginx
const MAX_REDIRECTS = 5;

const tokenCache = new Map();
const TOKEN_CACHE_TTL = 24 * 60 * 60 * 1000; // 24 hours

// SOURCE URL CACHE - shared across all users for same stream (FASTER!)
const sourceCache = new Map();
const SOURCE_CACHE_TTL = 60 * 60 * 1000; // 1 hour cache for source URLs

// OPTIMIZED: Aggressive connection pooling for faster channel switching
const httpAgent = new http.Agent({ 
  keepAlive: true, 
  maxSockets: 2048,           // More parallel connections
  maxFreeSockets: 256,        // Keep more idle sockets ready
  timeout: 15000,             // Shorter timeout
  keepAliveMsecs: 30000       // Keep connections alive longer
});
const httpsAgent = new https.Agent({ 
  keepAlive: true, 
  maxSockets: 2048, 
  maxFreeSockets: 256,
  timeout: 15000, 
  keepAliveMsecs: 30000,
  rejectUnauthorized: false 
});

// DNS cache for faster hostname resolution
const dnsCache = new Map();
const DNS_CACHE_TTL = 300000; // 5 minutes
function cachedLookup(hostname, opts, cb) {
  const cached = dnsCache.get(hostname);
  if (cached && Date.now() < cached.expires) {
    return cb(null, cached.address, cached.family);
  }
  require('dns').lookup(hostname, opts, (err, address, family) => {
    if (!err) dnsCache.set(hostname, { address, family, expires: Date.now() + DNS_CACHE_TTL });
    cb(err, address, family);
  });
}

async function validateWithMain(username, password, streamId, type) {
  return new Promise((resolve, reject) => {
    const reqUrl = MAIN_SERVER + '/internal/lb/validate?username=' + encodeURIComponent(username) + '&password=' + encodeURIComponent(password) + '&streamId=' + streamId + '&type=' + type;
    http.get(reqUrl, {
      headers: { 'X-LB-Token': SERVER_TOKEN, 'X-LB-Server-Id': SERVER_ID.toString() },
      agent: httpAgent
    }, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        if (res.statusCode === 200) {
          try { resolve(JSON.parse(data)); }
          catch { reject(new Error('Invalid JSON')); }
        } else { reject(new Error('Status ' + res.statusCode)); }
      });
    }).on('error', reject);
  });
}

function encodeAbsoluteUrl(td, u) { const i = td.absoluteUrlCounter++; td.absoluteUrls.set(i, u); return '_abs_' + i; }
function decodeAbsoluteUrl(td, e) { const m = e.match(/^_abs_(\\d+)$/); return m ? td.absoluteUrls.get(parseInt(m[1], 10)) : null; }

async function getTokenData(username, password, streamId, type) {
  const cacheKey = username + ':' + password + ':' + type + ':' + streamId;
  const sourceCacheKey = type + ':' + streamId;  // Shared across users!
  
  let td = tokenCache.get(cacheKey);
  if (!td || Date.now() > td.expires) {
    // Check if we have cached source URL for this stream (shared across users)
    const cachedSource = sourceCache.get(sourceCacheKey);
    let sourceUrl, userId;
    
    if (cachedSource && Date.now() < cachedSource.expires) {
      // FAST PATH: Use cached source, just validate user quickly
      const v = await validateWithMain(username, password, streamId, type);
      if (!v.sourceUrl) throw new Error('No source URL');
      sourceUrl = cachedSource.url;  // Use cached URL
      userId = v.userId;
      console.log('[LB] FAST: cached source for stream', streamId);
    } else {
      // SLOW PATH: Full validation + cache source
      const v = await validateWithMain(username, password, streamId, type);
      if (!v.sourceUrl) throw new Error('No source URL');
      sourceUrl = v.sourceUrl;
      userId = v.userId;
      // Cache source URL for other users
      sourceCache.set(sourceCacheKey, { url: sourceUrl, expires: Date.now() + SOURCE_CACHE_TTL });
      console.log('[LB] Cached source for stream', streamId);
    }
    
    td = { sourceUrl, baseUrl: sourceUrl.substring(0, sourceUrl.lastIndexOf('/') + 1), absoluteUrls: new Map(), absoluteUrlCounter: 0, expires: Date.now() + TOKEN_CACHE_TTL, userId, streamId: parseInt(streamId) };
    tokenCache.set(cacheKey, td);
  }
  return { tokenData: td, cacheKey };
}

function getClientIp(req) {
  const xff = req.headers['x-forwarded-for'];
  if (xff) return xff.split(',')[0].trim();
  return req.socket?.remoteAddress || req.connection?.remoteAddress || '0.0.0.0';
}

// Send heartbeat to main server with client IP for accurate connection tracking
let lastHeartbeat = new Map();
function sendHeartbeat(userId, streamId, clientIp, userAgent) {
  if (!userId || !streamId) return;
  const key = userId + ':' + streamId;
  const now = Date.now();
  // Only send heartbeat every 10 seconds per user/stream
  if (lastHeartbeat.has(key) && now - lastHeartbeat.get(key) < 10000) return;
  lastHeartbeat.set(key, now);
  
  const postData = JSON.stringify({ userId, streamId, clientIp: clientIp || '0.0.0.0', userAgent: userAgent || 'LB Proxy' });
  const req = http.request({
    hostname: new url.URL(MAIN_SERVER).hostname,
    port: new url.URL(MAIN_SERVER).port || 80,
    path: '/internal/lb/heartbeat',
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(postData), 'X-LB-Token': SERVER_TOKEN, 'X-LB-Server-Id': SERVER_ID.toString() },
    agent: httpAgent,
    timeout: 5000
  }, (res) => { res.on('data', () => {}); res.on('end', () => { if (res.statusCode === 200) console.log('[LB] Heartbeat OK: user=' + userId + ' stream=' + streamId + ' ip=' + clientIp); }); });
  req.on('error', (e) => console.log('[LB] Heartbeat error:', e.message));
  req.write(postData);
  req.end();
}

function proxyHlsPlaylist(sourceUrl, cacheKey, td, res, req, forcedPrefix, maxRedir) {
  if (maxRedir === undefined) maxRedir = MAX_REDIRECTS;
  if (maxRedir <= 0) { if (!res.headersSent) { res.writeHead(502); res.end('Too many redirects'); } return; }
  let parsed; try { parsed = new url.URL(sourceUrl); } catch { res.writeHead(400); res.end('Invalid URL'); return; }
  const isHttps = parsed.protocol === 'https:';
  const client = isHttps ? https : http;
  const agent = isHttps ? httpsAgent : httpAgent;
  // OPTIMIZED: Faster timeouts, DNS caching, priority headers
  const proxyReq = client.request({ 
    hostname: parsed.hostname, 
    port: parsed.port || (isHttps ? 443 : 80), 
    path: parsed.pathname + parsed.search, 
    method: 'GET', 
    agent, 
    timeout: 5000,  // 5s timeout for faster failover
    lookup: cachedLookup,  // Use DNS cache
    headers: { 
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36', 
      'Accept': '*/*',
      'Connection': 'keep-alive',
      'Accept-Encoding': 'identity'  // No compression for faster processing
    } 
  }, (proxyRes) => {
    if (proxyRes.statusCode >= 300 && proxyRes.statusCode < 400 && proxyRes.headers.location) {
      const loc = proxyRes.headers.location;
      const rUrl = loc.startsWith('http') ? loc : new url.URL(loc, sourceUrl).href;
      td.baseUrl = rUrl.substring(0, rUrl.lastIndexOf('/') + 1);
      return proxyHlsPlaylist(rUrl, cacheKey, td, res, req, forcedPrefix, maxRedir - 1);
    }
    if (proxyRes.statusCode >= 400) { res.writeHead(proxyRes.statusCode); res.end('Source error'); return; }
    let pathPrefix = forcedPrefix !== null && forcedPrefix !== undefined ? forcedPrefix : (() => { const d = sourceUrl.substring(0, sourceUrl.lastIndexOf('/') + 1); return d.startsWith(td.baseUrl) ? d.substring(td.baseUrl.length) : ''; })();
    let body = ''; proxyRes.setEncoding('utf8');
    proxyRes.on('data', c => body += c);
    proxyRes.on('end', () => {
      const rw = u => u.startsWith('http://') || u.startsWith('https://') ? '/_lb_/' + cacheKey + '/' + encodeAbsoluteUrl(td, u) : '/_lb_/' + cacheKey + '/' + pathPrefix + u;
      const rewritten = body.split('\\n').map(l => { 
        const t = l.trim(); 
        if (!t) return l; 
        if (t.startsWith('#EXT-X-MEDIA:') && t.includes('URI=')) {
          let ml = l.replace(/URI="([^"]+)"/g, (m, u) => 'URI="' + rw(u) + '"');
          // Auto-enable subtitles
          if (t.includes('TYPE=SUBTITLES')) {
            if (ml.includes('DEFAULT=NO')) ml = ml.replace(/DEFAULT=NO/g, 'DEFAULT=YES');
            else if (!ml.includes('DEFAULT=')) ml = ml.replace('#EXT-X-MEDIA:', '#EXT-X-MEDIA:DEFAULT=YES,');
            if (ml.includes('AUTOSELECT=NO')) ml = ml.replace(/AUTOSELECT=NO/g, 'AUTOSELECT=YES');
            else if (!ml.includes('AUTOSELECT=')) ml = ml.replace('#EXT-X-MEDIA:', '#EXT-X-MEDIA:AUTOSELECT=YES,');
          }
          return ml;
        }
        if (t.startsWith('#')) return l.replace(/URI="([^"]+)"/g, (m, u) => 'URI="' + rw(u) + '"'); 
        return rw(t); 
      }).join('\\n');
      res.writeHead(200, { 'Content-Type': 'application/vnd.apple.mpegurl', 'Cache-Control': 'no-store', 'Access-Control-Allow-Origin': '*' });
      res.end(rewritten);
    });
  });
  proxyReq.on('error', () => { if (!res.headersSent) { res.writeHead(502); res.end('Source unavailable'); } });
  proxyReq.on('timeout', () => { proxyReq.destroy(); if (!res.headersSent) { res.writeHead(504); res.end('Timeout'); } });
  req.on('close', () => proxyReq.destroy());
  proxyReq.end();
}

function proxySegment(segUrl, res, req, maxRedir) {
  if (maxRedir === undefined) maxRedir = MAX_REDIRECTS;
  if (maxRedir <= 0) { if (!res.headersSent) { res.writeHead(502); res.end('Too many redirects'); } return; }
  let parsed; try { parsed = new url.URL(segUrl); } catch { res.writeHead(400); res.end('Invalid URL'); return; }
  const isHttps = parsed.protocol === 'https:';
  const client = isHttps ? https : http;
  const agent = isHttps ? httpsAgent : httpAgent;
  // OPTIMIZED: Faster segment delivery with DNS cache
  const proxyReq = client.request({ 
    hostname: parsed.hostname, 
    port: parsed.port || (isHttps ? 443 : 80), 
    path: parsed.pathname + parsed.search, 
    method: 'GET', 
    agent, 
    timeout: 15000,  // 15s for segments (they're larger)
    lookup: cachedLookup,
    headers: { 
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36', 
      'Accept': '*/*',
      'Connection': 'keep-alive'
    } 
  }, (proxyRes) => {
    if (proxyRes.statusCode >= 300 && proxyRes.statusCode < 400 && proxyRes.headers.location) {
      const loc = proxyRes.headers.location;
      return proxySegment(loc.startsWith('http') ? loc : new url.URL(loc, segUrl).href, res, req, maxRedir - 1);
    }
    if (proxyRes.statusCode >= 400) { res.writeHead(proxyRes.statusCode); res.end('Source error'); return; }
    const h = { 'Content-Type': proxyRes.headers['content-type'] || 'video/mp2t', 'Cache-Control': 'no-cache', 'Access-Control-Allow-Origin': '*' };
    if (proxyRes.headers['content-length']) h['Content-Length'] = proxyRes.headers['content-length'];
    res.writeHead(200, h); proxyRes.pipe(res);
  });
  proxyReq.on('error', () => { if (!res.headersSent) { res.writeHead(502); res.end('Source unavailable'); } });
  proxyReq.on('timeout', () => { proxyReq.destroy(); if (!res.headersSent) { res.writeHead(504); res.end('Timeout'); } });
  req.on('close', () => proxyReq.destroy());
  proxyReq.end();
}

http.createServer(async (req, res) => {
  const path = req.url || '/';
  const clientIp = getClientIp(req);
  const userAgent = req.headers['user-agent'] || 'Unknown';

  // CORS headers for all requests
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Range');
  res.setHeader('Access-Control-Expose-Headers', 'Content-Length, Content-Range');
  
  // Handle OPTIONS preflight
  if (req.method === 'OPTIONS') { res.writeHead(204); res.end(); return; }

  // Internal HLS segment/playlist proxy - cacheKey format: username:password:type:streamId
  const lbM = path.match(/^\\/_lb_\\/([^\\/]+:[^\\/]+:[^\\/]+:\\d+)\\/(.*)$/);
  if (lbM) {
    const [, ck, seg] = lbM; const td = tokenCache.get(ck);
    if (!td) { res.writeHead(401); res.end('Session expired'); return; }
    sendHeartbeat(td.userId, td.streamId, clientIp, userAgent);
    const segDir = seg.includes('/') ? seg.substring(0, seg.lastIndexOf('/') + 1) : '';
    let segUrl; const dec = decodeAbsoluteUrl(td, seg);
    if (dec) segUrl = dec;
    else if (seg.startsWith('_abs_')) { res.writeHead(404); res.end('Not found'); return; }
    else if (seg.includes('://')) { res.writeHead(400); res.end('Invalid'); return; }
    else { try { const r = new url.URL(seg, td.baseUrl); if (r.host !== new url.URL(td.sourceUrl).host) { res.writeHead(400); res.end('Bad host'); return; } segUrl = r.href; } catch { res.writeHead(400); res.end('Bad path'); return; } }
    console.log('[LB]', seg.substring(0, 40), '->', segUrl.substring(0, 60));
    if (seg.endsWith('.m3u8') || seg.endsWith('.m3u') || (dec && (dec.endsWith('.m3u8') || dec.endsWith('.m3u')))) proxyHlsPlaylist(segUrl, ck, td, res, req, segDir);
    else proxySegment(segUrl, res, req);
    return;
  }

  // Live streaming - direct routes (standalone, no nginx needed)
  const liveM = path.match(/^\\/live\\/([^\\/]+)\\/([^\\/]+)\\/(\\d+)\\.(m3u8|ts)$/);
  if (liveM) { try { const { tokenData: td, cacheKey: ck } = await getTokenData(liveM[1], liveM[2], parseInt(liveM[3]), 'live'); sendHeartbeat(td.userId, td.streamId, clientIp, userAgent); console.log('[LB] Live', liveM[3], 'ext:', liveM[4], 'ip:', clientIp); if (liveM[4] === 'm3u8') proxyHlsPlaylist(td.sourceUrl, ck, td, res, req, null); else proxySegment(td.sourceUrl, res, req); } catch (e) { console.log('[LB] Err:', e.message); res.writeHead(403); res.end('Denied'); } return; }

  // Movie streaming - direct routes
  const movM = path.match(/^\\/movie\\/([^\\/]+)\\/([^\\/]+)\\/(\\d+)\\.(m3u8|mp4|mkv|avi)$/);
  if (movM) { try { const { tokenData: td, cacheKey: ck } = await getTokenData(movM[1], movM[2], parseInt(movM[3]), 'movie'); sendHeartbeat(td.userId, td.streamId, clientIp, userAgent); console.log('[LB] Movie', movM[3], 'ip:', clientIp); if (movM[4] === 'm3u8') proxyHlsPlaylist(td.sourceUrl, ck, td, res, req, null); else proxySegment(td.sourceUrl, res, req); } catch (e) { console.log('[LB] Err:', e.message); res.writeHead(403); res.end('Denied'); } return; }

  if (path === '/health' || path === '/') { res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify({ status: 'ok', serverId: SERVER_ID, sessions: tokenCache.size })); return; }
  res.writeHead(404); res.end('Not found');
}).listen(PORT, '0.0.0.0', () => console.log('[LB Proxy v6] Server ' + SERVER_ID + ' on port ' + PORT + ' -> ' + MAIN_SERVER));

// Cleanup expired tokens and heartbeat entries
setInterval(() => { const n = Date.now(); for (const [k, v] of tokenCache.entries()) if (v.expires < n) { console.log('[LB] Expired:', k); tokenCache.delete(k); } for (const [k, t] of lastHeartbeat.entries()) if (n - t > 120000) lastHeartbeat.delete(k); }, 60000);

// Network tracking for metrics
let lastNetworkStats = { rx: 0, tx: 0, timestamp: Date.now() };
function getNetworkStats() {
  try {
    const data = fs.readFileSync('/proc/net/dev', 'utf8');
    let totalRx = 0, totalTx = 0;
    for (const line of data.split('\\n')) {
      if (line.includes(':') && !line.includes('lo:')) {
        const parts = line.trim().split(/\\s+/);
        if (parts.length >= 10) { totalRx += parseInt(parts[1]) || 0; totalTx += parseInt(parts[9]) || 0; }
      }
    }
    return { rx: totalRx, tx: totalTx };
  } catch (e) { return { rx: 0, tx: 0 }; }
}

// Report metrics to main server every 30 seconds (standalone - no nginx)
function reportMetrics() {
  const cpus = os.cpus(); let totalIdle = 0, totalTick = 0;
  for (const cpu of cpus) { for (const type in cpu.times) totalTick += cpu.times[type]; totalIdle += cpu.times.idle; }
  const cpuUsage = 100 - (100 * totalIdle / totalTick);
  const memoryUsage = ((os.totalmem() - os.freemem()) / os.totalmem()) * 100;
  let diskUsage = 50; try { const { execSync } = require('child_process'); diskUsage = parseFloat(execSync("df -h / | tail -1 | awk '{print $5}' | sed 's/%//'", { encoding: 'utf8' }).trim()) || 50; } catch {}
  
  const now = Date.now();
  const currentNet = getNetworkStats();
  const elapsed = (now - lastNetworkStats.timestamp) / 1000;
  let networkIn = 0, networkOut = 0;
  if (elapsed > 0 && lastNetworkStats.rx > 0) {
    networkIn = Math.round((currentNet.rx - lastNetworkStats.rx) / elapsed);
    networkOut = Math.round((currentNet.tx - lastNetworkStats.tx) / elapsed);
    if (networkIn < 0) networkIn = 0;
    if (networkOut < 0) networkOut = 0;
  }
  lastNetworkStats = { rx: currentNet.rx, tx: currentNet.tx, timestamp: now };
  
  const metrics = { cpuUsage: Math.round(cpuUsage * 10) / 10, memoryUsage: Math.round(memoryUsage * 10) / 10, diskUsage: Math.round(diskUsage * 10) / 10, activeConnections: tokenCache.size, networkIn, networkOut };
  const postData = JSON.stringify(metrics);
  const req = http.request({ hostname: new url.URL(MAIN_SERVER).hostname, port: new url.URL(MAIN_SERVER).port || 80, path: '/internal/lb/metrics', method: 'POST', headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(postData), 'X-LB-Token': SERVER_TOKEN, 'X-LB-Server-Id': SERVER_ID.toString() }, agent: httpAgent }, (res) => { res.on('data', () => {}); res.on('end', () => { if (res.statusCode === 200) console.log('[LB] Metrics: sessions=' + tokenCache.size + ' net_in=' + Math.round(networkIn/1024) + 'KB/s'); }); });
  req.on('error', (e) => console.log('[LB] Metrics error:', e.message));
  req.write(postData);
  req.end();
}
setInterval(reportMetrics, 30000); setTimeout(reportMetrics, 5000);
`;
}


// Generate random server token for LB authentication
function generateServerToken(): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let token = '';
  for (let i = 0; i < 64; i++) {
    token += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return token;
}

// Async SSH installation of LB server with standalone Node.js proxy (proven architecture)
async function installLBServer(
  serverId: number,
  config: { host: string; port: number; username: string; password: string },
  mainServerIp: string,
  updateSysctl: boolean,
  storage: any
): Promise<void> {
  const serverToken = generateServerToken();
  const lbProxy = generateStandaloneLBProxy(mainServerIp, serverId, serverToken);
  
  let logs = `[${new Date().toISOString()}] Starting standalone LB proxy deployment...\n`;
  
  await storage.updateServerInstallTaskByServerId(serverId, {
    currentStep: "Connecting via SSH",
    completedSteps: 1,
    logs,
    status: "in_progress",
  });
  
  // Kernel optimizations for high-performance streaming
  const sysctlConfig = updateSysctl ? `
echo "STEP: Optimizing kernel parameters..."
cat >> /etc/sysctl.conf << 'EOFX'
# X NeoServ LB Optimization
net.core.somaxconn = 655350
net.ipv4.route.flush=1
net.ipv4.tcp_no_metrics_save=1
fs.file-max = 6815744
net.core.rmem_max = 16777216
net.core.wmem_max = 16777216
net.ipv4.tcp_rmem = 4096 87380 16777216
net.ipv4.tcp_wmem = 4096 65536 16777216
net.ipv4.tcp_max_syn_backlog = 65536
net.core.netdev_max_backlog = 65536
net.ipv4.ip_local_port_range = 1024 65535
net.ipv4.tcp_tw_reuse = 1
net.ipv4.tcp_fin_timeout = 15
EOFX
sysctl -p 2>/dev/null || true
echo "STEP: Kernel optimized"
` : '';

  // Build bootstrap script using string concatenation to properly interpolate variables
  const bootstrapScript = `#!/bin/bash
set -e
echo "STEP: Connected"
export DEBIAN_FRONTEND=noninteractive

# Stop any existing services
systemctl stop neoserv-lb 2>/dev/null || true
systemctl stop neoserv-auth 2>/dev/null || true
systemctl stop nginx 2>/dev/null || true

echo "STEP: Installing dependencies..."
apt-get update -y
apt-get install -y curl ca-certificates gnupg psmisc

# Check Node.js - install if missing or below v20
NODE_VERSION=0
if command -v node &>/dev/null; then
  NODE_VERSION=$(node -v 2>/dev/null | sed 's/v//' | cut -d. -f1 || echo "0")
fi

if [ "$NODE_VERSION" -lt 20 ]; then
  echo "STEP: Installing Node.js 20..."
  mkdir -p /etc/apt/keyrings
  curl -fsSL https://deb.nodesource.com/gpgkey/nodesource-repo.gpg.key | gpg --dearmor -o /etc/apt/keyrings/nodesource.gpg
  echo "deb [signed-by=/etc/apt/keyrings/nodesource.gpg] https://deb.nodesource.com/node_20.x nodistro main" > /etc/apt/sources.list.d/nodesource.list
  apt-get update -y
  apt-get install -y nodejs
  echo "STEP: Node.js installed - $(node -v)"
else
  echo "STEP: Node.js $NODE_VERSION already installed"
fi

NODE_PATH=$(which node)
echo "STEP: Node binary at $NODE_PATH"

echo "STEP: Creating directories..."
mkdir -p /opt/neoserv-lb

echo "STEP: Deploying standalone LB proxy..."
cat > /opt/neoserv-lb/proxy.js << 'EOFPROXY'
` + lbProxy + `
EOFPROXY
chmod +x /opt/neoserv-lb/proxy.js

echo "STEP: Creating systemd service..."
cat > /etc/systemd/system/neoserv-lb.service << EOFSERVICE
[Unit]
Description=X NeoServ LB Proxy v6
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/opt/neoserv-lb
ExecStart=$NODE_PATH /opt/neoserv-lb/proxy.js
Restart=always
RestartSec=3
StandardOutput=journal
StandardError=journal
# Allow binding to port 80
AmbientCapabilities=CAP_NET_BIND_SERVICE

[Install]
WantedBy=multi-user.target
EOFSERVICE

` + sysctlConfig + `

echo "STEP: Starting LB proxy..."
systemctl daemon-reload
systemctl disable neoserv-auth 2>/dev/null || true
systemctl disable nginx 2>/dev/null || true

# Kill any process holding port 80
echo "  Preparing port 80..."
fuser -k 80/tcp 2>/dev/null || true
sleep 1

# Start LB proxy (port 80)
systemctl enable neoserv-lb
systemctl restart neoserv-lb

# Wait for LB proxy to be healthy
echo "  Waiting for LB proxy health..."
for i in {1..30}; do
  if curl -sf http://127.0.0.1:80/health > /dev/null 2>&1; then
    echo "  LB proxy is healthy!"
    break
  fi
  if [ $i -eq 30 ]; then
    echo "ERROR: LB proxy failed to start within 30 seconds!"
    journalctl -u neoserv-lb -n 30 --no-pager || true
    exit 1
  fi
  sleep 1
done

echo "STEP: Health check..."
echo -n "LB Proxy (port 80): "
if curl -sf http://127.0.0.1:80/health; then
  echo " OK"
else
  echo ""
  echo "ERROR: LB proxy is not responding!"
  journalctl -u neoserv-lb -n 20 --no-pager || true
  exit 1
fi

echo "STEP: COMPLETED"
`;

  try {
    logs += `[${new Date().toISOString()}] Executing bootstrap script...\n`;
    
    await storage.updateServerInstallTaskByServerId(serverId, {
      currentStep: "Installing (this may take 30-60 seconds)",
      completedSteps: 2,
      logs,
      status: "in_progress",
    });
    
    // Execute entire bootstrap in single SSH session
    const result = await sshExec(config, bootstrapScript);
    
    // Parse steps from output
    const stepLines = (result.stdout || '').split('\n').filter(l => l.startsWith('STEP:'));
    for (const step of stepLines) {
      logs += `  ${step}\n`;
    }
    
    if (result.stdout?.includes('STEP: COMPLETED')) {
      logs += `\n[${new Date().toISOString()}] Installation completed successfully!\n`;
      logs += `Server token: ${serverToken.substring(0, 8)}... (stored securely)\n`;
      
      await storage.updateServerInstallTaskByServerId(serverId, {
        currentStep: "Completed",
        completedSteps: 8,
        logs,
        status: "completed",
        finishedAt: Math.floor(Date.now() / 1000),
      });
      
      await storage.updateServer(serverId, { 
        status: 1,
        serverToken: serverToken,
      });
    } else {
      throw new Error("Bootstrap script did not complete successfully");
    }
    
  } catch (error: any) {
    logs += `\n[${new Date().toISOString()}] ERROR: ${error.message}\n`;
    await storage.updateServerInstallTaskByServerId(serverId, {
      currentStep: "Failed",
      logs,
      status: "failed",
      error: error.message,
      finishedAt: Math.floor(Date.now() / 1000),
    });
    
    await storage.updateServer(serverId, { status: 0 });
  }
}

// Get real system metrics for the local server
async function getSystemMetrics(): Promise<{ cpuUsage: number; memoryUsage: number; diskUsage: number }> {
  try {
    // CPU usage from /proc/stat
    const cpus = os.cpus();
    let totalIdle = 0;
    let totalTick = 0;
    for (const cpu of cpus) {
      for (const type in cpu.times) {
        totalTick += (cpu.times as any)[type];
      }
      totalIdle += cpu.times.idle;
    }
    const cpuUsage = 100 - (100 * totalIdle / totalTick);
    
    // Memory usage
    const totalMem = os.totalmem();
    const freeMem = os.freemem();
    const memoryUsage = ((totalMem - freeMem) / totalMem) * 100;
    
    // Disk usage - try df command
    let diskUsage = 0;
    try {
      const { stdout } = await execAsync("df -h / | tail -1 | awk '{print $5}' | sed 's/%//'");
      diskUsage = parseFloat(stdout.trim()) || 0;
    } catch {
      diskUsage = 50; // fallback
    }
    
    return {
      cpuUsage: Math.round(cpuUsage * 10) / 10,
      memoryUsage: Math.round(memoryUsage * 10) / 10,
      diskUsage: Math.round(diskUsage * 10) / 10,
    };
  } catch {
    return { cpuUsage: 0, memoryUsage: 0, diskUsage: 0 };
  }
}

// Undici agent with aggressive settings matching Nginx proxy_buffers
const undiciAgent = new UndiciAgent({
  keepAliveTimeout: 60000,
  keepAliveMaxTimeout: 120000,
  pipelining: 10,
  connections: 256,
  bodyTimeout: 30000,
  headersTimeout: 5000,
  connect: {
    timeout: 2000, // Fast connect timeout like Nginx proxy_connect_timeout 2s
    rejectUnauthorized: false,
  },
});

// Persistent HTTP/HTTPS agents with keep-alive for faster connections
const httpAgent = new http.Agent({
  keepAlive: true,
  keepAliveMsecs: 60000,
  maxSockets: 512,
  maxFreeSockets: 128,
  timeout: 30000,
  scheduling: "fifo",
});

const httpsAgent = new https.Agent({
  keepAlive: true,
  keepAliveMsecs: 60000,
  maxSockets: 512,
  maxFreeSockets: 128,
  timeout: 30000,
  rejectUnauthorized: false,
  scheduling: "fifo",
});
import bcrypt from "bcryptjs";
import { z } from "zod";
import { storage } from "./storage";

// Zod schema for backup restore validation
const backupDataSchema = z.object({
  format: z.enum(["neoserv", "neoserv-full", "xui-one", "xtream-codec", "1-stream", "nxt"]),
  version: z.string().optional(),
  exported_at: z.string().optional(),
  data: z.object({
    users: z.array(z.any()).optional(),
    streams: z.array(z.any()).optional(),
    categories: z.array(z.any()).optional(),
    bouquets: z.array(z.any()).optional(),
    series: z.array(z.any()).optional(),
  }).optional(),
  users: z.array(z.any()).optional(),
  streams: z.array(z.any()).optional(),
  categories: z.array(z.any()).optional(),
  bouquets: z.array(z.any()).optional(),
  series: z.array(z.any()).optional(),
  lines: z.array(z.any()).optional(),
  reg_users: z.array(z.any()).optional(),
});

const restoreOptionsSchema = z.object({
  overwrite: z.boolean().optional().default(false),
  skipExisting: z.boolean().optional().default(true),
  importUsers: z.boolean().optional().default(true),
  importStreams: z.boolean().optional().default(true),
  importCategories: z.boolean().optional().default(true),
  importBouquets: z.boolean().optional().default(true),
  importSeries: z.boolean().optional().default(true),
});

const restoreRequestSchema = z.object({
  data: backupDataSchema,
  options: restoreOptionsSchema.optional(),
});

const execFileAsync = promisify(execFile);

// Helper function to format bytes
function formatBytes(bytes: number): string {
  if (bytes === 0) return "0 Bytes";
  const k = 1024;
  const sizes = ["Bytes", "KB", "MB", "GB", "TB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
}

// Helper function to escape XML special characters
function escapeXml(str: string): string {
  return str
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

// Helper function to format XMLTV timestamp (YYYYMMDDHHmmss +0000)
function formatXmltvTime(unixTimestamp: number): string {
  const date = new Date(unixTimestamp * 1000);
  const year = date.getUTCFullYear();
  const month = String(date.getUTCMonth() + 1).padStart(2, "0");
  const day = String(date.getUTCDate()).padStart(2, "0");
  const hours = String(date.getUTCHours()).padStart(2, "0");
  const minutes = String(date.getUTCMinutes()).padStart(2, "0");
  const seconds = String(date.getUTCSeconds()).padStart(2, "0");
  return `${year}${month}${day}${hours}${minutes}${seconds} +0000`;
}

// Helper function to escape SQL strings safely
function escapeSqlString(value: any): string {
  if (value === null || value === undefined) return 'NULL';
  const str = String(value);
  return "'" + str.replace(/'/g, "''").replace(/\\/g, '\\\\') + "'";
}

// Helper function to escape JSON for SQL insertion
function escapeSqlJson(value: any): string {
  if (value === null || value === undefined) return 'NULL';
  const jsonStr = JSON.stringify(value);
  return "'" + jsonStr.replace(/'/g, "''").replace(/\\/g, '\\\\') + "'";
}

// Helper function to calculate next backup run time
function calculateNextRun(frequency: string, time: string): string {
  const [hours, minutes] = time.split(":").map(Number);
  const now = new Date();
  const next = new Date();
  next.setHours(hours, minutes, 0, 0);
  
  if (next <= now) {
    switch (frequency) {
      case "daily":
        next.setDate(next.getDate() + 1);
        break;
      case "weekly":
        next.setDate(next.getDate() + 7);
        break;
      case "monthly":
        next.setMonth(next.getMonth() + 1);
        break;
    }
  }
  return next.toISOString();
}

// Failover tracking: Map<streamId, {activeIndex, lastFailover, sources}>
const streamFailoverState = new Map<number, {
  activeIndex: number;
  lastFailoverAt: number;
  primaryOnline: boolean;
}>();

// Playlist cache for faster stream opening (2 second TTL)
interface PlaylistCache {
  content: string;
  baseUrl: string;
  timestamp: number;
}
const playlistCache = new Map<string, PlaylistCache>();
const PLAYLIST_CACHE_TTL = 2000; // 2 seconds - short TTL for live streams

// Segment buffer cache - holds first segments for instant playback
interface SegmentCache {
  data: Buffer;
  contentType: string;
  timestamp: number;
}
const segmentCache = new Map<string, SegmentCache>();
const SEGMENT_CACHE_TTL = 30000; // 30 seconds for segments

// Warm stream buffer - continuously refreshed for active streams
interface WarmStream {
  sourceUrl: string;
  baseUrl: string;
  playlist: string;
  rewrittenPlaylist: string;
  token: string;
  lastRefresh: number;
  intervalId: NodeJS.Timeout | null;
  segmentUrls: string[];
}
const warmStreams = new Map<string, WarmStream>();
const WARM_REFRESH_INTERVAL = 2000; // Refresh every 2 seconds

function getCachedPlaylist(url: string): PlaylistCache | null {
  const cached = playlistCache.get(url);
  if (cached && Date.now() - cached.timestamp < PLAYLIST_CACHE_TTL) {
    return cached;
  }
  return null;
}

function setCachedPlaylist(url: string, content: string, baseUrl: string): void {
  playlistCache.set(url, { content, baseUrl, timestamp: Date.now() });
  // Cleanup old entries periodically
  if (playlistCache.size > 100) {
    const now = Date.now();
    const entries = Array.from(playlistCache.entries());
    for (let i = 0; i < entries.length; i++) {
      const [key, val] = entries[i];
      if (now - val.timestamp > PLAYLIST_CACHE_TTL * 2) {
        playlistCache.delete(key);
      }
    }
  }
}

function getCachedSegment(url: string): SegmentCache | null {
  const cached = segmentCache.get(url);
  if (cached && Date.now() - cached.timestamp < SEGMENT_CACHE_TTL) {
    return cached;
  }
  return null;
}

function setCachedSegment(url: string, data: Buffer, contentType: string): void {
  segmentCache.set(url, { data, contentType, timestamp: Date.now() });
  // Limit cache size
  if (segmentCache.size > 200) {
    const now = Date.now();
    const entries = Array.from(segmentCache.entries());
    for (let i = 0; i < entries.length; i++) {
      const [key, val] = entries[i];
      if (now - val.timestamp > SEGMENT_CACHE_TTL) {
        segmentCache.delete(key);
      }
    }
  }
}

// Start warm stream - continuously refreshes playlist and prefetches segments
function startWarmStream(token: string, sourceUrl: string): void {
  // Don't start duplicate
  if (warmStreams.has(token)) return;
  
  const baseUrl = sourceUrl.substring(0, sourceUrl.lastIndexOf("/") + 1);
  const warm: WarmStream = {
    sourceUrl,
    baseUrl,
    playlist: "",
    rewrittenPlaylist: "",
    token,
    lastRefresh: 0,
    intervalId: null,
    segmentUrls: [],
  };
  warmStreams.set(token, warm);
  
  // Initial fetch
  refreshWarmStream(token);
  
  // Set up continuous refresh
  warm.intervalId = setInterval(() => {
    refreshWarmStream(token);
  }, WARM_REFRESH_INTERVAL);
  
  // Auto-cleanup after 30 minutes of inactivity
  setTimeout(() => {
    stopWarmStream(token);
  }, 30 * 60 * 1000);
}

function stopWarmStream(token: string): void {
  const warm = warmStreams.get(token);
  if (warm) {
    if (warm.intervalId) clearInterval(warm.intervalId);
    warmStreams.delete(token);
  }
}

function refreshWarmStream(token: string): void {
  const warm = warmStreams.get(token);
  if (!warm) return;
  
  const tokenData = streamTokens.get(token);
  if (!tokenData) {
    stopWarmStream(token);
    return;
  }
  
  // Fetch playlist
  fetchPlaylistForWarm(warm.sourceUrl, (content, finalBaseUrl) => {
    if (!content) return;
    
    warm.playlist = content;
    warm.baseUrl = finalBaseUrl;
    warm.lastRefresh = Date.now();
    
    // Rewrite playlist for this token
    const lines = content.split("\n");
    const rewritten: string[] = [];
    const segments: string[] = [];
    
    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith("#")) {
        rewritten.push(line);
      } else if (trimmed.startsWith("http://") || trimmed.startsWith("https://")) {
        const encoded = encodeAbsoluteUrl(tokenData, trimmed);
        rewritten.push(`/hls/${token}/${encoded}`);
        segments.push(trimmed);
      } else {
        const pathPrefix = "";
        rewritten.push(`/hls/${token}/${pathPrefix}${trimmed}`);
        segments.push(finalBaseUrl + trimmed);
      }
    }
    
    warm.rewrittenPlaylist = rewritten.join("\n");
    warm.segmentUrls = segments;
    
    // Prefetch first 6 segments for faster startup
    for (let i = 0; i < Math.min(6, segments.length); i++) {
      prefetchSegment(segments[i]);
    }
  });
}

// Fetch playlist with redirect following (for warm stream)
function fetchPlaylistForWarm(url: string, callback: (content: string | null, baseUrl: string) => void, maxRedirects: number = 5): void {
  if (maxRedirects <= 0) {
    callback(null, "");
    return;
  }
  
  try {
    const parsedUrl = new URL(url);
    const isHttps = parsedUrl.protocol === "https:";
    const client = isHttps ? https : http;
    const agent = isHttps ? httpsAgent : httpAgent;
    
    const req = client.request({
      hostname: parsedUrl.hostname,
      port: parsedUrl.port || (isHttps ? 443 : 80),
      path: parsedUrl.pathname + parsedUrl.search,
      method: "GET",
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        "Accept": "*/*",
        "Connection": "keep-alive",
      },
      agent,
    }, (res) => {
      if ([301, 302, 303, 307, 308].includes(res.statusCode || 0) && res.headers.location) {
        res.destroy();
        const redirectUrl = new URL(res.headers.location, url).toString();
        fetchPlaylistForWarm(redirectUrl, callback, maxRedirects - 1);
        return;
      }
      
      let body = "";
      res.setEncoding("utf8");
      res.on("data", (chunk) => { body += chunk; });
      res.on("end", () => {
        const baseUrl = url.substring(0, url.lastIndexOf("/") + 1);
        callback(body, baseUrl);
      });
    });
    
    req.on("error", () => callback(null, ""));
    req.setTimeout(2000, () => { req.destroy(); callback(null, ""); });
    req.end();
  } catch (e) {
    callback(null, "");
  }
}

// Prefetch playlist and first segments when token is created
async function prefetchStream(sourceUrl: string): Promise<void> {
  return new Promise((resolve) => {
    try {
      const parsedUrl = new URL(sourceUrl);
      const isHttps = parsedUrl.protocol === "https:";
      const client = isHttps ? https : http;
      const agent = isHttps ? httpsAgent : httpAgent;
      
      const req = client.request({
        hostname: parsedUrl.hostname,
        port: parsedUrl.port || (isHttps ? 443 : 80),
        path: parsedUrl.pathname + parsedUrl.search,
        method: "GET",
        headers: {
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
          "Accept": "*/*",
          "Connection": "keep-alive",
        },
        agent,
      }, (res) => {
        // Follow redirects
        if ([301, 302, 303, 307, 308].includes(res.statusCode || 0) && res.headers.location) {
          res.destroy();
          const redirectUrl = new URL(res.headers.location, sourceUrl).toString();
          prefetchStream(redirectUrl).then(resolve);
          return;
        }
        
        let body = "";
        res.setEncoding("utf8");
        res.on("data", (chunk) => { body += chunk; });
        res.on("end", () => {
          const baseUrl = sourceUrl.substring(0, sourceUrl.lastIndexOf("/") + 1);
          setCachedPlaylist(sourceUrl, body, baseUrl);
          
          // Prefetch first 2 segments
          const lines = body.split("\n");
          let segmentCount = 0;
          for (const line of lines) {
            const trimmed = line.trim();
            if (trimmed && !trimmed.startsWith("#")) {
              let segmentUrl: string;
              if (trimmed.startsWith("http://") || trimmed.startsWith("https://")) {
                segmentUrl = trimmed;
              } else {
                segmentUrl = baseUrl + trimmed;
              }
              prefetchSegment(segmentUrl);
              segmentCount++;
              if (segmentCount >= 2) break;
            }
          }
          resolve();
        });
      });
      
      req.on("error", () => resolve());
      req.setTimeout(2000, () => { req.destroy(); resolve(); });
      req.end();
    } catch (e) {
      resolve();
    }
  });
}

// Prefetch a single segment into cache
function prefetchSegment(url: string): void {
  try {
    const parsedUrl = new URL(url);
    const isHttps = parsedUrl.protocol === "https:";
    const client = isHttps ? https : http;
    const agent = isHttps ? httpsAgent : httpAgent;
    
    const req = client.request({
      hostname: parsedUrl.hostname,
      port: parsedUrl.port || (isHttps ? 443 : 80),
      path: parsedUrl.pathname + parsedUrl.search,
      method: "GET",
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        "Accept": "*/*",
        "Connection": "keep-alive",
      },
      agent,
    }, (res) => {
      if (res.statusCode !== 200) {
        res.destroy();
        return;
      }
      
      const chunks: Buffer[] = [];
      res.on("data", (chunk) => chunks.push(chunk));
      res.on("end", () => {
        const data = Buffer.concat(chunks);
        const contentType = res.headers["content-type"] || "video/mp2t";
        setCachedSegment(url, data, contentType);
      });
    });
    
    req.on("error", () => {});
    req.setTimeout(3000, () => req.destroy());
    req.end();
  } catch (e) {}
}

// Get all sources for a stream (primary + backups)
function getAllSources(stream: { streamSource: string | null; backupSources?: string[] | null }): string[] {
  const sources: string[] = [];
  if (stream.streamSource) {
    sources.push(stream.streamSource);
  }
  if (stream.backupSources && Array.isArray(stream.backupSources)) {
    sources.push(...stream.backupSources.filter(s => s && typeof s === "string"));
  }
  return sources;
}

// Check if a source URL is reachable (quick HTTP HEAD check)
async function checkSourceReachable(url: string, timeoutMs: number = 5000): Promise<boolean> {
  return new Promise((resolve) => {
    try {
      const parsedUrl = new URL(url);
      const client = parsedUrl.protocol === "https:" ? https : http;
      
      const req = client.request({
        hostname: parsedUrl.hostname,
        port: parsedUrl.port || (parsedUrl.protocol === "https:" ? 443 : 80),
        path: parsedUrl.pathname + parsedUrl.search,
        method: "HEAD",
        headers: {
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        },
      }, (res) => {
        req.destroy();
        resolve(res.statusCode !== undefined && res.statusCode < 400);
      });
      
      req.on("error", () => {
        req.destroy();
        resolve(false);
      });
      
      req.setTimeout(timeoutMs, () => {
        req.destroy();
        resolve(false);
      });
      
      req.end();
    } catch {
      resolve(false);
    }
  });
}

// FAST: Get active source immediately without blocking health checks
// Used for playback - failover happens during streaming if source fails
function getActiveSourceFast(streamId: number, sources: string[]): {url: string; index: number; isBackup: boolean} | null {
  if (sources.length === 0) return null;
  
  let state = streamFailoverState.get(streamId);
  if (!state) {
    state = { activeIndex: 0, lastFailoverAt: 0, primaryOnline: true };
    streamFailoverState.set(streamId, state);
  }
  
  // Return cached active source immediately - no blocking checks
  const currentIndex = Math.min(state.activeIndex, sources.length - 1);
  const currentSource = sources[currentIndex];
  
  return { url: currentSource, index: currentIndex, isBackup: currentIndex > 0 };
}

// SLOW: Get active source with full health checks - use for background monitoring only
async function getActiveSource(streamId: number, sources: string[]): Promise<{url: string; index: number; isBackup: boolean} | null> {
  if (sources.length === 0) return null;
  
  let state = streamFailoverState.get(streamId);
  if (!state) {
    state = { activeIndex: 0, lastFailoverAt: 0, primaryOnline: true };
    streamFailoverState.set(streamId, state);
  }
  
  // Check if current active source is valid
  const currentIndex = Math.min(state.activeIndex, sources.length - 1);
  const currentSource = sources[currentIndex];
  
  // Try current active source first
  const isReachable = await checkSourceReachable(currentSource);
  if (isReachable) {
    return { url: currentSource, index: currentIndex, isBackup: currentIndex > 0 };
  }
  
  // Current source failed, try failover to next
  console.log(`Stream ${streamId}: Source ${currentIndex} failed, attempting failover...`);
  
  for (let i = 0; i < sources.length; i++) {
    if (i === currentIndex) continue; // Skip already-failed source
    
    const testReachable = await checkSourceReachable(sources[i]);
    if (testReachable) {
      // Update failover state
      state.activeIndex = i;
      state.lastFailoverAt = Math.floor(Date.now() / 1000);
      state.primaryOnline = (i === 0);
      streamFailoverState.set(streamId, state);
      
      // Persist to database
      await storage.updateStreamStatus(streamId, {
        activeSourceIndex: i,
        lastFailoverAt: state.lastFailoverAt,
        currentSource: sources[i],
        streamStatus: 1,
      });
      
      console.log(`Stream ${streamId}: Failover to source ${i} successful`);
      return { url: sources[i], index: i, isBackup: i > 0 };
    }
  }
  
  // All sources failed
  console.log(`Stream ${streamId}: All sources failed`);
  state.activeIndex = 0;
  state.primaryOnline = false;
  streamFailoverState.set(streamId, state);
  
  await storage.updateStreamStatus(streamId, {
    streamStatus: 0,
    streamDown: 1,
  });
  
  return null;
}

interface FFprobeResult {
  isOnline: boolean;
  resolution?: string;
  videoCodec?: string;
  audioCodec?: string;
  fps?: string;
  bitrate?: number;
  error?: string;
}

async function probeStream(url: string, timeoutSec: number = 5): Promise<FFprobeResult> {
  try {
    // Use execFile instead of exec to prevent command injection
    // execFile passes arguments as an array, not through a shell
    const args = [
      "-v", "quiet",
      "-print_format", "json",
      "-show_format",
      "-show_streams",
      "-timeout", String(timeoutSec * 1000000),
      url
    ];
    
    const { stdout } = await execFileAsync("ffprobe", args, { 
      timeout: (timeoutSec + 2) * 1000 
    });
    
    const data = JSON.parse(stdout);
    
    // Find all video streams and select the one with highest bitrate (best quality)
    const videoStreams = data.streams?.filter((s: any) => s.codec_type === "video") || [];
    let videoStream = videoStreams[0]; // Default to first
    
    if (videoStreams.length > 1) {
      // Sort by variant_bitrate descending and pick the highest
      videoStream = videoStreams.reduce((best: any, current: any) => {
        const bestBitrate = parseInt(best?.tags?.variant_bitrate || best?.bit_rate || "0");
        const currentBitrate = parseInt(current?.tags?.variant_bitrate || current?.bit_rate || "0");
        return currentBitrate > bestBitrate ? current : best;
      }, videoStreams[0]);
    }
    
    const audioStream = data.streams?.find((s: any) => s.codec_type === "audio");
    
    // Calculate FPS safely - try avg_frame_rate first (more accurate), then r_frame_rate
    let fps: string | undefined;
    const fpsSource = videoStream?.avg_frame_rate || videoStream?.r_frame_rate;
    if (fpsSource) {
      const parts = fpsSource.split("/");
      if (parts.length === 2) {
        const num = parseFloat(parts[0]);
        const den = parseFloat(parts[1]);
        if (den > 0 && num > 0) {
          const fpsValue = num / den;
          // Round to nearest integer for cleaner display (25, 30, 50, 60)
          fps = Math.round(fpsValue).toString();
        }
      } else if (parts.length === 1) {
        // Direct FPS value
        const fpsValue = parseFloat(parts[0]);
        if (fpsValue > 0) {
          fps = Math.round(fpsValue).toString();
        }
      }
    }
    
    // Get bitrate - try format first, then video stream variant_bitrate, then stream bit_rate
    let bitrate: number | undefined;
    if (data.format?.bit_rate) {
      bitrate = Math.round(parseInt(data.format.bit_rate) / 1000);
    } else if (videoStream?.tags?.variant_bitrate) {
      bitrate = Math.round(parseInt(videoStream.tags.variant_bitrate) / 1000);
    } else if (videoStream?.bit_rate) {
      bitrate = Math.round(parseInt(videoStream.bit_rate) / 1000);
    }
    
    return {
      isOnline: true,
      resolution: videoStream ? `${videoStream.width}x${videoStream.height}` : undefined,
      videoCodec: videoStream?.codec_name?.toUpperCase(),
      audioCodec: audioStream?.codec_name?.toUpperCase(),
      fps,
      bitrate,
    };
  } catch (error: any) {
    return {
      isOnline: false,
      error: error.message || "Stream probe failed",
    };
  }
}

function proxyStream(sourceUrl: string, res: Response, req: Request, maxRedirects: number = 5, streamId?: number): void {
  if (maxRedirects <= 0) {
    console.error("Proxy: Too many redirects for stream");
    if (!res.headersSent) {
      res.status(502).send("Too many redirects");
    }
    return;
  }

  console.log(`Proxy: Starting stream proxy (redirects left: ${maxRedirects})`);

  try {
    const parsedUrl = new URL(sourceUrl);
    const client = parsedUrl.protocol === "https:" ? https : http;
    
    const headers: Record<string, string> = {
      "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
      "Accept": "*/*",
      "Accept-Encoding": "identity",
    };
    if (req.headers.range) {
      headers["Range"] = req.headers.range;
    }
    
    const options = {
      hostname: parsedUrl.hostname,
      port: parsedUrl.port || (parsedUrl.protocol === "https:" ? 443 : 80),
      path: parsedUrl.pathname + parsedUrl.search,
      method: "GET",
      headers,
    };
    
    const proxyReq = client.request(options, (proxyRes) => {
      const statusCode = proxyRes.statusCode || 200;
      console.log(`Proxy: Got response ${statusCode} from source`);
      
      // Follow redirects
      if ([301, 302, 303, 307, 308].includes(statusCode) && proxyRes.headers.location) {
        proxyRes.destroy();
        proxyReq.destroy();
        const redirectUrl = new URL(proxyRes.headers.location, sourceUrl).toString();
        console.log(`Proxy: Following redirect to new location`);
        return proxyStream(redirectUrl, res, req, maxRedirects - 1, streamId);
      }
      
      const contentType = proxyRes.headers["content-type"];
      const contentLength = proxyRes.headers["content-length"];
      const acceptRanges = proxyRes.headers["accept-ranges"];
      const contentRange = proxyRes.headers["content-range"];
      
      // For m3u8 playlists, we need to rewrite URLs
      if (contentType?.includes("mpegurl") || contentType?.includes("m3u8") || sourceUrl.includes(".m3u8")) {
        console.log(`Proxy: Handling HLS playlist`);
        let body = "";
        proxyRes.setEncoding("utf8");
        proxyRes.on("data", (chunk) => { body += chunk; });
        proxyRes.on("end", () => {
          // Rewrite relative URLs to absolute (pointing to origin)
          const baseUrl = sourceUrl.substring(0, sourceUrl.lastIndexOf("/") + 1);
          const rewritten = body.replace(/^(?!#)(?!http)(.+\.ts.*)$/gm, (match) => {
            return baseUrl + match;
          }).replace(/^(?!#)(?!http)(.+\.m3u8.*)$/gm, (match) => {
            return baseUrl + match;
          });
          
          res.setHeader("Content-Type", "application/vnd.apple.mpegurl");
          res.setHeader("Cache-Control", "no-cache");
          res.send(rewritten);
        });
        return;
      }
      
      res.status(statusCode);
      
      if (contentType) res.setHeader("Content-Type", contentType);
      if (contentLength) res.setHeader("Content-Length", contentLength);
      if (acceptRanges) res.setHeader("Accept-Ranges", acceptRanges);
      if (contentRange) res.setHeader("Content-Range", contentRange);
      
      res.setHeader("Cache-Control", "no-cache");
      res.setHeader("Connection", "keep-alive");
      
      proxyRes.pipe(res);
      
      proxyRes.on("error", (err) => {
        console.error("Proxy: Response error:", err.message);
        proxyReq.destroy();
        res.end();
      });
      
      req.on("close", () => {
        proxyRes.destroy();
        proxyReq.destroy();
      });
    });
    
    proxyReq.on("error", (err) => {
      console.error("Proxy request error:", err.message);
      if (!res.headersSent) {
        res.status(502).send("Stream unavailable");
      }
    });
    
    proxyReq.setTimeout(30000, () => {
      console.error("Proxy: Request timeout");
      proxyReq.destroy();
      if (!res.headersSent) {
        res.status(504).send("Stream timeout");
      }
    });
    
    proxyReq.end();
    
  } catch (error: any) {
    console.error("Proxy error:", error.message);
    if (!res.headersSent) {
      res.status(500).send("Internal error");
    }
  }
}

// Proxy HLS playlist and rewrite URLs to use our proxy
function proxyHlsPlaylist(sourceUrl: string, token: string, res: Response, req: Request, maxRedirects: number = 5): void {
  if (maxRedirects <= 0) {
    if (!res.headersSent) res.status(502).send("Too many redirects");
    return;
  }

  const tokenData = streamTokens.get(token);
  if (!tokenData) {
    if (!res.headersSent) res.status(401).send("Invalid token");
    return;
  }

  // Helper to rewrite a single URL (relative or absolute)
  const rewriteUrl = (url: string, pathPrefix: string): string => {
    if (url.startsWith("http://") || url.startsWith("https://")) {
      const encoded = encodeAbsoluteUrl(tokenData, url);
      return `/hls/${token}/${encoded}`;
    }
    return `/hls/${token}/${pathPrefix}${url}`;
  };

  // Helper to rewrite playlist content (including subtitle/audio track URIs)
  const rewritePlaylist = (body: string, pathPrefix: string): string => {
    return body
      .split("\n")
      .map(line => {
        const trimmed = line.trim();
        if (!trimmed) return line;
        
        // Handle EXT-X-MEDIA tags (subtitles, audio tracks) - rewrite URI parameter
        // Example: #EXT-X-MEDIA:TYPE=SUBTITLES,URI="subtitles.m3u8",...
        if (trimmed.startsWith("#EXT-X-MEDIA:") && trimmed.includes("URI=")) {
          let modifiedLine = line.replace(/URI="([^"]+)"/g, (match, uri) => {
            const rewrittenUri = rewriteUrl(uri, pathPrefix);
            return `URI="${rewrittenUri}"`;
          }).replace(/URI=([^,\s"]+)/g, (match, uri) => {
            // Handle unquoted URIs
            if (uri.startsWith('"')) return match;
            const rewrittenUri = rewriteUrl(uri, pathPrefix);
            return `URI="${rewrittenUri}"`;
          });
          
          // Auto-enable subtitles: Set DEFAULT=YES and AUTOSELECT=YES for subtitle tracks
          if (trimmed.includes("TYPE=SUBTITLES")) {
            // Replace DEFAULT=NO with DEFAULT=YES, or add DEFAULT=YES if not present
            if (modifiedLine.includes("DEFAULT=NO")) {
              modifiedLine = modifiedLine.replace(/DEFAULT=NO/g, "DEFAULT=YES");
            } else if (!modifiedLine.includes("DEFAULT=")) {
              modifiedLine = modifiedLine.replace("#EXT-X-MEDIA:", "#EXT-X-MEDIA:DEFAULT=YES,");
            }
            // Replace AUTOSELECT=NO with AUTOSELECT=YES, or add if not present
            if (modifiedLine.includes("AUTOSELECT=NO")) {
              modifiedLine = modifiedLine.replace(/AUTOSELECT=NO/g, "AUTOSELECT=YES");
            } else if (!modifiedLine.includes("AUTOSELECT=")) {
              modifiedLine = modifiedLine.replace("#EXT-X-MEDIA:", "#EXT-X-MEDIA:AUTOSELECT=YES,");
            }
          }
          
          return modifiedLine;
        }
        
        // Handle EXT-X-I-FRAME-STREAM-INF tags - also have URI parameter
        if (trimmed.startsWith("#EXT-X-I-FRAME-STREAM-INF:") && trimmed.includes("URI=")) {
          return line.replace(/URI="([^"]+)"/g, (match, uri) => {
            const rewrittenUri = rewriteUrl(uri, pathPrefix);
            return `URI="${rewrittenUri}"`;
          });
        }
        
        // Skip other comment lines
        if (trimmed.startsWith("#")) return line;
        
        // Regular segment/playlist URLs
        return rewriteUrl(trimmed, pathPrefix);
      })
      .join("\n");
  };

  try {
    const parsedUrl = new URL(sourceUrl);
    const isHttps = parsedUrl.protocol === "https:";
    const client = isHttps ? https : http;
    const agent = isHttps ? httpsAgent : httpAgent;
    
    const headers: Record<string, string> = {
      "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
      "Accept": "*/*",
      "Connection": "keep-alive",
    };
    
    const options = {
      hostname: parsedUrl.hostname,
      port: parsedUrl.port || (isHttps ? 443 : 80),
      path: parsedUrl.pathname + parsedUrl.search,
      method: "GET",
      headers,
      agent,
    };
    
    const proxyReq = client.request(options, (proxyRes) => {
      const statusCode = proxyRes.statusCode || 200;
      
      // Store session cookies from xaccel-codec or similar servers for segment authentication
      const setCookieHeaders = proxyRes.headers["set-cookie"];
      if (setCookieHeaders && setCookieHeaders.length > 0) {
        const cookies = setCookieHeaders.map(c => c.split(";")[0]).join("; ");
        tokenData.cookies = cookies;
        console.log(`[HLS] Stored session cookies: ${cookies.substring(0, 50)}...`);
      }
      
      if ([301, 302, 303, 307, 308].includes(statusCode) && proxyRes.headers.location) {
        proxyRes.destroy();
        const redirectUrl = new URL(proxyRes.headers.location, sourceUrl).toString();
        const newBaseUrl = redirectUrl.substring(0, redirectUrl.lastIndexOf("/") + 1);
        tokenData.baseUrl = newBaseUrl;
        return proxyHlsPlaylist(redirectUrl, token, res, req, maxRedirects - 1);
      }
      
      const currentPlaylistDir = sourceUrl.substring(0, sourceUrl.lastIndexOf("/") + 1);
      const originalBase = tokenData.baseUrl;
      let pathPrefix = "";
      if (currentPlaylistDir.startsWith(originalBase)) {
        pathPrefix = currentPlaylistDir.substring(originalBase.length);
      }
      
      let body = "";
      proxyRes.setEncoding("utf8");
      proxyRes.on("data", (chunk) => { body += chunk; });
      proxyRes.on("end", () => {
        // Cache the raw playlist for faster subsequent requests
        setCachedPlaylist(sourceUrl, body, currentPlaylistDir);
        
        const rewritten = rewritePlaylist(body, pathPrefix);
        res.setHeader("Content-Type", "application/vnd.apple.mpegurl");
        res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
        res.setHeader("Pragma", "no-cache");
        res.setHeader("Access-Control-Allow-Origin", "*");
        res.setHeader("Access-Control-Allow-Methods", "GET, OPTIONS");
        res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, Range");
        res.setHeader("Access-Control-Expose-Headers", "Content-Length, Content-Range");
        res.send(rewritten);
      });
    });
    
    proxyReq.on("error", () => {
      if (!res.headersSent) {
        if (switchToBackup(token)) {
          const newTokenData = streamTokens.get(token);
          if (newTokenData) {
            return proxyHlsPlaylist(newTokenData.sourceUrl, token, res, req, maxRedirects);
          }
        }
        res.status(502).send("Stream unavailable");
      }
    });
    
    // Fast timeout - 3 seconds for playlists
    proxyReq.setTimeout(3000, () => {
      proxyReq.destroy();
      if (!res.headersSent) {
        if (switchToBackup(token)) {
          const newTokenData = streamTokens.get(token);
          if (newTokenData) {
            return proxyHlsPlaylist(newTokenData.sourceUrl, token, res, req, maxRedirects);
          }
        }
        res.status(504).send("Timeout");
      }
    });
    
    req.on("close", () => {
      proxyReq.destroy();
    });
    
    proxyReq.end();
  } catch (error: any) {
    if (!res.headersSent) res.status(500).send("Internal error");
  }
}

// Proxy HLS playlist for MAG devices - uses /mag-stream/ prefix instead of /hls/
function proxyHlsPlaylistForMag(sourceUrl: string, token: string, res: Response, req: Request, maxRedirects: number = 5): void {
  if (maxRedirects <= 0) {
    if (!res.headersSent) res.status(502).send("Too many redirects");
    return;
  }

  const tokenData = streamTokens.get(token);
  if (!tokenData) {
    if (!res.headersSent) res.status(401).send("Invalid token");
    return;
  }

  // Helper to rewrite a single URL for MAG
  const rewriteUrl = (url: string, pathPrefix: string): string => {
    if (url.startsWith("http://") || url.startsWith("https://")) {
      const encoded = encodeAbsoluteUrl(tokenData, url);
      return `/mag-stream/${token}/${encoded}`;
    }
    return `/mag-stream/${token}/${pathPrefix}${url}`;
  };

  // Helper to rewrite playlist for MAG (including subtitle/audio track URIs)
  const rewritePlaylist = (body: string, pathPrefix: string): string => {
    return body
      .split("\n")
      .map(line => {
        const trimmed = line.trim();
        if (!trimmed) return line;
        
        // Handle EXT-X-MEDIA tags (subtitles, audio tracks) - rewrite URI parameter
        if (trimmed.startsWith("#EXT-X-MEDIA:") && trimmed.includes("URI=")) {
          let modifiedLine = line.replace(/URI="([^"]+)"/g, (match, uri) => {
            const rewrittenUri = rewriteUrl(uri, pathPrefix);
            return `URI="${rewrittenUri}"`;
          }).replace(/URI=([^,\s"]+)/g, (match, uri) => {
            if (uri.startsWith('"')) return match;
            const rewrittenUri = rewriteUrl(uri, pathPrefix);
            return `URI="${rewrittenUri}"`;
          });
          
          // Auto-enable subtitles: Set DEFAULT=YES and AUTOSELECT=YES for subtitle tracks
          if (trimmed.includes("TYPE=SUBTITLES")) {
            if (modifiedLine.includes("DEFAULT=NO")) {
              modifiedLine = modifiedLine.replace(/DEFAULT=NO/g, "DEFAULT=YES");
            } else if (!modifiedLine.includes("DEFAULT=")) {
              modifiedLine = modifiedLine.replace("#EXT-X-MEDIA:", "#EXT-X-MEDIA:DEFAULT=YES,");
            }
            if (modifiedLine.includes("AUTOSELECT=NO")) {
              modifiedLine = modifiedLine.replace(/AUTOSELECT=NO/g, "AUTOSELECT=YES");
            } else if (!modifiedLine.includes("AUTOSELECT=")) {
              modifiedLine = modifiedLine.replace("#EXT-X-MEDIA:", "#EXT-X-MEDIA:AUTOSELECT=YES,");
            }
          }
          
          return modifiedLine;
        }
        
        // Handle EXT-X-I-FRAME-STREAM-INF tags
        if (trimmed.startsWith("#EXT-X-I-FRAME-STREAM-INF:") && trimmed.includes("URI=")) {
          return line.replace(/URI="([^"]+)"/g, (match, uri) => {
            const rewrittenUri = rewriteUrl(uri, pathPrefix);
            return `URI="${rewrittenUri}"`;
          });
        }
        
        // Skip other comment lines
        if (trimmed.startsWith("#")) return line;
        
        // Regular segment/playlist URLs
        return rewriteUrl(trimmed, pathPrefix);
      })
      .join("\n");
  };

  try {
    const parsedUrl = new URL(sourceUrl);
    const isHttps = parsedUrl.protocol === "https:";
    const client = isHttps ? https : http;
    const agent = isHttps ? httpsAgent : httpAgent;
    
    const headers: Record<string, string> = {
      "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
      "Accept": "*/*",
      "Connection": "keep-alive",
    };
    
    const options = {
      hostname: parsedUrl.hostname,
      port: parsedUrl.port || (isHttps ? 443 : 80),
      path: parsedUrl.pathname + parsedUrl.search,
      method: "GET",
      headers,
      agent,
    };
    
    const proxyReq = client.request(options, (proxyRes) => {
      const statusCode = proxyRes.statusCode || 200;
      
      if ([301, 302, 303, 307, 308].includes(statusCode) && proxyRes.headers.location) {
        proxyRes.destroy();
        const redirectUrl = new URL(proxyRes.headers.location, sourceUrl).toString();
        const newBaseUrl = redirectUrl.substring(0, redirectUrl.lastIndexOf("/") + 1);
        tokenData.baseUrl = newBaseUrl;
        return proxyHlsPlaylistForMag(redirectUrl, token, res, req, maxRedirects - 1);
      }
      
      const currentPlaylistDir = sourceUrl.substring(0, sourceUrl.lastIndexOf("/") + 1);
      const originalBase = tokenData.baseUrl;
      let pathPrefix = "";
      if (currentPlaylistDir.startsWith(originalBase)) {
        pathPrefix = currentPlaylistDir.substring(originalBase.length);
      }
      
      let body = "";
      proxyRes.setEncoding("utf8");
      proxyRes.on("data", (chunk) => { body += chunk; });
      proxyRes.on("end", () => {
        // Cache raw playlist
        setCachedPlaylist(sourceUrl, body, currentPlaylistDir);
        
        const rewritten = rewritePlaylist(body, pathPrefix);
        res.setHeader("Content-Type", "application/vnd.apple.mpegurl");
        res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
        res.setHeader("Pragma", "no-cache");
        res.send(rewritten);
      });
    });
    
    proxyReq.on("error", () => {
      if (!res.headersSent) {
        if (switchToBackup(token)) {
          const newTokenData = streamTokens.get(token);
          if (newTokenData) {
            return proxyHlsPlaylistForMag(newTokenData.sourceUrl, token, res, req, maxRedirects);
          }
        }
        res.status(502).send("Stream unavailable");
      }
    });
    
    // Fast timeout - 3 seconds
    proxyReq.setTimeout(3000, () => {
      proxyReq.destroy();
      if (!res.headersSent) {
        if (switchToBackup(token)) {
          const newTokenData = streamTokens.get(token);
          if (newTokenData) {
            return proxyHlsPlaylistForMag(newTokenData.sourceUrl, token, res, req, maxRedirects);
          }
        }
        res.status(504).send("Timeout");
      }
    });
    
    req.on("close", () => {
      proxyReq.destroy();
    });
    
    proxyReq.end();
  } catch (error: any) {
    if (!res.headersSent) res.status(500).send("Internal error");
  }
}

// FAST segment proxy using undici with large buffers (like Nginx 512k buffers)
async function proxySegmentFast(sourceUrl: string, res: Response, req: Request, token?: string, streamId?: number): Promise<void> {
  // Check segment cache first
  if (!req.headers.range) {
    const cached = getCachedSegment(sourceUrl);
    if (cached) {
      res.setHeader("Content-Type", cached.contentType);
      res.setHeader("Content-Length", cached.data.length);
      res.setHeader("Cache-Control", "no-store, no-cache");
      res.setHeader("X-Cache", "HIT");
      res.setHeader("Access-Control-Allow-Origin", "*");
      res.setHeader("Access-Control-Expose-Headers", "Content-Length, Content-Range");
      res.send(cached.data);
      return;
    }
  }

  // Get session cookies from token data for xaccel-codec authentication
  let sessionCookies: string | undefined;
  if (token) {
    const tokenData = streamTokens.get(token);
    if (tokenData?.cookies) {
      sessionCookies = tokenData.cookies;
    }
  }

  try {
    const headers: Record<string, string> = {
      "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
      "Accept": "*/*",
      "Connection": "keep-alive",
    };
    if (req.headers.range) {
      headers["Range"] = req.headers.range as string;
    }
    // Forward session cookies for xaccel-codec authentication
    if (sessionCookies) {
      headers["Cookie"] = sessionCookies;
    }

    const { statusCode, headers: resHeaders, body } = await undiciRequest(sourceUrl, {
      method: "GET",
      headers,
      dispatcher: undiciAgent,
      bodyTimeout: 30000,
      headersTimeout: 3000,
    });

    res.status(statusCode);
    
    let contentType = resHeaders["content-type"] as string | undefined;
    const contentLength = resHeaders["content-length"];
    const acceptRanges = resHeaders["accept-ranges"];
    const contentRange = resHeaders["content-range"];
    
    // Fix Content-Type for subtitle files (some upstream servers send wrong MIME type)
    const urlLower = sourceUrl.toLowerCase();
    if (urlLower.endsWith(".vtt") || urlLower.endsWith(".webvtt")) {
      contentType = "text/vtt; charset=utf-8";
    } else if (urlLower.endsWith(".srt")) {
      contentType = "text/plain; charset=utf-8";
    }
    
    if (contentType) res.setHeader("Content-Type", contentType);
    if (contentLength) res.setHeader("Content-Length", contentLength as string);
    if (acceptRanges) res.setHeader("Accept-Ranges", acceptRanges as string);
    if (contentRange) res.setHeader("Content-Range", contentRange as string);
    res.setHeader("Cache-Control", "no-store, no-cache");
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Methods", "GET, OPTIONS");
    res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, Range");
    res.setHeader("Access-Control-Expose-Headers", "Content-Length, Content-Range");
    
    // Use cork/uncork for faster buffered writes
    if (typeof (res as any).socket?.cork === 'function') {
      (res as any).socket.cork();
    }
    res.flushHeaders();
    
    // Stream body to response with bitrate tracking
    for await (const chunk of body) {
      if (!res.writableEnded) {
        res.write(chunk);
        // Track bytes for real-time bitrate calculation
        if (streamId && chunk.length) {
          recordStreamBytes(streamId, chunk.length);
        }
      }
    }
    
    if (typeof (res as any).socket?.uncork === 'function') {
      (res as any).socket.uncork();
    }
    res.end();
  } catch (error: any) {
    if (!res.headersSent) {
      // Try backup if available
      if (token && switchToBackup(token)) {
        const newTokenData = streamTokens.get(token);
        if (newTokenData) {
          try {
            const oldUrl = new URL(sourceUrl);
            const newUrl = new URL(newTokenData.sourceUrl);
            const newSegmentUrl = sourceUrl.replace(oldUrl.origin, newUrl.origin);
            return proxySegmentFast(newSegmentUrl, res, req, token, streamId);
          } catch {}
        }
      }
      res.status(502).send("Segment unavailable");
    }
  }
}

// Proxy segment/media files directly (no URL rewriting needed)
// Optimized with keep-alive agents and stream pipeline for low latency
function proxySegment(sourceUrl: string, res: Response, req: Request, maxRedirects: number = 5, token?: string): void {
  if (maxRedirects <= 0) {
    if (!res.headersSent) res.status(502).send("Too many redirects");
    return;
  }

  // Check segment cache first for instant response (only if no range request)
  if (!req.headers.range) {
    const cached = getCachedSegment(sourceUrl);
    if (cached) {
      res.setHeader("Content-Type", cached.contentType);
      res.setHeader("Content-Length", cached.data.length);
      res.setHeader("Cache-Control", "no-store, no-cache");
      res.setHeader("X-Cache", "HIT");
      res.send(cached.data);
      return;
    }
  }

  try {
    const parsedUrl = new URL(sourceUrl);
    const isHttps = parsedUrl.protocol === "https:";
    const client = isHttps ? https : http;
    const agent = isHttps ? httpsAgent : httpAgent;
    
    const headers: Record<string, string> = {
      "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
      "Accept": "*/*",
      "Accept-Encoding": "identity",
      "Connection": "keep-alive",
    };
    if (req.headers.range) {
      headers["Range"] = req.headers.range;
    }
    
    const options = {
      hostname: parsedUrl.hostname,
      port: parsedUrl.port || (isHttps ? 443 : 80),
      path: parsedUrl.pathname + parsedUrl.search,
      method: "GET",
      headers,
      agent,
    };
    
    const proxyReq = client.request(options, (proxyRes) => {
      const statusCode = proxyRes.statusCode || 200;
      
      if ([301, 302, 303, 307, 308].includes(statusCode) && proxyRes.headers.location) {
        proxyRes.destroy();
        const redirectUrl = new URL(proxyRes.headers.location, sourceUrl).toString();
        return proxySegment(redirectUrl, res, req, maxRedirects - 1, token);
      }
      
      res.status(statusCode);
      
      let contentType = proxyRes.headers["content-type"];
      const contentLength = proxyRes.headers["content-length"];
      const acceptRanges = proxyRes.headers["accept-ranges"];
      const contentRange = proxyRes.headers["content-range"];
      
      // Fix Content-Type for subtitle files (some upstream servers send wrong MIME type)
      const urlLower = sourceUrl.toLowerCase();
      if (urlLower.endsWith(".vtt") || urlLower.endsWith(".webvtt")) {
        contentType = "text/vtt; charset=utf-8";
      } else if (urlLower.endsWith(".srt")) {
        contentType = "text/plain; charset=utf-8";
      }
      
      if (contentType) res.setHeader("Content-Type", contentType);
      if (contentLength) res.setHeader("Content-Length", contentLength);
      if (acceptRanges) res.setHeader("Accept-Ranges", acceptRanges);
      if (contentRange) res.setHeader("Content-Range", contentRange);
      res.setHeader("Cache-Control", "no-store, no-cache");
      res.setHeader("X-Accel-Buffering", "no"); // Disable NGINX buffering if behind NGINX
      
      // Flush headers immediately to reduce time-to-first-byte
      res.flushHeaders();
      
      // Use pipeline for efficient streaming with proper cleanup
      pipeline(proxyRes, res, (err) => {
        if (err && !res.headersSent) {
          // Stream error - already handled below
        }
        proxyReq.destroy();
      });
      
      proxyRes.on("error", () => {
        proxyReq.destroy();
        res.end();
      });
    });
    
    // Handle client disconnect immediately
    req.on("close", () => {
      proxyReq.destroy();
    });
    
    proxyReq.on("error", () => {
      if (!res.headersSent) {
        if (token && switchToBackup(token)) {
          const newTokenData = streamTokens.get(token);
          if (newTokenData) {
            const newSegmentUrl = sourceUrl.replace(new URL(sourceUrl).origin, new URL(newTokenData.sourceUrl).origin);
            return proxySegment(newSegmentUrl, res, req, maxRedirects, token);
          }
        }
        res.status(502).send("Segment unavailable");
      }
    });
    
    // Reduced timeout (10 seconds) for faster failover
    proxyReq.setTimeout(10000, () => {
      proxyReq.destroy();
      if (!res.headersSent) {
        if (token && switchToBackup(token)) {
          const newTokenData = streamTokens.get(token);
          if (newTokenData) {
            const newSegmentUrl = sourceUrl.replace(new URL(sourceUrl).origin, new URL(newTokenData.sourceUrl).origin);
            return proxySegment(newSegmentUrl, res, req, maxRedirects, token);
          }
        }
        res.status(504).send("Timeout");
      }
    });
    
    proxyReq.end();
  } catch (error: any) {
    // Don't log source URL details for security
    if (!res.headersSent) res.status(500).send("Internal error");
  }
}

import {
  insertRegUserSchema,
  insertUserSchema,
  insertStreamSchema,
  insertSeriesSchema,
  insertSeriesEpisodeSchema,
  insertStreamCategorySchema,
  insertBouquetSchema,
  insertStreamingServerSchema,
  insertEpgSchema,
  insertMagDeviceSchema,
  loginSchema,
  STREAM_TYPE_LIVE,
  STREAM_TYPE_MOVIE,
  STREAM_TYPE_SERIES,
} from "@shared/schema";
import session from "express-session";
import MemoryStore from "memorystore";
import { logAudit, logAuditFromRequest, getAuditLogs, getAuditLogStats, deleteAuditLogs } from "./audit-log";

const loginAttempts = new Map<string, { count: number; lastAttempt: number }>();
const MAX_LOGIN_ATTEMPTS = 5;
const LOCKOUT_DURATION = 15 * 60 * 1000;

// LB server metrics cache (populated via SSH or LB proxy reports)
const lbMetricsCache = new Map<number, {
  cpuUsage: number;
  memoryUsage: number;
  diskUsage: number;
  networkIn: number;
  networkOut: number;
  activeConnections: number;
  timestamp: number;
}>();

// Rate limiting for streaming/playlist requests (anti-scanning protection)
interface RateLimitEntry {
  requests: number;
  windowStart: number;
  blocked: boolean;
  blockedUntil: number;
}
const streamRateLimits = new Map<string, RateLimitEntry>();
const RATE_LIMIT_WINDOW = 60 * 1000; // 1 minute
const MAX_REQUESTS_PER_WINDOW = 500; // Max 500 requests per minute per IP (HLS needs ~60-100 req/min per stream)
const RATE_BLOCK_DURATION = 1 * 60 * 1000; // Block for 1 minute if exceeded (was 5 min)

function checkRateLimit(ip: string): { allowed: boolean; remaining: number } {
  const now = Date.now();
  let entry = streamRateLimits.get(ip);
  
  if (!entry) {
    entry = { requests: 0, windowStart: now, blocked: false, blockedUntil: 0 };
    streamRateLimits.set(ip, entry);
  }
  
  // Check if blocked
  if (entry.blocked && now < entry.blockedUntil) {
    return { allowed: false, remaining: 0 };
  }
  
  // Reset block if expired
  if (entry.blocked && now >= entry.blockedUntil) {
    entry.blocked = false;
    entry.requests = 0;
    entry.windowStart = now;
  }
  
  // Reset window if expired
  if (now - entry.windowStart > RATE_LIMIT_WINDOW) {
    entry.requests = 0;
    entry.windowStart = now;
  }
  
  entry.requests++;
  
  // Block if exceeded
  if (entry.requests > MAX_REQUESTS_PER_WINDOW) {
    entry.blocked = true;
    entry.blockedUntil = now + RATE_BLOCK_DURATION;
    console.warn(`Rate limit exceeded for IP: ${ip} - blocked for 5 minutes`);
    return { allowed: false, remaining: 0 };
  }
  
  return { allowed: true, remaining: MAX_REQUESTS_PER_WINDOW - entry.requests };
}

// Cleanup rate limit entries periodically (including expired blocks)
setInterval(() => {
  const now = Date.now();
  const entries = Array.from(streamRateLimits.entries());
  entries.forEach(([ip, entry]) => {
    // Delete unblocked entries after 2x window
    if (!entry.blocked && now - entry.windowStart > RATE_LIMIT_WINDOW * 2) {
      streamRateLimits.delete(ip);
    }
    // Delete blocked entries after block expires
    if (entry.blocked && now >= entry.blockedUntil) {
      streamRateLimits.delete(ip);
    }
  });
}, 60 * 1000);

// Helper function to get user's allowed stream IDs from their assigned bouquets
// contentType: "channels" | "movies" | "series"
async function getUserAllowedStreamIds(
  user: { bouquet: string | null },
  storageRef: typeof storage,
  contentType: "channels" | "movies" | "series"
): Promise<number[]> {
  let userBouquetIds: number[] = [];
  try {
    if (user.bouquet) {
      userBouquetIds = JSON.parse(user.bouquet).map((id: number | string) => Number(id));
    }
  } catch {
    userBouquetIds = [];
  }

  // If user has no bouquet assignments, return empty (they see all content)
  if (userBouquetIds.length === 0) {
    return [];
  }

  const allBouquets = await storageRef.getBouquets();
  const userBouquets = allBouquets
    .filter(b => userBouquetIds.includes(b.id))
    .sort((a, b) => a.bouquetOrder - b.bouquetOrder);

  const allowedIds: number[] = [];
  
  for (const bouquet of userBouquets) {
    try {
      let ids: any[] = [];
      if (contentType === "channels") {
        ids = bouquet.bouquetChannels ? JSON.parse(bouquet.bouquetChannels) : [];
      } else if (contentType === "movies") {
        ids = bouquet.bouquetMovies ? JSON.parse(bouquet.bouquetMovies) : [];
      } else if (contentType === "series") {
        ids = bouquet.bouquetSeries ? JSON.parse(bouquet.bouquetSeries) : [];
      }
      
      for (const id of ids) {
        if (!allowedIds.includes(Number(id))) {
          allowedIds.push(Number(id));
        }
      }
    } catch {
      // Skip malformed bouquet data
    }
  }

  return allowedIds;
}

// Stream token storage for proxying - hides source URLs completely
interface StreamToken {
  sourceUrl: string;
  backupUrls: string[];
  currentBackupIndex: number;
  baseUrl: string;
  userId: number;
  streamId: number;
  createdAt: number;
  expiresAt: number;
  absoluteUrls: Map<number, string>;
  absoluteUrlCounter: number;
  cookies?: string; // Session cookies from xaccel-codec or similar servers
}
const streamTokens = new Map<string, StreamToken>();
const TOKEN_TTL = 4 * 60 * 60 * 1000; // 4 hours

// ===============================
// MAG DEVICE SECURITY
// ===============================

// MAG Token storage - validates handshake tokens for each device
interface MagSession {
  mac: string;
  token: string;
  validTokens: string[]; // Chain of valid tokens (current + up to 2 previous)
  clientIp: string;
  firstIp: string; // First IP seen - used for lockToIsp
  deviceId: string;
  hwVersion: string;
  createdAt: number;
  lastActive: number;
  tokenExpiresAt: number; // Token expiration timestamp
}
const magSessions = new Map<string, MagSession>(); // Key: normalized MAC
const MAG_SESSION_TTL = 24 * 60 * 60 * 1000; // 24 hours
const MAG_TOKEN_TTL = 4 * 60 * 60 * 1000; // 4 hours token expiration
const MAG_TOKEN_REFRESH_WINDOW = 30 * 60 * 1000; // Refresh if within 30 min of expiry
const MAG_MAX_VALID_TOKENS = 3; // Keep up to 3 tokens valid (current + 2 previous refreshes)

// Failed login attempt tracking
interface MagLoginAttempt {
  mac: string;
  ip: string;
  attempts: number;
  firstAttemptAt: number;
  blockedUntil: number; // 0 if not blocked
}
const magLoginAttempts = new Map<string, MagLoginAttempt>(); // Key: MAC or IP
const MAG_MAX_FAILED_ATTEMPTS = 5;
const MAG_BLOCK_DURATION = 15 * 60 * 1000; // 15 minutes block
const MAG_ATTEMPT_WINDOW = 15 * 60 * 1000; // 15 min window for counting attempts

// Check if MAC/IP is blocked due to failed attempts
function isMagBlocked(mac: string, ip: string): { blocked: boolean; remainingSeconds?: number } {
  const now = Date.now();
  
  // Check MAC-based block
  const macAttempt = magLoginAttempts.get(mac);
  if (macAttempt && macAttempt.blockedUntil > now) {
    const remaining = Math.ceil((macAttempt.blockedUntil - now) / 1000);
    console.log(`[MAG SECURITY] MAC ${mac} blocked for ${remaining}s`);
    return { blocked: true, remainingSeconds: remaining };
  }
  
  // Check IP-based block
  const ipAttempt = magLoginAttempts.get(`ip:${ip}`);
  if (ipAttempt && ipAttempt.blockedUntil > now) {
    const remaining = Math.ceil((ipAttempt.blockedUntil - now) / 1000);
    console.log(`[MAG SECURITY] IP ${ip} blocked for ${remaining}s`);
    return { blocked: true, remainingSeconds: remaining };
  }
  
  return { blocked: false };
}

// Record failed login attempt
function recordFailedMagAttempt(mac: string, ip: string): void {
  const now = Date.now();
  
  // Record for MAC
  let macAttempt = magLoginAttempts.get(mac);
  if (!macAttempt || (now - macAttempt.firstAttemptAt > MAG_ATTEMPT_WINDOW)) {
    macAttempt = { mac, ip, attempts: 0, firstAttemptAt: now, blockedUntil: 0 };
  }
  macAttempt.attempts++;
  macAttempt.ip = ip;
  
  if (macAttempt.attempts >= MAG_MAX_FAILED_ATTEMPTS) {
    macAttempt.blockedUntil = now + MAG_BLOCK_DURATION;
    console.log(`[MAG SECURITY] MAC ${mac} BLOCKED after ${macAttempt.attempts} failed attempts`);
  }
  magLoginAttempts.set(mac, macAttempt);
  
  // Record for IP
  let ipAttempt = magLoginAttempts.get(`ip:${ip}`);
  if (!ipAttempt || (now - ipAttempt.firstAttemptAt > MAG_ATTEMPT_WINDOW)) {
    ipAttempt = { mac: "", ip, attempts: 0, firstAttemptAt: now, blockedUntil: 0 };
  }
  ipAttempt.attempts++;
  
  if (ipAttempt.attempts >= MAG_MAX_FAILED_ATTEMPTS * 2) { // IP needs more attempts to block
    ipAttempt.blockedUntil = now + MAG_BLOCK_DURATION;
    console.log(`[MAG SECURITY] IP ${ip} BLOCKED after ${ipAttempt.attempts} failed attempts`);
  }
  magLoginAttempts.set(`ip:${ip}`, ipAttempt);
}

// Clear failed attempts on successful login
function clearFailedMagAttempts(mac: string, ip: string): void {
  magLoginAttempts.delete(mac);
  magLoginAttempts.delete(`ip:${ip}`);
}

// Get all blocked MAG entries for admin view
function getBlockedMagEntries(): Array<{ key: string; type: string; attempts: number; blockedUntil: number; remainingSeconds: number }> {
  const now = Date.now();
  const blocked: Array<{ key: string; type: string; attempts: number; blockedUntil: number; remainingSeconds: number }> = [];
  
  magLoginAttempts.forEach((attempt, key) => {
    if (attempt.blockedUntil > now) {
      blocked.push({
        key,
        type: key.startsWith("ip:") ? "IP" : "MAC",
        attempts: attempt.attempts,
        blockedUntil: attempt.blockedUntil,
        remainingSeconds: Math.ceil((attempt.blockedUntil - now) / 1000),
      });
    }
  });
  
  return blocked;
}

// Unblock a MAC or IP
function unblockMagEntry(key: string): boolean {
  const attempt = magLoginAttempts.get(key);
  if (attempt) {
    attempt.blockedUntil = 0;
    attempt.attempts = 0;
    magLoginAttempts.set(key, attempt);
    console.log(`[MAG SECURITY] Unblocked: ${key}`);
    return true;
  }
  return false;
}

// Check if token is expired or needs refresh
function checkMagTokenExpiry(session: MagSession): { valid: boolean; needsRefresh: boolean } {
  const now = Date.now();
  
  if (now > session.tokenExpiresAt) {
    return { valid: false, needsRefresh: false };
  }
  
  // Check if within refresh window
  if (session.tokenExpiresAt - now < MAG_TOKEN_REFRESH_WINDOW) {
    return { valid: true, needsRefresh: true };
  }
  
  return { valid: true, needsRefresh: false };
}

// Refresh token for active session - maintains chain of valid tokens
function refreshMagToken(normalizedMac: string): string | null {
  const session = magSessions.get(normalizedMac);
  if (!session) return null;
  
  const newToken = generateToken();
  const now = Date.now();
  
  // Add new token to the front of the valid tokens chain
  session.validTokens.unshift(newToken);
  // Keep only the last N tokens valid
  if (session.validTokens.length > MAG_MAX_VALID_TOKENS) {
    session.validTokens.pop();
  }
  
  // Set new token as current
  session.token = newToken;
  session.tokenExpiresAt = now + MAG_TOKEN_TTL;
  session.lastActive = now;
  magSessions.set(normalizedMac, session);
  
  console.log(`[MAG SECURITY] Token refreshed for ${normalizedMac}, ${session.validTokens.length} tokens valid`);
  return newToken;
}

// Cleanup expired MAG login attempts
setInterval(() => {
  const now = Date.now();
  const toDelete: string[] = [];
  
  magLoginAttempts.forEach((attempt, key) => {
    // Remove if window expired and not blocked
    if (now - attempt.firstAttemptAt > MAG_ATTEMPT_WINDOW && attempt.blockedUntil <= now) {
      toDelete.push(key);
    }
  });
  
  toDelete.forEach(key => magLoginAttempts.delete(key));
  if (toDelete.length > 0) {
    console.log(`[MAG SECURITY] Cleaned up ${toDelete.length} expired login attempts`);
  }
}, 5 * 60 * 1000); // Every 5 minutes

// MAG Connection tracking (separate from user connections)
interface MagConnection {
  mac: string;
  streamId: number;
  clientIp: string;
  startedAt: number;
  lastActive: number;
}
const magConnections = new Map<string, MagConnection[]>(); // Key: normalized MAC
const MAG_CONNECTION_TIMEOUT = 60 * 1000; // 60 seconds

// Validate MAG device access with strict enforcement
// Options:
// - skipSessionCheck=true: for handshake endpoint only
// - skipIpLock=true: for informational endpoints (EPG, channel lists) that don't provide stream URLs
// Returns: { valid, error, newToken (if refreshed) }
function validateMagSession(
  normalizedMac: string,
  clientIp: string,
  device: any,
  reqToken?: string,
  skipSessionCheck: boolean = false,
  skipIpLock: boolean = false
): { valid: boolean; error?: string; newToken?: string } {
  const session = magSessions.get(normalizedMac);
  
  // STRICT: Session MUST exist (handshake MUST have been done first)
  if (!session) {
    if (skipSessionCheck) {
      console.log(`[MAG SECURITY] No session for ${normalizedMac} - allowing handshake`);
      return { valid: true };
    }
    console.log(`[MAG SECURITY] REJECTED: No session for ${normalizedMac} - handshake required first`);
    return { valid: false, error: "Session not found - please reconnect" };
  }
  
  // Update last active
  session.lastActive = Date.now();
  
  // Check token expiration
  const tokenStatus = checkMagTokenExpiry(session);
  if (!tokenStatus.valid) {
    console.log(`[MAG SECURITY] TOKEN EXPIRED for ${normalizedMac}`);
    return { valid: false, error: "Session expired - please reconnect" };
  }
  
  // IP LOCK ENFORCEMENT: If lockToIsp is enabled and not skipped (for streaming endpoints)
  if (!skipIpLock && device.lockToIsp === 1) {
    if (session.firstIp && session.firstIp !== clientIp) {
      console.log(`[MAG SECURITY] IP LOCK VIOLATION for ${normalizedMac}: locked=${session.firstIp}, current=${clientIp}`);
      return { valid: false, error: "Device is locked to a different IP address" };
    }
  }
  
  // STRICT MANDATORY TOKEN VALIDATION (except for handshake which skips)
  if (!skipSessionCheck) {
    // Token MUST be provided and MUST match session token (or previous token during grace period)
    if (!reqToken) {
      console.log(`[MAG SECURITY] TOKEN MISSING for ${normalizedMac}`);
      return { valid: false, error: "Session token required - please reconnect" };
    }
    
    // Ensure validTokens is initialized (safeguard for legacy sessions)
    if (!session.validTokens || session.validTokens.length === 0) {
      session.validTokens = [session.token];
    }
    
    // Check if token is in the valid tokens chain (current + previous refreshes)
    const isTokenValid = session.validTokens.includes(reqToken);
    
    if (!isTokenValid) {
      console.log(`[MAG SECURITY] TOKEN MISMATCH for ${normalizedMac}`);
      return { valid: false, error: "Invalid session token - please reconnect" };
    }
    
    if (reqToken !== session.token) {
      console.log(`[MAG SECURITY] Using previous token for ${normalizedMac}`);
    }
  }
  
  // Auto-refresh token if within refresh window
  let newToken: string | undefined;
  if (tokenStatus.needsRefresh) {
    newToken = refreshMagToken(normalizedMac) || undefined;
  }
  
  return { valid: true, newToken };
}

// Extract MAG token from request (Authorization header or query param)
function getMagToken(req: any): string | undefined {
  // Try Authorization header first
  const authHeader = req.headers.authorization as string || "";
  if (authHeader.startsWith("Bearer ")) {
    return authHeader.substring(7);
  }
  // Try custom header
  if (req.headers["x-token"]) {
    return req.headers["x-token"] as string;
  }
  // Try query param
  if (req.query.token) {
    return req.query.token as string;
  }
  return undefined;
}

// Check if MAG connection limit allows new connection
function checkMagConnectionLimit(normalizedMac: string, device: any): { allowed: boolean; error?: string } {
  const maxConnections = device.playbackLimit || 1;
  const currentConnections = countMagConnections(normalizedMac);
  
  if (currentConnections >= maxConnections) {
    console.log(`[MAG SECURITY] CONNECTION LIMIT for ${normalizedMac}: ${currentConnections}/${maxConnections}`);
    return { allowed: false, error: `Connection limit reached (${maxConnections})` };
  }
  
  return { allowed: true };
}

// Create or update MAG session after handshake
function createMagSession(normalizedMac: string, clientIp: string, deviceId?: string, hwVersion?: string): string {
  const token = generateToken();
  const existingSession = magSessions.get(normalizedMac);
  const now = Date.now();
  
  magSessions.set(normalizedMac, {
    mac: normalizedMac,
    token,
    validTokens: [token], // Initialize with the new token
    clientIp,
    firstIp: existingSession?.firstIp || clientIp, // Keep original IP for lockToIsp
    deviceId: deviceId || existingSession?.deviceId || "",
    hwVersion: hwVersion || existingSession?.hwVersion || "",
    createdAt: existingSession?.createdAt || now,
    lastActive: now,
    tokenExpiresAt: now + MAG_TOKEN_TTL, // Token expires in 4 hours
  });
  
  return token;
}

// Track MAG device connection for stream
function addMagConnection(normalizedMac: string, streamId: number, clientIp: string): void {
  const conns = magConnections.get(normalizedMac) || [];
  
  // Remove stale connections first
  const now = Date.now();
  const activeConns = conns.filter(c => now - c.lastActive < MAG_CONNECTION_TIMEOUT);
  
  // Check if this stream already exists, update it
  const existingIdx = activeConns.findIndex(c => c.streamId === streamId);
  if (existingIdx >= 0) {
    activeConns[existingIdx].lastActive = now;
  } else {
    activeConns.push({
      mac: normalizedMac,
      streamId,
      clientIp,
      startedAt: now,
      lastActive: now,
    });
  }
  
  magConnections.set(normalizedMac, activeConns);
}

// Count active MAG connections
function countMagConnections(normalizedMac: string): number {
  const conns = magConnections.get(normalizedMac) || [];
  const now = Date.now();
  return conns.filter(c => now - c.lastActive < MAG_CONNECTION_TIMEOUT).length;
}

// Cleanup expired MAG sessions and connections
setInterval(() => {
  const now = Date.now();
  
  // Cleanup sessions
  Array.from(magSessions.entries()).forEach(([mac, session]) => {
    if (now - session.lastActive > MAG_SESSION_TTL) {
      magSessions.delete(mac);
    }
  });
  
  // Cleanup connections
  Array.from(magConnections.entries()).forEach(([mac, conns]) => {
    const activeConns = conns.filter((c: MagConnection) => now - c.lastActive < MAG_CONNECTION_TIMEOUT);
    if (activeConns.length === 0) {
      magConnections.delete(mac);
    } else {
      magConnections.set(mac, activeConns);
    }
  });
}, 60000); // Every minute

function generateToken(): string {
  return Math.random().toString(36).substring(2) + Date.now().toString(36);
}

// Encode absolute URLs to safe path component that hides the real URL
function encodeAbsoluteUrl(tokenData: StreamToken, absoluteUrl: string): string {
  // Store the URL with an index and return a reference
  const index = tokenData.absoluteUrlCounter++;
  tokenData.absoluteUrls.set(index, absoluteUrl);
  return `_abs_${index}`;
}

// Decode back to original URL
function decodeAbsoluteUrl(tokenData: StreamToken, encoded: string): string | null {
  const match = encoded.match(/^_abs_(\d+)$/);
  if (!match) return null;
  const index = parseInt(match[1], 10);
  return tokenData.absoluteUrls.get(index) || null;
}

function createStreamToken(sourceUrl: string, userId: number, streamId: number, backupUrls?: string[]): string {
  const token = generateToken();
  const baseUrl = sourceUrl.substring(0, sourceUrl.lastIndexOf("/") + 1);
  streamTokens.set(token, {
    sourceUrl,
    backupUrls: backupUrls || [],
    currentBackupIndex: -1,
    baseUrl,
    userId,
    streamId,
    createdAt: Date.now(),
    expiresAt: Date.now() + TOKEN_TTL,
    absoluteUrls: new Map(),
    absoluteUrlCounter: 0,
  });
  
  // Prefetch playlist and segments immediately for faster startup
  prefetchStream(sourceUrl).catch(() => {});
  
  return token;
}

function switchToBackup(token: string): boolean {
  const data = streamTokens.get(token);
  if (!data || data.backupUrls.length === 0) {
    return false;
  }
  // Try next backup in the list
  const nextIndex = data.currentBackupIndex + 1;
  if (nextIndex >= data.backupUrls.length) {
    console.log(`[Failover] Stream ${data.streamId} exhausted all backup sources`);
    return false;
  }
  const newSource = data.backupUrls[nextIndex];
  data.sourceUrl = newSource;
  data.baseUrl = newSource.substring(0, newSource.lastIndexOf("/") + 1);
  data.currentBackupIndex = nextIndex;
  data.absoluteUrls.clear();
  data.absoluteUrlCounter = 0;
  console.log(`[Failover] Stream ${data.streamId} switched to backup #${nextIndex + 1}`);
  return true;
}

function getStreamToken(token: string): StreamToken | null {
  const data = streamTokens.get(token);
  if (!data) return null;
  if (Date.now() > data.expiresAt) {
    streamTokens.delete(token);
    return null;
  }
  return data;
}

// Cleanup expired tokens periodically
setInterval(() => {
  const now = Date.now();
  const entries = Array.from(streamTokens.entries());
  entries.forEach(([token, data]) => {
    if (now > data.expiresAt) {
      streamTokens.delete(token);
    }
  });
}, 60 * 1000);

const updateAdminSchema = insertRegUserSchema.partial();
const updateUserSchema = insertUserSchema.partial();
const updateStreamSchema = insertStreamSchema.partial();
const updateSeriesSchema = insertSeriesSchema.partial();
const updateSeriesEpisodeSchema = insertSeriesEpisodeSchema.partial();
const updateCategorySchema = insertStreamCategorySchema.partial();
const updateBouquetSchema = insertBouquetSchema.partial();
const updateServerSchema = insertStreamingServerSchema.partial();
const updateEpgSchema = insertEpgSchema.partial();
const updateMagDeviceSchema = insertMagDeviceSchema.partial();

declare module "express-session" {
  interface SessionData {
    adminId: number;
    adminUsername: string;
    adminRole: string;
  }
}

// Token-based auth (works in all environments including Replit preview)
// Tokens are now stored in database for persistence across server restarts

function generateAuthToken(): string {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  let token = "";
  for (let i = 0; i < 64; i++) {
    token += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return token;
}

// Cleanup expired tokens every 5 minutes (now using database)
setInterval(async () => {
  try {
    await storage.deleteExpiredAuthTokens();
  } catch (err) {
    // Ignore cleanup errors
  }
}, 5 * 60 * 1000);

// Extended Request type with auth info
interface AuthRequest extends Request {
  adminId?: number;
  adminUsername?: string;
  adminRole?: string;
}

export async function registerRoutes(httpServer: Server, app: Express): Promise<void> {
  await storage.initialize();
  
  // Start real-time bitrate tracking
  startBitrateUpdater(storage);
  
  // Trust proxy for Replit environment
  app.set("trust proxy", 1);
  
  // Security headers with Helmet
  app.use(helmet({
    contentSecurityPolicy: false, // Disable for SPA compatibility
    crossOriginEmbedderPolicy: false,
    crossOriginResourcePolicy: { policy: "cross-origin" }, // Allow HLS streaming
  }));
  
  // Additional security headers
  app.use((req, res, next) => {
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.setHeader("X-Frame-Options", "DENY");
    res.setHeader("X-XSS-Protection", "1; mode=block");
    res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
    res.setHeader("Permissions-Policy", "camera=(), microphone=(), geolocation=()");
    next();
  });
  
  // Download routes for installation packages (admin only - will be protected after auth middleware)
  const path = await import("path");
  const fs = await import("fs");
  
  // PUBLIC download endpoint for source files (no auth required)
  app.get("/downloads/:file", (req, res) => {
    const allowedFiles: Record<string, string> = {
      "neoserv-source-update.zip": "dist/public/neoserv-source-update.zip",
      "neoserv-panel.zip": "dist/public/neoserv-panel.zip",
      "streams.tsx": "client/src/pages/streams.tsx",
      "routes.ts": "server/routes.ts",
    };
    
    const fileName = req.params.file;
    const filePath = allowedFiles[fileName];
    
    if (!filePath) {
      return res.status(404).send("File not found");
    }
    
    const fullPath = path.join(process.cwd(), filePath);
    if (!fs.existsSync(fullPath)) {
      return res.status(404).send("File does not exist");
    }
    
    res.download(fullPath, fileName);
  });
  
  // Normalize IP address (handle IPv6-mapped IPv4 addresses like ::ffff:192.168.1.1)
  function normalizeIp(ip: string): string {
    if (!ip) return "unknown";
    // Strip IPv6-mapped IPv4 prefix
    if (ip.startsWith("::ffff:")) {
      return ip.substring(7);
    }
    // Handle localhost variations
    if (ip === "::1") return "127.0.0.1";
    return ip;
  }

  // Parse auth token from Authorization header (now using database with IP binding)
  app.use(async (req: AuthRequest, res, next) => {
    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith("Bearer ")) {
      const token = authHeader.substring(7);
      const rawIp = req.ip || req.socket.remoteAddress || "unknown";
      const clientIp = normalizeIp(rawIp);
      try {
        const tokenData = await storage.getAuthToken(token);
        if (tokenData) {
          // Note: IP binding disabled due to multi-proxy environments (Replit, Cloudflare, etc.)
          // The IP can change between requests in these environments, causing session invalidation
          // Security is maintained through token-based auth, HTTPS, and short token expiry
          req.adminId = tokenData.adminId;
          req.adminUsername = tokenData.adminUsername;
          req.adminRole = tokenData.adminRole;
        } else {
          console.log(`[AUTH] Token not found or expired: ${token.substring(0, 8)}...`);
        }
      } catch (err) {
        console.log(`[AUTH] Token lookup error:`, err);
      }
    } else if (req.path.startsWith('/api/') && !req.path.includes('/player_api') && !req.path.includes('/internal/')) {
      console.log(`[AUTH] No auth header for: ${req.method} ${req.path}`);
    }
    next();
  });

  const requireAuth = (req: AuthRequest, res: Response, next: NextFunction) => {
    if (!req.adminId) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    next();
  };

  const requireAdmin = (req: AuthRequest, res: Response, next: NextFunction) => {
    if (!req.adminId || req.adminRole !== "admin") {
      return res.status(403).json({ error: "Forbidden - Admin access required" });
    }
    next();
  };

  // Download routes for installation packages (admin only)
  app.get("/download/:filename", requireAuth, requireAdmin, (req: AuthRequest, res) => {
    const allowedFiles = [
      "neoserv-panel.zip",
      "update-2026-01-04.zip", 
      "neoserv-lb-client.zip",
      "install.sh",
      "README.md",
      "INSTALLATION.md",
      "FEATURES.md"
    ];
    
    const filename = req.params.filename;
    if (!allowedFiles.includes(filename)) {
      return res.status(404).send("File not found");
    }
    
    const filePath = path.join(process.cwd(), "deployment", filename);
    if (!fs.existsSync(filePath)) {
      return res.status(404).send("File not found");
    }
    
    res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
    res.sendFile(filePath);
  });

  // Authentication Routes
  app.post("/api/auth/login", async (req, res) => {
    const clientIp = normalizeIp(req.ip || req.socket.remoteAddress || "unknown");
    
    // Check if IP is blocked
    const isBlocked = await storage.isIpBlocked(clientIp);
    if (isBlocked) {
      return res.status(403).json({ error: "Access denied: Your IP has been blocked" });
    }
    
    // Check if IP is in whitelist (if whitelist has entries)
    const isAllowed = await storage.isIpAllowed(clientIp);
    if (!isAllowed) {
      return res.status(403).json({ error: "Access denied: Your IP is not in the whitelist" });
    }
    
    const attempts = loginAttempts.get(clientIp);
    if (attempts && attempts.count >= MAX_LOGIN_ATTEMPTS) {
      const timeSinceLastAttempt = Date.now() - attempts.lastAttempt;
      if (timeSinceLastAttempt < LOCKOUT_DURATION) {
        const remainingMinutes = Math.ceil((LOCKOUT_DURATION - timeSinceLastAttempt) / 60000);
        return res.status(429).json({ 
          error: `Too many login attempts. Please try again in ${remainingMinutes} minutes.` 
        });
      }
      loginAttempts.delete(clientIp);
    }
    
    const result = loginSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json({ error: result.error.errors });
    }

    const { username, password } = result.data;
    const admin = await storage.getAdminByUsername(username);

    let isValidPassword = false;
    if (admin) {
      isValidPassword = await bcrypt.compare(password, admin.password);
    }

    if (!admin || !isValidPassword) {
      const currentAttempts = loginAttempts.get(clientIp) || { count: 0, lastAttempt: 0 };
      loginAttempts.set(clientIp, { 
        count: currentAttempts.count + 1, 
        lastAttempt: Date.now() 
      });
      
      logAudit({
        adminId: 0,
        adminUsername: username,
        adminRole: "unknown",
        action: "login_failed",
        targetType: "system",
        details: `Failed login attempt for ${username}`,
        ipAddress: clientIp,
        userAgent: req.headers["user-agent"] || "",
      });
      
      return res.status(401).json({ error: "Invalid credentials" });
    }

    loginAttempts.delete(clientIp);
    
    // Check if 2FA is enabled for this admin
    if (admin.google2faSec && admin.google2faSec.length > 0) {
      // 2FA is enabled - don't issue token yet, require 2FA verification
      return res.json({
        requires2FA: true,
        username: admin.username,
        message: "Please enter your 2FA code"
      });
    }
    
    // No 2FA - generate auth token and store in database for persistence
    const token = generateAuthToken();
    const role = admin.memberGroupId === 1 ? "admin" : "reseller";
    await storage.createAuthToken(token, {
      adminId: admin.id,
      adminUsername: admin.username,
      adminRole: role,
      expiresAt: Date.now() + 24 * 60 * 60 * 1000, // 24 hours
    });

    await storage.createActivityLog({
      logMessage: `Admin ${admin.username} logged in`,
      logType: "login",
      logData: `Admin ${admin.username} logged in from IP ${clientIp}`,
      ownerId: admin.id,
      ownerType: "admin",
    });

    logAudit({
      adminId: admin.id,
      adminUsername: admin.username,
      adminRole: role,
      action: "login",
      targetType: "system",
      details: `Logged in successfully`,
      ipAddress: clientIp,
      userAgent: req.headers["user-agent"] || "",
    });

    res.json({
      id: admin.id,
      username: admin.username,
      email: admin.email,
      role: role,
      credits: admin.credits,
      token: token,
    });
  });

  app.post("/api/auth/logout", requireAuth, async (req: AuthRequest, res) => {
    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith("Bearer ")) {
      const token = authHeader.substring(7);
      await storage.deleteAuthToken(token);
    }
    
    const clientIp = normalizeIp(req.ip || req.socket.remoteAddress || "unknown");
    logAudit({
      adminId: req.adminId || 0,
      adminUsername: req.adminUsername || "unknown",
      adminRole: req.adminRole || "unknown",
      action: "logout",
      targetType: "system",
      details: `Logged out`,
      ipAddress: clientIp,
      userAgent: req.headers["user-agent"] || "",
    });
    
    res.json({ message: "Logged out successfully" });
  });

  app.get("/api/auth/me", requireAuth, async (req: AuthRequest, res) => {
    const admin = await storage.getAdmin(req.adminId!);
    if (!admin) {
      return res.status(404).json({ error: "Admin not found" });
    }
    res.json({
      id: admin.id,
      username: admin.username,
      email: admin.email,
      role: admin.memberGroupId === 1 ? "admin" : "reseller",
      credits: admin.credits,
      has2FA: !!(admin.google2faSec && admin.google2faSec.length > 0),
    });
  });

  // ===============================
  // TWO-FACTOR AUTHENTICATION (2FA)
  // ===============================
  
  // Get 2FA status
  app.get("/api/auth/2fa/status", requireAuth, async (req: AuthRequest, res) => {
    try {
      const admin = await storage.getAdmin(req.adminId!);
      if (!admin) {
        return res.status(404).json({ error: "Admin not found" });
      }
      res.json({ 
        enabled: !!(admin.google2faSec && admin.google2faSec.length > 0) 
      });
    } catch (error) {
      console.error("[2FA] Status error:", error);
      res.status(500).json({ error: "Failed to get 2FA status" });
    }
  });
  
  // Generate 2FA secret and QR code
  app.post("/api/auth/2fa/setup", requireAuth, async (req: AuthRequest, res) => {
    try {
      const admin = await storage.getAdmin(req.adminId!);
      if (!admin) {
        return res.status(404).json({ error: "Admin not found" });
      }
      
      // Generate new secret
      const secret = authenticator.generateSecret();
      const otpauth = authenticator.keyuri(admin.username, "X NeoServ Panel", secret);
      
      // Generate QR code as data URL
      const qrCodeDataUrl = await QRCode.toDataURL(otpauth);
      
      res.json({
        secret,
        qrCode: qrCodeDataUrl,
        otpauth,
      });
    } catch (error) {
      console.error("[2FA] Setup error:", error);
      res.status(500).json({ error: "Failed to generate 2FA setup" });
    }
  });
  
  // Verify and enable 2FA
  app.post("/api/auth/2fa/enable", requireAuth, async (req: AuthRequest, res) => {
    try {
      const { secret, token } = req.body;
      
      if (!secret || !token) {
        return res.status(400).json({ error: "Secret and token are required" });
      }
      
      // Verify the token
      const isValid = authenticator.verify({ token, secret });
      if (!isValid) {
        return res.status(400).json({ error: "Invalid verification code" });
      }
      
      // Save secret to admin
      await storage.updateAdmin(req.adminId!, { google2faSec: secret });
      
      res.json({ success: true, message: "2FA enabled successfully" });
    } catch (error) {
      console.error("[2FA] Enable error:", error);
      res.status(500).json({ error: "Failed to enable 2FA" });
    }
  });
  
  // Disable 2FA
  app.post("/api/auth/2fa/disable", requireAuth, async (req: AuthRequest, res) => {
    try {
      const admin = await storage.getAdmin(req.adminId!);
      if (!admin) {
        return res.status(404).json({ error: "Admin not found" });
      }
      
      // Remove 2FA secret
      await storage.updateAdmin(req.adminId!, { google2faSec: "" });
      
      res.json({ success: true, message: "2FA disabled successfully" });
    } catch (error) {
      console.error("[2FA] Disable error:", error);
      res.status(500).json({ error: "Failed to disable 2FA" });
    }
  });
  
  // Verify 2FA token (for login flow)
  app.post("/api/auth/2fa/verify", async (req, res) => {
    try {
      const clientIp = normalizeIp(req.ip || req.socket.remoteAddress || "unknown");
      const { username, password, token } = req.body;
      
      if (!username || !password || !token) {
        return res.status(400).json({ error: "Username, password and token are required" });
      }
      
      const admin = await storage.getAdminByUsername(username);
      if (!admin) {
        return res.status(401).json({ error: "Invalid credentials" });
      }
      
      // Verify password
      const isValidPassword = await bcrypt.compare(password, admin.password);
      if (!isValidPassword) {
        return res.status(401).json({ error: "Invalid credentials" });
      }
      
      // Verify 2FA token
      const isValid = authenticator.verify({ token, secret: admin.google2faSec });
      if (!isValid) {
        return res.status(401).json({ error: "Invalid 2FA code" });
      }
      
      // Generate auth token
      const authToken = generateAuthToken();
      const role = admin.memberGroupId === 1 ? "admin" : "reseller";
      await storage.createAuthToken(authToken, {
        adminId: admin.id,
        adminUsername: admin.username,
        adminRole: role,
        expiresAt: Date.now() + 24 * 60 * 60 * 1000,
      });
      
      res.json({
        id: admin.id,
        username: admin.username,
        email: admin.email,
        role: role,
        credits: admin.credits,
        token: authToken,
      });
    } catch (error) {
      console.error("[2FA] Verify error:", error);
      res.status(500).json({ error: "Failed to verify 2FA" });
    }
  });

  // Dashboard
  app.get("/api/dashboard/stats", requireAuth, async (req: AuthRequest, res) => {
    // For resellers, filter stats to show only their users
    const ownerId = req.adminRole === "reseller" ? req.adminId : undefined;
    const stats = await storage.getDashboardStats(ownerId);
    res.json(stats);
  });

  // Network Traffic History (aggregated from all servers)
  app.get("/api/dashboard/network-traffic", requireAuth, requireAdmin, async (req, res) => {
    try {
      const minutes = parseInt(req.query.minutes as string) || 60;
      const data = await storage.getNetworkTrafficHistory(minutes);
      res.json(data);
    } catch (err) {
      console.error("[NETWORK TRAFFIC]", err);
      res.json([]);
    }
  });

  // Connections by Country
  app.get("/api/dashboard/connections-by-country", requireAuth, requireAdmin, async (req, res) => {
    try {
      const data = await storage.getConnectionsByCountry();
      res.json(data);
    } catch (err) {
      console.error("[CONNECTIONS BY COUNTRY]", err);
      res.json([]);
    }
  });

  // Users CRUD
  app.get("/api/users", requireAuth, async (req: AuthRequest, res) => {
    const ownerId = req.adminRole === "reseller" ? req.adminId : undefined;
    const allUsers = await storage.getUsers(ownerId);
    const allConnections = await storage.getConnections();
    const now = Math.floor(Date.now() / 1000);
    
    // Count connections per user
    const connectionCountByUser = new Map<number, number>();
    for (const conn of allConnections) {
      const count = connectionCountByUser.get(conn.userId) || 0;
      connectionCountByUser.set(conn.userId, count + 1);
    }
    
    const mapped = allUsers.map(u => ({
      id: u.id,
      username: u.username,
      password: u.password,
      email: null,
      maxConnections: u.maxConnections,
      isAdmin: false,
      isReseller: u.isRestreamer === 1,
      isTrial: u.isTrial === 1,
      status: u.enabled === 0 || u.adminEnabled === 0 ? "banned" : (u.expDate && u.expDate <= now ? "expired" : "active"),
      expirationDate: u.expDate ? new Date(u.expDate * 1000).toISOString().split("T")[0] : null,
      createdAt: u.createdAt ? new Date(u.createdAt * 1000).toISOString() : null,
      notes: u.adminNotes,
      bouquetIds: u.bouquet ? JSON.parse(u.bouquet) : [],
      ownerId: u.memberId,
      allowedIps: u.allowedIps ? u.allowedIps.split(",") : [],
      isMag: u.isMag === 1,
      onlineConnections: connectionCountByUser.get(u.id) || 0,
    }));
    res.json(mapped);
  });

  app.get("/api/users/:id", requireAuth, async (req, res) => {
    const user = await storage.getUser(parseInt(req.params.id));
    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }
    res.json(user);
  });

  app.post("/api/users", requireAuth, async (req: AuthRequest, res) => {
    try {
      const body = req.body;
      const authUser = (req as any).user;
      
      // If reseller, check and deduct credits based on admin-configured price
      if (authUser && authUser.role === "reseller") {
        const reseller = await storage.getAdmin(parseInt(authUser.id));
        if (!reseller) {
          return res.status(403).json({ error: "Reseller not found" });
        }
        
        // Get credit prices from settings
        const creditPricePerLineSetting = await storage.getSetting("credit_price_per_line");
        const creditPricePerConnectionSetting = await storage.getSetting("credit_price_per_connection");
        const basePricePerLine = creditPricePerLineSetting ? parseFloat(creditPricePerLineSetting.value) || 1 : 1;
        const pricePerExtraConnection = creditPricePerConnectionSetting ? parseFloat(creditPricePerConnectionSetting.value) || 0 : 0;
        
        // Calculate total credit cost: base price + (extra connections * price per connection)
        const maxConnections = body.maxConnections || 1;
        const extraConnections = Math.max(0, maxConnections - 1);
        const totalCreditCost = basePricePerLine + (extraConnections * pricePerExtraConnection);
        
        const currentCredits = reseller.credits || 0;
        if (currentCredits < totalCreditCost) {
          return res.status(400).json({ 
            error: `Insufficient credits. You need ${totalCreditCost} credit(s) for ${maxConnections} connection(s). You have ${currentCredits} credits.` 
          });
        }
        // Deduct credits from reseller (no refunds!)
        await storage.updateAdmin(reseller.id, { credits: currentCredits - totalCreditCost });
      }
      
      const expDate = body.expirationDate ? Math.floor(new Date(body.expirationDate).getTime() / 1000) : null;
      
      const user = await storage.createUser({
        username: body.username,
        password: body.password,
        maxConnections: body.maxConnections || 1,
        bouquet: JSON.stringify(body.bouquetIds || []),
        memberId: req.adminId,
        isTrial: body.isTrial ? 1 : 0,
        enabled: 1,
        adminEnabled: 1,
        expDate,
      });

      const clientIp = normalizeIp(req.ip || req.socket.remoteAddress || "unknown");
      logAudit({
        adminId: req.adminId || 0,
        adminUsername: req.adminUsername || "unknown",
        adminRole: req.adminRole || "unknown",
        action: "user_create",
        targetType: "user",
        targetId: user.id,
        targetName: user.username,
        details: `Created user with ${body.maxConnections || 1} connection(s)`,
        ipAddress: clientIp,
      });

      res.status(201).json(user);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.patch("/api/users/:id", requireAuth, async (req, res) => {
    const body = req.body;
    const updateData: any = {};
    
    if (body.username) updateData.username = body.username;
    if (body.password) updateData.password = body.password;
    if (body.maxConnections) updateData.maxConnections = body.maxConnections;
    if (body.expirationDate) updateData.expDate = Math.floor(new Date(body.expirationDate).getTime() / 1000);
    if (body.status === "banned") {
      updateData.enabled = 0;
    } else if (body.status === "active") {
      updateData.enabled = 1;
    }
    if (body.notes) updateData.adminNotes = body.notes;
    if (body.bouquetIds) updateData.bouquet = JSON.stringify(body.bouquetIds);
    
    const user = await storage.updateUser(parseInt(req.params.id), updateData);
    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }

    const clientIp = normalizeIp(req.ip || req.socket.remoteAddress || "unknown");
    logAudit({
      adminId: (req as AuthRequest).adminId || 0,
      adminUsername: (req as AuthRequest).adminUsername || "unknown",
      adminRole: (req as AuthRequest).adminRole || "unknown",
      action: "user_update",
      targetType: "user",
      targetId: user.id,
      targetName: user.username,
      details: `Updated user`,
      ipAddress: clientIp,
    });

    res.json(user);
  });

  app.delete("/api/users/:id", requireAuth, async (req: AuthRequest, res) => {
    const userId = parseInt(req.params.id);
    const user = await storage.getUser(userId);
    const deleted = await storage.deleteUser(userId);
    if (!deleted) {
      return res.status(404).json({ error: "User not found" });
    }

    const clientIp = normalizeIp(req.ip || req.socket.remoteAddress || "unknown");
    logAudit({
      adminId: req.adminId || 0,
      adminUsername: req.adminUsername || "unknown",
      adminRole: req.adminRole || "unknown",
      action: "user_delete",
      targetType: "user",
      targetId: userId,
      targetName: user?.username || "unknown",
      details: `Deleted user`,
      ipAddress: clientIp,
    });

    res.status(204).send();
  });

  app.post("/api/users/generate", requireAuth, async (req: AuthRequest, res) => {
    const { expirationDays, maxConnections, bouquetIds, isTrial } = req.body;
    
    // If reseller, check and deduct credits based on duration
    if (req.adminRole === "reseller" && req.adminId) {
      const reseller = await storage.getAdmin(req.adminId);
      if (!reseller) {
        return res.status(403).json({ error: "Reseller not found" });
      }
      
      // Get pricing settings
      const creditPricePerLineSetting = await storage.getSetting("credit_price_per_line");
      const creditPricePerConnectionSetting = await storage.getSetting("credit_price_per_connection");
      const durationOptionsSetting = await storage.getSetting("credit_duration_options");
      
      const basePricePerLine = creditPricePerLineSetting ? parseFloat(creditPricePerLineSetting.value) || 1 : 1;
      const parsedConnPrice = creditPricePerConnectionSetting ? parseFloat(creditPricePerConnectionSetting.value) : NaN;
      const pricePerConnection = Number.isFinite(parsedConnPrice) ? parsedConnPrice : 0;
      
      // Parse duration options and find the multiplier for selected days
      let durationMultiplier = 1;
      if (durationOptionsSetting) {
        try {
          const options = JSON.parse(durationOptionsSetting.value);
          const days = expirationDays || 30;
          const option = options.find((o: any) => o.days === days);
          if (option) {
            durationMultiplier = option.multiplier || 1;
          } else {
            // Default: calculate based on 30-day base (days / 30)
            durationMultiplier = Math.max(1, days / 30);
          }
        } catch (e) {
          durationMultiplier = 1;
        }
      }
      
      // Calculate total credits: (Base + ExtraConnections × PricePerConnection) × DurationMultiplier
      const connections = maxConnections || 1;
      const extraConnections = Math.max(0, connections - 1);
      const baseCredits = basePricePerLine + (extraConnections * pricePerConnection);
      const totalCredits = baseCredits * durationMultiplier;
      
      const currentCredits = reseller.credits || 0;
      if (currentCredits < totalCredits) {
        return res.status(400).json({ 
          error: `Insufficient credits. You need ${totalCredits.toFixed(2)} credits for ${expirationDays} days with ${connections} connection(s). You have ${currentCredits} credits.` 
        });
      }
      
      // Deduct credits
      const newBalance = currentCredits - totalCredits;
      await storage.updateAdmin(reseller.id, { credits: newBalance });
      
      // Log the credit transaction
      await storage.addCreditTransaction({
        resellerId: reseller.id,
        adminId: null,
        amount: -totalCredits,
        type: "line_create",
        reason: `Line created: ${expirationDays} days, ${connections} connection(s)`,
        balanceAfter: newBalance,
        createdAt: Math.floor(Date.now() / 1000),
      });
    }
    
    const line = await storage.generateLine({
      expirationDays: expirationDays || 30,
      maxConnections: maxConnections || 1,
      bouquetIds: bouquetIds || [],
      ownerId: req.adminId,
      isTrial: isTrial || false,
    });
    res.json(line);
  });

  app.post("/api/users/bulk/delete", requireAuth, async (req, res) => {
    const { ids } = req.body;
    if (!Array.isArray(ids)) {
      return res.status(400).json({ error: "ids must be an array" });
    }
    const deleted = await storage.bulkDeleteUsers(ids);
    res.json({ deleted });
  });

  app.post("/api/users/bulk/extend", requireAuth, async (req, res) => {
    const { ids, days } = req.body;
    if (!Array.isArray(ids) || typeof days !== "number") {
      return res.status(400).json({ error: "ids must be an array and days must be a number" });
    }
    const updated = await storage.bulkExtendExpiration(ids, days);
    res.json({ updated });
  });

  // User actions: ban, enable, disable, kill connection
  app.post("/api/users/:id/ban", requireAuth, async (req, res) => {
    const user = await storage.updateUser(parseInt(req.params.id), { 
      enabled: 0, 
      adminEnabled: 0 
    });
    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }
    logAuditFromRequest(req as any, {
      action: "user_ban",
      targetType: "user",
      targetId: user.id,
      targetName: user.username,
      details: "Banned user"
    });
    res.json({ success: true, message: "User banned" });
  });

  app.post("/api/users/:id/enable", requireAuth, async (req, res) => {
    const user = await storage.updateUser(parseInt(req.params.id), { 
      enabled: 1, 
      adminEnabled: 1 
    });
    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }
    logAuditFromRequest(req as any, {
      action: "user_enable",
      targetType: "user",
      targetId: user.id,
      targetName: user.username,
      details: "Enabled user"
    });
    res.json({ success: true, message: "User enabled" });
  });

  app.post("/api/users/:id/disable", requireAuth, async (req, res) => {
    const user = await storage.updateUser(parseInt(req.params.id), { 
      enabled: 0 
    });
    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }
    logAuditFromRequest(req as any, {
      action: "user_disable",
      targetType: "user",
      targetId: user.id,
      targetName: user.username,
      details: "Disabled user"
    });
    res.json({ success: true, message: "User disabled" });
  });

  app.post("/api/users/:id/kill", requireAuth, async (req, res) => {
    // Kill all active connections for user
    const userId = parseInt(req.params.id);
    const user = await storage.getUser(userId);
    const deleted = await storage.killUserConnections(userId);
    logAuditFromRequest(req as any, {
      action: "connection_kill",
      targetType: "connection",
      targetId: userId,
      targetName: user?.username || `User ${userId}`,
      details: `Killed ${deleted} connection(s)`
    });
    res.json({ success: true, killed: deleted });
  });

  // Get playlist URL for a user (returns URL with credentials)
  app.get("/api/users/:id/playlist-url/:type", requireAuth, async (req, res) => {
    const user = await storage.getUser(parseInt(req.params.id));
    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }
    const type = req.params.type; // m3u, m3u_plus, xtream
    const host = req.headers.host || "localhost:5000";
    const protocol = req.protocol || "http";
    const baseUrl = `${protocol}://${host}`;
    
    let url = "";
    if (type === "m3u") {
      url = `${baseUrl}/get.php?username=${user.username}&password=${user.password}&type=m3u`;
    } else if (type === "m3u_plus") {
      url = `${baseUrl}/get.php?username=${user.username}&password=${user.password}&type=m3u_plus`;
    } else if (type === "xtream") {
      url = `${baseUrl}/player_api.php?username=${user.username}&password=${user.password}`;
    } else {
      return res.status(400).json({ error: "Invalid type" });
    }
    
    res.json({ url });
  });

  app.get("/api/users/:id/playlist/:type", requireAuth, async (req, res) => {
    const user = await storage.getUser(parseInt(req.params.id));
    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }
    const type = req.params.type; // m3u, m3u_plus, enigma2
    const host = req.headers.host || "localhost:5000";
    const protocol = req.protocol || "http";
    
    // Update panel_url setting to use current host for proper URLs
    await storage.setSetting("panel_url", `${protocol}://${host}`);
    
    let content = "";
    
    if (type === "m3u" || type === "m3u_plus") {
      // Generate full playlist with all user's channels, EPG info, and bouquet filtering
      content = await storage.generatePlaylist(user.id, type, "all");
    } else if (type === "enigma2") {
      // Generate Enigma2 format playlist
      content = await storage.generateEnigma2Playlist(user.id);
    } else {
      return res.status(400).json({ error: "Invalid playlist type" });
    }
    
    const extension = type === "enigma2" ? "tv" : "m3u";
    res.setHeader("Content-Type", "audio/x-mpegurl");
    res.setHeader("Content-Disposition", `attachment; filename="${user.username}_${type}.${extension}"`);
    res.send(content);
  });

  // Stream actions: start, stop, reload
  app.post("/api/streams/:id/start", requireAuth, async (req, res) => {
    const stream = await storage.updateStream(parseInt(req.params.id), { 
      directSource: 0  // 0 = always on (started)
    });
    if (!stream) {
      return res.status(404).json({ error: "Stream not found" });
    }
    logAuditFromRequest(req as any, {
      action: "stream_start",
      targetType: "stream",
      targetId: stream.id,
      targetName: stream.streamDisplayName,
      details: "Started stream"
    });
    res.json({ success: true, message: "Stream started" });
  });

  app.post("/api/streams/:id/stop", requireAuth, async (req, res) => {
    const stream = await storage.updateStream(parseInt(req.params.id), { 
      directSource: 1  // 1 = on-demand (stopped)
    });
    if (!stream) {
      return res.status(404).json({ error: "Stream not found" });
    }
    logAuditFromRequest(req as any, {
      action: "stream_stop",
      targetType: "stream",
      targetId: stream.id,
      targetName: stream.streamDisplayName,
      details: "Stopped stream"
    });
    res.json({ success: true, message: "Stream stopped" });
  });

  app.post("/api/streams/:id/reload", requireAuth, async (req, res) => {
    // Reload triggers a stream restart - we just acknowledge it
    const stream = await storage.getStream(parseInt(req.params.id));
    if (!stream) {
      return res.status(404).json({ error: "Stream not found" });
    }
    logAuditFromRequest(req as any, {
      action: "stream_restart",
      targetType: "stream",
      targetId: stream.id,
      targetName: stream.streamDisplayName,
      details: "Reloaded stream"
    });
    res.json({ success: true, message: "Stream reload triggered" });
  });

  app.get("/api/streams/:id/play", requireAuth, async (req, res) => {
    const stream = await storage.getStream(parseInt(req.params.id));
    if (!stream) {
      return res.status(404).json({ error: "Stream not found" });
    }
    if (!stream.streamSource) {
      return res.status(400).json({ error: "Stream has no source URL" });
    }
    const format = req.query.format as string || "m3u8";
    // Create admin preview token directly (no user auth needed for admin panel)
    const token = createStreamToken(stream.streamSource, 0, stream.id, stream.backupSources || []);
    const host = req.headers.host || "localhost:5000";
    const protocol = req.protocol || "http";
    res.json({ 
      playbackUrl: `${protocol}://${host}/hls/${token}/playlist.${format}`,
      name: stream.streamDisplayName,
      formats: ["ts", "m3u8"]
    });
  });

  // Stream status endpoint - returns technical info and status
  app.get("/api/streams/status", requireAuth, async (req, res) => {
    const statuses = await storage.getStreamStatuses();
    res.json(statuses);
  });

  app.get("/api/streams/:id/status", requireAuth, async (req, res) => {
    const status = await storage.getStreamStatus(parseInt(req.params.id));
    if (!status) {
      return res.status(404).json({ error: "Stream status not found" });
    }
    res.json(status);
  });

  // Stream health check - probes stream source with FFprobe
  app.post("/api/streams/:id/health-check", requireAuth, async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id) || id <= 0) {
      return res.status(400).json({ error: "Invalid stream ID" });
    }
    
    const stream = await storage.getStream(id);
    if (!stream) {
      return res.status(404).json({ error: "Stream not found" });
    }
    
    if (!stream.streamSource) {
      return res.status(400).json({ error: "Stream has no source URL configured" });
    }

    const result = await probeStream(stream.streamSource);
    
    // Update stream status in database
    const streamStatus = result.isOnline ? 1 : 0;
    const now = Math.floor(Date.now() / 1000);
    const streamInfo = result.isOnline ? JSON.stringify({
      resolution: result.resolution || "",
      videoCodec: result.videoCodec || "",
      audioCodec: result.audioCodec || "",
      fps: result.fps || "",
    }) : null;
    
    await storage.updateStreamStatus(stream.id, {
      streamStatus,
      bitrate: result.bitrate || 0,
      streamInfo,
      currentSource: stream.streamSource,
      // Set timestamps for uptime/downtime tracking
      streamStarted: result.isOnline ? now : undefined,
      streamStopped: result.isOnline ? undefined : now,
    });

    // Use generic error message to prevent any source URL leakage
    // Detailed errors are logged server-side only
    if (result.error) {
      console.error(`Stream health check failed for stream ${stream.id}: ${result.error}`);
    }

    res.json({
      streamId: stream.id,
      name: stream.streamDisplayName,
      isOnline: result.isOnline,
      resolution: result.resolution,
      videoCodec: result.videoCodec,
      audioCodec: result.audioCodec,
      fps: result.fps,
      bitrate: result.bitrate,
      error: result.isOnline ? undefined : "Stream probe failed - check server logs",
      checkedAt: new Date().toISOString(),
    });
  });

  // Bulk health check for all streams
  app.post("/api/streams/health-check-all", requireAuth, async (req, res) => {
    const streams = await storage.getStreams();
    const results: any[] = [];
    
    // Process in batches of 5 to avoid overwhelming the system
    const batchSize = 5;
    for (let i = 0; i < streams.length; i += batchSize) {
      const batch = streams.slice(i, i + batchSize);
      const batchResults = await Promise.all(
        batch.map(async (stream) => {
          if (!stream.streamSource) {
            return { streamId: stream.id, name: stream.streamDisplayName, isOnline: false, error: "No source URL" };
          }
          
          const result = await probeStream(stream.streamSource, 3);
          
          // Update status
          const streamStatus = result.isOnline ? 1 : 0;
          const streamInfo = result.isOnline ? JSON.stringify({
            resolution: result.resolution || "",
            videoCodec: result.videoCodec || "",
            audioCodec: result.audioCodec || "",
            fps: result.fps || "",
          }) : null;
          const now = Math.floor(Date.now() / 1000);
          
          await storage.updateStreamStatus(stream.id, {
            streamStatus,
            bitrate: result.bitrate || 0,
            streamInfo,
            currentSource: stream.streamSource,
            streamStarted: result.isOnline ? now : undefined,
            streamStopped: result.isOnline ? undefined : now,
          });

          // Log detailed error server-side, return generic message
          if (result.error) {
            console.error(`Stream health check failed for stream ${stream.id}: ${result.error}`);
          }

          return {
            streamId: stream.id,
            name: stream.streamDisplayName,
            isOnline: result.isOnline,
            resolution: result.resolution,
            videoCodec: result.videoCodec,
            audioCodec: result.audioCodec,
            bitrate: result.bitrate,
            error: result.isOnline ? undefined : "Probe failed",
          };
        })
      );
      results.push(...batchResults);
    }

    const online = results.filter(r => r.isOnline).length;
    const offline = results.length - online;

    res.json({
      total: results.length,
      online,
      offline,
      streams: results,
      checkedAt: new Date().toISOString(),
    });
  });

  // Mass update streams
  app.post("/api/streams/mass-update", requireAuth, async (req, res) => {
    try {
      const { ids, updates } = req.body;
      
      if (!Array.isArray(ids) || ids.length === 0) {
        return res.status(400).json({ error: "No stream IDs provided" });
      }
      
      if (!updates || Object.keys(updates).length === 0) {
        return res.status(400).json({ error: "No updates provided" });
      }
      
      let updatedCount = 0;
      const bouquetId = updates.bouquetId;
      delete updates.bouquetId; // Handle separately
      
      // Build update object with only allowed fields
      const streamUpdates: Record<string, any> = {};
      
      if (updates.forceServerId !== undefined && updates.forceServerId !== "no_change") {
        streamUpdates.forceServerId = parseInt(updates.forceServerId) || 0;
      }
      if (updates.userAgent !== undefined && updates.userAgent.trim() !== "") {
        streamUpdates.userAgent = updates.userAgent;
      }
      if (updates.isActive !== undefined) {
        streamUpdates.isActive = updates.isActive ? true : false;
      }
      
      // Update each stream
      for (const id of ids) {
        const streamId = typeof id === "string" ? parseInt(id) : id;
        if (isNaN(streamId)) continue;
        
        // Update stream fields if any
        if (Object.keys(streamUpdates).length > 0) {
          await storage.updateStream(streamId, streamUpdates);
        }
        
        // Handle bouquet assignment (live streams use bouquetChannels field)
        if (bouquetId !== undefined) {
          // First, remove stream from ALL bouquets
          const bouquets = await storage.getBouquets();
          for (const bouquet of bouquets) {
            try {
              const channelIds: number[] = bouquet.bouquetChannels ? JSON.parse(bouquet.bouquetChannels) : [];
              if (channelIds.includes(streamId)) {
                const newChannels = channelIds.filter((s: number) => s !== streamId);
                await storage.updateBouquet(bouquet.id, { bouquetChannels: JSON.stringify(newChannels) });
              }
            } catch (e) {
              // Skip invalid JSON
            }
          }
          
          // Then add to the new bouquet (if not null/remove)
          if (bouquetId !== null) {
            const targetBouquet = await storage.getBouquet(bouquetId);
            if (targetBouquet) {
              try {
                const channelIds: number[] = targetBouquet.bouquetChannels ? JSON.parse(targetBouquet.bouquetChannels) : [];
                if (!channelIds.includes(streamId)) {
                  channelIds.push(streamId);
                  await storage.updateBouquet(bouquetId, { bouquetChannels: JSON.stringify(channelIds) });
                }
              } catch (e) {
                // Skip invalid JSON
              }
            }
          }
        }
        
        updatedCount++;
      }
      
      res.json({ updated: updatedCount });
    } catch (error: any) {
      console.error("Mass update error:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // Admin CRUD
  app.get("/api/admins", requireAuth, async (req, res) => {
    const admins = await storage.getAdmins();
    res.json(admins);
  });

  app.get("/api/admins/:id", requireAuth, async (req, res) => {
    const admin = await storage.getAdmin(parseInt(req.params.id));
    if (!admin) {
      return res.status(404).json({ error: "Admin not found" });
    }
    res.json(admin);
  });

  app.post("/api/admins", requireAuth, async (req, res) => {
    try {
      const body = req.body;
      const admin = await storage.createAdmin({
        username: body.username,
        password: body.password,
        email: body.email || null,
        memberGroupId: body.memberGroupId || 1,
        credits: body.credits || 0,
        status: body.status ?? 1,
        notes: body.notes || null,
      });
      logAuditFromRequest(req as any, {
        action: "reseller_create",
        targetType: "reseller",
        targetId: admin.id,
        targetName: admin.username,
        details: "Created admin/reseller"
      });
      res.status(201).json(admin);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.patch("/api/admins/:id", requireAuth, async (req, res) => {
    const body = req.body;
    const updateData: any = {};
    
    if (body.username) updateData.username = body.username;
    if (body.password) updateData.password = body.password;
    if (body.email !== undefined) updateData.email = body.email || null;
    if (body.memberGroupId !== undefined) updateData.memberGroupId = body.memberGroupId;
    if (body.credits !== undefined) updateData.credits = body.credits;
    if (body.status !== undefined) updateData.status = body.status;
    if (body.notes !== undefined) updateData.notes = body.notes || null;
    
    const admin = await storage.updateAdmin(parseInt(req.params.id), updateData);
    if (!admin) {
      return res.status(404).json({ error: "Admin not found" });
    }
    logAuditFromRequest(req as any, {
      action: "reseller_update",
      targetType: "reseller",
      targetId: admin.id,
      targetName: admin.username,
      details: "Updated admin/reseller"
    });
    res.json(admin);
  });

  app.delete("/api/admins/:id", requireAuth, async (req, res) => {
    const adminId = parseInt(req.params.id);
    const admin = await storage.getAdmin(adminId);
    const deleted = await storage.deleteAdmin(adminId);
    if (!deleted) {
      return res.status(404).json({ error: "Admin not found" });
    }
    logAuditFromRequest(req as any, {
      action: "reseller_delete",
      targetType: "reseller",
      targetId: adminId,
      targetName: admin?.username || `Admin ${adminId}`,
      details: "Deleted admin/reseller"
    });
    res.status(204).send();
  });

  // XUI Migration endpoint
  app.post("/api/migration/xui", requireAuth, async (req, res) => {
    try {
      const { sqlDump, preview, force } = req.body;
      
      if (!sqlDump || typeof sqlDump !== "string") {
        return res.status(400).json({ error: "SQL dump is required" });
      }
      
      const { processXUIMigration } = await import("./xui-migration");
      const result = await processXUIMigration(sqlDump, preview === true, force === true);
      
      if (!preview && 'stats' in result) {
        logAuditFromRequest(req as any, {
          action: "migration_import",
          targetType: "system",
          details: `XUI migration completed: ${JSON.stringify(result.stats)}`
        });
      }
      res.json(result);
    } catch (error: any) {
      console.error("[MIGRATION] Error:", error);
      res.status(500).json({ error: error.message || "Migration failed" });
    }
  });

  app.post("/api/migration/xui/preview", requireAuth, async (req, res) => {
    try {
      const { sqlDump } = req.body;
      
      if (!sqlDump || typeof sqlDump !== "string") {
        return res.status(400).json({ error: "SQL dump is required" });
      }
      
      const { processXUIMigration } = await import("./xui-migration");
      const result = await processXUIMigration(sqlDump, true);
      
      res.json(result);
    } catch (error: any) {
      console.error("[MIGRATION] Preview error:", error);
      res.status(500).json({ error: error.message || "Preview failed" });
    }
  });

  // Resellers CRUD (memberGroupId = 2)
  app.get("/api/resellers", requireAuth, async (req, res) => {
    const admins = await storage.getAdmins();
    const resellers = admins.filter(a => a.memberGroupId === 2);
    
    // Get user counts for each reseller (createdBy = reseller id)
    const allUsers = await storage.getUsers();
    const resellersWithCounts = resellers.map(r => {
      const userCount = allUsers.filter(u => u.createdBy === r.id).length;
      return { ...r, userCount };
    });
    
    res.json(resellersWithCounts);
  });

  app.get("/api/resellers/:id", requireAuth, async (req, res) => {
    const reseller = await storage.getAdmin(parseInt(req.params.id));
    if (!reseller || reseller.memberGroupId !== 2) {
      return res.status(404).json({ error: "Reseller not found" });
    }
    res.json(reseller);
  });

  app.post("/api/resellers", requireAdmin, async (req, res) => {
    try {
      const body = req.body;
      const reseller = await storage.createAdmin({
        username: body.username,
        password: body.password,
        email: body.email || null,
        memberGroupId: 2, // Always reseller
        credits: body.credits || 0,
        status: body.status ?? 1,
        notes: body.notes || null,
        resellerDns: body.resellerDns || "",
      });
      res.status(201).json(reseller);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.patch("/api/resellers/:id", requireAuth, async (req, res) => {
    const resellerId = parseInt(req.params.id);
    const existing = await storage.getAdmin(resellerId);
    if (!existing || existing.memberGroupId !== 2) {
      return res.status(404).json({ error: "Reseller not found" });
    }
    
    const body = req.body;
    const updateData: any = {};
    
    if (body.username) updateData.username = body.username;
    if (body.password) updateData.password = body.password;
    if (body.email !== undefined) updateData.email = body.email || null;
    if (body.credits !== undefined) updateData.credits = body.credits;
    if (body.status !== undefined) updateData.status = body.status;
    if (body.notes !== undefined) updateData.notes = body.notes || null;
    if (body.resellerDns !== undefined) updateData.resellerDns = body.resellerDns;
    
    const reseller = await storage.updateAdmin(resellerId, updateData);
    res.json(reseller);
  });

  app.delete("/api/resellers/:id", requireAdmin, async (req, res) => {
    const resellerId = parseInt(req.params.id);
    const existing = await storage.getAdmin(resellerId);
    if (!existing || existing.memberGroupId !== 2) {
      return res.status(404).json({ error: "Reseller not found" });
    }
    
    const deleted = await storage.deleteAdmin(resellerId);
    if (!deleted) {
      return res.status(404).json({ error: "Reseller not found" });
    }
    res.status(204).send();
  });

  // Add credits to reseller
  app.post("/api/resellers/:id/credits", requireAdmin, async (req: AuthRequest, res) => {
    const resellerId = parseInt(req.params.id);
    const existing = await storage.getAdmin(resellerId);
    if (!existing || existing.memberGroupId !== 2) {
      return res.status(404).json({ error: "Reseller not found" });
    }
    
    const { credits, reason } = req.body;
    if (typeof credits !== "number" || credits <= 0) {
      return res.status(400).json({ error: "Invalid credits amount" });
    }
    
    const newCredits = (existing.credits || 0) + credits;
    const reseller = await storage.updateAdmin(resellerId, { credits: newCredits });
    
    // Log the credit transaction
    await storage.addCreditTransaction({
      resellerId: resellerId,
      adminId: req.adminId || null,
      amount: credits,
      type: "add",
      reason: reason || "Credits added by admin",
      balanceAfter: newCredits,
      createdAt: Math.floor(Date.now() / 1000),
    });
    
    res.json(reseller);
  });

  // Reseller self-service profile endpoint
  app.get("/api/resellers/me/profile", requireAuth, async (req: AuthRequest, res) => {
    if (!req.adminId || req.adminRole !== "reseller") {
      return res.status(403).json({ error: "Access denied" });
    }
    
    const reseller = await storage.getAdmin(req.adminId);
    if (!reseller) {
      return res.status(404).json({ error: "Profile not found" });
    }
    
    res.json({
      id: reseller.id,
      username: reseller.username,
      email: reseller.email || "",
      credits: reseller.credits || 0,
      resellerDns: reseller.resellerDns || "",
      notes: reseller.notes || "",
    });
  });

  app.patch("/api/resellers/me/profile", requireAuth, async (req: AuthRequest, res) => {
    if (!req.adminId || req.adminRole !== "reseller") {
      return res.status(403).json({ error: "Access denied" });
    }
    
    const body = req.body;
    const updateData: any = {};
    
    // Resellers can only update limited fields
    if (body.email !== undefined) updateData.email = body.email || null;
    if (body.resellerDns !== undefined) updateData.resellerDns = body.resellerDns || "";
    if (body.notes !== undefined) updateData.notes = body.notes || "";
    
    const reseller = await storage.updateAdmin(req.adminId, updateData);
    if (!reseller) {
      return res.status(404).json({ error: "Profile not found" });
    }
    res.json({
      id: reseller.id,
      username: reseller.username,
      email: reseller.email || "",
      credits: reseller.credits || 0,
      resellerDns: reseller.resellerDns || "",
      notes: reseller.notes || "",
    });
  });

  // Reseller credits log - returns actual transaction history
  app.get("/api/resellers/me/credits-log", requireAuth, async (req: AuthRequest, res) => {
    if (!req.adminId || req.adminRole !== "reseller") {
      return res.status(403).json({ error: "Access denied" });
    }
    
    const transactions = await storage.getCreditTransactions(req.adminId);
    // Map to frontend format
    const formatted = transactions.map(t => ({
      id: t.id,
      admin: t.adminId ? `Admin #${t.adminId}` : "System",
      amount: t.amount,
      type: t.type,
      reason: t.reason,
      balanceAfter: t.balanceAfter,
      createdAt: new Date(t.createdAt * 1000).toISOString(),
    }));
    res.json(formatted);
  });

  // Reseller info endpoint - shows their rights and credit pricing
  app.get("/api/resellers/me/info", requireAuth, async (req: AuthRequest, res) => {
    if (!req.adminId || req.adminRole !== "reseller") {
      return res.status(403).json({ error: "Access denied" });
    }
    
    const reseller = await storage.getAdmin(req.adminId);
    if (!reseller) {
      return res.status(404).json({ error: "Reseller not found" });
    }
    
    // Get credit prices from settings
    const creditPricePerLineSetting = await storage.getSetting("credit_price_per_line");
    const creditPricePerConnectionSetting = await storage.getSetting("credit_price_per_connection");
    const durationOptionsSetting = await storage.getSetting("credit_duration_options");
    const creditPricePerLine = creditPricePerLineSetting ? parseFloat(creditPricePerLineSetting.value) || 1 : 1;
    const creditPricePerConnection = creditPricePerConnectionSetting ? parseFloat(creditPricePerConnectionSetting.value) || 0 : 0;
    
    // Parse duration options
    let durationOptions = [
      { label: "1 Month", days: 30, multiplier: 1 },
      { label: "3 Months", days: 90, multiplier: 2.5 },
      { label: "6 Months", days: 180, multiplier: 5 },
      { label: "1 Year", days: 365, multiplier: 10 },
    ];
    if (durationOptionsSetting) {
      try {
        durationOptions = JSON.parse(durationOptionsSetting.value);
      } catch (e) { /* use defaults */ }
    }
    
    res.json({
      username: reseller.username,
      email: reseller.email || "",
      credits: reseller.credits || 0,
      creditPricePerLine,
      creditPricePerConnection,
      resellerDns: reseller.resellerDns || "",
      rights: {
        canCreateUsers: true,
        canViewOwnUsers: true,
        canEditOwnUsers: true,
        canDeleteOwnUsers: true,
        canViewMagDevices: true,
        canAccessStreams: false,
        canAccessMovies: false,
        canAccessSeries: false,
        canAccessServers: false,
        canAccessEPG: false,
        canAccessSettings: false,
        canAccessBackup: false,
        creditRefundOnDelete: false,
      },
      notes: `Credits are non-refundable. Formula: (Base ${creditPricePerLine} + Extra connections x ${creditPricePerConnection}) x Duration multiplier. MAG device: ${creditPricePerLine} credit(s).`,
      durationOptions: durationOptions,
    });
  });

  // Streams CRUD
  app.get("/api/streams", requireAuth, async (req, res) => {
    const allStreams = await storage.getStreams(STREAM_TYPE_LIVE);
    const streamIds = allStreams.map(s => s.id);
    const statuses = await storage.getStreamStatuses(streamIds);
    const statusMap = new Map(statuses.map(st => [st.streamId, st]));
    
    // Get all servers for name lookup
    const allServers = await storage.getServers();
    const serverMap = new Map(allServers.map(srv => [srv.id, srv]));
    
    // Get all connections to count per stream
    const allConnections = await storage.getConnections();
    const connectionCounts = new Map<number, number>();
    allConnections.forEach(c => {
      connectionCounts.set(c.streamId, (connectionCounts.get(c.streamId) || 0) + 1);
    });
    
    const mapped = allStreams.map(s => {
      const status = statusMap.get(s.id);
      const connCount = connectionCounts.get(s.id) || 0;
      // Parse transcodeAttributes if it's a JSON string
      let transcodeData = { codec: "libx264", bitrate: 0, resolution: "" };
      try {
        if (s.transcodeAttributes) {
          transcodeData = JSON.parse(s.transcodeAttributes);
        }
      } catch {}
      return {
        id: s.id,
        name: s.streamDisplayName,
        streamType: "live",
        categoryId: s.categoryId,
        epgChannelId: s.channelId,
        language: s.epgLang || null,
        logoUrl: s.streamIcon,
        isActive: s.directSource === 0,
        order: s.order,
        tvArchive: s.tvArchiveDuration > 0,
        tvArchiveDuration: s.tvArchiveDuration,
        streamId: s.id,
        containerExtension: "ts",
        directSource: s.directSource,
        hasSource: !!s.streamSource,
        hasBackupSources: !!(s.backupSources && s.backupSources.length > 0),
        activeSourceIndex: status?.activeSourceIndex ?? 0,
        lastFailoverAt: status?.lastFailoverAt || null,
        status: status?.status || (s.streamSource ? (s.directSource === 0 ? "online" : "offline") : "offline"),
        usingBackup: (status?.activeSourceIndex ?? 0) > 0,
        serverName: s.forceServerId && s.forceServerId > 0 
          ? (serverMap.get(s.forceServerId)?.serverName || "MAIN") 
          : "MAIN",
        serverId: s.forceServerId || null,
        uptimeSeconds: status?.uptimeSeconds || 0,
        downtimeSeconds: status?.downtimeSeconds || 0,
        bitrate: status?.bitrate || null,
        streamInfo: status?.streamInfo || { resolution: "", videoCodec: "", audioCodec: "", fps: "", playbackSpeed: "" },
        outputFormats: status?.outputFormats || ["ts", "m3u8"],
        connectionCount: connCount,
        // Admin panel sees actual URLs for editing
        streamUrl: s.streamSource || "",
        backupSources: s.backupSources || [],
        userAgent: s.userAgent || "",
        // Additional fields for editing
        readNative: s.readNative,
        genTimestamps: s.genTimestamps,
        customFfmpeg: s.customFfmpeg || "",
        targetContainer: s.targetContainer || "mpegts",
        autoRestart: s.autoRestart || "never",
        delayMinutes: s.delayMinutes || 0,
        allowRecord: s.allowRecord,
        enableTranscode: s.enableTranscode,
        transcodeProfileId: s.transcodeProfileId || 0,
        transcodeCodec: transcodeData.codec || "libx264",
        transcodeBitrate: transcodeData.bitrate || 0,
        transcodeResolution: transcodeData.resolution || "original",
        forceServerId: s.forceServerId || 0,
      };
    });
    res.json(mapped);
  });

  app.get("/api/streams/:id", requireAuth, async (req, res) => {
    const stream = await storage.getStream(parseInt(req.params.id));
    if (!stream) {
      return res.status(404).json({ error: "Stream not found" });
    }
    // Admin panel needs to see actual URLs for editing
    res.json({
      ...stream,
      streamUrl: stream.streamSource || "",
      backupSources: stream.backupSources || [],
      userAgent: stream.userAgent || "",
    });
  });

  app.post("/api/streams", requireAuth, async (req, res) => {
    try {
      const body = req.body;
      const stream = await storage.createStream({
        type: STREAM_TYPE_LIVE,
        streamDisplayName: body.name,
        streamSource: body.streamUrl,
        categoryId: body.categoryId && body.categoryId !== "none" ? parseInt(body.categoryId) : null,
        channelId: body.epgChannelId || null,
        epgLang: body.language && body.language !== "none" ? body.language : "",
        streamIcon: body.logoUrl || "",
        order: body.order || 0,
        tvArchiveDuration: body.tvArchive ? (body.tvArchiveDuration || 7) : 0,
        customFfmpeg: body.customFfmpeg || "",
        targetContainer: body.targetContainer || "mpegts",
        directSource: body.directSource ? 1 : 0,
        readNative: body.readNative ? 1 : 0,
        enableTranscode: body.enableTranscode ? 1 : 0,
        transcodeProfileId: body.transcodeProfileId ? parseInt(body.transcodeProfileId) : 0,
        transcodeAttributes: body.transcodeCodec ? JSON.stringify({
          codec: body.transcodeCodec,
          bitrate: body.transcodeBitrate || 0,
          resolution: body.transcodeResolution === "original" ? "" : (body.transcodeResolution || "")
        }) : "",
        autoRestart: body.autoRestart || "",
        delayMinutes: body.delayMinutes || 0,
        genTimestamps: body.genTimestamps ? 1 : 0,
        allowRecord: body.allowRecord ? 1 : 0,
        backupSources: body.backupSources || [],
        userAgent: body.userAgent || "",
        forceServerId: body.loadBalancerId && body.loadBalancerId !== "auto" ? parseInt(body.loadBalancerId) : 0,
        onDemand: body.onDemand ? 1 : 0,
        proxyEnable: body.proxyUrl ? 1 : 0,
        proxyIp: body.proxyUrl || "",
      } as any);
      logAuditFromRequest(req as any, {
        action: "stream_create",
        targetType: "stream",
        targetId: stream.id,
        targetName: stream.streamDisplayName,
        details: "Created stream"
      });
      res.status(201).json({
        ...stream,
        streamUrl: stream.streamSource || "",
        backupSources: stream.backupSources || [],
        userAgent: stream.userAgent || "",
      });
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Import M3U playlist
  app.post("/api/streams/import", requireAuth, async (req, res) => {
    try {
      const { m3uContent, bouquetId } = req.body;
      
      if (!m3uContent || typeof m3uContent !== "string") {
        return res.status(400).json({ error: "M3U content is required" });
      }

      const lines = m3uContent.split("\n");
      const streams: Array<{ name: string; url: string; logo?: string; group?: string }> = [];
      let currentStream: { name: string; url: string; logo?: string; group?: string } | null = null;

      for (const line of lines) {
        const trimmed = line.trim();
        
        if (trimmed.startsWith("#EXTINF:")) {
          // Parse EXTINF line
          const nameMatch = trimmed.match(/,(.+)$/);
          const logoMatch = trimmed.match(/tvg-logo="([^"]+)"/);
          const groupMatch = trimmed.match(/group-title="([^"]+)"/);
          
          currentStream = {
            name: nameMatch ? nameMatch[1].trim() : "Unknown Channel",
            url: "",
            logo: logoMatch ? logoMatch[1] : undefined,
            group: groupMatch ? groupMatch[1] : undefined,
          };
        } else if (trimmed && !trimmed.startsWith("#") && currentStream) {
          // This is the URL line
          currentStream.url = trimmed;
          if (currentStream.url.startsWith("http")) {
            streams.push(currentStream);
          }
          currentStream = null;
        }
      }

      let imported = 0;
      let failed = 0;
      const createdStreamIds: number[] = [];

      for (const streamData of streams) {
        try {
          const stream = await storage.createStream({
            type: STREAM_TYPE_LIVE,
            streamDisplayName: streamData.name,
            streamSource: streamData.url,
            streamIcon: streamData.logo || "",
            categoryId: null,
            order: imported,
          });
          createdStreamIds.push(stream.id);
          imported++;
        } catch (e) {
          failed++;
        }
      }

      // Add streams to bouquet if specified
      if (bouquetId && createdStreamIds.length > 0) {
        try {
          const bouquet = await storage.getBouquet(bouquetId);
          if (bouquet) {
            let existingStreams: number[] = [];
            try {
              existingStreams = JSON.parse(bouquet.bouquetStreams || "[]");
            } catch { existingStreams = []; }
            const newStreams = [...existingStreams, ...createdStreamIds];
            await storage.updateBouquet(bouquetId, {
              bouquetStreams: JSON.stringify(newStreams),
            });
          }
        } catch (e) {
          console.error("[Import] Failed to add streams to bouquet:", e);
        }
      }

      res.json({ imported, failed, total: streams.length });
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.patch("/api/streams/:id", requireAuth, async (req, res) => {
    const body = req.body;
    const updateData: any = {};
    
    if (body.name !== undefined) updateData.streamDisplayName = body.name;
    if (body.streamUrl !== undefined) updateData.streamSource = body.streamUrl;
    if (body.categoryId !== undefined) updateData.categoryId = body.categoryId && body.categoryId !== "none" ? parseInt(body.categoryId) : null;
    if (body.epgChannelId !== undefined) updateData.channelId = body.epgChannelId;
    if (body.language !== undefined) updateData.epgLang = body.language === "none" ? "" : body.language;
    if (body.logoUrl !== undefined) updateData.streamIcon = body.logoUrl;
    if (body.order !== undefined) updateData.order = body.order;
    if (body.tvArchiveDuration !== undefined) updateData.tvArchiveDuration = body.tvArchiveDuration;
    if (body.tvArchive !== undefined) updateData.tvArchiveDuration = body.tvArchive ? (body.tvArchiveDuration || 7) : 0;
    if (body.customFfmpeg !== undefined) updateData.customFfmpeg = body.customFfmpeg;
    if (body.targetContainer !== undefined) updateData.targetContainer = body.targetContainer;
    if (body.directSource !== undefined) updateData.directSource = body.directSource ? 1 : 0;
    if (body.readNative !== undefined) updateData.readNative = body.readNative ? 1 : 0;
    if (body.enableTranscode !== undefined) updateData.enableTranscode = body.enableTranscode ? 1 : 0;
    if (body.transcodeProfileId !== undefined) updateData.transcodeProfileId = body.transcodeProfileId ? parseInt(body.transcodeProfileId) : 0;
    if (body.transcodeCodec !== undefined || body.transcodeBitrate !== undefined || body.transcodeResolution !== undefined) {
      updateData.transcodeAttributes = JSON.stringify({
        codec: body.transcodeCodec || "libx264",
        bitrate: body.transcodeBitrate || 0,
        resolution: body.transcodeResolution === "original" ? "" : (body.transcodeResolution || "")
      });
    }
    if (body.autoRestart !== undefined) updateData.autoRestart = body.autoRestart;
    if (body.delayMinutes !== undefined) updateData.delayMinutes = body.delayMinutes;
    if (body.genTimestamps !== undefined) updateData.genTimestamps = body.genTimestamps ? 1 : 0;
    if (body.allowRecord !== undefined) updateData.allowRecord = body.allowRecord ? 1 : 0;
    if (body.backupSources !== undefined) updateData.backupSources = body.backupSources;
    if (body.userAgent !== undefined) updateData.userAgent = body.userAgent;
    if (body.loadBalancerId !== undefined) updateData.forceServerId = body.loadBalancerId === "auto" ? 0 : parseInt(body.loadBalancerId);
    if (body.onDemand !== undefined) updateData.onDemand = body.onDemand ? 1 : 0;
    if (body.proxyUrl !== undefined) {
      updateData.proxyEnable = body.proxyUrl ? 1 : 0;
      updateData.proxyIp = body.proxyUrl || "";
    }
    
    const stream = await storage.updateStream(parseInt(req.params.id), updateData);
    if (!stream) {
      return res.status(404).json({ error: "Stream not found" });
    }
    logAuditFromRequest(req as any, {
      action: "stream_update",
      targetType: "stream",
      targetId: stream.id,
      targetName: stream.streamDisplayName,
      details: "Updated stream"
    });
    // Admin panel needs to see actual URLs for editing
    res.json({
      ...stream,
      streamUrl: stream.streamSource || "",
      backupSources: stream.backupSources || [],
      userAgent: stream.userAgent || "",
    });
  });

  app.delete("/api/streams/:id", requireAuth, async (req, res) => {
    const streamId = parseInt(req.params.id);
    const stream = await storage.getStream(streamId);
    const deleted = await storage.deleteStream(streamId);
    if (!deleted) {
      return res.status(404).json({ error: "Stream not found" });
    }
    logAuditFromRequest(req as any, {
      action: "stream_delete",
      targetType: "stream",
      targetId: streamId,
      targetName: stream?.streamDisplayName || `Stream ${streamId}`,
      details: "Deleted stream"
    });
    res.status(204).send();
  });

  // Movies CRUD (stored as streams with type=2)
  // Note: streamUrl is intentionally hidden for security
  app.get("/api/movies", requireAuth, async (req, res) => {
    const allMovies = await storage.getStreams(STREAM_TYPE_MOVIE);
    const mapped = allMovies.map(m => ({
      id: m.id,
      name: m.streamDisplayName,
      hasSource: !!m.streamSource,
      categoryId: m.categoryId,
      posterUrl: m.streamIcon,
      description: m.notes,
      isActive: true,
      vodId: m.id,
      containerExtension: "mp4",
    }));
    res.json(mapped);
  });

  app.get("/api/movies/:id", requireAuth, async (req, res) => {
    const movie = await storage.getStream(parseInt(req.params.id));
    if (!movie || movie.type !== STREAM_TYPE_MOVIE) {
      return res.status(404).json({ error: "Movie not found" });
    }
    // Exclude streamSource for security - never expose source URLs
    const { streamSource, ...safeMovie } = movie;
    res.json({ ...safeMovie, hasSource: !!streamSource });
  });

  app.post("/api/movies", requireAuth, async (req, res) => {
    try {
      const body = req.body;
      const movie = await storage.createStream({
        type: STREAM_TYPE_MOVIE,
        streamDisplayName: body.name,
        streamSource: body.streamUrl,
        categoryId: body.categoryId ? parseInt(body.categoryId) : null,
        streamIcon: body.posterUrl,
        notes: body.description,
      });
      // Exclude streamSource for security
      const { streamSource, ...safeMovie } = movie;
      res.status(201).json({ ...safeMovie, hasSource: !!streamSource });
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.patch("/api/movies/:id", requireAuth, async (req, res) => {
    const body = req.body;
    const updateData: any = {};
    
    if (body.name) updateData.streamDisplayName = body.name;
    if (body.streamUrl) updateData.streamSource = body.streamUrl;
    if (body.categoryId !== undefined) updateData.categoryId = body.categoryId ? parseInt(body.categoryId) : null;
    if (body.posterUrl !== undefined) updateData.streamIcon = body.posterUrl;
    if (body.description !== undefined) updateData.notes = body.description;
    
    const movie = await storage.updateStream(parseInt(req.params.id), updateData);
    if (!movie) {
      return res.status(404).json({ error: "Movie not found" });
    }
    // Exclude streamSource for security
    const { streamSource, ...safeMovie } = movie;
    res.json({ ...safeMovie, hasSource: !!streamSource });
  });

  app.delete("/api/movies/:id", requireAuth, async (req, res) => {
    const deleted = await storage.deleteStream(parseInt(req.params.id));
    if (!deleted) {
      return res.status(404).json({ error: "Movie not found" });
    }
    res.status(204).send();
  });

  // Series CRUD
  app.get("/api/series", requireAuth, async (req, res) => {
    const allSeries = await storage.getSeries();
    const mapped = allSeries.map(s => ({
      id: s.id,
      name: s.title,
      categoryId: s.categoryId,
      posterUrl: s.cover,
      description: s.plot,
      rating: s.rating?.toString(),
      releaseYear: s.releaseDate,
      genres: s.genre,
      actors: s.cast,
      isActive: true,
      tmdbId: s.tmdbId,
      totalSeasons: s.seasons ? JSON.parse(s.seasons).length : 0,
      seriesId: s.id,
    }));
    res.json(mapped);
  });

  app.get("/api/series/:id", requireAuth, async (req, res) => {
    const s = await storage.getSeriesById(parseInt(req.params.id));
    if (!s) {
      return res.status(404).json({ error: "Series not found" });
    }
    res.json(s);
  });

  app.post("/api/series", requireAuth, async (req, res) => {
    try {
      const body = req.body;
      const s = await storage.createSeries({
        title: body.name,
        categoryId: body.categoryId ? parseInt(body.categoryId) : null,
        cover: body.posterUrl,
        plot: body.description,
        rating: body.rating ? parseInt(body.rating) : 0,
        releaseDate: body.releaseYear,
        genre: body.genres,
        cast: body.actors,
      });
      res.status(201).json(s);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.patch("/api/series/:id", requireAuth, async (req, res) => {
    const body = req.body;
    const updateData: any = {};
    
    if (body.name) updateData.title = body.name;
    if (body.categoryId !== undefined) updateData.categoryId = body.categoryId ? parseInt(body.categoryId) : null;
    if (body.posterUrl !== undefined) updateData.cover = body.posterUrl;
    if (body.description !== undefined) updateData.plot = body.description;
    if (body.rating !== undefined) updateData.rating = parseInt(body.rating) || 0;
    if (body.releaseYear !== undefined) updateData.releaseDate = body.releaseYear;
    if (body.genres !== undefined) updateData.genre = body.genres;
    if (body.actors !== undefined) updateData.cast = body.actors;
    
    const s = await storage.updateSeries(parseInt(req.params.id), updateData);
    if (!s) {
      return res.status(404).json({ error: "Series not found" });
    }
    res.json(s);
  });

  app.delete("/api/series/:id", requireAuth, async (req, res) => {
    const deleted = await storage.deleteSeries(parseInt(req.params.id));
    if (!deleted) {
      return res.status(404).json({ error: "Series not found" });
    }
    res.status(204).send();
  });

  // Episodes CRUD
  app.get("/api/episodes", requireAuth, async (req, res) => {
    const seriesId = req.query.seriesId ? parseInt(req.query.seriesId as string) : undefined;
    const allEpisodes = await storage.getSeriesEpisodes(seriesId);
    res.json(allEpisodes);
  });

  app.post("/api/episodes", requireAuth, async (req, res) => {
    try {
      const body = req.body;
      const episode = await storage.createSeriesEpisode({
        seriesId: parseInt(body.seriesId),
        seasonNum: body.seasonNumber || 1,
        streamId: parseInt(body.streamId),
        sort: body.episodeNumber || 1,
      });
      res.status(201).json(episode);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.delete("/api/episodes/:id", requireAuth, async (req, res) => {
    const deleted = await storage.deleteSeriesEpisode(parseInt(req.params.id));
    if (!deleted) {
      return res.status(404).json({ error: "Episode not found" });
    }
    res.status(204).send();
  });

  // Categories CRUD
  app.get("/api/categories", requireAuth, async (req, res) => {
    const type = req.query.type as string | undefined;
    const allCategories = await storage.getCategories(type);
    const mapped = allCategories.map(c => ({
      id: c.id,
      name: c.categoryName,
      type: c.categoryType,
      parentId: c.parentId,
      order: c.catOrder,
      isActive: true,
      categoryId: c.id,
    }));
    res.json(mapped);
  });

  app.post("/api/categories", requireAuth, async (req, res) => {
    try {
      const body = req.body;
      const category = await storage.createCategory({
        categoryName: body.name,
        categoryType: body.type,
        parentId: body.parentId || 0,
        catOrder: body.order || 0,
      });
      logAuditFromRequest(req as any, {
        action: "category_create",
        targetType: "category",
        targetId: category.id,
        targetName: category.categoryName,
        details: "Created category"
      });
      res.status(201).json(category);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.patch("/api/categories/:id", requireAuth, async (req, res) => {
    const body = req.body;
    const updateData: any = {};
    
    if (body.name) updateData.categoryName = body.name;
    if (body.type) updateData.categoryType = body.type;
    if (body.parentId !== undefined) updateData.parentId = body.parentId;
    if (body.order !== undefined) updateData.catOrder = body.order;
    
    const category = await storage.updateCategory(parseInt(req.params.id), updateData);
    if (!category) {
      return res.status(404).json({ error: "Category not found" });
    }
    logAuditFromRequest(req as any, {
      action: "category_update",
      targetType: "category",
      targetId: category.id,
      targetName: category.categoryName,
      details: "Updated category"
    });
    res.json(category);
  });

  app.delete("/api/categories/:id", requireAuth, async (req, res) => {
    const categoryId = parseInt(req.params.id);
    const category = await storage.getCategory(categoryId);
    const deleted = await storage.deleteCategory(categoryId);
    if (!deleted) {
      return res.status(404).json({ error: "Category not found" });
    }
    logAuditFromRequest(req as any, {
      action: "category_delete",
      targetType: "category",
      targetId: categoryId,
      targetName: category?.categoryName || `Category ${categoryId}`,
      details: "Deleted category"
    });
    res.status(204).send();
  });

  // Bouquets CRUD
  app.get("/api/bouquets", requireAuth, async (req, res) => {
    const allBouquets = await storage.getBouquets();
    const mapped = allBouquets.map(b => ({
      id: b.id,
      bouquetName: b.bouquetName,
      bouquetOrder: b.bouquetOrder,
      bouquetChannels: b.bouquetChannels,
      bouquetMovies: b.bouquetMovies,
      bouquetSeries: b.bouquetSeries,
      bouquetStreams: b.bouquetStreams,
      bouquetRadios: b.bouquetRadios,
      streamIds: b.bouquetChannels ? JSON.parse(b.bouquetChannels) : [],
      movieIds: b.bouquetMovies ? JSON.parse(b.bouquetMovies) : [],
      seriesIds: b.bouquetSeries ? JSON.parse(b.bouquetSeries) : [],
      isActive: true,
      isDefault: b.bouquetOrder === 0,
    }));
    res.json(mapped);
  });

  app.post("/api/bouquets", requireAuth, async (req, res) => {
    try {
      const body = req.body;
      const bouquet = await storage.createBouquet({
        bouquetName: body.bouquetName || body.name,
        bouquetChannels: JSON.stringify(body.streamIds || []),
        bouquetMovies: JSON.stringify(body.movieIds || []),
        bouquetSeries: JSON.stringify(body.seriesIds || []),
        bouquetOrder: body.bouquetOrder || body.order || 0,
      });
      logAuditFromRequest(req as any, {
        action: "bouquet_create",
        targetType: "bouquet",
        targetId: bouquet.id,
        targetName: bouquet.bouquetName,
        details: "Created bouquet"
      });
      res.status(201).json(bouquet);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.patch("/api/bouquets/:id", requireAuth, async (req, res) => {
    const body = req.body;
    const updateData: any = {};
    
    if (body.bouquetName || body.name) updateData.bouquetName = body.bouquetName || body.name;
    // Accept both direct JSON strings and array formats
    if (body.bouquetChannels !== undefined) updateData.bouquetChannels = body.bouquetChannels;
    if (body.bouquetMovies !== undefined) updateData.bouquetMovies = body.bouquetMovies;
    if (body.bouquetSeries !== undefined) updateData.bouquetSeries = body.bouquetSeries;
    // Legacy format support
    if (body.streamIds) updateData.bouquetChannels = JSON.stringify(body.streamIds);
    if (body.movieIds) updateData.bouquetMovies = JSON.stringify(body.movieIds);
    if (body.seriesIds) updateData.bouquetSeries = JSON.stringify(body.seriesIds);
    if (body.bouquetOrder !== undefined || body.order !== undefined) updateData.bouquetOrder = body.bouquetOrder ?? body.order;
    
    // If no fields to update, just return the existing bouquet
    if (Object.keys(updateData).length === 0) {
      const existing = await storage.getBouquet(parseInt(req.params.id));
      if (!existing) {
        return res.status(404).json({ error: "Bouquet not found" });
      }
      return res.json(existing);
    }
    
    const bouquet = await storage.updateBouquet(parseInt(req.params.id), updateData);
    if (!bouquet) {
      return res.status(404).json({ error: "Bouquet not found" });
    }
    logAuditFromRequest(req as any, {
      action: "bouquet_update",
      targetType: "bouquet",
      targetId: bouquet.id,
      targetName: bouquet.bouquetName,
      details: "Updated bouquet"
    });
    res.json(bouquet);
  });

  app.delete("/api/bouquets/:id", requireAuth, async (req, res) => {
    const bouquetId = parseInt(req.params.id);
    const bouquet = await storage.getBouquet(bouquetId);
    const deleted = await storage.deleteBouquet(bouquetId);
    if (!deleted) {
      return res.status(404).json({ error: "Bouquet not found" });
    }
    logAuditFromRequest(req as any, {
      action: "bouquet_delete",
      targetType: "bouquet",
      targetId: bouquetId,
      targetName: bouquet?.bouquetName || `Bouquet ${bouquetId}`,
      details: "Deleted bouquet"
    });
    res.status(204).send();
  });

  // Servers CRUD
  app.get("/api/servers", requireAuth, async (req, res) => {
    const allServers = await storage.getServers();
    
    // Get real system metrics for main server
    const realMetrics = await getSystemMetrics();
    
    // Count connections per server
    const allConnections = await storage.getConnections();
    const connectionsByServer = new Map<number, number>();
    for (const conn of allConnections) {
      const sid = conn.serverId || 1;
      connectionsByServer.set(sid, (connectionsByServer.get(sid) || 0) + 1);
    }
    
    const mapped = allServers.map(s => {
      // Get real metrics for main server, cached LB metrics for load balancers
      let cpuUsage = 0, ramUsage = 0, diskUsage = 0;
      
      if (s.isMain === 1) {
        cpuUsage = realMetrics.cpuUsage;
        ramUsage = realMetrics.memoryUsage;
        diskUsage = realMetrics.diskUsage;
      } else {
        // Try to get cached LB metrics
        const lbCachedMetrics = lbMetricsCache.get(s.id);
        if (lbCachedMetrics && Date.now() - lbCachedMetrics.timestamp < 60000) {
          cpuUsage = lbCachedMetrics.cpuUsage;
          ramUsage = lbCachedMetrics.memoryUsage;
          diskUsage = lbCachedMetrics.diskUsage;
        }
      }
      
      const totalClients = connectionsByServer.get(s.id) || 0;
      
      return {
        id: s.id,
        name: s.serverName,
        serverName: s.serverName,
        domainName: s.domainName,
        serverIp: s.serverIp,
        httpPort: s.httpBroadcastPort,
        httpsPort: s.httpsBroadcastPort,
        rtmpPort: s.rtmpPort,
        status: s.status === 1 ? "online" : "offline",
        totalClients: totalClients,
        maxClients: s.maxClients || 1000,
        networkSpeed: s.networkSpeed || 1000,
        networkInterface: s.networkInterface || "eth0",
        isMain: s.isMain === 1,
        isActive: s.status === 1,
        cpuUsage: Math.round(cpuUsage * 10) / 10,
        ramUsage: Math.round(ramUsage * 10) / 10,
        diskUsage: Math.round(diskUsage * 10) / 10,
        // LB metrics debug info
        metricsStatus: s.isMain === 1 ? "live" : (lbMetricsCache.has(s.id) && Date.now() - (lbMetricsCache.get(s.id)?.timestamp || 0) < 60000 ? "live" : "no_data"),
        metricsLastUpdate: s.isMain === 1 ? null : (lbMetricsCache.get(s.id)?.timestamp ? new Date(lbMetricsCache.get(s.id)!.timestamp).toISOString() : null),
        hasServerToken: !!s.serverToken,
      };
    });
    res.json(mapped);
  });

  // Server Monitoring - Real-time stats for all servers
  app.get("/api/servers/monitoring", requireAuth, async (req, res) => {
    const allServers = await storage.getServers();
    const allConnections = await storage.getConnections();
    const allStreams = await storage.getStreams();
    
    // Get real system metrics for the main server (this panel's server)
    const realMetrics = await getSystemMetrics();
    
    // Count connections per server (using actual serverId from connections)
    const connectionsByServer = new Map<number, number>();
    for (const conn of allConnections) {
      const sid = conn.serverId || 1;
      connectionsByServer.set(sid, (connectionsByServer.get(sid) || 0) + 1);
    }
    
    // Count streams assigned to each server by forceServerId
    const streamsAssignedToServer = new Map<number, number>();
    for (const stream of allStreams) {
      const sid = stream.forceServerId || 0;
      if (sid > 0) {
        streamsAssignedToServer.set(sid, (streamsAssignedToServer.get(sid) || 0) + 1);
      }
    }
    
    // Group connections and streams by server
    const serverStats = allServers.map(server => {
      // REAL connection count for this server
      const connectionCount = connectionsByServer.get(server.id) || 0;
      
      // For main server: all streams in DB
      // For LB servers: count streams ASSIGNED to that server (forceServerId)
      const streamCount = server.isMain === 1 ? allStreams.length : (streamsAssignedToServer.get(server.id) || 0);
      
      // Bandwidth based on REAL connections for this server
      const uploadMbps = connectionCount * 2.5; // ~2.5 Mbps per stream average
      const downloadMbps = connectionCount * 5; // ~5 Mbps download per active connection
      
      // Use REAL metrics for main server, simulated for others
      let cpuUsage: number;
      let memoryUsage: number;
      let diskUsage: number;
      
      if (server.isMain === 1) {
        // Real metrics for main server
        cpuUsage = realMetrics.cpuUsage;
        memoryUsage = realMetrics.memoryUsage;
        diskUsage = realMetrics.diskUsage;
      } else {
        // Try to get cached LB metrics
        const lbCachedMetrics = lbMetricsCache.get(server.id);
        if (lbCachedMetrics && Date.now() - lbCachedMetrics.timestamp < 60000) {
          cpuUsage = lbCachedMetrics.cpuUsage;
          memoryUsage = lbCachedMetrics.memoryUsage;
          diskUsage = lbCachedMetrics.diskUsage;
        } else {
          // No recent metrics - show as unknown (0)
          cpuUsage = 0;
          memoryUsage = 0;
          diskUsage = 0;
        }
      }
      
      // LB metrics status
      const cachedMetrics = server.isMain !== 1 ? lbMetricsCache.get(server.id) : null;
      const hasRecentMetrics = cachedMetrics && Date.now() - cachedMetrics.timestamp < 60000;
      const metricsAge = cachedMetrics ? Math.floor((Date.now() - cachedMetrics.timestamp) / 1000) : null;
      
      const networkIn = downloadMbps;
      const networkOut = uploadMbps;
      
      return {
        id: server.id,
        name: server.serverName,
        domainName: server.domainName,
        serverIp: server.serverIp || server.domainName,
        status: server.status === 1 ? "online" : server.status === -1 ? "installing" : "offline",
        isMain: server.isMain === 1,
        isLoadBalancer: server.isMain !== 1,
        
        // Client/Stream counts
        activeClients: connectionCount,
        maxClients: server.maxClients || 1000,
        activeStreams: streamCount,
        totalStreams: allStreams.length,
        
        // Bandwidth (Mbps)
        uploadMbps: Math.round(uploadMbps * 100) / 100,
        downloadMbps: Math.round(downloadMbps * 100) / 100,
        totalBandwidthMbps: Math.round((uploadMbps + downloadMbps) * 100) / 100,
        
        // Resource usage (percentage) - REAL for main server and LB with fresh metrics
        cpuUsage: Math.round(cpuUsage * 10) / 10,
        memoryUsage: Math.round(memoryUsage * 10) / 10,
        diskUsage: Math.round(diskUsage * 10) / 10,
        
        // Network I/O (Mbps)
        networkIn: Math.round(networkIn * 100) / 100,
        networkOut: Math.round(networkOut * 100) / 100,
        
        // LB metrics status
        metricsStatus: server.isMain === 1 ? "live" : (hasRecentMetrics ? "live" : "stale"),
        lastMetricsUpdate: cachedMetrics ? new Date(cachedMetrics.timestamp).toISOString() : null,
        metricsAgeSeconds: metricsAge,
        
        // Uptime
        uptime: server.status === 1 ? "99.9%" : "0%",
        lastSeen: hasRecentMetrics || server.isMain === 1 ? new Date().toISOString() : (cachedMetrics ? new Date(cachedMetrics.timestamp).toISOString() : null),
      };
    });
    
    // Aggregate totals
    const totals = {
      totalServers: allServers.length,
      onlineServers: allServers.filter(s => s.status === 1).length,
      offlineServers: allServers.filter(s => s.status === 0).length,
      totalClients: allConnections.length,
      totalStreams: allStreams.length,
      totalUploadMbps: serverStats.reduce((sum, s) => sum + s.uploadMbps, 0),
      totalDownloadMbps: serverStats.reduce((sum, s) => sum + s.downloadMbps, 0),
      avgCpuUsage: serverStats.reduce((sum, s) => sum + s.cpuUsage, 0) / (serverStats.length || 1),
      avgMemoryUsage: serverStats.reduce((sum, s) => sum + s.memoryUsage, 0) / (serverStats.length || 1),
    };
    
    res.json({
      servers: serverStats,
      totals: {
        ...totals,
        totalUploadMbps: Math.round(totals.totalUploadMbps * 100) / 100,
        totalDownloadMbps: Math.round(totals.totalDownloadMbps * 100) / 100,
        avgCpuUsage: Math.round(totals.avgCpuUsage * 10) / 10,
        avgMemoryUsage: Math.round(totals.avgMemoryUsage * 10) / 10,
      },
      timestamp: new Date().toISOString(),
    });
  });

  app.post("/api/servers", requireAuth, async (req, res) => {
    try {
      const body = req.body;
      const server = await storage.createServer({
        serverName: body.name,
        domainName: body.domainName,
        serverIp: body.serverIp,
        httpBroadcastPort: body.httpPort || 80,
        httpsBroadcastPort: body.httpsPort || 443,
        rtmpPort: body.rtmpPort || 1935,
        status: body.status === "online" ? 1 : 0,
        isMain: body.isMain ? 1 : 0,
      });
      res.status(201).json(server);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.patch("/api/servers/:id", requireAuth, async (req, res) => {
    const body = req.body;
    const serverId = parseInt(req.params.id);
    const updateData: any = {};
    
    // Basic server fields
    if (body.name) updateData.serverName = body.name;
    if (body.domainName) updateData.domainName = body.domainName;
    if (body.serverIp) updateData.serverIp = body.serverIp;
    if (body.privateIp) updateData.vpnIp = body.privateIp;
    if (body.httpPort) updateData.httpBroadcastPort = body.httpPort;
    if (body.httpsPort) updateData.httpsBroadcastPort = body.httpsPort;
    if (body.rtmpPort) updateData.rtmpPort = body.rtmpPort;
    if (body.status) updateData.status = body.status === "online" ? 1 : 0;
    if (body.isMain !== undefined) updateData.isMain = body.isMain ? 1 : 0;
    if (body.isActive !== undefined) updateData.status = body.isActive ? 1 : 0;
    if (body.maxClients !== undefined) updateData.maxClients = body.maxClients;
    if (body.networkSpeed !== undefined) updateData.networkSpeed = body.networkSpeed;
    if (body.timeshiftOnly !== undefined) updateData.timeshiftOnly = body.timeshiftOnly ? 1 : 0;
    if (body.proxied !== undefined) updateData.proxyEnable = body.proxied ? 1 : 0;
    
    // Advanced GeoIP/ISP fields
    if (body.networkInterface) updateData.networkInterface = body.networkInterface;
    if (body.networkGuaranteedSpeed !== undefined) updateData.networkGuaranteedSpeed = body.networkGuaranteedSpeed;
    if (body.geoipPriority) updateData.geoipType = body.geoipPriority;
    if (body.geoipCountries) updateData.geoipCountries = body.geoipCountries;
    if (body.geoipLoadBalancing !== undefined) updateData.enableGeoip = body.geoipLoadBalancing ? 1 : 0;
    if (body.ispPriority) updateData.ispType = body.ispPriority;
    if (body.ispNames) updateData.ispNames = body.ispNames;
    if (body.ispLoadBalancing !== undefined) updateData.enableIsp = body.ispLoadBalancing ? 1 : 0;
    if (body.httpPorts) updateData.httpPortsAdd = body.httpPorts;
    if (body.httpsPorts) updateData.httpsPortsAdd = body.httpsPorts;
    
    const server = await storage.updateServer(serverId, updateData);
    if (!server) {
      return res.status(404).json({ error: "Server not found" });
    }
    
    // Handle performance settings if any performance field is provided
    if (body.phpVersion !== undefined || body.phpServices !== undefined || body.rateLimitPerSecond !== undefined || 
        body.rateLimitBurstQueue !== undefined || body.cpuGovernor !== undefined || body.customSysctl !== undefined ||
        body.disableRamdisk !== undefined) {
      const perfData: any = {};
      if (body.phpVersion !== undefined) perfData.phpVersion = body.phpVersion;
      if (body.phpServices !== undefined) perfData.phpServices = body.phpServices;
      if (body.rateLimitPerSecond !== undefined) perfData.rateLimitPerSecond = body.rateLimitPerSecond;
      if (body.rateLimitBurstQueue !== undefined) perfData.rateLimitBurstQueue = body.rateLimitBurstQueue;
      if (body.cpuGovernor !== undefined) perfData.cpuGovernor = body.cpuGovernor;
      if (body.customSysctl !== undefined) perfData.customSysctl = body.customSysctl;
      if (body.disableRamdisk !== undefined) perfData.disableRamdisk = body.disableRamdisk ? 1 : 0;
      
      await storage.createOrUpdateServerPerformance(serverId, perfData);
    }
    
    res.json(server);
  });

  app.delete("/api/servers/:id", requireAuth, async (req, res) => {
    const deleted = await storage.deleteServer(parseInt(req.params.id));
    if (!deleted) {
      return res.status(404).json({ error: "Server not found" });
    }
    res.status(204).send();
  });

  // Server Installation via SSH
  app.post("/api/servers/install", requireAuth, async (req, res) => {
    try {
      const { name, serverIp, sshPort, sshUsername, sshPassword, updateSysctl, mainServerIp } = req.body;
      
      if (!name || !serverIp || !sshPassword) {
        return res.status(400).json({ error: "Missing required fields" });
      }

      const now = Math.floor(Date.now() / 1000);

      // Create server record with installation status (-1 = installing)
      const server = await storage.createServer({
        serverName: name,
        domainName: serverIp,
        serverIp: serverIp,
        sshPort: sshPort || 22,
        status: -1, // Installing status
        isMain: 0,
        httpBroadcastPort: 80,
        httpsBroadcastPort: 443,
        rtmpPort: 8880,
      });

      // Create install task to track progress
      const installTask = await storage.createServerInstallTask({
        serverId: server.id,
        status: "pending",
        currentStep: "Initializing",
        totalSteps: 8,
        completedSteps: 0,
        logs: `[${new Date().toISOString()}] Installation queued for server ${serverIp}\n`,
        createdAt: now,
      });

      // Start async SSH installation (don't await - runs in background)
      const sshConfig = {
        host: serverIp,
        port: sshPort || 22,
        username: sshUsername || "root",
        password: sshPassword,
      };
      
      // Get main server IP from database (main server record) or provided value
      let panelIp = mainServerIp;
      if (!panelIp) {
        const allServers = await storage.getServers();
        const mainServer = allServers.find((s: any) => s.isMain === 1);
        panelIp = mainServer?.serverIp || mainServer?.domainName || "127.0.0.1";
      }
      
      installLBServer(server.id, sshConfig, panelIp, !!updateSysctl, storage)
        .catch(err => console.error(`[SSH] Installation failed for ${serverIp}:`, err));

      res.status(201).json({ 
        message: "Installation started", 
        serverId: server.id,
        taskId: installTask.id,
      });
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Get server install task progress
  app.get("/api/servers/:id/install-status", requireAuth, async (req, res) => {
    const task = await storage.getServerInstallTaskByServerId(parseInt(req.params.id));
    if (!task) {
      return res.status(404).json({ error: "No installation task found" });
    }
    res.json(task);
  });

  // Deploy LB proxy to existing server
  app.post("/api/servers/:id/deploy", requireAuth, async (req, res) => {
    try {
      const serverId = parseInt(req.params.id);
      const { sshPort, sshUsername, sshPassword, mainServerIp, updateSysctl } = req.body;
      
      if (!sshPassword) {
        return res.status(400).json({ error: "SSH password is required" });
      }
      
      const server = await storage.getServer(serverId);
      if (!server) {
        return res.status(404).json({ error: "Server not found" });
      }
      
      if (server.isMain === 1) {
        return res.status(400).json({ error: "Cannot deploy LB proxy to main server" });
      }
      
      const serverIp = server.serverIp || server.domainName;
      if (!serverIp) {
        return res.status(400).json({ error: "Server IP not configured" });
      }
      
      // Update server status to installing
      await storage.updateServer(serverId, { status: -1 });
      
      const now = Math.floor(Date.now() / 1000);
      
      // Create or update install task
      const existingTask = await storage.getServerInstallTaskByServerId(serverId);
      let taskId;
      
      if (existingTask) {
        await storage.updateServerInstallTask(existingTask.id, {
          status: "pending",
          currentStep: "Initializing deployment",
          completedSteps: 0,
          logs: `[${new Date().toISOString()}] LB proxy deployment started for ${serverIp}\n`,
        });
        taskId = existingTask.id;
      } else {
        const task = await storage.createServerInstallTask({
          serverId,
          status: "pending",
          currentStep: "Initializing deployment",
          totalSteps: 8,
          completedSteps: 0,
          logs: `[${new Date().toISOString()}] LB proxy deployment started for ${serverIp}\n`,
          createdAt: now,
        });
        taskId = task.id;
      }
      
      // SSH config
      const sshConfig = {
        host: serverIp,
        port: sshPort || 22,
        username: sshUsername || "root",
        password: sshPassword,
      };
      
      // Get main server IP from database (main server record) or provided value
      let panelIp = mainServerIp;
      if (!panelIp) {
        const allServers = await storage.getServers();
        const mainServer = allServers.find((s: any) => s.isMain === 1);
        panelIp = mainServer?.serverIp || mainServer?.domainName || "127.0.0.1";
      }
      
      // Start async SSH installation
      installLBServer(serverId, sshConfig, panelIp, !!updateSysctl, storage)
        .catch(err => console.error(`[SSH] Deployment failed for ${serverIp}:`, err));
      
      res.json({
        message: "Deployment started",
        serverId,
        taskId,
      });
    } catch (error: any) {
      console.error("[DEPLOY] Error:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // Server domains management
  app.get("/api/servers/:id/domains", requireAuth, async (req, res) => {
    const domains = await storage.getServerDomains(parseInt(req.params.id));
    res.json(domains);
  });

  app.post("/api/servers/:id/domains", requireAuth, async (req, res) => {
    try {
      const domain = await storage.createServerDomain({
        serverId: parseInt(req.params.id),
        domainType: req.body.domainType || "domain",
        domainValue: req.body.domainValue,
        isActive: 1,
        createdAt: Math.floor(Date.now() / 1000),
      });
      res.status(201).json(domain);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.delete("/api/servers/:id/domains/:domainId", requireAuth, async (req, res) => {
    await storage.deleteServerDomain(parseInt(req.params.domainId));
    res.status(204).send();
  });

  // Server performance settings
  app.get("/api/servers/:id/performance", requireAuth, async (req, res) => {
    const perf = await storage.getServerPerformance(parseInt(req.params.id));
    res.json(perf || {});
  });

  // EPG CRUD
  app.get("/api/epg", requireAuth, async (req, res) => {
    const allEpg = await storage.getEpgSources();
    const mapped = allEpg.map(e => ({
      id: e.id,
      name: e.epgName,
      url: e.epgFile,
      lastUpdate: e.lastUpdated ? new Date(e.lastUpdated * 1000).toISOString() : null,
      isActive: true,
      autoUpdate: e.updateAuto === 1,
    }));
    res.json(mapped);
  });

  app.post("/api/epg", requireAuth, async (req, res) => {
    try {
      const body = req.body;
      const epgSource = await storage.createEpgSource({
        epgName: body.name,
        epgFile: body.url,
        updateAuto: body.autoUpdate ? 1 : 0,
      });
      res.status(201).json(epgSource);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.patch("/api/epg/:id", requireAuth, async (req, res) => {
    const body = req.body;
    const updateData: any = {};
    
    if (body.name) updateData.epgName = body.name;
    if (body.url) updateData.epgFile = body.url;
    if (body.autoUpdate !== undefined) updateData.updateAuto = body.autoUpdate ? 1 : 0;
    
    const epgSource = await storage.updateEpgSource(parseInt(req.params.id), updateData);
    if (!epgSource) {
      return res.status(404).json({ error: "EPG source not found" });
    }
    res.json(epgSource);
  });

  app.delete("/api/epg/:id", requireAuth, async (req, res) => {
    const deleted = await storage.deleteEpgSource(parseInt(req.params.id));
    if (!deleted) {
      return res.status(404).json({ error: "EPG source not found" });
    }
    res.status(204).send();
  });

  app.post("/api/epg/:id/refresh", requireAuth, async (req, res) => {
    const epgId = parseInt(req.params.id);
    const epgSource = await storage.getEpgSource(epgId);
    if (!epgSource) {
      return res.status(404).json({ error: "EPG source not found" });
    }
    
    try {
      const { importEpgSource } = await import("./epgImport");
      const result = await importEpgSource(epgId);
      
      if (result.success) {
        res.json({ 
          message: "EPG import completed", 
          channelsCount: result.channelsCount,
          programmesCount: result.programmesCount
        });
      } else {
        res.status(500).json({ 
          error: "EPG import failed", 
          details: result.error 
        });
      }
    } catch (error: any) {
      console.error("[EPG Refresh] Error:", error.message);
      res.status(500).json({ error: "EPG import failed", details: error.message });
    }
  });

  app.get("/api/epg/:id/channels", requireAuth, async (req, res) => {
    const epgId = parseInt(req.params.id);
    const epgSource = await storage.getEpgSource(epgId);
    if (!epgSource) {
      return res.status(404).json({ error: "EPG source not found" });
    }
    const channels = await storage.getEpgChannels(epgId);
    res.json(channels);
  });

  // Connections - enriched with user and stream info for dashboard
  app.get("/api/connections", requireAuth, async (req, res) => {
    const allConnections = await storage.getConnections();
    const allUsers = await storage.getUsers();
    const allStreams = await storage.getStreams();
    
    // Enrich connections with user and stream details
    const enrichedConnections = allConnections.map(conn => {
      const user = allUsers.find(u => u.id === conn.userId);
      const stream = allStreams.find(s => s.id === conn.streamId);
      
      return {
        id: conn.activityId,
        activityId: conn.activityId,
        userId: conn.userId,
        username: user?.username || `User #${conn.userId}`,
        streamId: conn.streamId,
        streamName: stream?.streamDisplayName || `Stream #${conn.streamId}`,
        streamType: stream?.type === 1 ? "Live" : stream?.type === 2 ? "Movie" : "Stream",
        serverId: conn.serverId,
        ipAddress: conn.userIp,
        userIp: conn.userIp,
        userAgent: conn.userAgent,
        container: conn.container,
        countryCode: conn.geoipCountryCode || "",
        dateStart: conn.dateStart,
        hlsLastRead: conn.hlsLastRead,
      };
    });
    
    res.json(enrichedConnections);
  });

  app.get("/api/streams/:id/connections", requireAuth, async (req, res) => {
    const streamId = parseInt(req.params.id);
    const connections = await storage.getConnectionsByStream(streamId);
    res.json(connections.map(c => ({
      id: c.activityId,
      userId: c.userId,
      userIp: c.userIp,
      userAgent: c.userAgent,
      container: c.container,
      dateStart: c.dateStart,
      countryCode: c.geoipCountryCode,
    })));
  });

  app.delete("/api/connections/:id", requireAuth, async (req, res) => {
    const deleted = await storage.deleteConnection(parseInt(req.params.id));
    if (!deleted) {
      return res.status(404).json({ error: "Connection not found" });
    }
    res.status(204).send();
  });

  app.post("/api/connections/kill-all", requireAuth, async (req, res) => {
    const { userId } = req.body;
    const killed = await storage.killAllConnections(userId);
    res.json({ killed });
  });

  // Cleanup stale connections - removes connections older than 60 seconds globally
  app.post("/api/connections/cleanup", requireAuth, async (req, res) => {
    try {
      const allConnections = await storage.getConnections();
      const now = Math.floor(Date.now() / 1000);
      let cleaned = 0;
      
      // Delete connections older than 60 seconds (not actively streaming)
      for (const conn of allConnections) {
        const age = now - (conn.dateStart || 0);
        if (age > 60) {
          await storage.deleteConnection(conn.activityId);
          cleaned++;
        }
      }
      
      console.log(`[CLEANUP] Removed ${cleaned} stale connections`);
      res.json({ cleaned, message: `Removed ${cleaned} stale connections` });
    } catch (error: any) {
      console.error("[CLEANUP] Error:", error);
      res.status(500).json({ error: "Failed to cleanup connections" });
    }
  });

  // MAG Devices
  app.get("/api/mag-devices", requireAuth, async (req, res) => {
    const authUser = (req as any).user;
    let devices = await storage.getMagDevices();
    const allConnections = await storage.getConnections();
    
    // Count connections per user
    const connectionCountByUser = new Map<number, number>();
    for (const conn of allConnections) {
      const count = connectionCountByUser.get(conn.userId) || 0;
      connectionCountByUser.set(conn.userId, count + 1);
    }
    
    // If reseller, filter to only show MAG devices belonging to their users
    if (authUser && authUser.role === "reseller") {
      const resellerId = parseInt(authUser.id);
      // Get all users owned by this reseller
      const allUsers = await storage.getUsers();
      const resellerUserIds = new Set(
        allUsers.filter(u => u.memberId === resellerId).map(u => u.id)
      );
      // Filter MAG devices to only those belonging to reseller's users
      devices = devices.filter(d => resellerUserIds.has(d.userId));
    }
    
    // Parse bouquetIds from JSON string to array for frontend and add online status
    const now = Math.floor(Date.now() / 1000);
    const devicesWithParsedBouquets = devices.map(d => ({
      ...d,
      bouquetIds: d.bouquetIds ? (typeof d.bouquetIds === 'string' ? JSON.parse(d.bouquetIds || '[]') : d.bouquetIds) : [],
      isOnline: connectionCountByUser.get(d.userId) ? connectionCountByUser.get(d.userId)! > 0 : false,
      onlineConnections: connectionCountByUser.get(d.userId) || 0,
    }));
    res.json(devicesWithParsedBouquets);
  });

  app.post("/api/mag-devices", requireAuth, async (req, res) => {
    try {
      const authUser = (req as any).user;
      
      // Convert bouquetIds array to JSON string for storage
      const body = { ...req.body };
      if (Array.isArray(body.bouquetIds)) {
        body.bouquetIds = JSON.stringify(body.bouquetIds);
      }
      
      // If reseller, verify they own the user and deduct credits
      if (authUser && authUser.role === "reseller") {
        const resellerId = parseInt(authUser.id);
        
        // Verify the user belongs to this reseller
        if (body.userId) {
          const user = await storage.getUser(body.userId);
          if (!user || user.memberId !== resellerId) {
            return res.status(403).json({ error: "You can only create MAG devices for your own users" });
          }
        }
        
        // Check and deduct credits for MAG device
        const reseller = await storage.getAdmin(resellerId);
        if (!reseller) {
          return res.status(403).json({ error: "Reseller not found" });
        }
        
        // Get credit price for MAG device (use same base price as line)
        const creditPricePerLineSetting = await storage.getSetting("credit_price_per_line");
        const basePricePerLine = creditPricePerLineSetting ? parseFloat(creditPricePerLineSetting.value) || 1 : 1;
        
        const currentCredits = reseller.credits || 0;
        if (currentCredits < basePricePerLine) {
          return res.status(400).json({ 
            error: `Insufficient credits. You need ${basePricePerLine} credit(s) to create a MAG device. You have ${currentCredits} credits.` 
          });
        }
        // Deduct credits (no refunds!)
        await storage.updateAdmin(reseller.id, { credits: currentCredits - basePricePerLine });
      }
      
      const result = insertMagDeviceSchema.safeParse(body);
      if (!result.success) {
        return res.status(400).json({ error: result.error.errors });
      }
      const device = await storage.createMagDevice(result.data);
      res.status(201).json(device);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.get("/api/mag-devices/:id", requireAuth, async (req, res) => {
    const device = await storage.getMagDevice(parseInt(req.params.id));
    if (!device) {
      return res.status(404).json({ error: "MAG device not found" });
    }
    res.json(device);
  });

  app.patch("/api/mag-devices/:id", requireAuth, async (req, res) => {
    try {
      // Convert bouquetIds array to JSON string for storage
      const body = { ...req.body };
      if (Array.isArray(body.bouquetIds)) {
        body.bouquetIds = JSON.stringify(body.bouquetIds);
      }
      const result = insertMagDeviceSchema.partial().safeParse(body);
      if (!result.success) {
        return res.status(400).json({ error: result.error.errors });
      }
      const device = await storage.updateMagDevice(parseInt(req.params.id), result.data);
      if (!device) {
        return res.status(404).json({ error: "MAG device not found" });
      }
      res.json(device);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.delete("/api/mag-devices/:id", requireAuth, async (req, res) => {
    const deleted = await storage.deleteMagDevice(parseInt(req.params.id));
    if (!deleted) {
      return res.status(404).json({ error: "MAG device not found" });
    }
    res.status(204).send();
  });

  // ==========================================
  // MAG SECURITY ADMIN API
  // ==========================================

  // Get all blocked MAG entries (MAC addresses and IPs)
  app.get("/api/mag-security/blocked", requireAuth, async (req, res) => {
    const blocked = getBlockedMagEntries();
    res.json(blocked);
  });

  // Unblock a specific MAC or IP
  app.post("/api/mag-security/unblock", requireAuth, async (req, res) => {
    const { key } = req.body;
    if (!key) {
      return res.status(400).json({ error: "Key is required" });
    }
    
    const success = unblockMagEntry(key);
    if (success) {
      res.json({ message: `Unblocked: ${key}` });
    } else {
      res.status(404).json({ error: "Entry not found" });
    }
  });

  // Get active MAG sessions
  app.get("/api/mag-security/sessions", requireAuth, async (req, res) => {
    const sessions: Array<{
      mac: string;
      ip: string;
      firstIp: string;
      createdAt: number;
      lastActive: number;
      tokenExpiresAt: number;
      tokenExpiresIn: number;
    }> = [];
    
    const now = Date.now();
    magSessions.forEach((session, mac) => {
      sessions.push({
        mac,
        ip: session.clientIp,
        firstIp: session.firstIp,
        createdAt: session.createdAt,
        lastActive: session.lastActive,
        tokenExpiresAt: session.tokenExpiresAt,
        tokenExpiresIn: Math.max(0, Math.floor((session.tokenExpiresAt - now) / 1000)),
      });
    });
    
    res.json(sessions);
  });

  // Clear IP lock for a device (reset firstIp)
  app.post("/api/mag-security/clear-ip-lock/:mac", requireAuth, async (req, res) => {
    const mac = req.params.mac.toUpperCase().replace(/[^A-F0-9]/g, "");
    const normalizedMac = mac.match(/.{2}/g)?.join(":") || mac;
    
    const session = magSessions.get(normalizedMac);
    if (session) {
      session.firstIp = ""; // Clear IP lock
      magSessions.set(normalizedMac, session);
      console.log(`[MAG SECURITY] IP lock cleared for ${normalizedMac}`);
      res.json({ message: `IP lock cleared for ${normalizedMac}` });
    } else {
      res.status(404).json({ error: "Session not found" });
    }
  });

  // Kill a MAG session (force reconnect)
  app.delete("/api/mag-security/sessions/:mac", requireAuth, async (req, res) => {
    const mac = req.params.mac.toUpperCase().replace(/[^A-F0-9]/g, "");
    const normalizedMac = mac.match(/.{2}/g)?.join(":") || mac;
    
    const deleted = magSessions.delete(normalizedMac);
    if (deleted) {
      // Also clear connections
      magConnections.delete(normalizedMac);
      console.log(`[MAG SECURITY] Session killed for ${normalizedMac}`);
      res.json({ message: `Session killed for ${normalizedMac}` });
    } else {
      res.status(404).json({ error: "Session not found" });
    }
  });

  // Get MAG security stats
  app.get("/api/mag-security/stats", requireAuth, async (req, res) => {
    const now = Date.now();
    
    let activeSessions = 0;
    let expiredTokens = 0;
    magSessions.forEach(session => {
      if (session.tokenExpiresAt > now) {
        activeSessions++;
      } else {
        expiredTokens++;
      }
    });
    
    let activeConnections = 0;
    magConnections.forEach(conns => {
      activeConnections += conns.filter(c => now - c.lastActive < MAG_CONNECTION_TIMEOUT).length;
    });
    
    const blocked = getBlockedMagEntries();
    
    res.json({
      activeSessions,
      expiredTokens,
      activeConnections,
      blockedEntries: blocked.length,
      tokenTtlHours: MAG_TOKEN_TTL / (60 * 60 * 1000),
      sessionTtlHours: MAG_SESSION_TTL / (60 * 60 * 1000),
      maxFailedAttempts: MAG_MAX_FAILED_ATTEMPTS,
      blockDurationMinutes: MAG_BLOCK_DURATION / (60 * 1000),
    });
  });

  // Activity Logs
  app.get("/api/activity-logs", requireAuth, async (req, res) => {
    const limit = req.query.limit ? parseInt(req.query.limit as string) : 100;
    const logs = await storage.getActivityLogs(limit);
    res.json(logs);
  });

  // ==========================================
  // INTERNAL LB API - Used by LB proxy servers
  // ==========================================

  // Validate LB server token middleware
  const validateLBToken = async (req: Request, res: Response, next: NextFunction) => {
    const token = req.headers["x-lb-token"] as string;
    const serverId = parseInt(req.headers["x-lb-server-id"] as string);
    
    if (!token || !serverId) {
      return res.status(401).json({ error: "Missing LB credentials" });
    }
    
    // Verify token matches server
    const server = await storage.getServer(serverId);
    if (!server || server.serverToken !== token) {
      return res.status(403).json({ error: "Invalid LB token" });
    }
    
    (req as any).lbServerId = serverId;
    next();
  };

  // LB: Validate user and get stream source URL
  app.get("/internal/lb/validate", validateLBToken, async (req, res) => {
    try {
      const { username, password, streamId, type } = req.query;
      
      if (!username || !password || !streamId) {
        return res.status(400).json({ error: "Missing parameters" });
      }
      
      // Find user by credentials
      const users = await storage.getUsers();
      const user = users.find(u => u.username === username && u.password === password);
      
      if (!user) {
        return res.status(403).json({ error: "Invalid credentials" });
      }
      
      // Check if user is active and not expired
      if (!user.enabled || !user.adminEnabled) {
        return res.status(403).json({ error: "User is disabled" });
      }
      
      if (user.expDate) {
        // expDate is Unix timestamp in seconds, convert to milliseconds for Date
        const expiry = new Date(user.expDate * 1000);
        if (expiry < new Date()) {
          return res.status(403).json({ error: "Subscription expired" });
        }
      }
      
      // Get stream - try by ID first, then by number (XUI uses stream numbers)
      const sid = parseInt(streamId as string);
      let stream = await storage.getStream(sid);
      if (!stream) {
        // Fallback: XUI/Xtream uses stream number, not ID
        const streamType = type === "movie" ? 2 : 1;
        const allStreams = await storage.getStreams(streamType);
        stream = allStreams.find(s => s.number === sid);
      }
      
      if (!stream) {
        return res.status(404).json({ error: "Stream not found" });
      }
      
      // Use actual stream ID for access checks and response
      const actualStreamId = stream.id;
      
      // Verify stream type matches request
      if (type === "movie" && stream.type !== 2) {
        return res.status(404).json({ error: "Not a movie" });
      }
      if (type === "live" && stream.type !== 1) {
        return res.status(404).json({ error: "Not a live stream" });
      }
      
      // Check if user has access to this stream via bouquets
      if (user.bouquet) {
        // Parse bouquet IDs - handle both JSON array "[1,2,3]" and comma-separated "1,2,3" formats
        let userBouquetIds: number[] = [];
        try {
          const parsed = JSON.parse(user.bouquet);
          if (Array.isArray(parsed)) {
            userBouquetIds = parsed.map(b => parseInt(b)).filter(b => !isNaN(b));
          }
        } catch {
          // Fallback to comma-separated format
          userBouquetIds = user.bouquet.split(",").map(b => parseInt(b.trim())).filter(b => !isNaN(b));
        }
        if (userBouquetIds.length > 0) {
          const bouquets = await storage.getBouquets();
          const userBouquets = bouquets.filter(b => userBouquetIds.includes(b.id));
          
          let hasAccess = false;
          for (const bouquet of userBouquets) {
            try {
              // Live streams use bouquetChannels, movies use bouquetMovies
              const fieldToCheck = type === "movie" ? bouquet.bouquetMovies : bouquet.bouquetChannels;
              const streamIds = JSON.parse(fieldToCheck || "[]");
              if (streamIds.includes(actualStreamId)) {
                hasAccess = true;
                break;
              }
            } catch {}
          }
          
          if (!hasAccess) {
            return res.status(403).json({ error: "No access to this stream" });
          }
        }
      }
      
      // Return source URL (LB will fetch directly)
      res.json({
        sourceUrl: stream.streamSource || "",
        streamId: actualStreamId,
        userId: user.id,
        userAgent: stream.userAgent || "",
      });
      
    } catch (error: any) {
      console.error("[LB Validate] Error:", error.message);
      res.status(500).json({ error: "Internal error" });
    }
  });

  // LB: Get token data for HLS proxy
  app.get("/internal/lb/token", validateLBToken, async (req, res) => {
    try {
      const { token } = req.query;
      
      if (!token) {
        return res.status(400).json({ error: "Missing token" });
      }
      
      // Look up token in main server's token map
      const tokenData = streamTokens.get(token as string);
      
      if (!tokenData) {
        return res.status(404).json({ error: "Token not found or expired" });
      }
      
      res.json({
        baseUrl: tokenData.baseUrl,
        sourceUrl: tokenData.sourceUrl,
        streamId: tokenData.streamId,
        userId: tokenData.userId,
      });
      
    } catch (error: any) {
      console.error("[LB Token] Error:", error.message);
      res.status(500).json({ error: "Internal error" });
    }
  });

  // LB: Report metrics (called periodically by LB proxy)
  app.post("/internal/lb/metrics", validateLBToken, async (req, res) => {
    try {
      const serverId = (req as any).lbServerId;
      const { cpuUsage, memoryUsage, diskUsage, networkIn, networkOut, activeConnections } = req.body;
      
      console.log(`[LB METRICS] Server ${serverId}: CPU=${cpuUsage}%, RAM=${memoryUsage}%, Disk=${diskUsage}%`);
      
      // Update LB metrics cache for real-time dashboard
      lbMetricsCache.set(serverId, {
        cpuUsage: cpuUsage || 0,
        memoryUsage: memoryUsage || 0,
        diskUsage: diskUsage || 0,
        networkIn: networkIn || 0,
        networkOut: networkOut || 0,
        activeConnections: activeConnections || 0,
        timestamp: Date.now(),
      });
      
      // Store metrics in database
      await storage.addServerMetrics({
        serverId,
        cpuUsage: cpuUsage || 0,
        cpuCores: 1,
        memoryUsage: memoryUsage || 0,
        memoryTotal: 0,
        diskUsage: diskUsage || 0,
        diskTotal: 0,
        ioWait: 0,
        networkIn: networkIn || 0,
        networkOut: networkOut || 0,
        activeConnections: activeConnections || 0,
        onlineStreams: 0,
        timestamp: Math.floor(Date.now() / 1000),
      });
      
      // Update server status
      await storage.updateServer(serverId, {
        totalClients: activeConnections || 0,
        lastCheckAgo: 0,
      });
      
      res.json({ status: "ok" });
      
    } catch (error: any) {
      console.error("[LB Metrics] Error:", error.message);
      res.status(500).json({ error: "Internal error" });
    }
  });

  // LB: Heartbeat - called by LB proxy when serving segments to keep connection alive
  app.post("/internal/lb/heartbeat", validateLBToken, async (req, res) => {
    try {
      const { userId, streamId, clientIp, userAgent } = req.body;
      const serverId = parseInt(req.headers["x-lb-server-id"] as string) || 1;
      
      if (!userId || !streamId) {
        return res.status(400).json({ error: "Missing userId or streamId" });
      }
      
      const realClientIp = clientIp || req.ip || "0.0.0.0";
      const realUserAgent = userAgent || req.headers["user-agent"] || "LB Proxy";
      const now = Math.floor(Date.now() / 1000);
      
      // GeoIP lookup for country code
      const geo = await getGeoLocation(realClientIp);
      
      // First check if connection exists for this user+stream (ANY server - to avoid duplicates)
      const connections = await storage.getConnections();
      const existingConn = connections.find(c => 
        c.userId === Number(userId) && 
        c.streamId === Number(streamId)
      );
      
      if (existingConn) {
        // Update existing connection - update hlsLastRead, IP, userAgent, serverId, and geoip
        await storage.touchConnectionByUserStream(Number(userId), Number(streamId), serverId, realClientIp, realUserAgent, geo.countryCode || null);
      } else {
        // Create new connection only if none exists for this user+stream
        await storage.createConnection({
          userId: Number(userId),
          streamId: Number(streamId),
          serverId: serverId,
          userIp: realClientIp,
          userAgent: realUserAgent,
          container: "lb_proxy",
          dateStart: now,
          geoipCountryCode: geo.countryCode || null,
          isp: null,
        });
        console.log(`[LB Heartbeat] Created: user=${userId} stream=${streamId} ip=${realClientIp} country=${geo.countryCode}`);
      }
      
      res.json({ status: "ok" });
      
    } catch (error: any) {
      res.status(500).json({ error: "Internal error" });
    }
  });

  // ==========================================
  // END INTERNAL LB API
  // ==========================================

  // Public branding endpoint (no auth required - for login page, sidebar, footer)
  app.get("/api/branding", async (req, res) => {
    res.setHeader("Cache-Control", "public, max-age=300"); // Cache 5 minutes
    const panelName = await storage.getSetting("panel_name");
    const panelLogoUrl = await storage.getSetting("panel_logo_url");
    res.json({
      panelName: panelName?.value || "X NeoServ",
      panelLogoUrl: panelLogoUrl?.value || "",
    });
  });

  // ===============================
  // AUDIT LOG ENDPOINTS
  // ===============================

  app.get("/api/audit-logs", requireAuth, async (req: AuthRequest, res) => {
    try {
      if (req.adminRole !== "admin") {
        return res.status(403).json({ error: "Admin access required" });
      }

      const filters = {
        adminId: req.query.adminId ? parseInt(req.query.adminId as string) : undefined,
        action: req.query.action as string | undefined,
        targetType: req.query.targetType as string | undefined,
        startDate: req.query.startDate ? parseInt(req.query.startDate as string) : undefined,
        endDate: req.query.endDate ? parseInt(req.query.endDate as string) : undefined,
        search: req.query.search as string | undefined,
        limit: req.query.limit ? parseInt(req.query.limit as string) : 100,
        offset: req.query.offset ? parseInt(req.query.offset as string) : 0,
      };

      const logs = await getAuditLogs(filters);
      res.json(logs);
    } catch (error) {
      console.error("[AUDIT] Failed to get logs:", error);
      res.status(500).json({ error: "Failed to get audit logs" });
    }
  });

  app.get("/api/audit-logs/stats", requireAuth, async (req: AuthRequest, res) => {
    try {
      if (req.adminRole !== "admin") {
        return res.status(403).json({ error: "Admin access required" });
      }

      const stats = await getAuditLogStats();
      res.json(stats);
    } catch (error) {
      console.error("[AUDIT] Failed to get stats:", error);
      res.status(500).json({ error: "Failed to get audit stats" });
    }
  });

  // Delete audit logs - by IDs or by age
  app.delete("/api/audit-logs", requireAuth, async (req: AuthRequest, res) => {
    try {
      if (req.adminRole !== "admin") {
        return res.status(403).json({ error: "Admin access required" });
      }

      const { ids, olderThanDays } = req.body;
      
      if (!ids && olderThanDays === undefined) {
        return res.status(400).json({ error: "Provide ids array or olderThanDays number" });
      }

      const deletedCount = await deleteAuditLogs({
        ids: ids as number[] | undefined,
        olderThanDays: olderThanDays as number | undefined,
      });

      logAuditFromRequest(req as any, {
        action: "settings_update",
        targetType: "system",
        targetName: "audit_logs",
        details: `Deleted ${deletedCount} audit logs`,
      });

      res.json({ success: true, deletedCount });
    } catch (error) {
      console.error("[AUDIT] Failed to delete logs:", error);
      res.status(500).json({ error: "Failed to delete audit logs" });
    }
  });

  // Settings
  app.get("/api/settings", requireAuth, async (req, res) => {
    res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
    res.setHeader("Pragma", "no-cache");
    res.setHeader("Expires", "0");
    const settings = await storage.getSettings();
    res.json(settings);
  });

  app.post("/api/settings/general", requireAuth, async (req, res) => {
    const { panelName, panelUrl, panelLogoUrl, timezone, defaultLanguage, creditPricePerLine, creditPricePerConnection } = req.body;
    if (panelName) await storage.setSetting("panel_name", panelName);
    if (panelUrl !== undefined) await storage.setSetting("panel_url", panelUrl);
    if (panelLogoUrl !== undefined) await storage.setSetting("panel_logo_url", panelLogoUrl);
    if (timezone) await storage.setSetting("timezone", timezone);
    if (defaultLanguage) await storage.setSetting("default_language", defaultLanguage);
    if (creditPricePerLine !== undefined) await storage.setSetting("credit_price_per_line", creditPricePerLine.toString());
    if (creditPricePerConnection !== undefined) await storage.setSetting("credit_price_per_connection", creditPricePerConnection.toString());
    logAuditFromRequest(req as any, {
      action: "settings_update",
      targetType: "settings",
      targetName: "general",
      details: "Updated general settings"
    });
    res.json({ message: "Settings updated" });
  });

  // Duration options for credit pricing
  app.get("/api/settings/duration-options", requireAuth, async (req, res) => {
    res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
    res.setHeader("Pragma", "no-cache");
    res.setHeader("Expires", "0");
    const setting = await storage.getSetting("credit_duration_options");
    if (setting) {
      try {
        res.json(JSON.parse(setting.value));
      } catch {
        res.json([
          { label: "1 Month", days: 30, multiplier: 1 },
          { label: "3 Months", days: 90, multiplier: 2.5 },
          { label: "6 Months", days: 180, multiplier: 5 },
          { label: "1 Year", days: 365, multiplier: 10 },
        ]);
      }
    } else {
      // Return default options
      res.json([
        { label: "1 Month", days: 30, multiplier: 1 },
        { label: "3 Months", days: 90, multiplier: 2.5 },
        { label: "6 Months", days: 180, multiplier: 5 },
        { label: "1 Year", days: 365, multiplier: 10 },
      ]);
    }
  });

  app.post("/api/settings/duration-options", requireAdmin, async (req, res) => {
    const { options } = req.body;
    if (!Array.isArray(options)) {
      return res.status(400).json({ error: "Options must be an array" });
    }
    
    // Validate each option
    for (const opt of options) {
      if (!opt.label || typeof opt.days !== "number" || typeof opt.multiplier !== "number") {
        return res.status(400).json({ error: "Each option must have label, days, and multiplier" });
      }
      if (opt.days < 1 || opt.multiplier < 0.1) {
        return res.status(400).json({ error: "Days must be >= 1 and multiplier >= 0.1" });
      }
    }
    
    await storage.setSetting("credit_duration_options", JSON.stringify(options));
    res.json({ message: "Duration options updated" });
  });

  app.post("/api/settings/security", requireAuth, async (req, res) => {
    const { maxLoginAttempts, sessionTimeout, twoFactorAuth, ipWhitelist, enforceHttps, allowRegistration } = req.body;
    if (maxLoginAttempts) await storage.setSetting("max_login_attempts", maxLoginAttempts.toString());
    if (sessionTimeout) await storage.setSetting("session_timeout", sessionTimeout.toString());
    if (twoFactorAuth !== undefined) await storage.setSetting("two_factor_auth", twoFactorAuth ? "1" : "0");
    if (ipWhitelist) await storage.setSetting("ip_whitelist", ipWhitelist);
    if (enforceHttps !== undefined) await storage.setSetting("enforce_https", enforceHttps ? "1" : "0");
    if (allowRegistration !== undefined) await storage.setSetting("allow_registration", allowRegistration ? "1" : "0");
    res.json({ message: "Security settings updated" });
  });

  app.post("/api/settings/streaming", requireAuth, async (req, res) => {
    const { defaultOutputFormat, maxConnectionsPerUser, enableRestream, transcodingEnabled, 
            defaultBitrate, maxConnections, bufferSize, enableTimeshift, timeshiftDuration } = req.body;
    if (defaultOutputFormat) await storage.setSetting("default_output_format", defaultOutputFormat);
    if (maxConnectionsPerUser) await storage.setSetting("max_connections_per_user", maxConnectionsPerUser.toString());
    if (enableRestream !== undefined) await storage.setSetting("enable_restream", enableRestream ? "1" : "0");
    if (transcodingEnabled !== undefined) await storage.setSetting("transcoding_enabled", transcodingEnabled ? "1" : "0");
    if (defaultBitrate) await storage.setSetting("default_bitrate", defaultBitrate);
    if (maxConnections) await storage.setSetting("max_connections", maxConnections.toString());
    if (bufferSize) await storage.setSetting("buffer_size", bufferSize.toString());
    if (enableTimeshift !== undefined) await storage.setSetting("enable_timeshift", enableTimeshift ? "1" : "0");
    if (timeshiftDuration) await storage.setSetting("timeshift_duration", timeshiftDuration.toString());
    res.json({ message: "Streaming settings updated" });
  });

  app.post("/api/settings/server", requireAuth, async (req, res) => {
    const { mainServerIp, mainServerPort, mainServerUser, mainServerPassword,
            loadBalancerIp, loadBalancerPort, loadBalancerUser, loadBalancerPassword } = req.body;
    if (mainServerIp) await storage.setSetting("main_server_ip", mainServerIp);
    if (mainServerPort) await storage.setSetting("main_server_port", mainServerPort.toString());
    if (mainServerUser) await storage.setSetting("main_server_user", mainServerUser);
    if (mainServerPassword) await storage.setSetting("main_server_password", mainServerPassword);
    if (loadBalancerIp !== undefined) await storage.setSetting("load_balancer_ip", loadBalancerIp);
    if (loadBalancerPort) await storage.setSetting("load_balancer_port", loadBalancerPort.toString());
    if (loadBalancerUser !== undefined) await storage.setSetting("load_balancer_user", loadBalancerUser);
    if (loadBalancerPassword !== undefined) await storage.setSetting("load_balancer_password", loadBalancerPassword);
    res.json({ message: "Server settings updated" });
  });

  app.post("/api/settings/email", requireAuth, async (req, res) => {
    const { smtpHost, smtpPort, smtpUser, smtpPassword, smtpFrom, smtpFromName, smtpSecure } = req.body;
    if (smtpHost) await storage.setSetting("smtp_host", smtpHost);
    if (smtpPort) await storage.setSetting("smtp_port", smtpPort.toString());
    if (smtpUser) await storage.setSetting("smtp_user", smtpUser);
    if (smtpPassword) await storage.setSetting("smtp_password", smtpPassword);
    if (smtpFrom !== undefined) await storage.setSetting("smtp_from", smtpFrom);
    if (smtpFromName !== undefined) await storage.setSetting("smtp_from_name", smtpFromName);
    if (smtpSecure !== undefined) await storage.setSetting("smtp_secure", smtpSecure ? "1" : "0");
    res.json({ message: "Email settings updated" });
  });

  app.post("/api/settings/api", requireAuth, async (req, res) => {
    const { apiEnabled, apiPort, apiKey, playerApiEnabled, enigma2ApiEnabled, magApiEnabled } = req.body;
    if (apiEnabled !== undefined) await storage.setSetting("api_enabled", apiEnabled ? "1" : "0");
    if (apiPort) await storage.setSetting("api_port", apiPort.toString());
    if (apiKey !== undefined) await storage.setSetting("api_key", apiKey);
    if (playerApiEnabled !== undefined) await storage.setSetting("player_api_enabled", playerApiEnabled ? "1" : "0");
    if (enigma2ApiEnabled !== undefined) await storage.setSetting("enigma2_api_enabled", enigma2ApiEnabled ? "1" : "0");
    if (magApiEnabled !== undefined) await storage.setSetting("mag_api_enabled", magApiEnabled ? "1" : "0");
    res.json({ message: "API settings updated" });
  });

  app.post("/api/settings/transcoding", requireAuth, async (req, res) => {
    const { transcodingEnabled, ffmpegPath, defaultCodec, hardwareAcceleration, maxTranscodingTasks } = req.body;
    if (transcodingEnabled !== undefined) await storage.setSetting("transcoding_enabled", transcodingEnabled ? "1" : "0");
    if (ffmpegPath) await storage.setSetting("ffmpeg_path", ffmpegPath);
    if (defaultCodec) await storage.setSetting("default_codec", defaultCodec);
    if (hardwareAcceleration !== undefined) await storage.setSetting("hardware_acceleration", hardwareAcceleration ? "1" : "0");
    if (maxTranscodingTasks) await storage.setSetting("max_transcoding_tasks", maxTranscodingTasks.toString());
    res.json({ message: "Transcoding settings updated" });
  });

  // External Streaming Proxy Settings (Hybrid Architecture)
  app.post("/api/settings/streaming-proxy", requireAuth, async (req, res) => {
    const { 
      externalProxyEnabled, 
      externalProxyUrl, 
      proxySecretKey,
      proxyTokenTtl 
    } = req.body;
    
    if (externalProxyEnabled !== undefined) {
      await storage.setSetting("external_proxy_enabled", externalProxyEnabled ? "1" : "0");
    }
    if (externalProxyUrl !== undefined) {
      await storage.setSetting("external_proxy_url", externalProxyUrl);
    }
    if (proxySecretKey !== undefined) {
      await storage.setSetting("proxy_secret_key", proxySecretKey);
    }
    if (proxyTokenTtl !== undefined) {
      await storage.setSetting("proxy_token_ttl", proxyTokenTtl.toString());
    }
    res.json({ message: "Streaming proxy settings updated" });
  });

  // Cloudflare Domain Settings (Panel vs Streaming subdomain)
  app.post("/api/settings/domains", requireAuth, async (req, res) => {
    const { panelDomain, panelPort, streamingDomain, streamingPort } = req.body;
    
    if (panelDomain !== undefined) {
      await storage.setSetting("panel_domain", panelDomain);
    }
    if (panelPort !== undefined) {
      await storage.setSetting("panel_port", panelPort.toString());
    }
    if (streamingDomain !== undefined) {
      await storage.setSetting("streaming_domain", streamingDomain);
    }
    if (streamingPort !== undefined) {
      await storage.setSetting("streaming_port", streamingPort.toString());
    }
    res.json({ message: "Domain settings updated" });
  });

  // Token validation endpoint for Nginx auth_request
  // Nginx calls this to validate tokens before proxying streams
  app.get("/api/proxy/validate", async (req, res) => {
    try {
      const token = req.query.token as string;
      const streamId = req.query.stream_id as string;
      const signature = req.query.sig as string;
      
      if (!token || !streamId || !signature) {
        return res.status(401).json({ error: "Missing parameters" });
      }
      
      // Get secret key for signature validation
      const secretKeySetting = await storage.getSetting("proxy_secret_key");
      const secretKey = secretKeySetting?.value || "default_secret_change_me";
      
      // Validate signature: HMAC-SHA256(token:streamId, secretKey)
      const crypto = await import("crypto");
      const expectedSig = crypto.createHmac("sha256", secretKey)
        .update(`${token}:${streamId}`)
        .digest("hex")
        .substring(0, 16); // Use first 16 chars for shorter URLs
      
      if (signature !== expectedSig) {
        return res.status(401).json({ error: "Invalid signature" });
      }
      
      // Parse token to get user info and expiry
      const tokenParts = Buffer.from(token, "base64").toString().split(":");
      if (tokenParts.length < 4) {
        return res.status(401).json({ error: "Invalid token format" });
      }
      
      const [userId, username, expiry, _] = tokenParts;
      const expiryTime = parseInt(expiry);
      
      if (Date.now() > expiryTime) {
        return res.status(401).json({ error: "Token expired" });
      }
      
      // Verify user exists and is active
      const user = await storage.getUserByUsername(username);
      if (!user || user.enabled !== 1 || user.adminEnabled !== 1) {
        return res.status(401).json({ error: "User not active" });
      }
      
      // Check user expiration
      if (user.expDate && user.expDate < Math.floor(Date.now() / 1000)) {
        return res.status(401).json({ error: "Subscription expired" });
      }
      
      // Get the stream source URL
      const stream = await storage.getStream(parseInt(streamId));
      if (!stream || !stream.streamSource) {
        return res.status(404).json({ error: "Stream not found" });
      }
      
      // Return source URL in X-Source-Url header for Nginx to use
      res.setHeader("X-Source-Url", stream.streamSource);
      res.setHeader("X-User-Id", user.id.toString());
      res.setHeader("X-Stream-Id", streamId);
      res.status(200).json({ valid: true });
    } catch (error: any) {
      console.error("Token validation error:", error);
      res.status(500).json({ error: "Validation failed" });
    }
  });

  // Generate signed proxy URL for a stream
  app.get("/api/proxy/generate-url", requireAuth, async (req, res) => {
    try {
      const streamId = req.query.stream_id as string;
      const userId = req.query.user_id as string;
      
      if (!streamId || !userId) {
        return res.status(400).json({ error: "Missing stream_id or user_id" });
      }
      
      const user = await storage.getUser(parseInt(userId));
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      
      const stream = await storage.getStream(parseInt(streamId));
      if (!stream) {
        return res.status(404).json({ error: "Stream not found" });
      }
      
      const externalProxyUrlSetting = await storage.getSetting("external_proxy_url");
      const externalProxyUrl = externalProxyUrlSetting?.value || "";
      const secretKeySetting = await storage.getSetting("proxy_secret_key");
      const secretKey = secretKeySetting?.value || "default_secret_change_me";
      const ttlSetting = await storage.getSetting("proxy_token_ttl");
      const ttl = parseInt(ttlSetting?.value || "14400") * 1000; // Default 4 hours
      
      // Create token: base64(userId:username:expiry:random)
      const expiry = Date.now() + ttl;
      const random = Math.random().toString(36).substring(2, 10);
      const token = Buffer.from(`${user.id}:${user.username}:${expiry}:${random}`).toString("base64url");
      
      // Create signature
      const crypto = await import("crypto");
      const sig = crypto.createHmac("sha256", secretKey)
        .update(`${token}:${streamId}`)
        .digest("hex")
        .substring(0, 16);
      
      // Build proxy URL
      const proxyUrl = `${externalProxyUrl}/stream/${streamId}/${token}/${sig}`;
      
      res.json({
        url: proxyUrl,
        expires: expiry,
        token,
        signature: sig
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Generate Nginx configuration for the external proxy server
  app.get("/api/proxy/nginx-config", requireAuth, async (req, res) => {
    try {
      const panelUrlSetting = await storage.getSetting("panel_url");
      const panelUrl = panelUrlSetting?.value || "https://your-panel.replit.app";
      
      const nginxConfig = `# X NeoServ Streaming Proxy - Nginx Configuration
# Place this in /etc/nginx/sites-available/streaming-proxy
# Then: ln -s /etc/nginx/sites-available/streaming-proxy /etc/nginx/sites-enabled/
# And: nginx -t && systemctl reload nginx

# Upstream for source streams (adjust resolver for your DNS)
resolver 8.8.8.8 8.8.4.4 valid=300s;
resolver_timeout 5s;

# Cache for upstream responses
proxy_cache_path /var/cache/nginx/streams levels=1:2 keys_zone=stream_cache:100m max_size=10g inactive=10m use_temp_path=off;

# Map for extracting stream components from URI
map $uri $stream_id {
    ~^/stream/([0-9]+)/ $1;
}

map $uri $stream_token {
    ~^/stream/[0-9]+/([^/]+)/ $1;
}

map $uri $stream_sig {
    ~^/stream/[0-9]+/[^/]+/([^/]+) $1;
}

server {
    listen 80;
    listen 443 ssl http2;
    server_name streaming.yourdomain.com;  # CHANGE THIS

    # SSL Configuration (use certbot or your own certs)
    # ssl_certificate /etc/letsencrypt/live/streaming.yourdomain.com/fullchain.pem;
    # ssl_certificate_key /etc/letsencrypt/live/streaming.yourdomain.com/privkey.pem;
    
    # Optimized buffering for HLS streaming (matches your working config)
    proxy_buffering on;
    proxy_buffer_size 512k;
    proxy_buffers 16 512k;
    proxy_busy_buffers_size 1024k;
    proxy_connect_timeout 2s;
    proxy_read_timeout 60s;
    proxy_send_timeout 60s;
    
    # Keepalive connections to upstream
    proxy_http_version 1.1;
    proxy_set_header Connection "";
    
    # Stream proxy location
    location ~ ^/stream/([0-9]+)/([^/]+)/([^/]+)(/.*)?$ {
        set $sid $1;
        set $tok $2;
        set $sig $3;
        set $path $4;
        
        # Validate token with panel
        auth_request /auth;
        auth_request_set $source_url $upstream_http_x_source_url;
        
        # If path is empty, request the main playlist
        if ($path = "") {
            set $path "/";
        }
        
        # Proxy to the source URL
        # The source URL is returned by the auth endpoint
        proxy_pass $source_url$path$is_args$args;
        
        # Don't pass auth headers to upstream
        proxy_set_header Authorization "";
        
        # Cache segments for faster subsequent requests
        proxy_cache stream_cache;
        proxy_cache_valid 200 10s;
        proxy_cache_key $source_url$path;
        
        # Hide source in error logs
        proxy_intercept_errors on;
        error_page 502 503 504 = @stream_error;
    }
    
    # MAG/STB compatible endpoint (uses username:password format)
    location ~ ^/live/([^/]+)/([^/]+)/([0-9]+)\\.([a-z0-9]+)$ {
        set $uname $1;
        set $pass $2;
        set $sid $3;
        set $ext $4;
        
        # Validate with panel's player_api
        auth_request /auth_mag;
        auth_request_set $source_url $upstream_http_x_source_url;
        
        proxy_pass $source_url;
        proxy_set_header Authorization "";
        
        proxy_cache stream_cache;
        proxy_cache_valid 200 10s;
        
        proxy_intercept_errors on;
        error_page 502 503 504 = @stream_error;
    }
    
    # Auth endpoint - validates tokens with panel
    location = /auth {
        internal;
        proxy_pass ${panelUrl}/api/proxy/validate?token=$tok&stream_id=$sid&sig=$sig;
        proxy_pass_request_body off;
        proxy_set_header Content-Length "";
        proxy_set_header X-Original-URI $request_uri;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_connect_timeout 2s;
        proxy_read_timeout 5s;
    }
    
    # MAG auth endpoint - validates username/password with panel
    location = /auth_mag {
        internal;
        proxy_pass ${panelUrl}/api/proxy/validate-mag?username=$uname&password=$pass&stream_id=$sid;
        proxy_pass_request_body off;
        proxy_set_header Content-Length "";
        proxy_set_header X-Original-URI $request_uri;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_connect_timeout 2s;
        proxy_read_timeout 5s;
    }
    
    # Error handler - returns generic error without source info
    location @stream_error {
        return 503 "Stream temporarily unavailable";
    }
    
    # Health check
    location /health {
        return 200 "OK";
    }
    
    # Block direct access to root
    location / {
        return 403 "Access denied";
    }
}
`;
      
      res.setHeader("Content-Type", "text/plain");
      res.setHeader("Content-Disposition", "attachment; filename=streaming-proxy.conf");
      res.send(nginxConfig);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // MAG/STB validation endpoint for Nginx auth_request
  app.get("/api/proxy/validate-mag", async (req, res) => {
    try {
      const username = req.query.username as string;
      const password = req.query.password as string;
      const streamId = req.query.stream_id as string;
      
      if (!username || !password || !streamId) {
        return res.status(401).json({ error: "Missing parameters" });
      }
      
      // Verify user credentials
      const user = await storage.getUserByUsername(username);
      if (!user || user.password !== password) {
        return res.status(401).json({ error: "Invalid credentials" });
      }
      
      if (user.enabled !== 1 || user.adminEnabled !== 1) {
        return res.status(401).json({ error: "User not active" });
      }
      
      // Check user expiration
      if (user.expDate && user.expDate < Math.floor(Date.now() / 1000)) {
        return res.status(401).json({ error: "Subscription expired" });
      }
      
      // Get the stream source URL
      const stream = await storage.getStream(parseInt(streamId));
      if (!stream || !stream.streamSource) {
        return res.status(404).json({ error: "Stream not found" });
      }
      
      // Return source URL in header for Nginx
      res.setHeader("X-Source-Url", stream.streamSource);
      res.setHeader("X-User-Id", user.id.toString());
      res.setHeader("X-Stream-Id", streamId);
      res.status(200).json({ valid: true });
    } catch (error: any) {
      console.error("MAG validation error:", error);
      res.status(500).json({ error: "Validation failed" });
    }
  });

  // Backup/Export functionality
  app.post("/api/backup/export", requireAuth, async (req, res) => {
    try {
      const format = req.query.format as string || "neoserv";
      
      // Gather all data
      const users = await storage.getUsers();
      const streams = await storage.getStreams();
      const movies = await storage.getStreams(2);
      const series = await storage.getSeries();
      const categories = await storage.getCategories();
      const bouquets = await storage.getBouquets();
      const servers = await storage.getServers();
      const epgSources = await storage.getEpgSources();
      const settings = await storage.getSettings();

      let exportData: any;

      switch (format) {
        case "xui-one":
          // XUI.ONE format - flatten structure
          exportData = {
            format: "xui-one",
            version: "1.0",
            exported_at: new Date().toISOString(),
            users: users.map(u => ({
              id: u.id,
              username: u.username,
              password: u.password,
              exp_date: u.expDate,
              max_connections: u.maxConnections,
              is_trial: u.isTrial,
              is_banned: u.enabled === 0,
              admin_enabled: u.adminEnabled,
              created_at: u.createdAt,
              bouquet: u.bouquet,
            })),
            streams: streams.map(s => ({
              id: s.id,
              stream_display_name: s.streamDisplayName,
              stream_source: s.streamSource,
              category_id: s.categoryId,
              epg_channel_id: s.channelId,
            })),
            movies: movies.map((m: any) => ({
              id: m.id,
              stream_display_name: m.streamDisplayName,
              stream_source: m.streamSource,
              category_id: m.categoryId,
            })),
            series: series.map(s => ({
              id: s.id,
              title: s.title,
              category_id: s.categoryId,
            })),
            categories: categories.map(c => ({
              id: c.id,
              category_name: c.categoryName,
              category_type: c.categoryType,
              parent_id: c.parentId,
            })),
            bouquets: bouquets.map(b => ({
              id: b.id,
              bouquet_name: b.bouquetName,
              bouquet_channels: b.bouquetChannels,
              bouquet_movies: b.bouquetMovies,
              bouquet_series: b.bouquetSeries,
            })),
          };
          break;

        case "xtream-codec":
          // Xtream Codes compatible format
          exportData = {
            format: "xtream-codec",
            version: "2.0",
            exported_at: new Date().toISOString(),
            reg_users: users,
            streams: streams,
            stream_categories: categories.filter(c => c.categoryType === "live"),
            vod_categories: categories.filter(c => c.categoryType === "movie"),
            series_categories: categories.filter(c => c.categoryType === "series"),
            movie: movies,
            series: series,
            bouquets: bouquets,
            streaming_servers: servers,
            epg_sources: epgSources,
          };
          break;

        case "1-stream":
          // 1-Stream format
          exportData = {
            format: "1-stream",
            version: "1.0",
            exported_at: new Date().toISOString(),
            lines: users.map(u => ({
              username: u.username,
              password: u.password,
              expiry: u.expDate,
              connections: u.maxConnections,
              status: u.adminEnabled ? "active" : "disabled",
            })),
            channels: streams.map(s => ({
              name: s.streamDisplayName,
              source: s.streamSource,
              category: s.categoryId,
            })),
            vod: movies.map((m: any) => ({
              name: m.streamDisplayName,
              source: m.streamSource,
              category: m.categoryId,
            })),
            categories: categories,
          };
          break;

        case "nxt":
          // NXT Panel format
          exportData = {
            format: "nxt",
            version: "1.0",
            exported_at: new Date().toISOString(),
            panel_users: users,
            live_streams: streams,
            vod_streams: movies,
            series: series,
            categories: categories,
            packages: bouquets,
            servers: servers,
          };
          break;

        default:
          // Native X NeoServ format (full export)
          exportData = {
            format: "neoserv",
            version: "1.0",
            exported_at: new Date().toISOString(),
            users,
            streams,
            movies,
            series,
            categories,
            bouquets,
            servers,
            epgSources,
            settings,
          };
      }

      // Handle file format (json, sql, xml)
      const fileFormat = req.query.fileFormat as string || "json";
      
      if (fileFormat === "sql") {
        // Generate SQL dump format with proper escaping
        let sqlContent = `-- X NeoServ Database Backup\n-- Format: ${format}\n-- Exported: ${new Date().toISOString()}\n-- Version: 1.0\n\n`;
        
        // Users table SQL
        sqlContent += `-- Users\n`;
        for (const u of users) {
          sqlContent += `INSERT INTO users (id, username, password, exp_date, max_connections, is_trial, admin_enabled, created_at) VALUES (${u.id}, ${escapeSqlString(u.username)}, ${escapeSqlString(u.password)}, ${u.expDate || 'NULL'}, ${u.maxConnections}, ${u.isTrial || 0}, ${u.adminEnabled}, ${u.createdAt || 0});\n`;
        }
        
        // Streams table SQL
        sqlContent += `\n-- Streams\n`;
        for (const s of streams) {
          sqlContent += `INSERT INTO streams (id, stream_display_name, stream_source, category_id, type) VALUES (${s.id}, ${escapeSqlString(s.streamDisplayName)}, ${escapeSqlString(s.streamSource)}, ${s.categoryId || 'NULL'}, ${s.type});\n`;
        }
        
        // Categories table SQL  
        sqlContent += `\n-- Categories\n`;
        for (const c of categories) {
          sqlContent += `INSERT INTO stream_categories (id, category_name, category_type, parent_id) VALUES (${c.id}, ${escapeSqlString(c.categoryName)}, ${escapeSqlString(c.categoryType)}, ${c.parentId || 'NULL'});\n`;
        }
        
        // Bouquets table SQL - use escapeSqlJson for array/JSON fields
        sqlContent += `\n-- Bouquets\n`;
        for (const b of bouquets) {
          sqlContent += `INSERT INTO bouquets (id, bouquet_name, bouquet_channels, bouquet_movies, bouquet_series) VALUES (${b.id}, ${escapeSqlString(b.bouquetName)}, ${escapeSqlJson(b.bouquetChannels || [])}, ${escapeSqlJson(b.bouquetMovies || [])}, ${escapeSqlJson(b.bouquetSeries || [])});\n`;
        }
        
        // Series table SQL
        sqlContent += `\n-- Series\n`;
        for (const s of series) {
          sqlContent += `INSERT INTO series (id, title, category_id) VALUES (${s.id}, ${escapeSqlString(s.title)}, ${s.categoryId || 'NULL'});\n`;
        }
        
        res.setHeader('Content-Type', 'application/sql');
        res.setHeader('Content-Disposition', `attachment; filename="backup-${format}-${new Date().toISOString().split('T')[0]}.sql"`);
        return res.send(sqlContent);
      } else if (fileFormat === "xml") {
        // Generate XML format
        let xmlContent = `<?xml version="1.0" encoding="UTF-8"?>\n`;
        xmlContent += `<backup format="${format}" version="1.0" exported_at="${new Date().toISOString()}">\n`;
        
        // Users
        xmlContent += `  <users>\n`;
        for (const u of users) {
          xmlContent += `    <user id="${u.id}">\n`;
          xmlContent += `      <username><![CDATA[${u.username}]]></username>\n`;
          xmlContent += `      <password><![CDATA[${u.password}]]></password>\n`;
          xmlContent += `      <exp_date>${u.expDate || ''}</exp_date>\n`;
          xmlContent += `      <max_connections>${u.maxConnections}</max_connections>\n`;
          xmlContent += `      <is_trial>${u.isTrial || 0}</is_trial>\n`;
          xmlContent += `      <admin_enabled>${u.adminEnabled}</admin_enabled>\n`;
          xmlContent += `    </user>\n`;
        }
        xmlContent += `  </users>\n`;
        
        // Streams
        xmlContent += `  <streams>\n`;
        for (const s of streams) {
          xmlContent += `    <stream id="${s.id}">\n`;
          xmlContent += `      <display_name><![CDATA[${s.streamDisplayName}]]></display_name>\n`;
          xmlContent += `      <source><![CDATA[${s.streamSource || ''}]]></source>\n`;
          xmlContent += `      <category_id>${s.categoryId || ''}</category_id>\n`;
          xmlContent += `      <type>${s.type}</type>\n`;
          xmlContent += `    </stream>\n`;
        }
        xmlContent += `  </streams>\n`;
        
        // Categories
        xmlContent += `  <categories>\n`;
        for (const c of categories) {
          xmlContent += `    <category id="${c.id}">\n`;
          xmlContent += `      <name><![CDATA[${c.categoryName}]]></name>\n`;
          xmlContent += `      <type>${c.categoryType}</type>\n`;
          xmlContent += `      <parent_id>${c.parentId || ''}</parent_id>\n`;
          xmlContent += `    </category>\n`;
        }
        xmlContent += `  </categories>\n`;
        
        // Bouquets
        xmlContent += `  <bouquets>\n`;
        for (const b of bouquets) {
          xmlContent += `    <bouquet id="${b.id}">\n`;
          xmlContent += `      <name><![CDATA[${b.bouquetName}]]></name>\n`;
          xmlContent += `      <channels>${JSON.stringify(b.bouquetChannels || [])}</channels>\n`;
          xmlContent += `      <movies>${JSON.stringify(b.bouquetMovies || [])}</movies>\n`;
          xmlContent += `      <series>${JSON.stringify(b.bouquetSeries || [])}</series>\n`;
          xmlContent += `    </bouquet>\n`;
        }
        xmlContent += `  </bouquets>\n`;
        
        // Series
        xmlContent += `  <series_list>\n`;
        for (const s of series) {
          xmlContent += `    <series id="${s.id}">\n`;
          xmlContent += `      <title><![CDATA[${s.title}]]></title>\n`;
          xmlContent += `      <category_id>${s.categoryId || ''}</category_id>\n`;
          xmlContent += `    </series>\n`;
        }
        xmlContent += `  </series_list>\n`;
        
        xmlContent += `</backup>`;
        
        res.setHeader('Content-Type', 'application/xml');
        res.setHeader('Content-Disposition', `attachment; filename="backup-${format}-${new Date().toISOString().split('T')[0]}.xml"`);
        return res.send(xmlContent);
      }
      
      // Default: JSON format
      res.json(exportData);
    } catch (error: any) {
      console.error("Export error:", error);
      res.status(500).json({ error: "Export failed" });
    }
  });

  // Full Database Backup (PostgreSQL pg_dump style)
  app.post("/api/backup/full", requireAuth, async (req, res) => {
    try {
      const users = await storage.getUsers();
      const streams = await storage.getStreams();
      const movies = await storage.getStreams(2);
      const series = await storage.getSeries();
      const episodes = await storage.getSeriesEpisodes();
      const categories = await storage.getCategories();
      const bouquets = await storage.getBouquets();
      const servers = await storage.getServers();
      const epgSources = await storage.getEpgSources();
      const settings = await storage.getSettings();
      const admins = await storage.getAdmins();
      const blockedIps = await storage.getBlockedIps();
      const blockedUserAgents = await storage.getBlockedUserAgents();
      const allowedIps = await storage.getAllowedIps();
      const magDevices = await storage.getMagDevices();

      const fullBackup = {
        format: "neoserv-full",
        version: "1.0",
        exported_at: new Date().toISOString(),
        checksum: Date.now().toString(36),
        data: {
          users,
          streams,
          movies,
          series,
          episodes,
          categories,
          bouquets,
          servers,
          epgSources,
          settings,
          admins: admins.map(a => ({ ...a, password: "***REDACTED***" })),
          blockedIps,
          blockedUserAgents,
          allowedIps,
          magDevices,
        },
        stats: {
          users: users.length,
          streams: streams.length,
          movies: movies.length,
          series: series.length,
          episodes: episodes.length,
          categories: categories.length,
          bouquets: bouquets.length,
          servers: servers.length,
          epgSources: epgSources.length,
        }
      };

      // Store backup metadata
      const backupId = Date.now().toString(36);
      await storage.setSetting(`backup_${backupId}`, JSON.stringify({
        id: backupId,
        date: new Date().toISOString(),
        size: JSON.stringify(fullBackup).length,
        stats: fullBackup.stats,
      }));
      await storage.setSetting("last_backup", new Date().toISOString());

      res.json(fullBackup);
    } catch (error: any) {
      console.error("Full backup error:", error);
      res.status(500).json({ error: "Full backup failed" });
    }
  });

  // Restore backup with validation
  app.post("/api/backup/restore", requireAuth, async (req, res) => {
    try {
      // Validate request body with Zod schema
      const parseResult = restoreRequestSchema.safeParse(req.body);
      
      if (!parseResult.success) {
        const errors = parseResult.error.errors.map(e => `${e.path.join('.')}: ${e.message}`);
        return res.status(400).json({ 
          error: "Invalid backup data structure",
          details: errors
        });
      }
      
      const { data, options } = parseResult.data;

      const importResults = {
        users: 0,
        streams: 0,
        categories: 0,
        bouquets: 0,
        series: 0,
        errors: [] as string[],
      };

      const restoreOptions = {
        overwrite: options?.overwrite ?? false,
        skipExisting: options?.skipExisting ?? true,
        importUsers: options?.importUsers ?? true,
        importStreams: options?.importStreams ?? true,
        importCategories: options?.importCategories ?? true,
        importBouquets: options?.importBouquets ?? true,
        importSeries: options?.importSeries ?? true,
      };

      // Import Categories first (dependencies)
      if (restoreOptions.importCategories && data.categories) {
        const categories = data.data?.categories || data.categories;
        for (const cat of categories) {
          try {
            await storage.createCategory({
              categoryName: cat.categoryName || cat.category_name || cat.name,
              categoryType: cat.categoryType || cat.category_type || cat.type || "live",
              parentId: cat.parentId || cat.parent_id || null,
              catOrder: cat.catOrder || cat.cat_order || 0,
            });
            importResults.categories++;
          } catch (e: any) {
            if (!e.message?.includes("duplicate")) {
              importResults.errors.push(`Category: ${e.message}`);
            }
          }
        }
      }

      // Import Bouquets
      if (restoreOptions.importBouquets && (data.bouquets || data.data?.bouquets)) {
        const bouquets = data.data?.bouquets || data.bouquets || [];
        for (const b of bouquets) {
          try {
            await storage.createBouquet({
              bouquetName: b.bouquetName || b.bouquet_name || b.name,
              bouquetChannels: b.bouquetChannels || b.bouquet_channels || [],
              bouquetMovies: b.bouquetMovies || b.bouquet_movies || [],
              bouquetSeries: b.bouquetSeries || b.bouquet_series || [],
              bouquetOrder: b.bouquetOrder || b.bouquet_order || 0,
            });
            importResults.bouquets++;
          } catch (e: any) {
            if (!e.message?.includes("duplicate")) {
              importResults.errors.push(`Bouquet: ${e.message}`);
            }
          }
        }
      }

      // Import Streams
      if (restoreOptions.importStreams && (data.streams || data.data?.streams)) {
        const streams = data.data?.streams || data.streams || [];
        for (const s of streams) {
          try {
            await storage.createStream({
              streamDisplayName: s.streamDisplayName || s.stream_display_name || s.name,
              streamSource: s.streamSource || s.stream_source || s.source,
              categoryId: s.categoryId || s.category_id || null,
              type: s.type || 1,
              notes: s.notes || null,
              order: s.order || 0,
              channelId: s.channelId || s.channel_id || null,
              streamIcon: s.streamIcon || s.stream_icon || null,
              customFfmpeg: s.customFfmpeg || null,
              customSid: s.customSid || null,
            });
            importResults.streams++;
          } catch (e: any) {
            if (!e.message?.includes("duplicate")) {
              importResults.errors.push(`Stream: ${e.message}`);
            }
          }
        }
      }

      // Import Users
      if (restoreOptions.importUsers && (data.users || data.data?.users || data.lines || data.reg_users)) {
        const users = data.data?.users || data.users || data.lines || data.reg_users || [];
        for (const u of users) {
          try {
            await storage.createUser({
              username: u.username,
              password: u.password,
              expDate: u.expDate || u.exp_date || u.expiry || null,
              maxConnections: u.maxConnections || u.max_connections || u.connections || 1,
              isTrial: u.isTrial || u.is_trial || 0,
              adminEnabled: u.adminEnabled || u.admin_enabled || (u.status === "active" ? 1 : 0),
              bouquet: u.bouquet || [],
              enabled: 1,
              memberId: null,
              adminNotes: u.adminNotes || "",
              resellerNotes: u.resellerNotes || "",
            });
            importResults.users++;
          } catch (e: any) {
            if (!e.message?.includes("duplicate")) {
              importResults.errors.push(`User: ${e.message}`);
            }
          }
        }
      }

      // Import Series
      if (restoreOptions.importSeries && (data.series || data.data?.series)) {
        const series = data.data?.series || data.series || [];
        for (const s of series) {
          try {
            await storage.createSeries({
              title: s.title || s.name,
              categoryId: s.categoryId || s.category_id || null,
              cover: s.cover || null,
              plot: s.plot || null,
              cast: s.cast || null,
              director: s.director || null,
              genre: s.genre || null,
              releaseDate: s.releaseDate || s.release_date || null,
              rating: s.rating || null,
              backdropPath: s.backdropPath || s.backdrop_path || [],
            });
            importResults.series++;
          } catch (e: any) {
            if (!e.message?.includes("duplicate")) {
              importResults.errors.push(`Series: ${e.message}`);
            }
          }
        }
      }

      await storage.setSetting("last_restore", new Date().toISOString());

      res.json({
        success: true,
        imported: importResults,
        message: `Restored ${importResults.users} users, ${importResults.streams} streams, ${importResults.categories} categories, ${importResults.bouquets} bouquets, ${importResults.series} series`,
      });
    } catch (error: any) {
      console.error("Restore error:", error);
      res.status(500).json({ error: "Restore failed: " + error.message });
    }
  });

  // Scheduled backups management
  app.get("/api/backup/schedules", requireAuth, async (req, res) => {
    try {
      const schedulesData = await storage.getSetting("backup_schedules");
      const schedulesValue = typeof schedulesData === 'string' ? schedulesData : schedulesData?.value;
      res.json(schedulesValue ? JSON.parse(schedulesValue) : []);
    } catch (error) {
      res.json([]);
    }
  });

  app.post("/api/backup/schedules", requireAuth, async (req, res) => {
    try {
      const { frequency, time, retention, enabled } = req.body;
      
      if (!frequency || !["daily", "weekly", "monthly"].includes(frequency)) {
        return res.status(400).json({ error: "Invalid frequency (daily, weekly, monthly)" });
      }

      const existingData = await storage.getSetting("backup_schedules");
      const existingValue = typeof existingData === 'string' ? existingData : existingData?.value;
      const schedules = existingValue ? JSON.parse(existingValue) : [];
      
      const newSchedule = {
        id: Date.now().toString(36),
        frequency,
        time: time || "03:00",
        retention: retention || 7,
        enabled: enabled !== false,
        createdAt: new Date().toISOString(),
        lastRun: null,
        nextRun: calculateNextRun(frequency, time || "03:00"),
      };

      schedules.push(newSchedule);
      await storage.setSetting("backup_schedules", JSON.stringify(schedules));

      res.status(201).json(newSchedule);
    } catch (error: any) {
      res.status(500).json({ error: "Failed to create schedule" });
    }
  });

  app.delete("/api/backup/schedules/:id", requireAuth, async (req, res) => {
    try {
      const existingData = await storage.getSetting("backup_schedules");
      const existingValue = typeof existingData === 'string' ? existingData : existingData?.value;
      const schedules = existingValue ? JSON.parse(existingValue) : [];
      const filtered = schedules.filter((s: any) => s.id !== req.params.id);
      await storage.setSetting("backup_schedules", JSON.stringify(filtered));
      res.json({ message: "Schedule deleted" });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete schedule" });
    }
  });

  // ===============================
  // LICENSE MANAGEMENT
  // ===============================
  
  // Generate license key helper function
  function generateLicenseKey(): string {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    const segments = [];
    for (let s = 0; s < 4; s++) {
      let segment = '';
      for (let i = 0; i < 4; i++) {
        segment += chars[Math.floor(Math.random() * chars.length)];
      }
      segments.push(segment);
    }
    return 'NEO-' + segments.join('-');
  }

  // Get all licenses (developer only - requires active developer license)
  app.get("/api/licenses", requireAuth, async (req, res) => {
    try {
      // Verify requester has a developer license
      const activeLicense = await storage.getActiveLicense();
      if (!activeLicense || activeLicense.licenseType !== 'developer') {
        return res.status(403).json({ error: "Developer license required" });
      }

      const licenses = await storage.getLicenses();
      
      // Developer can see full keys for:
      // 1. Their own developer license
      // 2. All client licenses they generated (so they can share with clients)
      // Other developer licenses are masked for security
      const maskedLicenses = licenses.map(license => ({
        ...license,
        licenseKey: (license.id === activeLicense.id || license.licenseType === 'client')
          ? license.licenseKey 
          : (license.licenseKey ? 'NEO-****-****-****-' + license.licenseKey.slice(-4) : null)
      }));
      
      res.json(maskedLicenses);
    } catch (error) {
      res.status(500).json({ error: "Failed to get licenses" });
    }
  });

  // Get current license status
  app.get("/api/license/status", async (req, res) => {
    try {
      const activeLicense = await storage.getActiveLicense();
      if (!activeLicense) {
        return res.json({ 
          licensed: false,
          requiresActivation: true 
        });
      }
      
      const now = Math.floor(Date.now() / 1000);
      const daysRemaining = activeLicense.expiresAt 
        ? Math.ceil((activeLicense.expiresAt - now) / 86400) 
        : null;
      
      // Mask license key for security - show only last 4 characters
      const maskedKey = activeLicense.licenseKey 
        ? 'NEO-****-****-****-' + activeLicense.licenseKey.slice(-4)
        : null;

      res.json({
        licensed: true,
        licenseType: activeLicense.licenseType,
        status: activeLicense.status,
        expiresAt: activeLicense.expiresAt,
        daysRemaining: activeLicense.licenseType === 'developer' ? null : daysRemaining,
        email: activeLicense.email,
        licenseKey: maskedKey,
        activatedAt: activeLicense.activatedAt,
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to check license" });
    }
  });

  // Generate a unique server identifier
  function generateServerId(req: Request): string {
    const hostname = require('os').hostname();
    const platform = require('os').platform();
    const cpuCount = require('os').cpus().length;
    // Create a fingerprint from server characteristics
    return require('crypto')
      .createHash('sha256')
      .update(`${hostname}-${platform}-${cpuCount}`)
      .digest('hex')
      .substring(0, 32);
  }

  // Activate/validate a license key
  app.post("/api/license/activate", async (req, res) => {
    try {
      const { licenseKey } = req.body;
      if (!licenseKey) {
        return res.status(400).json({ error: "License key is required" });
      }

      const result = await storage.validateLicense(licenseKey);
      if (!result.valid) {
        return res.status(400).json({ error: result.error });
      }

      const license = result.license;
      if (!license) {
        return res.status(400).json({ error: "License not found" });
      }

      // Generate server fingerprint
      const serverId = generateServerId(req);
      const serverHostname = require('os').hostname();
      const serverIp = req.ip || req.socket.remoteAddress || 'unknown';
      const now = Math.floor(Date.now() / 1000);

      // Check if this is a client license (developer licenses don't need binding)
      if (license.licenseType === 'client') {
        // Check if license is already bound to a different server
        if (license.boundServerId && license.boundServerId !== serverId) {
          return res.status(403).json({ 
            error: "License already activated on another server",
            message: "This license key is bound to a different server. Contact your administrator to reset the binding."
          });
        }

        // Bind license to this server if not already bound
        await storage.updateLicense(license.id, {
          activatedAt: license.activatedAt || now,
          status: "active",
          boundServerId: serverId,
          boundServerHostname: serverHostname,
          boundServerIp: serverIp,
          boundAt: license.boundAt || now,
        });
      } else {
        // Developer license - just mark as activated
        await storage.updateLicense(license.id, {
          activatedAt: license.activatedAt || now,
          status: "active",
        });
      }

      res.json({ 
        success: true, 
        message: "License activated successfully",
        licenseType: license.licenseType,
        boundToServer: license.licenseType === 'client'
      });
    } catch (error) {
      res.status(500).json({ error: "License activation failed" });
    }
  });

  // Generate a new license (developer only)
  app.post("/api/licenses/generate", requireAuth, async (req, res) => {
    try {
      // Check if current user has developer license
      const activeLicense = await storage.getActiveLicense();
      if (!activeLicense || activeLicense.licenseType !== 'developer') {
        return res.status(403).json({ error: "Developer license required to generate licenses" });
      }

      const { email, durationDays } = req.body;
      if (!email) {
        return res.status(400).json({ error: "Client email is required" });
      }

      const now = Math.floor(Date.now() / 1000);
      const expiresAt = now + (durationDays || 30) * 86400;

      const license = await storage.createLicense({
        licenseKey: generateLicenseKey(),
        licenseType: "client",
        email,
        status: "active",
        durationDays: durationDays || 30,
        createdAt: now,
        expiresAt,
        generatedBy: activeLicense.id,
      });

      res.status(201).json(license);
    } catch (error: any) {
      res.status(500).json({ error: "Failed to generate license" });
    }
  });

  // Delete/revoke license
  app.delete("/api/licenses/:id", requireAuth, async (req, res) => {
    try {
      const activeLicense = await storage.getActiveLicense();
      if (!activeLicense || activeLicense.licenseType !== 'developer') {
        return res.status(403).json({ error: "Developer license required" });
      }

      const deleted = await storage.deleteLicense(parseInt(req.params.id));
      if (!deleted) {
        return res.status(404).json({ error: "License not found" });
      }
      res.json({ message: "License deleted" });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete license" });
    }
  });

  // Reset/unbind license from server (developer only)
  app.post("/api/licenses/:id/reset-binding", requireAuth, async (req, res) => {
    try {
      // Verify requester has developer license
      const activeLicense = await storage.getActiveLicense();
      if (!activeLicense || activeLicense.licenseType !== 'developer') {
        return res.status(403).json({ error: "Developer license required" });
      }

      const licenseId = parseInt(req.params.id);
      const licenses = await storage.getLicenses();
      const license = licenses.find(l => l.id === licenseId);
      
      if (!license) {
        return res.status(404).json({ error: "License not found" });
      }

      // Only client licenses can be reset (developer licenses don't have binding)
      if (license.licenseType !== 'client') {
        return res.status(400).json({ error: "Only client licenses can be reset" });
      }

      // Check if license is actually bound
      if (!license.boundServerId) {
        return res.status(400).json({ error: "License is not bound to any server" });
      }

      // Reset the server binding
      await storage.updateLicense(licenseId, {
        boundServerId: null,
        boundServerHostname: null,
        boundServerIp: null,
        boundAt: null,
      });

      res.json({ 
        success: true, 
        message: "License binding reset successfully. Client can now activate on a new server." 
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to reset license binding" });
    }
  });

  // Seed developer license (one-time setup)
  // In production: requires DEVELOPER_KEY env variable and matching key in request
  // In development: always allowed
  app.post("/api/license/seed-developer", async (req, res) => {
    const { developerKey } = req.body || {};
    const envDeveloperKey = process.env.DEVELOPER_KEY;
    
    // In production, require DEVELOPER_KEY match
    if (process.env.NODE_ENV === "production") {
      if (!envDeveloperKey) {
        return res.status(403).json({ error: "Developer activation not configured on this server" });
      }
      if (!developerKey || developerKey !== envDeveloperKey) {
        return res.status(403).json({ error: "Invalid developer key" });
      }
    }
    
    try {
      // Check if developer license already exists
      const existingLicenses = await storage.getLicenses();
      const hasDevLicense = existingLicenses.some(l => l.licenseType === 'developer');
      
      if (hasDevLicense) {
        return res.status(400).json({ error: "Developer license already exists" });
      }

      const now = Math.floor(Date.now() / 1000);
      const license = await storage.createLicense({
        licenseKey: generateLicenseKey(),
        licenseType: "developer",
        email: "developer@neoserv.com",
        status: "active",
        durationDays: 0,
        createdAt: now,
        expiresAt: null,
        activatedAt: now,
      });

      res.status(201).json({
        success: true,
        message: "Developer license created",
        license
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to create developer license" });
    }
  });

  // Backup info/status
  app.get("/api/backup/info", requireAuth, async (req, res) => {
    try {
      const lastBackupData = await storage.getSetting("last_backup");
      const lastRestoreData = await storage.getSetting("last_restore");
      const schedulesData = await storage.getSetting("backup_schedules");
      
      const lastBackup = typeof lastBackupData === 'string' ? lastBackupData : lastBackupData?.value;
      const lastRestore = typeof lastRestoreData === 'string' ? lastRestoreData : lastRestoreData?.value;
      const schedulesValue = typeof schedulesData === 'string' ? schedulesData : schedulesData?.value;
      
      // Calculate approximate database size
      const users = await storage.getUsers();
      const streams = await storage.getStreams();
      const series = await storage.getSeries();
      const categories = await storage.getCategories();
      
      const estimatedSize = (users.length * 500) + (streams.length * 300) + (series.length * 400) + (categories.length * 100);

      res.json({
        lastBackup: lastBackup || null,
        lastRestore: lastRestore || null,
        scheduledBackups: schedulesValue ? JSON.parse(schedulesValue).length : 0,
        estimatedDatabaseSize: estimatedSize,
        formattedSize: formatBytes(estimatedSize),
        stats: {
          users: users.length,
          streams: streams.length,
          series: series.length,
          categories: categories.length,
        }
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to get backup info" });
    }
  });

  // Security - Blocked IPs
  app.get("/api/security/blocked-ips", requireAuth, async (req, res) => {
    const blockedIps = await storage.getBlockedIps();
    res.json(blockedIps);
  });

  app.post("/api/security/blocked-ips", requireAuth, async (req, res) => {
    try {
      const { ip, notes } = req.body;
      if (!ip) {
        return res.status(400).json({ error: "IP address is required" });
      }
      const blockedIp = await storage.createBlockedIp({
        ip,
        notes: notes || "",
        date: Math.floor(Date.now() / 1000),
        attemptsBlocked: 0,
      });
      res.status(201).json(blockedIp);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.delete("/api/security/blocked-ips/:id", requireAuth, async (req, res) => {
    const deleted = await storage.deleteBlockedIp(parseInt(req.params.id));
    if (!deleted) {
      return res.status(404).json({ error: "Blocked IP not found" });
    }
    res.json({ message: "IP unblocked successfully" });
  });

  // Security - Blocked User Agents
  app.get("/api/security/blocked-user-agents", requireAuth, async (req, res) => {
    const blockedUserAgents = await storage.getBlockedUserAgents();
    res.json(blockedUserAgents);
  });

  app.post("/api/security/blocked-user-agents", requireAuth, async (req, res) => {
    try {
      const { userAgent, exactMatch } = req.body;
      if (!userAgent) {
        return res.status(400).json({ error: "User agent is required" });
      }
      const blockedUa = await storage.createBlockedUserAgent({
        userAgent,
        exactMatch: exactMatch ? 1 : 0,
        attemptsBlocked: 0,
      });
      res.status(201).json(blockedUa);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.delete("/api/security/blocked-user-agents/:id", requireAuth, async (req, res) => {
    const deleted = await storage.deleteBlockedUserAgent(parseInt(req.params.id));
    if (!deleted) {
      return res.status(404).json({ error: "Blocked user agent not found" });
    }
    res.json({ message: "User agent unblocked successfully" });
  });

  // Security - Allowed IPs (Whitelist)
  app.get("/api/security/allowed-ips", requireAuth, async (req, res) => {
    const allowedIps = await storage.getAllowedIps();
    res.json(allowedIps);
  });

  app.post("/api/security/allowed-ips", requireAuth, async (req, res) => {
    try {
      const { ip, notes } = req.body;
      if (!ip) {
        return res.status(400).json({ error: "IP address is required" });
      }
      const allowedIp = await storage.createAllowedIp({
        ip,
        notes: notes || "",
        date: Math.floor(Date.now() / 1000),
      });
      res.status(201).json(allowedIp);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.delete("/api/security/allowed-ips/:id", requireAuth, async (req, res) => {
    const deleted = await storage.deleteAllowedIp(parseInt(req.params.id));
    if (!deleted) {
      return res.status(404).json({ error: "Allowed IP not found" });
    }
    res.json({ message: "IP removed from whitelist successfully" });
  });

  // X NeoServ Compatible Player API
  app.get("/player_api.php", async (req, res) => {
    const { username, password, action } = req.query;
    const userIp = (req.headers["x-forwarded-for"] as string)?.split(",")[0]?.trim() || req.socket.remoteAddress || "";
    
    // Rate limiting - anti-scanning protection for API
    const rateCheck = checkRateLimit(userIp);
    if (!rateCheck.allowed) {
      return res.status(429).json({ error: "Too many requests. Try again later." });
    }
    
    if (!username || !password) {
      return res.json({ user_info: null, server_info: null });
    }

    const user = await storage.getUserByUsername(username as string);
    if (!user || user.password !== password) {
      return res.json({ user_info: null, server_info: null });
    }

    const now = Math.floor(Date.now() / 1000);
    const isExpired = user.expDate && user.expDate <= now;
    const isDisabled = user.enabled === 0 || user.adminEnabled === 0;

    const servers = await storage.getServers();
    const mainServer = servers.find(s => s.isMain === 1) || servers[0];
    const serverUrl = mainServer?.domainName || "localhost";
    const serverPort = mainServer?.httpBroadcastPort || 80;

    const userInfo = {
      username: user.username,
      password: user.password,
      message: "",
      auth: isExpired || isDisabled ? 0 : 1,
      status: isExpired ? "Expired" : (isDisabled ? "Disabled" : "Active"),
      exp_date: user.expDate?.toString() || "",
      is_trial: user.isTrial?.toString() || "0",
      active_cons: "0",
      created_at: user.createdAt?.toString() || "",
      max_connections: user.maxConnections?.toString() || "1",
      allowed_output_formats: ["m3u8", "ts"],
    };

    const serverInfo = {
      url: serverUrl,
      port: serverPort.toString(),
      https_port: mainServer?.httpsBroadcastPort?.toString() || "443",
      server_protocol: "http",
      rtmp_port: mainServer?.rtmpPort?.toString() || "1935",
      timezone: "UTC",
      timestamp_now: now,
      time_now: new Date().toISOString(),
    };

    if (!action || action === "get_account_info") {
      return res.json({ user_info: userInfo, server_info: serverInfo });
    }

    if (action === "get_live_categories") {
      const categories = await storage.getCategories("live");
      return res.json(categories.map(c => ({
        category_id: c.id.toString(),
        category_name: c.categoryName,
        parent_id: c.parentId?.toString() || "0",
      })));
    }

    if (action === "get_vod_categories") {
      const categories = await storage.getCategories("movie");
      return res.json(categories.map(c => ({
        category_id: c.id.toString(),
        category_name: c.categoryName,
        parent_id: c.parentId?.toString() || "0",
      })));
    }

    if (action === "get_series_categories") {
      const categories = await storage.getCategories("series");
      return res.json(categories.map(c => ({
        category_id: c.id.toString(),
        category_name: c.categoryName,
        parent_id: c.parentId?.toString() || "0",
      })));
    }

    if (action === "get_live_streams") {
      const categoryId = req.query.category_id as string | undefined;
      let liveStreams = await storage.getStreams(STREAM_TYPE_LIVE);
      
      // Filter by user's bouquet assignments
      const allowedIds = await getUserAllowedStreamIds(user, storage, "channels");
      if (allowedIds.length > 0) {
        // Order by bouquet assignment order
        liveStreams = allowedIds.map(id => liveStreams.find(s => s.id === id)).filter(Boolean) as typeof liveStreams;
      }
      
      if (categoryId) {
        liveStreams = liveStreams.filter(s => s.categoryId?.toString() === categoryId);
      }
      return res.json(liveStreams.map((s, i) => ({
        num: i + 1,
        name: s.streamDisplayName,
        stream_type: "live",
        stream_id: s.id,
        stream_icon: s.streamIcon || "",
        epg_channel_id: s.channelId || "",
        category_id: s.categoryId?.toString() || "1",
        tv_archive: s.tvArchiveDuration > 0 ? 1 : 0,
        tv_archive_duration: s.tvArchiveDuration || 0,
      })));
    }

    if (action === "get_vod_streams") {
      const categoryId = req.query.category_id as string | undefined;
      let movies = await storage.getStreams(STREAM_TYPE_MOVIE);
      
      // Filter by user's bouquet assignments
      const allowedIds = await getUserAllowedStreamIds(user, storage, "movies");
      if (allowedIds.length > 0) {
        movies = allowedIds.map(id => movies.find(m => m.id === id)).filter(Boolean) as typeof movies;
      }
      
      if (categoryId) {
        movies = movies.filter(m => m.categoryId?.toString() === categoryId);
      }
      return res.json(movies.map((m, i) => ({
        num: i + 1,
        name: m.streamDisplayName,
        stream_type: "movie",
        stream_id: m.id,
        stream_icon: m.streamIcon || "",
        category_id: m.categoryId?.toString() || "1",
        container_extension: "mp4",
      })));
    }

    if (action === "get_series") {
      const categoryId = req.query.category_id as string | undefined;
      let allSeries = await storage.getSeries();
      
      // Filter by user's bouquet assignments
      const allowedIds = await getUserAllowedStreamIds(user, storage, "series");
      if (allowedIds.length > 0) {
        allSeries = allowedIds.map(id => allSeries.find(s => s.id === id)).filter(Boolean) as typeof allSeries;
      }
      
      if (categoryId) {
        allSeries = allSeries.filter(s => s.categoryId?.toString() === categoryId);
      }
      return res.json(allSeries.map(s => ({
        series_id: s.id,
        name: s.title,
        cover: s.cover || "",
        plot: s.plot || "",
        cast: s.cast || "",
        director: s.director || "",
        genre: s.genre || "",
        release_date: s.releaseDate || "",
        rating: s.rating?.toString() || "0",
        category_id: s.categoryId?.toString() || "1",
        backdrop_path: s.backdropPath ? [s.backdropPath] : [],
      })));
    }

    return res.json({ user_info: userInfo, server_info: serverInfo });
  });

  // XMLTV EPG endpoint - returns EPG data in XMLTV format for players
  app.get("/xmltv.php", async (req, res) => {
    const { username, password } = req.query;
    const userIp = (req.headers["x-forwarded-for"] as string)?.split(",")[0]?.trim() || req.socket.remoteAddress || "";
    
    // Rate limiting
    const rateCheck = checkRateLimit(userIp);
    if (!rateCheck.allowed) {
      return res.status(429).send("Too many requests. Try again later.");
    }
    
    if (!username || !password) {
      return res.status(401).send("Invalid credentials");
    }

    const user = await storage.getUserByUsername(username as string);
    if (!user || user.password !== password) {
      return res.status(401).send("Invalid credentials");
    }

    const now = Math.floor(Date.now() / 1000);
    if (user.expDate && user.expDate <= now) {
      return res.status(403).send("Account expired");
    }
    if (user.enabled === 0 || user.adminEnabled === 0) {
      return res.status(403).send("Account disabled");
    }

    // Get all streams with channelId mappings
    const streams = await storage.getStreams(1); // Live streams
    const channelMap = new Map<string, { name: string; icon: string }>();
    for (const stream of streams) {
      if (stream.channelId) {
        channelMap.set(stream.channelId, {
          name: stream.streamDisplayName,
          icon: stream.streamIcon || ""
        });
      }
    }

    // Get all EPG data
    const epgDataList = await storage.getAllEpgData();

    // Build XMLTV format
    let xml = '<?xml version="1.0" encoding="UTF-8"?>\n';
    xml += '<!DOCTYPE tv SYSTEM "xmltv.dtd">\n';
    xml += '<tv generator-info-name="X NeoServ" generator-info-url="https://xneoserv.com">\n';

    // Add channel definitions
    const uniqueChannels = new Set<string>();
    for (const epg of epgDataList) {
      if (!uniqueChannels.has(epg.channelId)) {
        uniqueChannels.add(epg.channelId);
        const channelInfo = channelMap.get(epg.channelId);
        const displayName = channelInfo?.name || epg.channelId;
        const icon = channelInfo?.icon || "";
        
        xml += `  <channel id="${escapeXml(epg.channelId)}">\n`;
        xml += `    <display-name>${escapeXml(displayName)}</display-name>\n`;
        if (icon) {
          xml += `    <icon src="${escapeXml(icon)}" />\n`;
        }
        xml += `  </channel>\n`;
      }
    }

    // Add programme entries
    for (const epg of epgDataList) {
      const startTime = formatXmltvTime(epg.start);
      const endTime = formatXmltvTime(epg.end || epg.start + 3600);
      
      xml += `  <programme start="${startTime}" stop="${endTime}" channel="${escapeXml(epg.channelId)}">\n`;
      xml += `    <title lang="${epg.lang || 'en'}">${escapeXml(epg.title)}</title>\n`;
      if (epg.description) {
        xml += `    <desc lang="${epg.lang || 'en'}">${escapeXml(epg.description)}</desc>\n`;
      }
      xml += `  </programme>\n`;
    }

    xml += '</tv>\n';

    res.setHeader("Content-Type", "application/xml; charset=utf-8");
    res.setHeader("Content-Disposition", 'attachment; filename="epg.xml"');
    res.send(xml);
  });

  // M3U/Enigma2 Playlist Generation
  app.get("/get.php", async (req, res) => {
    const { username, password, type, output } = req.query;
    const userIp = (req.headers["x-forwarded-for"] as string)?.split(",")[0]?.trim() || req.socket.remoteAddress || "";
    
    // Rate limiting - anti-scanning protection for playlists
    const rateCheck = checkRateLimit(userIp);
    if (!rateCheck.allowed) {
      return res.status(429).send("Too many requests. Try again later.");
    }
    
    if (!username || !password) {
      return res.status(401).send("Invalid credentials");
    }

    const user = await storage.getUserByUsername(username as string);
    if (!user || user.password !== password) {
      return res.status(401).send("Invalid credentials");
    }

    const now = Math.floor(Date.now() / 1000);
    if (user.expDate && user.expDate <= now) {
      return res.status(403).send("Account expired");
    }
    if (user.enabled === 0 || user.adminEnabled === 0) {
      return res.status(403).send("Account disabled");
    }

    const playlistType = (type as string) || "m3u_plus";
    const contentType = (output as string) || "ts";
    
    const playlist = await storage.generatePlaylist(user.id, playlistType, "all");
    
    res.setHeader("Content-Type", "audio/x-mpegurl");
    res.setHeader("Content-Disposition", `attachment; filename="${username}.m3u"`);
    res.send(playlist);
  });

  // Live stream endpoint - creates token and proxies via HLS system
  // Supports both regular users (username/password) and MAG devices (mac/MAC_ADDRESS)
  app.get("/live/:username/:password/:streamId.:ext", async (req, res) => {
    const { username, password, streamId, ext } = req.params;
    const userIp = (req.headers["x-forwarded-for"] as string)?.split(",")[0]?.trim() || req.socket.remoteAddress || "";
    
    console.log(`[LIVE] Request: ${username}/${password}/${streamId}.${ext} from ${userIp}`);
    
    // No rate limiting on live streams - already protected by user authentication
    // Session is valid for 24h, token for 4h
    
    let user: any = null;
    let magDevice: any = null;
    const now = Math.floor(Date.now() / 1000);
    
    // Check if this is a MAG device authentication (username = "mac", password = MAC address)
    if (username.toLowerCase() === "mac") {
      // Password is the MAC address (normalized, no colons)
      const normalizedMac = password.toUpperCase().replace(/:/g, "");
      const devices = await storage.getMagDevices();
      magDevice = devices.find(d => d.mac.toUpperCase().replace(/:/g, "") === normalizedMac);
      
      if (!magDevice) {
        return res.status(401).send("MAG device not registered");
      }
      
      // Check device expiry
      if (magDevice.expiry) {
        const expiryDate = new Date(magDevice.expiry).getTime() / 1000;
        if (expiryDate <= now) {
          return res.status(403).send("Device expired");
        }
      }
      
      // If device has linked user, use that for connection tracking
      if (magDevice.userId) {
        user = await storage.getUser(magDevice.userId);
      }
      
      // Update device last activity
      await storage.updateMagDevice(magDevice.magId, { lastActive: now });
    } else {
      // Regular user authentication
      user = await storage.getUserByUsername(username);
      if (!user || user.password !== password) {
        return res.status(401).send("Invalid credentials");
      }

      // Check if user is enabled and not expired
      if (user.expDate && user.expDate <= now) {
        return res.status(403).send("Account expired");
      }
      if (user.enabled === 0 || user.adminEnabled === 0) {
        return res.status(403).send("Account disabled");
      }
    }

    // Try to find stream by ID first, then by number (XUI uses stream numbers)
    let stream = await storage.getStream(parseInt(streamId));
    if (!stream) {
      // Fallback: XUI/Xtream uses stream number, not ID
      const allStreams = await storage.getStreams(1); // type=1 for live streams
      stream = allStreams.find(s => s.number === parseInt(streamId));
    }
    if (!stream || !stream.streamSource) {
      return res.status(404).send("Stream not found");
    }

    // =========================================
    // CONNECTION MANAGEMENT - MUST HAPPEN FIRST
    // Before redirect so LB heartbeats can update connection
    // =========================================
    
    // Get geolocation for IP (async, non-blocking with cache)
    const geo = await getGeoLocation(userIp);
    
    // Determine LB server selection first (we need serverId for connection)
    let selectedLB: LBServer | null = null;
    const isFromLbRedirect = req.headers["x-lb-from-main"] === "1";
    
    if (!isFromLbRedirect) {
      // Option 1: Stream has specific server assigned (forceServerId)
      if (stream.forceServerId && stream.forceServerId >= 1) {
        const assignedServer = await storage.getServer(stream.forceServerId);
        if (assignedServer && assignedServer.status === 1) {
          if (assignedServer.isMain === 1) {
            // Stream assigned to Main server - DO NOT redirect to LB, serve from Main
            selectedLB = null;
          } else if (assignedServer.serverIp || assignedServer.domainName) {
            // Stream assigned to specific LB server
            selectedLB = assignedServer;
          }
        }
      } else {
        // Option 2: No specific server assigned - Auto round-robin across all online LB servers
        const onlineLBServers = await getOnlineLBServers(storage);
        if (onlineLBServers.length > 0) {
          selectedLB = selectLoadBalancer(onlineLBServers);
        }
      }
    }
    
    // Determine which server will serve the stream
    const servingServerId = selectedLB ? selectedLB.id : getServerIdFromRequest(req);
    
    if (user) {
      // Smart connection management for channel switching:
      // 1. First, expire any stale connections (no heartbeat for 60+ seconds)
      await storage.expireStaleConnections(user.id, 60);
      
      // 2. Try to replace existing connection from same IP (channel switch)
      const replaced = await storage.replaceConnectionFromSameIp(user.id, userIp, stream.id);
      
      if (!replaced) {
        // 3. No existing connection to replace - check limit before creating new one
        const currentConnections = await storage.countUserConnections(user.id);
        const maxConnections = user.maxConnections || 1;
        if (currentConnections >= maxConnections) {
          return res.status(403).send(`Connection limit reached (${maxConnections})`);
        }
        
        // 4. Create new connection
        console.log(`[LIVE] Creating connection for user ${user.id}, stream ${stream.id}, country: ${geo.countryCode}, server: ${servingServerId}`);
        await storage.createConnection({
          userId: user.id,
          streamId: stream.id,
          serverId: servingServerId,
          userIp: userIp,
          userAgent: req.headers["user-agent"] || "",
          container: ext || "ts",
          dateStart: now,
          hlsLastRead: now,
          geoipCountryCode: geo.countryCode,
        });
      } else {
        console.log(`[LIVE] Replaced connection for user ${user.id}, stream ${stream.id}`);
      }
    } else if (magDevice) {
      // Standalone MAG device - create/replace single connection
      // Use negative magId as a marker to distinguish from regular users
      const magUserId = -magDevice.magId;
      console.log(`[LIVE] MAG device ${magDevice.mac} (magId: ${magDevice.magId}), using userId: ${magUserId}`);
      
      // Clean up any old connections for this MAG device
      await storage.expireStaleConnections(magUserId, 60);
      
      // Replace or create connection for MAG device
      const replaced = await storage.replaceConnectionFromSameIp(magUserId, userIp, stream.id);
      if (!replaced) {
        console.log(`[LIVE] Creating connection for MAG ${magDevice.mac}, stream ${stream.id}, country: ${geo.countryCode}, server: ${servingServerId}`);
        await storage.createConnection({
          userId: magUserId,
          streamId: stream.id,
          serverId: servingServerId,
          userIp: userIp,
          userAgent: `MAG/${magDevice.mac}`,
          container: ext || "ts",
          dateStart: now,
          hlsLastRead: now,
          geoipCountryCode: geo.countryCode,
        });
      } else {
        console.log(`[LIVE] Replaced connection for MAG ${magDevice.mac}, stream ${stream.id}`);
      }
    }
    
    // =========================================
    // NOW REDIRECT OR SERVE
    // Connection is already created, heartbeat will keep it alive
    // =========================================
    
    if (selectedLB) {
      const lbUrl = buildLBRedirectUrl(selectedLB, `/live/${username}/${password}/${streamId}.${ext}`);
      console.log(`[LIVE] Redirecting stream ${streamId} to LB server ${selectedLB.serverName} (${lbUrl})`);
      return res.redirect(302, lbUrl);
    }
    
    console.log(`[LIVE] No LB selected for stream ${streamId}, serving from main server`);

    // Create a token for this stream session (include backup sources for failover)
    const userId = user?.id || (magDevice ? -magDevice.magId : 0);
    const token = createStreamToken(stream.streamSource, userId, stream.id, stream.backupSources || []);
    
    // Redirect to our HLS proxy which hides the source
    res.redirect(`/hls/${token}/playlist.${ext}`);
  });

  // HLS Proxy - serves playlists with rewritten URLs
  app.get("/hls/:token/playlist.:ext", async (req, res) => {
    const { token } = req.params;
    const tokenData = getStreamToken(token);
    
    if (!tokenData) {
      return res.status(401).send("Invalid or expired token");
    }

    // Update connection heartbeat on playlist refresh - keeps connection alive
    // Use serverId=1 for MAIN server direct streaming
    if (tokenData.userId !== undefined && tokenData.userId !== 0 && tokenData.streamId) {
      storage.touchConnectionByUserStream(tokenData.userId, tokenData.streamId, 1).catch(() => {});
    }

    const sourceUrl = tokenData.sourceUrl;
    proxyHlsPlaylist(sourceUrl, token, res, req);
  });

  // HLS Proxy - serves segments and nested playlists
  app.get("/hls/:token/*", async (req, res) => {
    const { token } = req.params;
    // Express 5: Access wildcard via ['0'] key
    const segment = (req.params as Record<string, string>)['0'] || "";
    console.log(`[HLS] Segment request: token=${token.substring(0,8)}... segment=${segment}`);
    
    const tokenData = getStreamToken(token);
    if (!tokenData) {
      console.log(`[HLS] Token not found: ${token.substring(0,8)}...`);
      return res.status(401).send("Invalid or expired token");
    }
    console.log(`[HLS] Token valid, baseUrl=${tokenData.baseUrl}, streamId=${tokenData.streamId}`);

    // Update connection heartbeat - keeps connection alive during streaming
    // Note: userId can be negative for standalone MAG devices, so check for !== undefined
    // Use serverId=1 for MAIN server direct streaming
    if (tokenData.userId !== undefined && tokenData.userId !== 0 && tokenData.streamId) {
      storage.touchConnectionByUserStream(tokenData.userId, tokenData.streamId, 1).catch(() => {});
    }

    // Security validation - reject path traversal attempts (allow relative paths with slashes)
    if (segment.includes("..") || segment.startsWith("/") || segment.includes("://")) {
      console.log(`[HLS] Security block: segment=${segment}`);
      return res.status(400).send("Invalid segment path");
    }

    // Check if this is an encoded absolute URL from our lookup table
    let segmentUrl: string;
    const decodedAbsolute = decodeAbsoluteUrl(tokenData, segment);
    if (decodedAbsolute) {
      // This was an absolute URL that we encoded - use it directly
      segmentUrl = decodedAbsolute;
    } else if (segment.startsWith("_abs_")) {
      // Invalid _abs_ reference (not found in lookup table)
      return res.status(404).send("Segment not found");
    } else {
      // Build the full URL for relative segments
      segmentUrl = tokenData.baseUrl + segment;
    }
    console.log(`[HLS] Proxying to: ${segmentUrl}`);
    
    // Check if this is another playlist or a segment
    if (segment.endsWith(".m3u8") || segment.endsWith(".m3u") || decodedAbsolute?.endsWith(".m3u8") || decodedAbsolute?.endsWith(".m3u")) {
      proxyHlsPlaylist(segmentUrl, token, res, req);
    } else {
      // Use FAST undici proxy for segments - 512KB buffers like Nginx
      console.log(`[HLS] Calling proxySegmentFast...`);
      try {
        await proxySegmentFast(segmentUrl, res, req, token, tokenData.streamId);
      } catch (err: any) {
        console.log(`[HLS] proxySegmentFast error: ${err.message}`);
        if (!res.headersSent) res.status(500).send("Proxy error");
      }
    }
  });

  // MAG Stream Proxy - completely hides source URLs from MAG/STB Emu devices
  // Uses /mag-stream/ prefix so players request segments through our proxy
  app.get("/mag-stream/:token/*", async (req, res) => {
    const { token } = req.params;
    const segment = (req.params as Record<string, string>)[0] || "";
    
    const tokenData = getStreamToken(token);
    if (!tokenData) {
      return res.status(401).send("Invalid or expired token");
    }

    // Update connection heartbeat - keeps MAG connection alive during streaming
    // This prevents the auto-cleanup from removing the connection after 60 seconds
    // Use serverId=1 for MAIN server direct streaming
    if (tokenData.userId !== undefined && tokenData.userId !== 0 && tokenData.streamId) {
      storage.touchConnectionByUserStream(tokenData.userId, tokenData.streamId, 1).catch(() => {});
    }

    const sourceUrl = tokenData.sourceUrl;
    
    // For VOD/movie files - proxy directly without HLS rewriting
    if (segment === "movie.mp4" || segment === "movie.mkv" || segment === "movie.avi") {
      proxySegment(sourceUrl, res, req);
      return;
    }
    
    // For initial request (live.ts/playlist.m3u8) - serve HLS playlist with rewritten URLs
    if (segment === "live.ts" || segment === "" || segment === "playlist.m3u8") {
      proxyHlsPlaylistForMag(sourceUrl, token, res, req);
    } else if (segment.endsWith(".m3u8") || segment.endsWith(".m3u")) {
      // Sub-playlist request - rewrite URLs
      const decodedAbsolute = decodeAbsoluteUrl(tokenData, segment);
      const segmentUrl = decodedAbsolute || tokenData.baseUrl + segment;
      proxyHlsPlaylistForMag(segmentUrl, token, res, req);
    } else {
      // Use FAST undici proxy for segments - 512KB buffers like Nginx
      const decodedAbsolute = decodeAbsoluteUrl(tokenData, segment);
      const segmentUrl = decodedAbsolute || tokenData.baseUrl + segment;
      proxySegmentFast(segmentUrl, res, req, token, tokenData.streamId);
    }
  });

  // VOD stream endpoint - creates token and proxies via HLS system
  app.get("/movie/:username/:password/:vodId.:ext", async (req, res) => {
    const { username, password, vodId, ext } = req.params;
    const userIp = (req.headers["x-forwarded-for"] as string)?.split(",")[0]?.trim() || req.socket.remoteAddress || "";
    
    console.log(`[VOD] Movie request - vodId: ${vodId}, ext: ${ext}, user: ${username}, ip: ${userIp}`);
    
    // No rate limiting on VOD - already protected by user authentication
    
    const user = await storage.getUserByUsername(username);
    if (!user || user.password !== password) {
      console.log(`[VOD] Invalid credentials for ${username}`);
      return res.status(401).send("Invalid credentials");
    }

    // Check if user is enabled and not expired
    const now = Math.floor(Date.now() / 1000);
    if (user.expDate && user.expDate <= now) {
      console.log(`[VOD] Account expired for ${username}, expDate: ${user.expDate}, now: ${now}`);
      return res.status(403).send("Account expired");
    }
    if (user.enabled === 0 || user.adminEnabled === 0) {
      console.log(`[VOD] Account disabled for ${username}, enabled: ${user.enabled}, adminEnabled: ${user.adminEnabled}`);
      return res.status(403).send("Account disabled");
    }

    // Try to find movie by ID first, then by number
    let movie = await storage.getStream(parseInt(vodId));
    if (!movie) {
      const allMovies = await storage.getStreams(STREAM_TYPE_MOVIE);
      movie = allMovies.find(m => m.number === parseInt(vodId));
    }
    if (!movie || !movie.streamSource) {
      console.log(`[VOD] Movie not found: ${vodId}`);
      return res.status(404).send("Movie not found");
    }

    // Check if movie should be routed to a Load Balancer server
    const isFromLbRedirect = req.headers["x-lb-from-main"] === "1";
    
    if (!isFromLbRedirect) {
      let selectedLB: LBServer | null = null;
      let forceMain = false;
      
      // Option 1: Movie has specific server assigned (forceServerId)
      if (movie.forceServerId && movie.forceServerId >= 1) {
        const assignedServer = await storage.getServer(movie.forceServerId);
        if (assignedServer && assignedServer.status === 1) {
          if (assignedServer.isMain === 1) {
            // Movie assigned to Main server - DO NOT redirect to LB, serve from Main
            forceMain = true;
          } else if (assignedServer.serverIp || assignedServer.domainName) {
            // Movie assigned to specific LB server
            selectedLB = assignedServer;
          }
        }
      }
      
      // Option 2: No specific server assigned - Auto round-robin across all online LB servers
      if (!selectedLB && !forceMain) {
        const onlineLBServers = await getOnlineLBServers(storage);
        if (onlineLBServers.length > 0) {
          selectedLB = selectLoadBalancer(onlineLBServers);
        }
      }
      
      // Redirect to selected LB server
      if (selectedLB) {
        const lbUrl = buildLBRedirectUrl(selectedLB, `/movie/${username}/${password}/${vodId}.${ext}`);
        console.log(`[VOD] Redirecting movie ${vodId} to LB server ${selectedLB.serverName} (${lbUrl})`);
        return res.redirect(302, lbUrl);
      }
    }

    // For VOD, use smart connection management like live streams
    await storage.expireStaleConnections(user.id, 1);
    const replaced = await storage.replaceConnectionFromSameIp(user.id, userIp, parseInt(vodId));
    
    if (!replaced) {
      const currentConnections = await storage.countUserConnections(user.id);
      const maxConnections = user.maxConnections || 1;
      if (currentConnections >= maxConnections) {
        console.log(`[VOD] Connection limit for ${username}: ${currentConnections}/${maxConnections}`);
        return res.status(403).send(`Connection limit reached (${maxConnections})`);
      }
    }

    console.log(`[VOD] Found movie: ${movie.streamDisplayName}, source: ${movie.streamSource.substring(0, 50)}...`);

    // Get geolocation and track connection
    const geo = await getGeoLocation(userIp);
    console.log(`[VOD] Creating connection for user ${user.id}, movie ${movie.id}, server: ${getServerIdFromRequest(req)}`);
    await storage.createConnection({
      userId: user.id,
      streamId: movie.id,
      serverId: getServerIdFromRequest(req),
      userIp: userIp,
      userAgent: req.headers["user-agent"] || "",
      container: ext || "ts",
      dateStart: now,
      geoipCountryCode: geo.countryCode,
    });

    // Create a token for this VOD session
    const token = createStreamToken(movie.streamSource, user.id, movie.id);
    
    // For non-HLS formats (mp4, mkv, etc.), proxy directly
    if (!movie.streamSource.includes(".m3u8")) {
      proxySegment(movie.streamSource, res, req);
    } else {
      res.redirect(`/hls/${token}/playlist.${ext}`);
    }
  });

  // Series episode endpoint - for Xtream Codes API players
  app.get("/series/:username/:password/:episodeId.:ext", async (req, res) => {
    const { username, password, episodeId, ext } = req.params;
    const userIp = (req.headers["x-forwarded-for"] as string)?.split(",")[0]?.trim() || req.socket.remoteAddress || "";
    
    console.log(`[SERIES] Episode request - episodeId: ${episodeId}, ext: ${ext}, user: ${username}, ip: ${userIp}`);
    
    // No rate limiting on series - already protected by user authentication
    
    const user = await storage.getUserByUsername(username);
    if (!user || user.password !== password) {
      console.log(`[SERIES] Invalid credentials for ${username}`);
      return res.status(401).send("Invalid credentials");
    }

    const now = Math.floor(Date.now() / 1000);
    if (user.expDate && user.expDate <= now) {
      console.log(`[SERIES] Account expired for ${username}`);
      return res.status(403).send("Account expired");
    }
    if (user.enabled === 0 || user.adminEnabled === 0) {
      console.log(`[SERIES] Account disabled for ${username}`);
      return res.status(403).send("Account disabled");
    }

    // Smart connection management
    await storage.expireStaleConnections(user.id, 1);
    const replaced = await storage.replaceConnectionFromSameIp(user.id, userIp, parseInt(episodeId));
    
    if (!replaced) {
      const currentConnections = await storage.countUserConnections(user.id);
      const maxConnections = user.maxConnections || 1;
      if (currentConnections >= maxConnections) {
        console.log(`[SERIES] Connection limit for ${username}: ${currentConnections}/${maxConnections}`);
        return res.status(403).send(`Connection limit reached (${maxConnections})`);
      }
    }

    // Find episode by ID - episodes link to streams via streamId
    const episode = await storage.getSeriesEpisode(parseInt(episodeId));
    if (!episode) {
      console.log(`[SERIES] Episode not found: ${episodeId}`);
      return res.status(404).send("Episode not found");
    }
    
    // Get the stream that contains the actual video source
    const stream = await storage.getStream(episode.streamId);
    if (!stream || !stream.streamSource) {
      console.log(`[SERIES] Stream for episode ${episodeId} not found: streamId=${episode.streamId}`);
      return res.status(404).send("Episode source not found");
    }
    
    console.log(`[SERIES] Found episode: S${episode.seasonNum}, streamId: ${episode.streamId}, source: ${stream.streamSource.substring(0, 50)}...`);

    // Get geolocation and track connection
    const geo = await getGeoLocation(userIp);
    console.log(`[SERIES] Creating connection for user ${user.id}, episode ${episodeId}, server: ${getServerIdFromRequest(req)}`);
    await storage.createConnection({
      userId: user.id,
      streamId: stream.id,
      serverId: getServerIdFromRequest(req),
      userIp: userIp,
      userAgent: req.headers["user-agent"] || "",
      container: ext || "ts",
      dateStart: now,
      geoipCountryCode: geo.countryCode,
    });

    // Create token and proxy
    const token = createStreamToken(stream.streamSource, user.id, stream.id);
    
    if (!stream.streamSource.includes(".m3u8")) {
      proxySegment(stream.streamSource, res, req);
    } else {
      res.redirect(`/hls/${token}/playlist.${ext}`);
    }
  });

  // ===============================
  // STALKER PORTAL API FOR MAG DEVICES
  // URL: /xmag/c/ (instead of /stalker_portal/c/)
  // ===============================

  // Helper: Get MAG device by MAC (user is optional for standalone devices)
  async function getMagDeviceByMac(mac: string): Promise<{ user: any | null; device: any } | null> {
    const devices = await storage.getMagDevices();
    const device = devices.find(d => d.mac.toUpperCase().replace(/:/g, "") === mac.toUpperCase().replace(/:/g, ""));
    if (!device) return null;
    
    // Check if device is locked
    if (device.lockDevice === 1) return null;
    
    // Check device expiry
    if (device.expiry) {
      const expiryDate = new Date(device.expiry);
      if (expiryDate < new Date()) return null;
    }
    
    // Get user if assigned (userId > 0)
    let user = null;
    if (device.userId && device.userId > 0) {
      user = await storage.getUser(device.userId);
      if (user) {
        const now = Math.floor(Date.now() / 1000);
        if (user.expDate && user.expDate <= now) user = null;
        if (user && (user.enabled === 0 || user.adminEnabled === 0)) user = null;
      }
    }
    
    return { user, device };
  }
  
  // Helper: Get bouquet IDs for MAG device (from device or user)
  function getMagBouquetIds(device: any, user: any | null): number[] {
    // First try device bouquetIds
    let bouquetIds: number[] = [];
    if (device.bouquetIds) {
      if (typeof device.bouquetIds === 'string') {
        try { bouquetIds = JSON.parse(device.bouquetIds); } catch {}
      } else if (Array.isArray(device.bouquetIds)) {
        bouquetIds = device.bouquetIds;
      }
    }
    
    // If device has no bouquets but has user, use user's bouquets
    if (bouquetIds.length === 0 && user && user.bouquetIds) {
      if (typeof user.bouquetIds === 'string') {
        try { bouquetIds = JSON.parse(user.bouquetIds); } catch {}
      } else if (Array.isArray(user.bouquetIds)) {
        bouquetIds = user.bouquetIds;
      }
    }
    
    return bouquetIds;
  }

  // Main Stalker Portal endpoint - handle multiple path formats for compatibility
  // Include portal.php for STB Emu compatibility
  app.get(["/xmag/c/", "/xmag/c", "/stalker_portal/c/", "/stalker_portal/c", "/portal.php", "/server/load.php", "/c/", "/c"], async (req, res) => {
    const { type, action, JsHttpRequest } = req.query;
    
    // Get MAC from query - check both lowercase 'mac' and uppercase 'MAC'
    const queryMac = (req.query.mac || req.query.MAC || "") as string;
    
    // Debug log for MAG requests
    console.log(`[MAG] GET request - type=${type}, action=${action}, mac=${queryMac}`);
    
    // Set headers for CORS and compatibility
    res.setHeader("Content-Type", "application/json; charset=utf-8");
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
    res.setHeader("Access-Control-Allow-Headers", "*");
    res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
    
    // Try to get MAC from multiple sources: query, cookie, header
    let macAddress = queryMac;
    if (!macAddress) {
      // Try cookie
      const cookieMac = req.cookies?.mac || req.headers.cookie?.match(/mac=([^;]+)/)?.[1] || "";
      macAddress = decodeURIComponent(cookieMac);
    }
    if (!macAddress) {
      // Try X-User-Agent header (STB Emu sometimes sends MAC here)
      const userAgentHeader = req.headers["x-user-agent"] as string || "";
      const macMatch = userAgentHeader.match(/MAC:([0-9A-Fa-f:]+)/);
      if (macMatch) macAddress = macMatch[1];
    }
    if (!macAddress) {
      // Try custom header
      macAddress = req.headers["x-mac"] as string || "";
    }
    
    // Normalize MAC
    const normalizedMac = macAddress.toUpperCase().replace(/:/g, "");
    const clientIp = normalizeIp(req.ip || req.socket.remoteAddress || "unknown");
    
    // Get device info from headers (STB Emu sends this)
    const deviceId = req.headers["x-device-id"] as string || req.query.sn as string || "";
    const hwVersion = req.headers["x-hw-version"] as string || "";
    
    // Handshake - initial connection with session creation
    if (type === "stb" && action === "handshake") {
      // Check if MAC/IP is blocked due to failed attempts
      const blockStatus = isMagBlocked(normalizedMac, clientIp);
      if (blockStatus.blocked) {
        console.log(`[MAG SECURITY] Handshake BLOCKED for MAC=${normalizedMac}, IP=${clientIp}`);
        return res.json({
          js: {
            token: "",
            not_valid: 1,
            error: `Too many failed attempts. Try again in ${blockStatus.remainingSeconds} seconds.`,
          }
        });
      }
      
      // Verify device exists in database
      const magData = await getMagDeviceByMac(normalizedMac);
      if (!magData) {
        // Record failed attempt for unknown device
        recordFailedMagAttempt(normalizedMac, clientIp);
        console.log(`[MAG SECURITY] Handshake FAILED - unknown device: ${normalizedMac}`);
        return res.json({
          js: {
            token: "",
            not_valid: 1,
            error: "Device not registered",
          }
        });
      }
      
      // Check if device is locked
      if (magData.device.lockDevice === 1) {
        recordFailedMagAttempt(normalizedMac, clientIp);
        console.log(`[MAG SECURITY] Handshake FAILED - device locked: ${normalizedMac}`);
        return res.json({
          js: {
            token: "",
            not_valid: 1,
            error: "Device is locked",
          }
        });
      }
      
      // Check device expiry
      if (magData.device.expiry) {
        const expiryDate = new Date(magData.device.expiry);
        if (expiryDate < new Date()) {
          recordFailedMagAttempt(normalizedMac, clientIp);
          console.log(`[MAG SECURITY] Handshake FAILED - device expired: ${normalizedMac}`);
          return res.json({
            js: {
              token: "",
              not_valid: 1,
              error: "Subscription expired",
            }
          });
        }
      }
      
      // Success - create session and clear failed attempts
      clearFailedMagAttempts(normalizedMac, clientIp);
      const token = createMagSession(normalizedMac, clientIp, deviceId, hwVersion);
      console.log(`[MAG SECURITY] Handshake SUCCESS for MAC=${normalizedMac}, IP=${clientIp}, deviceId=${deviceId}`);
      
      return res.json({
        js: {
          token: token,
          not_valid: 0,
          random: Math.random().toString(36).substring(2),
        }
      });
    }
    
    // Get profile with security validation
    if (type === "stb" && action === "get_profile") {
      const magData = await getMagDeviceByMac(normalizedMac);
      if (!magData) {
        console.log(`[MAG SECURITY] Device not found: ${normalizedMac}`);
        return res.json({ js: { id: 0, name: "", login: "", password: "", status: 0 } });
      }
      
      const { user, device } = magData;
      
      // Get token from request for validation
      const reqToken = getMagToken(req);
      
      // Security validation (requires handshake, token match, informational - skip IP lock)
      const validation = validateMagSession(normalizedMac, clientIp, device, reqToken, false, true);
      if (!validation.valid) {
        recordFailedMagAttempt(normalizedMac, clientIp);
        console.log(`[MAG SECURITY] Validation failed for ${normalizedMac}: ${validation.error}`);
        return res.json({ js: { id: 0, name: "", login: "", password: "", status: 0, blocked: 1, block_msg: validation.error } });
      }
      
      // Use device expiry or user expiry
      let expDateStr = "";
      if (device.expiry) {
        expDateStr = device.expiry;
      } else if (user?.expDate) {
        expDateStr = new Date(user.expDate * 1000).toISOString().split("T")[0];
      }
      
      // Update device last_active and IP
      await storage.updateMagDevice(device.magId, { 
        lastActive: Math.floor(Date.now() / 1000),
        ip: clientIp,
      });
      
      // Update session activity
      const session = magSessions.get(normalizedMac);
      if (session) {
        session.lastActive = Date.now();
      }
      
      // Use MAC as login for standalone devices
      const loginName = user?.username || device.mac;
      
      // Build response with optional refreshed token
      const profileResponse: any = {
        js: {
          id: device.magId,
          name: loginName,
          login: loginName,
          password: "",
          status: 1,
          blocked: 0,
          ls: device.ls || "",
          end_date: expDateStr,
          tariff: {
            name: "Standard",
            id: 1,
          },
          max_connections: user?.maxConnections || 1,
          version: device.ver || "",
          locale: device.locale || "en_GB.utf8",
        }
      };
      // Include refreshed token if available (auto-refresh within 30 min of expiry)
      if (validation.newToken) {
        profileResponse.js.token = validation.newToken;
      }
      return res.json(profileResponse);
    }
    
    // Get genres (categories) with security validation
    if (type === "itv" && action === "get_genres") {
      // Security: validate device exists and session is valid
      const magData = await getMagDeviceByMac(normalizedMac);
      if (!magData) {
        console.log(`[MAG SECURITY] get_genres - device not found: ${normalizedMac}`);
        return res.json({ js: [] });
      }
      
      const { device } = magData;
      const reqToken = getMagToken(req);
      // Informational endpoint - skip IP lock to allow IP drift
      const validation = validateMagSession(normalizedMac, clientIp, device, reqToken, false, true);
      if (!validation.valid) {
        recordFailedMagAttempt(normalizedMac, clientIp);
        console.log(`[MAG SECURITY] get_genres validation failed: ${validation.error}`);
        return res.json({ js: [] });
      }
      
      const categories = await storage.getCategories();
      const liveCategories = categories.filter(c => c.categoryType === "live");
      
      const genres = liveCategories.map(cat => ({
        id: cat.id.toString(),
        title: cat.categoryName,
        alias: cat.categoryName.toLowerCase().replace(/\s+/g, "_"),
        active_sub: true,
        censored: 0,
      }));
      
      // Add "All" category at the beginning
      genres.unshift({
        id: "*",
        title: "All channels",
        alias: "all",
        active_sub: true,
        censored: 0,
      });
      
      return res.json({ js: genres });
    }
    
    // Get all channels (non-paginated, for STB Emu) with security validation
    if (type === "itv" && action === "get_all_channels") {
      console.log(`[MAG] get_all_channels - normalizedMac: ${normalizedMac}`);
      const magData = await getMagDeviceByMac(normalizedMac);
      console.log(`[MAG] get_all_channels - magData:`, magData ? `found device ${magData.device.magId}` : "not found");
      
      if (!magData) {
        console.log(`[MAG SECURITY] get_all_channels - device not found: ${normalizedMac}`);
        return res.json({ js: { data: [] } });
      }
      
      const { user, device } = magData;
      
      // Security: validate session and token (informational - skip IP lock)
      const reqToken = getMagToken(req);
      const validation = validateMagSession(normalizedMac, clientIp, device, reqToken, false, true);
      if (!validation.valid) {
        recordFailedMagAttempt(normalizedMac, clientIp);
        console.log(`[MAG SECURITY] get_all_channels validation failed: ${validation.error}`);
        return res.json({ js: { data: [] } });
      }
      
      // Get streams filtered by device/user bouquets
      const allStreams = await storage.getStreams();
      const liveStreams = allStreams.filter(s => s.type === 1);
      
      const bouquetIds = getMagBouquetIds(device, user);
      console.log(`[MAG] get_all_channels - bouquetIds:`, bouquetIds);
      
      let filteredStreams = liveStreams;
      
      if (bouquetIds.length > 0) {
        const bouquets = await storage.getBouquets();
        const allowedStreamIds: number[] = [];
        
        for (const bouquetId of bouquetIds) {
          const bouquet = bouquets.find(b => b.id === bouquetId);
          if (bouquet) {
            let channels: number[] = [];
            if (bouquet.bouquetChannels) {
              try {
                channels = typeof bouquet.bouquetChannels === 'string' 
                  ? JSON.parse(bouquet.bouquetChannels) 
                  : bouquet.bouquetChannels;
              } catch {}
            }
            for (const id of channels) {
              if (!allowedStreamIds.includes(id)) {
                allowedStreamIds.push(id);
              }
            }
          }
        }
        
        console.log(`[MAG] get_all_channels - allowedStreamIds:`, allowedStreamIds);
        
        if (allowedStreamIds.length > 0) {
          filteredStreams = allowedStreamIds
            .map(id => liveStreams.find(s => s.id === id))
            .filter((s): s is NonNullable<typeof s> => s !== undefined);
        }
      }
      
      console.log(`[MAG] get_all_channels - returning ${filteredStreams.length} channels`);
      
      const serverHost = req.get("host") || "localhost:5000";
      const protocol = req.protocol || "http";
      const loginName = user?.username || device.mac.replace(/:/g, "");
      
      const data = filteredStreams.map((stream, index) => ({
        id: stream.id.toString(),
        name: stream.streamDisplayName || `Channel ${stream.id}`,
        number: index + 1,
        censored: 0,
        cmd: `ffrt ${protocol}://${serverHost}/live/${loginName}/${loginName}/${stream.id}.ts`,
        tv_genre_id: stream.categoryId?.toString() || "1",
        base_ch: 1,
        hd: 0,
        xmltv_id: stream.channelId || "",
        logo: stream.streamIcon || "",
        use_http_tmp_link: 1,
        monitoring_url: "",
      }));
      
      return res.json({ js: { data: data } });
    }
    
    // Get ordered list (channels)
    if (type === "itv" && action === "get_ordered_list") {
      const magData = await getMagDeviceByMac(normalizedMac);
      if (!magData) {
        console.log(`[MAG SECURITY] get_ordered_list - device not found: ${normalizedMac}`);
        return res.json({ js: { total_items: 0, max_page_items: 20, data: [] } });
      }
      
      const { user, device } = magData;
      
      // Security: validate session and token (informational - skip IP lock)
      const reqToken = getMagToken(req);
      const validation = validateMagSession(normalizedMac, clientIp, device, reqToken, false, true);
      if (!validation.valid) {
        recordFailedMagAttempt(normalizedMac, clientIp);
        console.log(`[MAG SECURITY] get_ordered_list validation failed: ${validation.error}`);
        return res.json({ js: { total_items: 0, max_page_items: 20, data: [] } });
      }
      
      const genre = req.query.genre as string || "*";
      const p = parseInt(req.query.p as string) || 1;
      const sortby = req.query.sortby as string || "number";
      
      // Get streams filtered by device/user bouquets
      const allStreams = await storage.getStreams();
      const liveStreams = allStreams.filter(s => s.type === 1); // Live streams only
      
      // Get bouquet IDs from device or user
      const bouquetIds = getMagBouquetIds(device, user);
      
      let filteredStreams = liveStreams;
      
      if (bouquetIds.length > 0) {
        // Get bouquets and extract stream IDs in order
        const bouquets = await storage.getBouquets();
        const allowedStreamIds: number[] = [];
        
        for (const bouquetId of bouquetIds) {
          const bouquet = bouquets.find(b => b.id === bouquetId);
          if (bouquet) {
            let channels: number[] = [];
            if (bouquet.bouquetChannels) {
              try {
                channels = typeof bouquet.bouquetChannels === 'string' 
                  ? JSON.parse(bouquet.bouquetChannels) 
                  : bouquet.bouquetChannels;
              } catch {}
            }
            for (const id of channels) {
              if (!allowedStreamIds.includes(id)) {
                allowedStreamIds.push(id);
              }
            }
          }
        }
        
        if (allowedStreamIds.length > 0) {
          // Order by bouquet order
          filteredStreams = allowedStreamIds
            .map(id => liveStreams.find(s => s.id === id))
            .filter((s): s is NonNullable<typeof s> => s !== undefined);
        }
      }
      
      // Filter by genre if not "All"
      if (genre !== "*") {
        filteredStreams = filteredStreams.filter(s => s.categoryId?.toString() === genre);
      }
      
      // Get categories for lookup
      const categories = await storage.getCategories();
      const catMap = new Map(categories.map(c => [c.id, c]));
      
      // Build channel list with logos and EPG IDs
      const pageSize = 20;
      const startIndex = (p - 1) * pageSize;
      const pageStreams = filteredStreams.slice(startIndex, startIndex + pageSize);
      
      const serverHost = req.get("host") || "localhost:5000";
      const protocol = req.protocol || "http";
      
      // For standalone MAG devices, use MAC-based URL
      const loginName = user?.username || device.mac.replace(/:/g, "");
      const loginPass = user?.password || device.mac.replace(/:/g, "");
      
      // Helper functions for EPG formatting
      const formatDateTime = (timestamp: number) => {
        const d = new Date(timestamp * 1000);
        return d.toISOString().replace('T', ' ').substring(0, 19);
      };
      const formatTime = (timestamp: number) => {
        const d = new Date(timestamp * 1000);
        return d.toTimeString().substring(0, 5);
      };
      
      // Fetch EPG for all channels in this page
      const now = Math.floor(Date.now() / 1000);
      const epgEndTime = now + (4 * 3600); // Next 4 hours
      
      const data = await Promise.all(pageStreams.map(async (stream, index) => {
        const cat = catMap.get(stream.categoryId || 0);
        const streamNum = stream.number || stream.id;
        
        // Fetch EPG for this channel
        let epgArray: any[] = [];
        let nowPlaying = "";
        let nextPlaying = "";
        
        if (stream.channelId) {
          const epgItems = await storage.getEpgDataByChannel(stream.channelId, now - 3600, epgEndTime);
          
          // Find current program (now playing)
          const currentProgram = epgItems.find(e => e.start <= now && (e.end || 0) > now);
          // Find next program
          const nextProgram = epgItems.find(e => e.start > now);
          
          if (currentProgram) {
            nowPlaying = currentProgram.title;
          }
          if (nextProgram) {
            nextPlaying = nextProgram.title;
          }
          
          // Format EPG array for Stalker Portal
          epgArray = epgItems.slice(0, 4).map(item => ({
            id: item.id.toString(),
            ch_id: streamNum.toString(),
            time: formatDateTime(item.start),
            time_to: item.end ? formatDateTime(item.end) : "",
            t_time: formatTime(item.start),
            t_time_to: item.end ? formatTime(item.end) : "",
            start_timestamp: item.start,
            stop_timestamp: item.end || 0,
            duration: item.end ? (item.end - item.start) : 0,
            name: item.title,
            descr: item.description || "",
            real_id: item.channelId,
          }));
        }
        
        return {
          id: streamNum.toString(),
          name: stream.streamDisplayName || stream.streamSource?.split("/").pop() || `Channel ${streamNum}`,
          number: startIndex + index + 1,
          censored: 0,
          cmd: `${protocol}://${serverHost}/live/${loginName}/${loginPass}/${streamNum}.ts`,
          tv_genre_id: stream.categoryId?.toString() || "1",
          base_ch: 1,
          hd: 0,
          xmltv_id: stream.channelId || "",
          service_id: "",
          bonus_ch: 0,
          volume_correction: 0,
          lock: 0,
          fav: 0,
          logo: stream.streamIcon || "",
          use_http_tmp_link: 0,
          mc_cmd: "",
          enable_wowza_load_balancing: 0,
          // EPG data embedded in channel
          epg: epgArray,
          cur_playing: nowPlaying,
          next_playing: nextPlaying,
          epg_id: stream.channelId || "",
          use_dvr: 0,
          tv_archive: 0,
          real_id: stream.channelId || "",
        };
      }));
      
      return res.json({
        js: {
          total_items: filteredStreams.length,
          max_page_items: pageSize,
          selected_item: 0,
          cur_page: p,
          data: data,
        }
      });
    }
    
    // Create link for playback (STB Emu uses this to get stream URL)
    // SECURITY: Returns proxy URL instead of actual source URL
    // With connection limit enforcement
    if (type === "itv" && action === "create_link") {
      const cmd = req.query.cmd as string || "";
      const chId = req.query.ch_id as string || "";
      
      console.log(`[MAG] create_link - cmd: ${cmd}, ch_id: ${chId}, mac: ${normalizedMac}`);
      
      // MAG Security: Validate device and enforce connection limit
      const magData = await getMagDeviceByMac(normalizedMac);
      if (!magData) {
        console.log(`[MAG SECURITY] create_link - device not found: ${normalizedMac}`);
        return res.json({ js: { cmd: "", error: "Device not authorized" } });
      }
      
      const { device } = magData;
      
      // Get token from request for validation
      const reqToken = getMagToken(req);
      
      // STRICT Validate session (requires handshake, IP lock, token validation)
      const validation = validateMagSession(normalizedMac, clientIp, device, reqToken, false);
      if (!validation.valid) {
        recordFailedMagAttempt(normalizedMac, clientIp);
        console.log(`[MAG SECURITY] create_link validation failed: ${validation.error}`);
        return res.json({ js: { cmd: "", error: validation.error } });
      }
      
      // STRICT CONNECTION LIMIT ENFORCEMENT
      const limitCheck = checkMagConnectionLimit(normalizedMac, device);
      if (!limitCheck.allowed) {
        console.log(`[MAG SECURITY] Connection limit ENFORCED for ${normalizedMac}`);
        return res.json({ js: { cmd: "", error: limitCheck.error } });
      }
      
      // Find stream by various methods
      const allStreams = await storage.getStreams();
      let stream: typeof allStreams[0] | undefined;
      
      // Try to find by ch_id first
      if (chId) {
        stream = allStreams.find(s => (s.number || s.id).toString() === chId || s.id.toString() === chId);
      }
      
      // Try to extract stream ID from cmd URL
      if (!stream && cmd) {
        // Match patterns like /live/xxx/xxx/1.ts or /1.ts or ffrt http://.../1.ts
        const patterns = [
          /\/live\/[^\/]+\/[^\/]+\/(\d+)\.(ts|m3u8)/,
          /\/(\d+)\.(ts|m3u8)$/,
          /\/ch\/(\d+)/,
          /ffmpeg\s+http:\/\/localhost\/ch\/(\d+)/,
          /ffrt\s+http:\/\/[^\/]+\/(\d+)\.(ts|m3u8)/,
        ];
        
        for (const pattern of patterns) {
          const match = cmd.match(pattern);
          if (match) {
            const streamId = parseInt(match[1]);
            stream = allStreams.find(s => (s.number || s.id) === streamId || s.id === streamId);
            if (stream) break;
          }
        }
      }
      
      if (!stream || !stream.streamSource) {
        console.log(`[MAG] create_link - stream not found for cmd: ${cmd}, chId: ${chId}`);
        return res.json({ js: { cmd: "", error: "Stream not found" } });
      }
      
      console.log(`[MAG] create_link - found stream ${stream.id}: ${stream.streamDisplayName}`);
      
      // SMART MAG CONNECTION MANAGEMENT:
      // MAG uses single connection model - NEVER block, always replace
      const userIp = (req.headers["x-forwarded-for"] as string)?.split(",")[0]?.trim() || req.socket.remoteAddress || "";
      const userAgent = req.headers["user-agent"] || "MAG/STB";
      
      // Track MAG connection (both in-memory and database)
      addMagConnection(normalizedMac, stream.id, clientIp);
      
      // Get MAG device to find assigned user
      const magDevice = device;
      console.log(`[MAG] create_link - device found: magId=${device.magId}, userId=${device.userId}`);
      if (magDevice && magDevice.userId) {
        // MAG with assigned user - track connection in database (auto-replaces previous)
        await storage.replaceOrCreateMagConnection(
          normalizedMac, 
          magDevice.userId, 
          stream.id, 
          clientIp, 
          userAgent
        );
        console.log(`[MAG] create_link - connection tracked for user ${magDevice.userId}`);
      }
      // If userId is 0, MAG is in standalone mode - database tracking not needed
      
      // SECURITY: Create a token-based proxy URL instead of exposing source
      // This ensures the actual source URL is NEVER visible to end users
      const serverHost = req.get("host") || "localhost:5000";
      const protocol = req.protocol || "http";
      
      // Create a secure token for this stream session
      const userId = magDevice?.userId || 0;
      const token = createStreamToken(stream.streamSource, userId, stream.id);
      
      // Return proxy URL - source is completely hidden
      // STB Emu will request /mag-stream/:token which proxies the actual source
      const proxyUrl = `${protocol}://${serverHost}/mag-stream/${token}/live.ts`;
      
      console.log(`[MAG] create_link - returning proxy URL for stream ${stream.id}`);
      
      return res.json({
        js: {
          cmd: proxyUrl,
          id: stream.id.toString(),
        }
      });
    }
    
    // Create link for VOD playback (STB Emu uses this to get movie URL)
    // With security validation and connection limit enforcement
    if (type === "vod" && action === "create_link") {
      const cmd = req.query.cmd as string || "";
      const vodId = req.query.vod_id as string || req.query.id as string || "";
      
      console.log(`[MAG] VOD create_link - cmd: ${cmd}, vod_id: ${vodId}, mac: ${normalizedMac}`);
      
      // MAG Security: Validate device
      const magData = await getMagDeviceByMac(normalizedMac);
      if (!magData) {
        console.log(`[MAG SECURITY] VOD create_link - device not found: ${normalizedMac}`);
        return res.json({ js: { cmd: "", error: "Device not authorized" } });
      }
      
      const { device } = magData;
      
      // Get token from request for validation
      const reqToken = getMagToken(req);
      
      // STRICT Validate session (requires handshake, IP lock, token validation)
      const validation = validateMagSession(normalizedMac, clientIp, device, reqToken, false);
      if (!validation.valid) {
        recordFailedMagAttempt(normalizedMac, clientIp);
        console.log(`[MAG SECURITY] VOD create_link validation failed: ${validation.error}`);
        return res.json({ js: { cmd: "", error: validation.error } });
      }
      
      // STRICT CONNECTION LIMIT ENFORCEMENT
      const limitCheck = checkMagConnectionLimit(normalizedMac, device);
      if (!limitCheck.allowed) {
        console.log(`[MAG SECURITY] VOD connection limit ENFORCED for ${normalizedMac}`);
        return res.json({ js: { cmd: "", error: limitCheck.error } });
      }
      
      // Find movie by various methods
      const allMovies = await storage.getStreams(STREAM_TYPE_MOVIE);
      let movie: typeof allMovies[0] | undefined;
      
      // Try to find by vod_id first
      if (vodId) {
        movie = allMovies.find(m => (m.number || m.id).toString() === vodId || m.id.toString() === vodId);
      }
      
      // Try to extract movie ID from cmd URL
      if (!movie && cmd) {
        const patterns = [
          /\/media\/(\d+)\.(mpg|mp4|mkv|avi|m3u8)/,  // STB Emu format: /media/2.mpg
          /\/movie\/[^\/]+\/[^\/]+\/(\d+)\.(mp4|mkv|avi|m3u8)/,
          /\/(\d+)\.(mp4|mkv|avi|m3u8)$/,
        ];
        
        for (const pattern of patterns) {
          const match = cmd.match(pattern);
          if (match) {
            const movieId = parseInt(match[1]);
            movie = allMovies.find(m => (m.number || m.id) === movieId || m.id === movieId);
            if (movie) break;
          }
        }
      }
      
      if (!movie || !movie.streamSource) {
        console.log(`[MAG] VOD create_link - movie not found for cmd: ${cmd}, vodId: ${vodId}`);
        return res.json({ js: { cmd: "", error: "Movie not found" } });
      }
      
      console.log(`[MAG] VOD create_link - found movie ${movie.id}: ${movie.streamDisplayName}`);
      
      // Track MAG connection (both in-memory and database)
      addMagConnection(normalizedMac, movie.id, clientIp);
      
      const userAgent = req.headers["user-agent"] || "MAG/STB";
      
      // Use the device we already validated
      const magDevice = device;
      if (magDevice && magDevice.userId) {
        await storage.replaceOrCreateMagConnection(
          normalizedMac, 
          magDevice.userId, 
          movie.id, 
          clientIp, 
          userAgent
        );
        console.log(`[MAG] VOD create_link - connection tracked for user ${magDevice.userId}`);
      }
      
      // Create proxy URL for movie
      const serverHost = req.get("host") || "localhost:5000";
      const protocol = req.protocol || "http";
      
      const userId = magDevice?.userId || 0;
      const token = createStreamToken(movie.streamSource, userId, movie.id);
      
      // For movies, use direct proxy (not HLS rewriting)
      const proxyUrl = `${protocol}://${serverHost}/mag-stream/${token}/movie.mp4`;
      
      console.log(`[MAG] VOD create_link - returning proxy URL for movie ${movie.id}`);
      
      return res.json({
        js: {
          cmd: proxyUrl,
          id: movie.id.toString(),
        }
      });
    }
    
    // Get short EPG (now playing + upcoming)
    if (type === "itv" && action === "get_short_epg") {
      // Security: validate device and session
      const magData = await getMagDeviceByMac(normalizedMac);
      if (!magData) {
        console.log(`[MAG SECURITY] get_short_epg - device not found: ${normalizedMac}`);
        return res.json({ js: { data: [] } });
      }
      
      const { device } = magData;
      const reqToken = getMagToken(req);
      // Informational endpoint - skip IP lock to allow IP drift
      const validation = validateMagSession(normalizedMac, clientIp, device, reqToken, false, true);
      if (!validation.valid) {
        recordFailedMagAttempt(normalizedMac, clientIp);
        console.log(`[MAG SECURITY] get_short_epg validation failed: ${validation.error}`);
        return res.json({ js: { data: [] } });
      }
      
      const period = parseInt(req.query.period as string) || 4; // hours
      const chId = req.query.ch_id as string;
      
      console.log(`[MAG] get_short_epg - ch_id: ${chId}, period: ${period}`);
      
      // Get stream by id (number may be 0)
      const allStreams = await storage.getStreams();
      const stream = allStreams.find(s => (s.number || s.id).toString() === chId);
      
      console.log(`[MAG] get_short_epg - stream found: ${stream ? stream.streamDisplayName : 'none'}, channelId: ${stream?.channelId}`);
      
      if (!stream || !stream.channelId) {
        console.log(`[MAG] get_short_epg - no stream or channelId, returning empty`);
        return res.json({ js: { data: [] } });
      }
      
      // Get EPG data for this channel (next N hours)
      const now = Math.floor(Date.now() / 1000);
      const endTime = now + (period * 3600);
      const epgItems = await storage.getEpgDataByChannel(stream.channelId, now - 3600, endTime);
      
      console.log(`[MAG] get_short_epg - found ${epgItems.length} EPG items for channelId: ${stream.channelId}`);
      
      // Format for Stalker Portal - full format with all required fields
      const data = epgItems.map(item => {
        const startDate = new Date(item.start * 1000);
        const endDate = item.end ? new Date(item.end * 1000) : null;
        
        // MySQL datetime format: YYYY-MM-DD HH:mm:ss
        const formatDateTime = (d: Date) => {
          return d.toISOString().replace('T', ' ').substring(0, 19);
        };
        
        // HH:mm format for t_time
        const formatTime = (d: Date) => {
          return d.toTimeString().substring(0, 5);
        };
        
        return {
          id: item.id.toString(),
          ch_id: chId,
          time: formatDateTime(startDate),
          time_to: endDate ? formatDateTime(endDate) : "",
          t_time: formatTime(startDate),
          t_time_to: endDate ? formatTime(endDate) : "",
          start_timestamp: item.start,
          stop_timestamp: item.end || 0,
          duration: item.end ? (item.end - item.start) : 0,
          name: item.title,
          descr: item.description || "",
          real_id: item.channelId,
          category: "",
          director: "",
          actor: "",
          mark_memo: 0,
          mark_archive: 0,
        };
      });
      
      return res.json({ js: { data } });
    }
    
    // Get full EPG info
    if (type === "itv" && action === "get_epg_info") {
      // Security: validate device and session
      const magData = await getMagDeviceByMac(normalizedMac);
      if (!magData) {
        console.log(`[MAG SECURITY] get_epg_info - device not found: ${normalizedMac}`);
        return res.json({ js: {} });
      }
      
      const { device } = magData;
      const reqToken = getMagToken(req);
      // Informational endpoint - skip IP lock to allow IP drift
      const validation = validateMagSession(normalizedMac, clientIp, device, reqToken, false, true);
      if (!validation.valid) {
        recordFailedMagAttempt(normalizedMac, clientIp);
        console.log(`[MAG SECURITY] get_epg_info validation failed: ${validation.error}`);
        return res.json({ js: {} });
      }
      
      const period = parseInt(req.query.period as string) || 24; // hours
      const chId = req.query.ch_id as string;
      
      console.log(`[MAG] get_epg_info - ch_id: ${chId}, period: ${period}`);
      
      const allStreams = await storage.getStreams();
      const liveStreams = allStreams.filter(s => s.type === 1);
      
      const now = Math.floor(Date.now() / 1000);
      const startTime = now - 3600; // 1 hour before
      const endTime = now + (period * 3600);
      
      // Helper functions for EPG formatting  
      const formatDateTime = (timestamp: number) => {
        const d = new Date(timestamp * 1000);
        return d.toISOString().replace('T', ' ').substring(0, 19);
      };
      const formatTime = (timestamp: number) => {
        const d = new Date(timestamp * 1000);
        return d.toTimeString().substring(0, 5);
      };
      
      // If ch_id specified, return EPG for that channel only
      if (chId) {
        const stream = liveStreams.find(s => (s.number || s.id).toString() === chId);
        
        if (!stream || !stream.channelId) {
          console.log(`[MAG] get_epg_info - stream not found or no channelId`);
          return res.json({ js: { data: {} } });
        }
        
        const epgItems = await storage.getEpgDataByChannel(stream.channelId, startTime, endTime);
        console.log(`[MAG] get_epg_info - found ${epgItems.length} items for channel ${stream.channelId}`);
        
        // Format as array of EPG items (same format as get_short_epg)
        const data = epgItems.map(item => ({
          id: item.id.toString(),
          ch_id: chId,
          time: formatDateTime(item.start),
          time_to: item.end ? formatDateTime(item.end) : "",
          t_time: formatTime(item.start),
          t_time_to: item.end ? formatTime(item.end) : "",
          start_timestamp: item.start,
          stop_timestamp: item.end || 0,
          duration: item.end ? (item.end - item.start) : 0,
          name: item.title,
          descr: item.description || "",
          real_id: item.channelId,
          category: "",
        }));
        
        return res.json({ js: { data } });
      }
      
      // No ch_id - return EPG for ALL channels (grouped by channel ID)
      const epgByChannel: Record<string, any[]> = {};
      
      for (const stream of liveStreams) {
        if (!stream.channelId) continue;
        
        const streamNum = (stream.number || stream.id).toString();
        const epgItems = await storage.getEpgDataByChannel(stream.channelId, startTime, endTime);
        
        if (epgItems.length > 0) {
          epgByChannel[streamNum] = epgItems.map(item => ({
            id: item.id.toString(),
            ch_id: streamNum,
            time: formatDateTime(item.start),
            time_to: item.end ? formatDateTime(item.end) : "",
            t_time: formatTime(item.start),
            t_time_to: item.end ? formatTime(item.end) : "",
            start_timestamp: item.start,
            stop_timestamp: item.end || 0,
            duration: item.end ? (item.end - item.start) : 0,
            name: item.title,
            descr: item.description || "",
            real_id: item.channelId,
          }));
        }
      }
      
      console.log(`[MAG] get_epg_info - returning EPG for ${Object.keys(epgByChannel).length} channels`);
      return res.json({ js: { data: epgByChannel } });
    }

    // VOD categories
    if (type === "vod" && action === "get_categories") {
      // Security: validate device and session
      const magData = await getMagDeviceByMac(normalizedMac);
      if (!magData) {
        console.log(`[MAG SECURITY] VOD get_categories - device not found: ${normalizedMac}`);
        return res.json({ js: [] });
      }
      
      const { device } = magData;
      const reqToken = getMagToken(req);
      // Informational endpoint - skip IP lock to allow IP drift
      const validation = validateMagSession(normalizedMac, clientIp, device, reqToken, false, true);
      if (!validation.valid) {
        recordFailedMagAttempt(normalizedMac, clientIp);
        console.log(`[MAG SECURITY] VOD get_categories validation failed: ${validation.error}`);
        return res.json({ js: [] });
      }
      
      const categories = await storage.getCategories();
      const vodCategories = categories.filter(c => c.categoryType === "movie");
      
      const cats = vodCategories.map(cat => ({
        id: cat.id.toString(),
        title: cat.categoryName,
        alias: cat.categoryName.toLowerCase().replace(/\s+/g, "_"),
        active_sub: true,
        censored: 0,
      }));
      
      cats.unshift({
        id: "*",
        title: "All movies",
        alias: "all",
        active_sub: true,
        censored: 0,
      });
      
      return res.json({ js: cats });
    }

    // VOD list
    if (type === "vod" && action === "get_ordered_list") {
      const magData = await getMagDeviceByMac(normalizedMac);
      if (!magData) {
        console.log(`[MAG SECURITY] VOD get_ordered_list - device not found: ${normalizedMac}`);
        return res.json({ js: { total_items: 0, max_page_items: 20, data: [] } });
      }
      
      const { user, device } = magData;
      
      // Security: validate session and token (informational - skip IP lock)
      const reqToken = getMagToken(req);
      const validation = validateMagSession(normalizedMac, clientIp, device, reqToken, false, true);
      if (!validation.valid) {
        recordFailedMagAttempt(normalizedMac, clientIp);
        console.log(`[MAG SECURITY] VOD get_ordered_list validation failed: ${validation.error}`);
        return res.json({ js: { total_items: 0, max_page_items: 20, data: [] } });
      }
      
      const category = req.query.category as string || "*";
      const p = parseInt(req.query.p as string) || 1;
      
      const allStreams = await storage.getStreams();
      const vodStreams = allStreams.filter(s => s.type === 2); // Movies
      
      // Get bouquet IDs from device or user
      const bouquetIds = getMagBouquetIds(device, user);
      
      let filteredStreams = vodStreams;
      
      if (bouquetIds.length > 0) {
        const bouquets = await storage.getBouquets();
        const allowedMovieIds: number[] = [];
        
        for (const bouquetId of bouquetIds) {
          const bouquet = bouquets.find(b => b.id === bouquetId);
          if (bouquet) {
            let movies: number[] = [];
            if (bouquet.bouquetMovies) {
              try {
                movies = typeof bouquet.bouquetMovies === 'string' 
                  ? JSON.parse(bouquet.bouquetMovies) 
                  : bouquet.bouquetMovies;
              } catch {}
            }
            for (const id of movies) {
              if (!allowedMovieIds.includes(id)) {
                allowedMovieIds.push(id);
              }
            }
          }
        }
        
        if (allowedMovieIds.length > 0) {
          filteredStreams = allowedMovieIds
            .map(id => vodStreams.find(s => s.id === id))
            .filter((s): s is NonNullable<typeof s> => s !== undefined);
        }
      }
      
      if (category !== "*") {
        filteredStreams = filteredStreams.filter(s => s.categoryId?.toString() === category);
      }
      
      const pageSize = 20;
      const startIndex = (p - 1) * pageSize;
      const pageStreams = filteredStreams.slice(startIndex, startIndex + pageSize);
      
      const serverHost = req.get("host") || "localhost:5000";
      const protocol = req.protocol || "http";
      
      // For standalone MAG devices, use MAC-based URL
      const loginName = user?.username || device.mac.replace(/:/g, "");
      const loginPass = user?.password || device.mac.replace(/:/g, "");
      
      const data = pageStreams.map(stream => {
        const streamNum = stream.number || stream.id;
        return {
          id: streamNum.toString(),
          name: stream.streamDisplayName || `Movie ${streamNum}`,
          o_name: stream.streamDisplayName || "",
          description: stream.notes || "",
          pic: stream.streamIcon || "",
          time: "01:30:00",
          director: "",
          actors: "",
          year: "",
          censored: 0,
          cmd: `${protocol}://${serverHost}/movie/${loginName}/${loginPass}/${streamNum}.mp4`,
          category_id: stream.categoryId?.toString() || "1",
          hd: 0,
        };
      });
      
      return res.json({
        js: {
          total_items: filteredStreams.length,
          max_page_items: pageSize,
          selected_item: 0,
          cur_page: p,
          data: data,
        }
      });
    }

    // Default response - Portal info page (no type/action means initial load)
    if (!type && !action) {
      console.log(`[MAG] Initial portal load request - returning loader`);
      
      // STB Emu expects an HTML page with JavaScript that loads the portal
      // Use /xmag/c/ as the standard path for MAG devices
      const portalUrl = `${req.protocol}://${req.get("host")}/xmag/c/`;
      const loaderHtml = `<!DOCTYPE html>
<html>
<head>
  <title>X NeoServ Portal</title>
  <meta charset="UTF-8">
  <script type="text/javascript">
    var stb = {
      setAspect: function(){},
      setMode: function(){},
      setWindowSize: function(){},
      setTopWin: function(){},
      setMediaURL: function(){},
      play: function(){},
      Stop: function(){}
    };
    if(typeof gSTB === 'undefined') { var gSTB = stb; }
  </script>
</head>
<body style="background:#000;color:#fff;font-family:Arial;">
  <div style="text-align:center;padding-top:100px;">
    <h1>X NeoServ Portal</h1>
    <p>Loading...</p>
  </div>
  <script>
    // Initialize portal
    var portal_url = "${portalUrl}";
  </script>
</body>
</html>`;
      
      res.setHeader("Content-Type", "text/html; charset=utf-8");
      return res.send(loaderHtml);
    }

    // Unknown action
    return res.json({ js: { error: "Unknown action" } });
  });

  // POST version for compatibility
  app.post(["/xmag/c/", "/xmag/c", "/stalker_portal/c/", "/stalker_portal/c"], async (req, res) => {
    // Debug log for MAG POST requests
    console.log(`[MAG] POST /xmag/c - body:`, req.body, `query:`, req.query);
    
    // Merge body params with query for compatibility
    const allParams = { ...req.query, ...req.body };
    req.query = allParams;
    
    // Forward to GET handler by redirecting the request internally
    const url = new URL(req.originalUrl, `http://${req.get("host")}`);
    Object.keys(allParams).forEach(key => url.searchParams.set(key, allParams[key]));
    
    res.redirect(307, url.pathname + url.search);
  });

  // ============================================
  // SOURCE FILE DOWNLOAD (temporary for updates)
  // ============================================
  const fsModule = await import("fs");
  const pathModule = await import("path");
  
  app.get("/internal/source/:file", async (req, res) => {
    const fileMap: Record<string, string> = {
      "streams": "client/src/pages/streams.tsx",
      "routes": "server/routes.ts",
    };
    
    const filePath = fileMap[req.params.file];
    if (!filePath) {
      return res.status(404).send("File not found");
    }
    
    try {
      const fullPath = pathModule.join(process.cwd(), filePath);
      const content = fsModule.readFileSync(fullPath, "utf-8");
      res.setHeader("Content-Type", "text/plain; charset=utf-8");
      res.send(content);
    } catch (err) {
      res.status(500).send("Error reading file");
    }
  });

  // ============================================
  // AUTOMATIC CONNECTION CLEANUP
  // Runs every 10 seconds to remove stale connections
  // ============================================
  const CONNECTION_TIMEOUT_SECONDS = 60; // Connections older than 60 seconds without activity are removed
  
  setInterval(async () => {
    try {
      const allConnections = await storage.getConnections();
      const now = Math.floor(Date.now() / 1000);
      let cleaned = 0;
      
      for (const conn of allConnections) {
        // Check last activity time (hlsLastRead) or start time
        const lastActivity = conn.hlsLastRead || conn.dateStart || 0;
        const age = now - lastActivity;
        
        if (age > CONNECTION_TIMEOUT_SECONDS) {
          await storage.deleteConnection(conn.activityId);
          cleaned++;
        }
      }
      
      if (cleaned > 0) {
        console.log(`[AUTO-CLEANUP] Removed ${cleaned} stale connections`);
      }
    } catch (error) {
      console.error("[AUTO-CLEANUP] Error:", error);
    }
  }, 10000); // Run every 10 seconds
  
  console.log("[CONNECTIONS] Automatic cleanup enabled (10s interval, 60s timeout)");
}
