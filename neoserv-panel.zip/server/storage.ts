import type {
  RegUser, InsertRegUser,
  User, InsertUser,
  Stream, InsertStream,
  Series, InsertSeries,
  SeriesEpisode, InsertSeriesEpisode,
  StreamCategory, InsertStreamCategory,
  Bouquet, InsertBouquet,
  StreamingServer, InsertStreamingServer,
  Epg, InsertEpg,
  EpgData, InsertEpgData,
  UserActivityNow, InsertUserActivityNow,
  MagDevice, InsertMagDevice,
  PanelLog, InsertPanelLog,
  BlockedIp, InsertBlockedIp,
  BlockedUserAgent, InsertBlockedUserAgent,
  AllowedIp, InsertAllowedIp,
  AdminSetting,
  DashboardStats,
  GeneratedLine,
  StreamStatusResponse,
  InsertStreamsSys,
  License, InsertLicense,
  CreditTransaction, InsertCreditTransaction,
  ServerInstallTask, InsertServerInstallTask,
} from "@shared/schema";

export interface IStorage {
  initialize(): Promise<void>;
  
  // Admins (reg_users)
  getAdmins(): Promise<RegUser[]>;
  getAdmin(id: number): Promise<RegUser | undefined>;
  getAdminByUsername(username: string): Promise<RegUser | undefined>;
  createAdmin(admin: InsertRegUser): Promise<RegUser>;
  updateAdmin(id: number, admin: Partial<InsertRegUser>): Promise<RegUser | undefined>;
  deleteAdmin(id: number): Promise<boolean>;

  // Users
  getUsers(ownerId?: number): Promise<User[]>;
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByCredentials(username: string, password: string): Promise<User | undefined>;
  getStreamByNumber(streamNumber: number, streamType: number): Promise<Stream | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<InsertUser>): Promise<User | undefined>;
  deleteUser(id: number): Promise<boolean>;
  bulkCreateUsers(users: InsertUser[]): Promise<User[]>;
  bulkUpdateUsers(ids: number[], update: Partial<InsertUser>): Promise<number>;
  bulkDeleteUsers(ids: number[]): Promise<number>;
  bulkExtendExpiration(ids: number[], days: number): Promise<number>;
  generateLine(options: { expirationDays: number; maxConnections: number; bouquetIds?: number[]; ownerId?: number; isTrial?: boolean }): Promise<GeneratedLine>;
  killUserConnections(userId: number): Promise<number>;

  // Streams
  getStreams(type?: number): Promise<Stream[]>;
  getStream(id: number): Promise<Stream | undefined>;
  createStream(stream: InsertStream): Promise<Stream>;
  updateStream(id: number, stream: Partial<InsertStream>): Promise<Stream | undefined>;
  deleteStream(id: number): Promise<boolean>;

  // Series
  getSeries(): Promise<Series[]>;
  getSeriesById(id: number): Promise<Series | undefined>;
  createSeries(series: InsertSeries): Promise<Series>;
  updateSeries(id: number, series: Partial<InsertSeries>): Promise<Series | undefined>;
  deleteSeries(id: number): Promise<boolean>;

  // Series Episodes
  getSeriesEpisodes(seriesId?: number): Promise<SeriesEpisode[]>;
  getSeriesEpisode(id: number): Promise<SeriesEpisode | undefined>;
  createSeriesEpisode(episode: InsertSeriesEpisode): Promise<SeriesEpisode>;
  updateSeriesEpisode(id: number, episode: Partial<InsertSeriesEpisode>): Promise<SeriesEpisode | undefined>;
  deleteSeriesEpisode(id: number): Promise<boolean>;

  // Categories
  getCategories(type?: string): Promise<StreamCategory[]>;
  getCategory(id: number): Promise<StreamCategory | undefined>;
  createCategory(category: InsertStreamCategory): Promise<StreamCategory>;
  updateCategory(id: number, category: Partial<InsertStreamCategory>): Promise<StreamCategory | undefined>;
  deleteCategory(id: number): Promise<boolean>;

  // Bouquets
  getBouquets(): Promise<Bouquet[]>;
  getBouquet(id: number): Promise<Bouquet | undefined>;
  createBouquet(bouquet: InsertBouquet): Promise<Bouquet>;
  updateBouquet(id: number, bouquet: Partial<InsertBouquet>): Promise<Bouquet | undefined>;
  deleteBouquet(id: number): Promise<boolean>;

  // Servers
  getServers(): Promise<StreamingServer[]>;
  getServer(id: number): Promise<StreamingServer | undefined>;
  createServer(server: InsertStreamingServer): Promise<StreamingServer>;
  updateServer(id: number, server: Partial<InsertStreamingServer>): Promise<StreamingServer | undefined>;
  deleteServer(id: number): Promise<boolean>;

  // EPG Sources
  getEpgSources(): Promise<Epg[]>;
  getEpgSource(id: number): Promise<Epg | undefined>;
  createEpgSource(epgSource: InsertEpg): Promise<Epg>;
  updateEpgSource(id: number, epgSource: Partial<InsertEpg>): Promise<Epg | undefined>;
  deleteEpgSource(id: number): Promise<boolean>;
  
  // EPG Data (program listings)
  getEpgDataByChannel(channelId: string, startTime?: number, endTime?: number): Promise<EpgData[]>;
  getEpgDataNowPlaying(channelId: string): Promise<EpgData | undefined>;
  getAllEpgData(): Promise<EpgData[]>;
  saveEpgData(data: InsertEpgData[]): Promise<number>;
  clearEpgData(epgId?: number): Promise<number>;

  // Connections
  getConnections(): Promise<UserActivityNow[]>;
  getConnectionsByStream(streamId: number): Promise<UserActivityNow[]>;
  getConnectionsByUser(userId: number): Promise<UserActivityNow[]>;
  countUserConnections(userId: number): Promise<number>;
  getConnection(id: number): Promise<UserActivityNow | undefined>;
  createConnection(connection: InsertUserActivityNow): Promise<UserActivityNow>;
  deleteConnection(id: number): Promise<boolean>;
  killAllConnections(userId?: number): Promise<number>;
  touchConnection(activityId: number): Promise<void>;
  touchConnectionByUserStream(userId: number, streamId: number, serverId?: number, clientIp?: string, userAgent?: string, geoipCountryCode?: string | null): Promise<void>;
  expireStaleConnections(userId: number, maxAgeSeconds?: number): Promise<number>;
  replaceConnectionFromSameIp(userId: number, userIp: string, newStreamId: number): Promise<boolean>;
  replaceOrCreateMagConnection(magMac: string, userId: number, streamId: number, userIp: string, userAgent: string): Promise<void>;

  // MAG Devices
  getMagDevices(): Promise<MagDevice[]>;
  getMagDevice(id: number): Promise<MagDevice | undefined>;
  getMagDeviceByMac(mac: string): Promise<MagDevice | undefined>;
  createMagDevice(device: InsertMagDevice): Promise<MagDevice>;
  updateMagDevice(id: number, device: Partial<InsertMagDevice>): Promise<MagDevice | undefined>;
  deleteMagDevice(id: number): Promise<boolean>;

  // Activity Logs
  getActivityLogs(limit?: number, filters?: { adminId?: number; action?: string }): Promise<PanelLog[]>;
  createActivityLog(log: InsertPanelLog): Promise<PanelLog>;

  // Settings
  getSettings(): Promise<AdminSetting[]>;
  getSetting(key: string): Promise<AdminSetting | undefined>;
  setSetting(key: string, value: string): Promise<AdminSetting>;

  // Blocked IPs (Security)
  getBlockedIps(): Promise<BlockedIp[]>;
  getBlockedIp(id: number): Promise<BlockedIp | undefined>;
  createBlockedIp(ip: InsertBlockedIp): Promise<BlockedIp>;
  deleteBlockedIp(id: number): Promise<boolean>;

  // Blocked User Agents
  getBlockedUserAgents(): Promise<BlockedUserAgent[]>;
  getBlockedUserAgent(id: number): Promise<BlockedUserAgent | undefined>;
  createBlockedUserAgent(ua: InsertBlockedUserAgent): Promise<BlockedUserAgent>;
  deleteBlockedUserAgent(id: number): Promise<boolean>;

  // Allowed IPs (Whitelist)
  getAllowedIps(): Promise<AllowedIp[]>;
  getAllowedIp(id: number): Promise<AllowedIp | undefined>;
  createAllowedIp(ip: InsertAllowedIp): Promise<AllowedIp>;
  deleteAllowedIp(id: number): Promise<boolean>;
  isIpAllowed(ip: string): Promise<boolean>;
  isIpBlocked(ip: string): Promise<boolean>;

  // Stream System Status
  getStreamStatuses(streamIds?: number[]): Promise<StreamStatusResponse[]>;
  getStreamStatus(streamId: number): Promise<StreamStatusResponse | undefined>;
  updateStreamStatus(streamId: number, status: Partial<InsertStreamsSys>): Promise<boolean>;

  // Dashboard
  getDashboardStats(ownerId?: number): Promise<DashboardStats>;

  // Playlist generation
  generatePlaylist(userId: number, format: string, type: string): Promise<string>;
  generateEnigma2Playlist(userId: number): Promise<string>;
  
  // Licenses
  getLicenses(): Promise<License[]>;
  getLicense(id: number): Promise<License | undefined>;
  getLicenseByKey(key: string): Promise<License | undefined>;
  createLicense(license: InsertLicense): Promise<License>;
  updateLicense(id: number, license: Partial<InsertLicense>): Promise<License | undefined>;
  deleteLicense(id: number): Promise<boolean>;
  validateLicense(key: string): Promise<{ valid: boolean; license?: License; error?: string }>;
  getActiveLicense(): Promise<License | undefined>;

  // Auth Tokens (persistent login sessions with IP binding)
  getAuthToken(token: string): Promise<{ adminId: number; adminUsername: string; adminRole: string; expiresAt: number; ipAddress?: string | null } | undefined>;
  createAuthToken(token: string, data: { adminId: number; adminUsername: string; adminRole: string; expiresAt: number; ipAddress?: string }): Promise<void>;
  deleteAuthToken(token: string): Promise<void>;
  deleteExpiredAuthTokens(): Promise<number>;

  // Credit Transactions
  getCreditTransactions(resellerId: number): Promise<CreditTransaction[]>;
  addCreditTransaction(transaction: InsertCreditTransaction): Promise<CreditTransaction>;

  // Server Install Tasks
  getServerInstallTaskByServerId(serverId: number): Promise<ServerInstallTask | undefined>;
  createServerInstallTask(task: InsertServerInstallTask): Promise<ServerInstallTask>;
  updateServerInstallTaskByServerId(serverId: number, data: Partial<InsertServerInstallTask>): Promise<ServerInstallTask | undefined>;

  // Dashboard Analytics
  getNetworkTrafficHistory(minutes?: number): Promise<{ time: string; input: number; output: number }[]>;
  getConnectionsByCountry(): Promise<{ country: string; countryCode: string; count: number; percent: number }[]>;
}

import { dbStorage } from "./dbStorage";
export const storage = dbStorage;
