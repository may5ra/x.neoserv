import { db } from "./db";
import { 
  users, streams, bouquets, streamCategories, series, seriesEpisodes,
  regUsers, streamingServers, magDevices, packages, streamsSys,
  accessOutput, blockedIps, adminSettings, memberGroups, epg, epgData,
  transcodingProfiles, userActivity, subreseller_setup
} from "@shared/schema";
import { sql } from "drizzle-orm";

interface MigrationResult {
  success: boolean;
  tables: {
    name: string;
    imported: number;
    skipped: number;
    errors: string[];
  }[];
  totalImported: number;
  totalErrors: number;
}

interface PreviewResult {
  tables: { name: string; rowCount: number }[];
  warnings?: string[];
  hasBlockingWarnings?: boolean;
}

const KNOWN_COLUMNS: Record<string, string[]> = {
  users: ["id", "member_id", "username", "password", "exp_date", "admin_enabled", "enabled", "admin_notes", "reseller_notes", "bouquet", "max_connections", "is_restreamer", "allowed_ips", "allowed_ua", "is_trial", "created_at", "created_by", "pair_id", "is_mag", "is_e2", "force_server_id", "is_isplock", "as_number", "isp_desc", "forced_country", "is_stalker", "bypass_ua", "play_token"],
  streams: ["id", "type", "category_id", "stream_display_name", "stream_source", "stream_icon", "notes", "created_channel_location", "enable_transcode", "transcode_attributes", "custom_ffmpeg", "movie_propeties", "movie_subtitles", "read_native", "target_container", "stream_all", "remove_subtitles", "custom_sid", "epg_id", "channel_id", "epg_lang", "order", "auto_restart", "transcode_profile_id", "pids_create_channel", "cchannel_rsources", "gen_timestamps", "added", "series_no", "direct_source", "tv_archive_duration", "tv_archive_server_id", "tv_archive_pid", "movie_symlink", "redirect_stream", "rtmp_output", "number", "allow_record", "probesize_ondemand", "custom_map", "external_push", "delay_minutes"],
  stream_categories: ["id", "category_type", "category_name", "parent_id", "cat_order"],
  bouquets: ["id", "bouquet_name", "bouquet_channels", "bouquet_series", "bouquet_order"],
  series: ["id", "title", "category_id", "cover", "cover_big", "genre", "plot", "cast", "rating", "director", "releaseDate", "release_date", "last_modified", "tmdb_id", "seasons", "episode_run_time", "backdrop_path", "youtube_trailer"],
  streaming_servers: ["id", "server_name", "domain_name", "server_ip", "datacenter", "vpn_ip", "ssh_password", "ssh_port", "diff_time_main", "http_broadcast_port", "total_clients", "max_clients", "system_os", "network_interface", "latency", "status", "enable_geoip", "geoip_countries", "last_check_ago", "can_delete", "server_hardware", "total_services", "persistent_connections", "rtmp_port", "geoip_type", "isp_names", "isp_type", "enable_isp", "boost_fpm", "http_ports_add", "network_guaranteed_speed", "https_broadcast_port", "https_ports_add", "network_speed"],
  mag_devices: ["user_id", "mac", "bright", "contrast", "saturation", "aspect", "video_out", "volume", "playback_buffer_bytes", "playback_buffer_size", "audio_out", "ip", "ls", "ver", "lang", "locale", "city_id", "hd", "main_notify", "fav_itv_on", "stb_type", "sn", "country", "created", "last_active", "last_start", "keep_alive"],
  users_packages: ["id", "package_name", "is_trial", "is_official", "trial_credits", "official_credits", "trial_duration", "trial_duration_in", "official_duration", "official_duration_in", "groups", "bouquets", "output_formats", "max_connections", "force_server_id", "forced_country", "lock_device", "is_mag", "is_e2", "is_restreamer", "is_isplock"],
  reg_users: ["id", "username", "password", "email", "ip", "date_registered", "verify_key", "last_login", "member_group_id", "verified", "credits", "notes", "status", "default_lang", "reseller_dns", "owner_id", "override_packages", "google_2fa_sec"],
  epg: ["id", "epg_name", "epg_file", "integrity", "last_updated", "days_keep", "data"],
  transcoding_profiles: ["profile_id", "profile_name", "profile_options"],
  access_output: ["access_output_id", "output_name", "output_key", "output_ext"],
};

export class XUIMigration {
  private sqlContent: string;
  private parsedTables: Map<string, Map<string, any>[]> = new Map();
  private columnOrder: Map<string, string[]> = new Map();
  private warnings: string[] = [];

  constructor(sqlDump: string) {
    this.sqlContent = sqlDump;
  }

  private validateColumns(tableName: string, columns: string[]): string[] {
    const knownCols = KNOWN_COLUMNS[tableName];
    if (!knownCols) return [];
    
    const unknownCols: string[] = [];
    for (const col of columns) {
      if (!knownCols.includes(col)) {
        unknownCols.push(col);
      }
    }
    return unknownCols;
  }

  private parseCreateStatements(): void {
    const createRegex = /CREATE TABLE[^`]*`(\w+)`\s*\(([^;]+?)\)\s*(?:ENGINE|;)/gims;
    let match;

    while ((match = createRegex.exec(this.sqlContent)) !== null) {
      const tableName = match[1];
      const columnsStr = match[2];
      const columns: string[] = [];

      const columnLines = columnsStr.split('\n');
      for (const line of columnLines) {
        const columnMatch = line.match(/^\s*`(\w+)`\s+/);
        if (columnMatch && !line.includes('PRIMARY KEY') && !line.includes('KEY ')) {
          columns.push(columnMatch[1]);
        }
      }

      if (columns.length > 0) {
        this.columnOrder.set(tableName, columns);
      }
    }
  }

  private parseInsertStatements(): void {
    const insertWithColsPattern = /INSERT INTO `(\w+)`\s*\(([^)]+)\)\s*VALUES\s*(.+?)(?=(?:INSERT INTO|DROP TABLE|CREATE TABLE|ALTER TABLE|\/\*|$))/gims;
    const insertWithoutColsPattern = /INSERT INTO `(\w+)`\s+VALUES\s*(.+?)(?=(?:INSERT INTO|DROP TABLE|CREATE TABLE|ALTER TABLE|\/\*|$))/gims;

    let match;
    while ((match = insertWithColsPattern.exec(this.sqlContent)) !== null) {
      const tableName = match[1];
      const columnListStr = match[2];
      const valuesStr = match[3];
      
      const columns = this.parseColumnList(columnListStr);
      const rows = this.parseAllValues(valuesStr);
      
      const unknownCols = this.validateColumns(tableName, columns);
      if (unknownCols.length > 0) {
        this.warnings.push(`${tableName}: unknown columns [${unknownCols.join(', ')}] - rows will be imported but these columns ignored`);
      }
      
      const rowsWithColumns: Record<string, any>[] = [];
      for (let rowIdx = 0; rowIdx < rows.length; rowIdx++) {
        const row = rows[rowIdx];
        if (row.length !== columns.length) {
          this.warnings.push(`${tableName} row ${rowIdx + 1}: column count (${columns.length}) != value count (${row.length}) - SKIPPED`);
          continue;
        }
        const obj: Record<string, any> = {};
        row.forEach((val, idx) => {
          const colName = columns[idx];
          const knownCols = KNOWN_COLUMNS[tableName];
          if (!knownCols || knownCols.includes(colName)) {
            obj[colName] = val;
          }
        });
        rowsWithColumns.push(obj);
      }

      if (this.parsedTables.has(tableName)) {
        this.parsedTables.get(tableName)!.push(...rowsWithColumns);
      } else {
        this.parsedTables.set(tableName, rowsWithColumns);
      }
    }

    while ((match = insertWithoutColsPattern.exec(this.sqlContent)) !== null) {
      const tableName = match[1];
      const valuesStr = match[2];
      
      const rows = this.parseAllValues(valuesStr);
      const columns = this.columnOrder.get(tableName) || [];
      
      const rowsWithColumns: Record<string, any>[] = [];
      for (let rowIdx = 0; rowIdx < rows.length; rowIdx++) {
        const row = rows[rowIdx];
        if (columns.length > 0 && row.length !== columns.length) {
          this.warnings.push(`${tableName} row ${rowIdx + 1}: expected ${columns.length} values, got ${row.length} - SKIPPED`);
          continue;
        }
        if (columns.length === 0 && row.length > 0) {
          this.warnings.push(`${tableName}: no CREATE TABLE found, cannot map ${row.length} columns - SKIPPED`);
          continue;
        }
        const obj: Record<string, any> = {};
        row.forEach((val, idx) => {
          obj[columns[idx]] = val;
        });
        rowsWithColumns.push(obj);
      }

      if (this.parsedTables.has(tableName)) {
        this.parsedTables.get(tableName)!.push(...rowsWithColumns);
      } else {
        this.parsedTables.set(tableName, rowsWithColumns);
      }
    }
  }

  private parseColumnList(columnListStr: string): string[] {
    const columns: string[] = [];
    const columnRegex = /`(\w+)`/g;
    let match;
    while ((match = columnRegex.exec(columnListStr)) !== null) {
      columns.push(match[1]);
    }
    if (columns.length === 0) {
      const bareColumns = columnListStr.split(',').map(s => s.trim().replace(/[`'"]/g, ''));
      return bareColumns.filter(c => c.length > 0);
    }
    return columns;
  }

  private parseAllValues(valuesStr: string): any[][] {
    const rows: any[][] = [];
    let currentRow: any[] = [];
    let inString = false;
    let stringChar = "";
    let escapeNext = false;
    let currentValue = "";
    let depth = 0;
    let i = 0;

    while (i < valuesStr.length) {
      const char = valuesStr[i];
      
      if (escapeNext) {
        if (char === 'n') currentValue += '\n';
        else if (char === 'r') currentValue += '\r';
        else if (char === 't') currentValue += '\t';
        else if (char === '0') currentValue += '\0';
        else currentValue += char;
        escapeNext = false;
        i++;
        continue;
      }

      if (char === '\\' && inString) {
        escapeNext = true;
        i++;
        continue;
      }

      if ((char === "'" || char === '"') && !inString) {
        inString = true;
        stringChar = char;
        i++;
        continue;
      }

      if (char === stringChar && inString) {
        if (valuesStr[i + 1] === stringChar) {
          currentValue += stringChar;
          i += 2;
          continue;
        }
        inString = false;
        stringChar = "";
        i++;
        continue;
      }

      if (inString) {
        currentValue += char;
        i++;
        continue;
      }

      if (char === '(') {
        depth++;
        if (depth === 1) {
          currentRow = [];
          currentValue = "";
        }
        i++;
        continue;
      }

      if (char === ')') {
        depth--;
        if (depth === 0) {
          const trimmed = currentValue.trim();
          if (trimmed !== "" || currentRow.length > 0) {
            currentRow.push(this.parseValue(trimmed));
          }
          if (currentRow.length > 0) {
            rows.push([...currentRow]);
          }
          currentRow = [];
          currentValue = "";
        }
        i++;
        continue;
      }

      if (char === ',' && depth === 1) {
        currentRow.push(this.parseValue(currentValue.trim()));
        currentValue = "";
        i++;
        continue;
      }

      if (depth >= 1 && !/[\r\n\t]/.test(char)) {
        currentValue += char;
      }
      i++;
    }

    return rows;
  }

  private parseValue(value: string): any {
    if (value === "NULL" || value === "" || value === "''") {
      if (value === "''") return "";
      return null;
    }
    
    if (/^-?\d+$/.test(value)) return parseInt(value, 10);
    if (/^-?\d+\.\d+$/.test(value)) return parseFloat(value);
    
    return value;
  }

  private getTableData(tableName: string): Map<string, any>[] {
    return this.parsedTables.get(tableName) || [];
  }

  private safeGet(row: Map<string, any>, key: string, defaultVal: any = null): any {
    const val = (row as any)[key];
    return val !== undefined ? val : defaultVal;
  }

  async migrate(): Promise<MigrationResult> {
    const result: MigrationResult = {
      success: true,
      tables: [],
      totalImported: 0,
      totalErrors: 0,
    };

    this.parseCreateStatements();
    this.parseInsertStatements();

    await this.migrateAccessOutput(result);
    await this.migrateCategories(result);
    await this.migrateBouquets(result);
    await this.migrateUsers(result);
    await this.migrateStreams(result);
    await this.migrateSeries(result);
    await this.migrateServers(result);
    await this.migrateMagDevices(result);
    await this.migratePackages(result);
    await this.migrateRegUsers(result);
    await this.migrateEpg(result);
    await this.migrateTranscodingProfiles(result);

    result.success = result.totalErrors === 0;
    return result;
  }

  private async migrateAccessOutput(result: MigrationResult): Promise<void> {
    const tableResult = { name: "access_output", imported: 0, skipped: 0, errors: [] as string[] };
    const rows = this.getTableData("access_output");

    for (const row of rows) {
      try {
        await db.insert(accessOutput).values({
          accessOutputId: this.safeGet(row, "access_output_id"),
          outputName: this.safeGet(row, "output_name", ""),
          outputKey: this.safeGet(row, "output_key", ""),
          outputExt: this.safeGet(row, "output_ext", ""),
        }).onConflictDoNothing();
        tableResult.imported++;
      } catch (e: any) {
        tableResult.errors.push(`access_output: ${e.message}`);
        tableResult.skipped++;
      }
    }

    result.tables.push(tableResult);
    result.totalImported += tableResult.imported;
    result.totalErrors += tableResult.errors.length;
  }

  private async migrateCategories(result: MigrationResult): Promise<void> {
    const tableResult = { name: "stream_categories", imported: 0, skipped: 0, errors: [] as string[] };
    const rows = this.getTableData("stream_categories");

    for (const row of rows) {
      try {
        await db.insert(streamCategories).values({
          id: this.safeGet(row, "id"),
          categoryType: this.safeGet(row, "category_type", "live"),
          categoryName: this.safeGet(row, "category_name", "Unknown"),
          parentId: this.safeGet(row, "parent_id", 0),
          catOrder: this.safeGet(row, "cat_order", 0),
        }).onConflictDoNothing();
        tableResult.imported++;
      } catch (e: any) {
        tableResult.errors.push(`stream_categories: ${e.message}`);
        tableResult.skipped++;
      }
    }

    result.tables.push(tableResult);
    result.totalImported += tableResult.imported;
    result.totalErrors += tableResult.errors.length;
  }

  private async migrateBouquets(result: MigrationResult): Promise<void> {
    const tableResult = { name: "bouquets", imported: 0, skipped: 0, errors: [] as string[] };
    const rows = this.getTableData("bouquets");

    for (const row of rows) {
      try {
        await db.insert(bouquets).values({
          id: this.safeGet(row, "id"),
          bouquetName: this.safeGet(row, "bouquet_name", "Unnamed"),
          bouquetChannels: this.safeGet(row, "bouquet_channels", "[]"),
          bouquetSeries: this.safeGet(row, "bouquet_series", "[]"),
          bouquetOrder: this.safeGet(row, "bouquet_order", 0),
          bouquetStreams: "[]",
          bouquetRadios: "[]",
          bouquetMovies: "[]",
        }).onConflictDoNothing();
        tableResult.imported++;
      } catch (e: any) {
        tableResult.errors.push(`bouquets: ${e.message}`);
        tableResult.skipped++;
      }
    }

    result.tables.push(tableResult);
    result.totalImported += tableResult.imported;
    result.totalErrors += tableResult.errors.length;
  }

  private async migrateUsers(result: MigrationResult): Promise<void> {
    const tableResult = { name: "users", imported: 0, skipped: 0, errors: [] as string[] };
    const rows = this.getTableData("users");

    for (const row of rows) {
      try {
        await db.insert(users).values({
          id: this.safeGet(row, "id"),
          memberId: this.safeGet(row, "member_id"),
          username: this.safeGet(row, "username", ""),
          password: this.safeGet(row, "password", ""),
          expDate: this.safeGet(row, "exp_date"),
          adminEnabled: this.safeGet(row, "admin_enabled", 1),
          enabled: this.safeGet(row, "enabled", 1),
          adminNotes: this.safeGet(row, "admin_notes", ""),
          resellerNotes: this.safeGet(row, "reseller_notes", ""),
          bouquet: this.safeGet(row, "bouquet", "[]"),
          maxConnections: this.safeGet(row, "max_connections", 1),
          isRestreamer: this.safeGet(row, "is_restreamer", 0),
          allowedIps: this.safeGet(row, "allowed_ips", ""),
          allowedUa: this.safeGet(row, "allowed_ua", ""),
          isTrial: this.safeGet(row, "is_trial", 0),
          createdAt: this.safeGet(row, "created_at") || Math.floor(Date.now() / 1000),
          createdBy: this.safeGet(row, "created_by", 0),
          pairId: this.safeGet(row, "pair_id"),
          isMag: this.safeGet(row, "is_mag", 0),
          isE2: this.safeGet(row, "is_e2", 0),
          forceServerId: this.safeGet(row, "force_server_id", 0),
          isIsplock: this.safeGet(row, "is_isplock", 0),
          asNumber: this.safeGet(row, "as_number"),
          ispDesc: this.safeGet(row, "isp_desc"),
          forcedCountry: this.safeGet(row, "forced_country", ""),
          isStalker: this.safeGet(row, "is_stalker", 0),
          bypassUa: this.safeGet(row, "bypass_ua", 0),
          playToken: this.safeGet(row, "play_token", ""),
          userIpVisak: 0,
          paid: "",
          userIp2: 0,
          bouquetPackeg: "",
          packageName: "",
          test: 0,
          noRestreamCh: "[]",
          restreamCh: "[]",
          providerDomain: "",
        }).onConflictDoNothing();
        tableResult.imported++;
      } catch (e: any) {
        tableResult.errors.push(`users id=${this.safeGet(row, "id")}: ${e.message}`);
        tableResult.skipped++;
      }
    }

    result.tables.push(tableResult);
    result.totalImported += tableResult.imported;
    result.totalErrors += tableResult.errors.length;
  }

  private async migrateStreams(result: MigrationResult): Promise<void> {
    const tableResult = { name: "streams", imported: 0, skipped: 0, errors: [] as string[] };
    const rows = this.getTableData("streams");

    for (const row of rows) {
      try {
        await db.insert(streams).values({
          id: this.safeGet(row, "id"),
          type: this.safeGet(row, "type", 1),
          categoryId: this.safeGet(row, "category_id"),
          streamDisplayName: this.safeGet(row, "stream_display_name", "Unnamed"),
          streamSource: this.safeGet(row, "stream_source", ""),
          streamIcon: this.safeGet(row, "stream_icon", ""),
          notes: this.safeGet(row, "notes"),
          createdChannelLocation: this.safeGet(row, "created_channel_location"),
          enableTranscode: this.safeGet(row, "enable_transcode", 0),
          transcodeAttributes: this.safeGet(row, "transcode_attributes", ""),
          customFfmpeg: this.safeGet(row, "custom_ffmpeg", ""),
          moviePropeties: this.safeGet(row, "movie_propeties"),
          movieSubtitles: this.safeGet(row, "movie_subtitles", ""),
          readNative: this.safeGet(row, "read_native", 1),
          targetContainer: this.safeGet(row, "target_container"),
          streamAll: this.safeGet(row, "stream_all", 0),
          removeSubtitles: this.safeGet(row, "remove_subtitles", 0),
          customSid: this.safeGet(row, "custom_sid"),
          epgId: this.safeGet(row, "epg_id"),
          channelId: this.safeGet(row, "channel_id"),
          epgLang: this.safeGet(row, "epg_lang"),
          order: this.safeGet(row, "order", 0),
          autoRestart: this.safeGet(row, "auto_restart", "{}"),
          transcodeProfileId: this.safeGet(row, "transcode_profile_id", 0),
          pidsCreateChannel: this.safeGet(row, "pids_create_channel", ""),
          cchannelRsources: this.safeGet(row, "cchannel_rsources", ""),
          genTimestamps: this.safeGet(row, "gen_timestamps", 1),
          added: this.safeGet(row, "added") || Math.floor(Date.now() / 1000),
          seriesNo: this.safeGet(row, "series_no", 0),
          directSource: this.safeGet(row, "direct_source", 0),
          tvArchiveDuration: this.safeGet(row, "tv_archive_duration", 0),
          tvArchiveServerId: this.safeGet(row, "tv_archive_server_id", 0),
          tvArchivePid: this.safeGet(row, "tv_archive_pid", 0),
          movieSymlink: this.safeGet(row, "movie_symlink", 0),
          redirectStream: this.safeGet(row, "redirect_stream", 0),
          rtmpOutput: this.safeGet(row, "rtmp_output", 0),
          number: this.safeGet(row, "number", 0),
          allowRecord: this.safeGet(row, "allow_record", 0),
          probesizeOndemand: this.safeGet(row, "probesize_ondemand", 512000),
          customMap: this.safeGet(row, "custom_map", ""),
          externalPush: this.safeGet(row, "external_push", ""),
          delayMinutes: this.safeGet(row, "delay_minutes", 0),
          noRestreamUsers: "",
          allowRestreamUsers: "",
        }).onConflictDoNothing();
        tableResult.imported++;
      } catch (e: any) {
        tableResult.errors.push(`streams id=${this.safeGet(row, "id")}: ${e.message}`);
        tableResult.skipped++;
      }
    }

    result.tables.push(tableResult);
    result.totalImported += tableResult.imported;
    result.totalErrors += tableResult.errors.length;
  }

  private async migrateSeries(result: MigrationResult): Promise<void> {
    const tableResult = { name: "series", imported: 0, skipped: 0, errors: [] as string[] };
    const rows = this.getTableData("series");

    for (const row of rows) {
      try {
        await db.insert(series).values({
          id: this.safeGet(row, "id"),
          title: this.safeGet(row, "title", "Untitled"),
          categoryId: this.safeGet(row, "category_id"),
          cover: this.safeGet(row, "cover", ""),
          coverBig: this.safeGet(row, "cover_big", ""),
          genre: this.safeGet(row, "genre", ""),
          plot: this.safeGet(row, "plot", ""),
          cast: this.safeGet(row, "cast", ""),
          rating: this.safeGet(row, "rating", 0),
          director: this.safeGet(row, "director", ""),
          releaseDate: this.safeGet(row, "releaseDate", ""),
          lastModified: this.safeGet(row, "last_modified") || Math.floor(Date.now() / 1000),
          tmdbId: this.safeGet(row, "tmdb_id", 0),
          seasons: this.safeGet(row, "seasons", ""),
          episodeRunTime: this.safeGet(row, "episode_run_time", 0),
          backdropPath: this.safeGet(row, "backdrop_path", ""),
          youtubeTrailer: this.safeGet(row, "youtube_trailer", ""),
        }).onConflictDoNothing();
        tableResult.imported++;
      } catch (e: any) {
        tableResult.errors.push(`series id=${this.safeGet(row, "id")}: ${e.message}`);
        tableResult.skipped++;
      }
    }

    result.tables.push(tableResult);
    result.totalImported += tableResult.imported;
    result.totalErrors += tableResult.errors.length;
  }

  private async migrateServers(result: MigrationResult): Promise<void> {
    const tableResult = { name: "streaming_servers", imported: 0, skipped: 0, errors: [] as string[] };
    const rows = this.getTableData("streaming_servers");

    for (const row of rows) {
      try {
        await db.insert(streamingServers).values({
          id: this.safeGet(row, "id"),
          serverName: this.safeGet(row, "server_name", "Server"),
          domainName: this.safeGet(row, "domain_name", ""),
          serverIp: this.safeGet(row, "server_ip"),
          datacenter: this.safeGet(row, "datacenter"),
          vpnIp: this.safeGet(row, "vpn_ip", ""),
          sshPassword: this.safeGet(row, "ssh_password"),
          sshPort: this.safeGet(row, "ssh_port"),
          diffTimeMain: this.safeGet(row, "diff_time_main", 0),
          httpBroadcastPort: this.safeGet(row, "http_broadcast_port", 8080),
          totalClients: this.safeGet(row, "total_clients", 0),
          maxClients: this.safeGet(row, "max_clients", 1000),
          systemOs: this.safeGet(row, "system_os"),
          networkInterface: this.safeGet(row, "network_interface", ""),
          latency: this.safeGet(row, "latency", 0),
          status: this.safeGet(row, "status", -1),
          enableGeoip: this.safeGet(row, "enable_geoip", 0),
          geoipCountries: this.safeGet(row, "geoip_countries", ""),
          lastCheckAgo: this.safeGet(row, "last_check_ago", 0),
          canDelete: this.safeGet(row, "can_delete", 1),
          serverHardware: this.safeGet(row, "server_hardware", ""),
          totalServices: this.safeGet(row, "total_services", 3),
          persistentConnections: this.safeGet(row, "persistent_connections", 0),
          rtmpPort: this.safeGet(row, "rtmp_port", 8001),
          geoipType: this.safeGet(row, "geoip_type", "low_priority"),
          ispNames: this.safeGet(row, "isp_names", ""),
          ispType: this.safeGet(row, "isp_type", "low_priority"),
          enableIsp: this.safeGet(row, "enable_isp", 0),
          boostFpm: this.safeGet(row, "boost_fpm", 0),
          httpPortsAdd: this.safeGet(row, "http_ports_add", ""),
          networkGuaranteedSpeed: this.safeGet(row, "network_guaranteed_speed", 0),
          httpsBroadcastPort: this.safeGet(row, "https_broadcast_port", 25463),
          httpsPortsAdd: this.safeGet(row, "https_ports_add", ""),
          networkSpeed: this.safeGet(row, "network_speed", 1000),
        }).onConflictDoNothing();
        tableResult.imported++;
      } catch (e: any) {
        tableResult.errors.push(`streaming_servers: ${e.message}`);
        tableResult.skipped++;
      }
    }

    result.tables.push(tableResult);
    result.totalImported += tableResult.imported;
    result.totalErrors += tableResult.errors.length;
  }

  private async migrateMagDevices(result: MigrationResult): Promise<void> {
    const tableResult = { name: "mag_devices", imported: 0, skipped: 0, errors: [] as string[] };
    const rows = this.getTableData("mag_devices");

    for (const row of rows) {
      try {
        await db.insert(magDevices).values({
          userId: this.safeGet(row, "user_id", 0),
          mac: this.safeGet(row, "mac", ""),
          bright: this.safeGet(row, "bright", 200),
          contrast: this.safeGet(row, "contrast", 127),
          saturation: this.safeGet(row, "saturation", 127),
          aspect: this.safeGet(row, "aspect", ""),
          videoOut: this.safeGet(row, "video_out", "rca"),
          volume: this.safeGet(row, "volume", 50),
          playbackBufferBytes: this.safeGet(row, "playback_buffer_bytes", 0),
          playbackBufferSize: this.safeGet(row, "playback_buffer_size", 0),
          audioOut: this.safeGet(row, "audio_out", 1),
          ip: this.safeGet(row, "ip"),
          ls: this.safeGet(row, "ls"),
          ver: this.safeGet(row, "ver"),
          lang: this.safeGet(row, "lang"),
          locale: this.safeGet(row, "locale", "en_GB.utf8"),
          cityId: this.safeGet(row, "city_id", 0),
          hd: this.safeGet(row, "hd", 1),
          mainNotify: this.safeGet(row, "main_notify", 1),
          favItvOn: this.safeGet(row, "fav_itv_on", 0),
          stbType: this.safeGet(row, "stb_type", ""),
          sn: this.safeGet(row, "sn"),
          country: this.safeGet(row, "country"),
          created: this.safeGet(row, "created") || Math.floor(Date.now() / 1000),
          lastActive: this.safeGet(row, "last_active"),
          lastStart: this.safeGet(row, "last_start"),
          keepAlive: this.safeGet(row, "keep_alive"),
        }).onConflictDoNothing();
        tableResult.imported++;
      } catch (e: any) {
        tableResult.errors.push(`mag_devices: ${e.message}`);
        tableResult.skipped++;
      }
    }

    result.tables.push(tableResult);
    result.totalImported += tableResult.imported;
    result.totalErrors += tableResult.errors.length;
  }

  private async migratePackages(result: MigrationResult): Promise<void> {
    const tableResult = { name: "packages", imported: 0, skipped: 0, errors: [] as string[] };
    const rows = this.getTableData("users_packages");

    for (const row of rows) {
      try {
        await db.insert(packages).values({
          id: this.safeGet(row, "id"),
          packageName: this.safeGet(row, "package_name", "Package"),
          isTrial: this.safeGet(row, "is_trial", 0),
          isOfficial: this.safeGet(row, "is_official", 0),
          trialCredits: this.safeGet(row, "trial_credits", 0),
          officialCredits: this.safeGet(row, "official_credits", 0),
          trialDuration: this.safeGet(row, "trial_duration", 0),
          trialDurationIn: this.safeGet(row, "trial_duration_in", "days"),
          officialDuration: this.safeGet(row, "official_duration", 0),
          officialDurationIn: this.safeGet(row, "official_duration_in", "days"),
          groups: this.safeGet(row, "groups", ""),
          bouquets: this.safeGet(row, "bouquets", ""),
          outputFormats: this.safeGet(row, "output_formats", ""),
          maxConnections: this.safeGet(row, "max_connections", 1),
          forceServerId: this.safeGet(row, "force_server_id", 0),
          forcedCountry: this.safeGet(row, "forced_country", ""),
          lockDevice: this.safeGet(row, "lock_device", 0),
          canGenMag: this.safeGet(row, "is_mag", 0),
          canGenE2: this.safeGet(row, "is_e2", 0),
          isRestreamer: this.safeGet(row, "is_restreamer", 0),
          isIsplock: this.safeGet(row, "is_isplock", 0),
        }).onConflictDoNothing();
        tableResult.imported++;
      } catch (e: any) {
        tableResult.errors.push(`packages: ${e.message}`);
        tableResult.skipped++;
      }
    }

    result.tables.push(tableResult);
    result.totalImported += tableResult.imported;
    result.totalErrors += tableResult.errors.length;
  }

  private async migrateRegUsers(result: MigrationResult): Promise<void> {
    const tableResult = { name: "reg_users", imported: 0, skipped: 0, errors: [] as string[] };
    const rows = this.getTableData("reg_users");

    for (const row of rows) {
      try {
        await db.insert(regUsers).values({
          id: this.safeGet(row, "id"),
          username: this.safeGet(row, "username", ""),
          password: this.safeGet(row, "password", ""),
          email: this.safeGet(row, "email", ""),
          ip: this.safeGet(row, "ip"),
          dateRegistered: this.safeGet(row, "date_registered") || Math.floor(Date.now() / 1000),
          verifyKey: this.safeGet(row, "verify_key"),
          lastLogin: this.safeGet(row, "last_login"),
          memberGroupId: this.safeGet(row, "member_group_id", 1),
          verified: this.safeGet(row, "verified", 0),
          credits: this.safeGet(row, "credits", 0),
          notes: this.safeGet(row, "notes"),
          status: this.safeGet(row, "status", 1),
          defaultLang: this.safeGet(row, "default_lang", "en"),
          resellerDns: this.safeGet(row, "reseller_dns", ""),
          ownerId: this.safeGet(row, "owner_id", 0),
          overridePackages: this.safeGet(row, "override_packages"),
          google2faSec: this.safeGet(row, "google_2fa_sec", ""),
          darkMode: 3,
          sidebar: 0,
          expandedSidebar: 0,
          topbarTheme: "",
          navigationTheme: "",
          navigationTextColor: "",
          navigationMode: 1,
          navigationCenter: 0,
          navigationMethode: 0,
          dropbox: "",
        }).onConflictDoNothing();
        tableResult.imported++;
      } catch (e: any) {
        tableResult.errors.push(`reg_users: ${e.message}`);
        tableResult.skipped++;
      }
    }

    result.tables.push(tableResult);
    result.totalImported += tableResult.imported;
    result.totalErrors += tableResult.errors.length;
  }

  private async migrateEpg(result: MigrationResult): Promise<void> {
    const tableResult = { name: "epg", imported: 0, skipped: 0, errors: [] as string[] };
    const rows = this.getTableData("epg");

    for (const row of rows) {
      try {
        await db.insert(epg).values({
          id: this.safeGet(row, "id"),
          epgName: this.safeGet(row, "epg_name", ""),
          epgFile: this.safeGet(row, "epg_file", ""),
          integrity: this.safeGet(row, "integrity"),
          lastUpdated: this.safeGet(row, "last_updated"),
          daysKeep: this.safeGet(row, "days_keep", 7),
          data: this.safeGet(row, "data", ""),
        }).onConflictDoNothing();
        tableResult.imported++;
      } catch (e: any) {
        tableResult.errors.push(`epg: ${e.message}`);
        tableResult.skipped++;
      }
    }

    result.tables.push(tableResult);
    result.totalImported += tableResult.imported;
    result.totalErrors += tableResult.errors.length;
  }

  private async migrateTranscodingProfiles(result: MigrationResult): Promise<void> {
    const tableResult = { name: "transcoding_profiles", imported: 0, skipped: 0, errors: [] as string[] };
    const rows = this.getTableData("transcoding_profiles");

    for (const row of rows) {
      try {
        await db.insert(transcodingProfiles).values({
          profileId: this.safeGet(row, "profile_id"),
          profileName: this.safeGet(row, "profile_name", "Profile"),
          profileOptions: this.safeGet(row, "profile_options", "{}"),
        }).onConflictDoNothing();
        tableResult.imported++;
      } catch (e: any) {
        tableResult.errors.push(`transcoding_profiles: ${e.message}`);
        tableResult.skipped++;
      }
    }

    result.tables.push(tableResult);
    result.totalImported += tableResult.imported;
    result.totalErrors += tableResult.errors.length;
  }

  getWarnings(): string[] {
    return this.warnings;
  }

  async getPreview(): Promise<PreviewResult> {
    this.parseCreateStatements();
    this.parseInsertStatements();
    
    const tables: { name: string; rowCount: number }[] = [];
    const importantTables = [
      "users", "streams", "bouquets", "stream_categories", "series",
      "streaming_servers", "mag_devices", "users_packages", "reg_users",
      "epg", "transcoding_profiles", "access_output"
    ];

    for (const tableName of importantTables) {
      const rows = this.parsedTables.get(tableName) || [];
      if (rows.length > 0) {
        tables.push({ name: tableName, rowCount: rows.length });
      }
    }

    const hasBlockingWarnings = this.warnings.some(w => 
      w.includes('SKIPPED') || w.includes('unknown columns')
    );

    return { 
      tables, 
      warnings: this.warnings.length > 0 ? this.warnings.slice(0, 20) : undefined,
      hasBlockingWarnings
    };
  }
}

export async function processXUIMigration(sqlDump: string, preview: boolean = false, force: boolean = false): Promise<PreviewResult | MigrationResult> {
  const migration = new XUIMigration(sqlDump);
  
  if (preview) {
    return migration.getPreview();
  }
  
  const previewResult = await migration.getPreview();
  if (previewResult.hasBlockingWarnings && !force) {
    return {
      success: false,
      tables: [],
      totalImported: 0,
      totalErrors: 1,
      error: "Migration blocked due to warnings. Use 'Force Import' to proceed anyway, or fix the SQL dump.",
      warnings: previewResult.warnings
    } as MigrationResult & { error: string; warnings?: string[] };
  }
  
  return migration.migrate();
}
